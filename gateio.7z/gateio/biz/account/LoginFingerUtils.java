package com.gateio.biz.account;

import android.app.Activity;
import android.text.TextUtils;
import androidx.fragment.app.FragmentManager;
import com.gate.login.R;
import com.gate.login.dialog.SafeSecurityVerificationFragment;
import com.gateio.biz.account.service.router.AccountApiProvider;
import com.gateio.biz.base.router.RouterConst;
import com.gateio.biz.safe.fido.GTCheckFingerPrintCallback;
import com.gateio.biz.safe.fido.GTCipherHelper;
import com.gateio.biz.safe.fido.GTFingerPrintHelper;
import com.gateio.biz.safe.fido2.event.EventValue;
import com.gateio.biz.safe.http.SafeHttpMethodsV3;
import com.gateio.biz.safe.service.router.provider.FingerPrintConfirm;
import com.gateio.biz.safe.service.router.provider.SafeApi;
import com.gateio.biz.safe.service.router.provider.SafePasswordType;
import com.gateio.biz.safe.service.router.provider.SafeUsageType;
import com.gateio.comlib.utils.ToastType;
import com.gateio.comlib.utils.ToastUtils;
import com.gateio.common.listener.ISuccessCallBack;
import com.gateio.gateio.entity.SafeQridEntity;
import com.gateio.http.entity.HttpResultV2;
import com.gateio.lib.router.GTRouter;
import com.gateio.lib.thread.coroutine.GTGlobalIOCoroutine;
import com.gateio.rxjava.CustomObserver;
import com.gateio.rxjava.SchedulerConfig;
import java.util.List;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Ref;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.MainCoroutineDispatcher;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: LoginFingerUtils.kt */
@Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002JD\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\f2\u001a\u0010\r\u001a\u0016\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\u000f\u0012\u0004\u0012\u00020\u00040\u000eJT\u0010\u0010\u001a\u00020\n2\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00142\u001a\u0010\r\u001a\u0016\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\u000f\u0012\u0004\u0012\u00020\u00040\u000e2\u0006\u0010\u0015\u001a\u00020\f2\u0006\u0010\u0016\u001a\u00020\nH\u0002JL\u0010\u0017\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\f2\u001a\u0010\r\u001a\u0016\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\u000f\u0012\u0004\u0012\u00020\u00040\u000eH\u0002J2\u0010\u0018\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u001a\u0010\r\u001a\u0016\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\u000f\u0012\u0004\u0012\u00020\u00040\u000eJ<\u0010\u0019\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\u0011\u001a\u00020\u00122\u001a\u0010\r\u001a\u0016\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\u000f\u0012\u0004\u0012\u00020\u00040\u000eH\u0002JD\u0010\u001a\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\u0011\u001a\u00020\u00122\u001a\u0010\r\u001a\u0016\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\u000f\u0012\u0004\u0012\u00020\u00040\u000e2\u0006\u0010\u001b\u001a\u00020\u001cH\u0002JF\u0010\u001d\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\u0011\u001a\u00020\u00122\u001a\u0010\r\u001a\u0016\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\u000f\u0012\u0004\u0012\u00020\u00040\u000e2\b\u0010\u0015\u001a\u0004\u0018\u00010\fH\u0002J.\u0010\u001e\u001a\u00020\u00042\u001a\u0010\r\u001a\u0016\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\u000f\u0012\u0004\u0012\u00020\u00040\u000e2\b\u0010\u001f\u001a\u0004\u0018\u00010\fH\u0002J>\u0010 \u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u00122\u001a\u0010\r\u001a\u0016\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\u000f\u0012\u0004\u0012\u00020\u00040\u000e2\b\u0010\u001f\u001a\u0004\u0018\u00010\fH\u0002JL\u0010!\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\u0011\u001a\u00020\u00122\u001a\u0010\r\u001a\u0016\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\u000f\u0012\u0004\u0012\u00020\u00040\u000e2\u0006\u0010\t\u001a\u00020\n2\b\u0010\"\u001a\u0004\u0018\u00010\f¨\u0006#"}, d2 = {"Lcom/gateio/biz/account/LoginFingerUtils;", "", "()V", "changeBiometryLoginSwitch", "", "activity", "Landroid/app/Activity;", "fragmentManager", "Landroidx/fragment/app/FragmentManager;", "open", "", "password", "", "callback", "Lkotlin/Function1;", "Lkotlin/Result;", "checkFingerPrint", "safeApi", "Lcom/gateio/biz/safe/service/router/provider/SafeApi;", "usageType", "Lcom/gateio/biz/safe/service/router/provider/SafeUsageType;", "loginPass", "isDelete", "deleteFidoDevice", "getBiologyLoginSwitch", "getFidoDevice", "getFidoDeviceSuccess", "p0", "Lcom/gateio/gateio/entity/SafeQridEntity;", "postFidoDevice", "postFidoDeviceConfirm", EventValue.STRATEGY_QRID, "showFingerPrint", "showLoginPass", "message", "biz_account_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class LoginFingerUtils {

    /* compiled from: LoginFingerUtils.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.account.LoginFingerUtils$getFidoDeviceSuccess$1", f = "LoginFingerUtils.kt", i = {}, l = {137, 145}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.account.LoginFingerUtils$getFidoDeviceSuccess$1, reason: invalid class name and case insensitive filesystem */
    static final class C17781 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Activity $activity;
        final /* synthetic */ Function1<Result<Boolean>, Unit> $callback;
        final /* synthetic */ FragmentManager $fragmentManager;
        final /* synthetic */ Ref.BooleanRef $isOpen;
        final /* synthetic */ SafeApi $safeApi;
        int label;
        final /* synthetic */ LoginFingerUtils this$0;

        /* compiled from: LoginFingerUtils.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
        @DebugMetadata(c = "com.gateio.biz.account.LoginFingerUtils$getFidoDeviceSuccess$1$1", f = "LoginFingerUtils.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
        /* renamed from: com.gateio.biz.account.LoginFingerUtils$getFidoDeviceSuccess$1$1, reason: invalid class name and collision with other inner class name */
        static final class C01191 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ Function1<Result<Boolean>, Unit> $callback;
            final /* synthetic */ boolean $checkResult;
            int label;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            C01191(Function1<? super Result<Boolean>, Unit> function1, boolean z10, Continuation<? super C01191> continuation) {
                super(2, continuation);
                this.$callback = function1;
                this.$checkResult = z10;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            @NotNull
            public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
                return new C01191(this.$callback, this.$checkResult, continuation);
            }

            @Override // kotlin.jvm.functions.Function2
            @Nullable
            /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
            public final Object mo2invoke(@NotNull CoroutineScope coroutineScope, @Nullable Continuation<? super Unit> continuation) {
                return ((C01191) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            @Nullable
            public final Object invokeSuspend(@NotNull Object obj) {
                IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                if (this.label == 0) {
                    ResultKt.throwOnFailure(obj);
                    Function1<Result<Boolean>, Unit> function1 = this.$callback;
                    Result.Companion companion = Result.INSTANCE;
                    function1.invoke(Result.m4829boximpl(Result.m4830constructorimpl(Boxing.boxBoolean(this.$checkResult))));
                    return Unit.INSTANCE;
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }

        /* compiled from: LoginFingerUtils.kt */
        @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
        @DebugMetadata(c = "com.gateio.biz.account.LoginFingerUtils$getFidoDeviceSuccess$1$2", f = "LoginFingerUtils.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
        /* renamed from: com.gateio.biz.account.LoginFingerUtils$getFidoDeviceSuccess$1$2, reason: invalid class name */
        static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ Function1<Result<Boolean>, Unit> $callback;
            int label;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            AnonymousClass2(Function1<? super Result<Boolean>, Unit> function1, Continuation<? super AnonymousClass2> continuation) {
                super(2, continuation);
                this.$callback = function1;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            @NotNull
            public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
                return new AnonymousClass2(this.$callback, continuation);
            }

            @Override // kotlin.jvm.functions.Function2
            @Nullable
            /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
            public final Object mo2invoke(@NotNull CoroutineScope coroutineScope, @Nullable Continuation<? super Unit> continuation) {
                return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            @Nullable
            public final Object invokeSuspend(@NotNull Object obj) {
                IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                if (this.label == 0) {
                    ResultKt.throwOnFailure(obj);
                    Function1<Result<Boolean>, Unit> function1 = this.$callback;
                    Result.Companion companion = Result.INSTANCE;
                    function1.invoke(Result.m4829boximpl(Result.m4830constructorimpl(Boxing.boxBoolean(false))));
                    return Unit.INSTANCE;
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        C17781(Ref.BooleanRef booleanRef, LoginFingerUtils loginFingerUtils, Activity activity, FragmentManager fragmentManager, SafeApi safeApi, Function1<? super Result<Boolean>, Unit> function1, Continuation<? super C17781> continuation) {
            super(2, continuation);
            this.$isOpen = booleanRef;
            this.this$0 = loginFingerUtils;
            this.$activity = activity;
            this.$fragmentManager = fragmentManager;
            this.$safeApi = safeApi;
            this.$callback = function1;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            return new C17781(this.$isOpen, this.this$0, this.$activity, this.$fragmentManager, this.$safeApi, this.$callback, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull CoroutineScope coroutineScope, @Nullable Continuation<? super Unit> continuation) {
            return ((C17781) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1 && i10 != 2) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                if (this.$isOpen.element) {
                    boolean zCheckFingerPrint = this.this$0.checkFingerPrint(this.$activity, this.$fragmentManager, this.$safeApi, SafeUsageType.ALL, this.$callback, "", false);
                    MainCoroutineDispatcher main = Dispatchers.getMain();
                    C01191 c01191 = new C01191(this.$callback, zCheckFingerPrint, null);
                    this.label = 1;
                    if (BuildersKt.withContext(main, c01191, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else {
                    GTCipherHelper.getInstance().saveFingerKey(SafeUsageType.LOGIN, false);
                    MainCoroutineDispatcher main2 = Dispatchers.getMain();
                    AnonymousClass2 anonymousClass2 = new AnonymousClass2(this.$callback, null);
                    this.label = 2;
                    if (BuildersKt.withContext(main2, anonymousClass2, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                }
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void showFingerPrint(Activity activity, SafeApi safeApi, final Function1<? super Result<Boolean>, Unit> callback, String qrid) {
        FingerPrintConfirm fingerPrintConfirmCreateFingerPasswordConfirm = safeApi.createFingerPasswordConfirm(activity, true);
        fingerPrintConfirmCreateFingerPasswordConfirm.setOnFingerPrintListener(new FingerPrintConfirm.IFingerPrintListener() { // from class: com.gateio.biz.account.LoginFingerUtils.showFingerPrint.1
            @Override // com.gateio.biz.safe.service.router.provider.FingerPrintConfirm.IFingerPrintListener
            public void onSuccess(@NotNull String qrid2) {
                LoginFingerUtils.this.postFidoDeviceConfirm(callback, qrid2);
            }

            @Override // com.gateio.biz.safe.service.router.provider.FingerPrintConfirm.IFingerPrintListener
            public void onError(@NotNull SafePasswordType type, @NotNull String msg) {
            }
        });
        SafeUsageType safeUsageType = SafeUsageType.LOGIN;
        String userId = AccountApiProvider.getDefaultUserUtilsApi().getUserId();
        if (userId == null) {
            userId = "";
        }
        fingerPrintConfirmCreateFingerPasswordConfirm.setUsageInfo(safeUsageType, userId);
        fingerPrintConfirmCreateFingerPasswordConfirm.show(qrid);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean checkFingerPrint(final Activity activity, final FragmentManager fragmentManager, final SafeApi safeApi, final SafeUsageType usageType, final Function1<? super Result<Boolean>, Unit> callback, final String loginPass, final boolean isDelete) {
        final Ref.BooleanRef booleanRef = new Ref.BooleanRef();
        GTFingerPrintHelper.checkFingerPrint(activity, SafeUsageType.LOGIN, new GTCheckFingerPrintCallback() { // from class: com.gateio.biz.account.LoginFingerUtils.checkFingerPrint.1
            @Override // com.gateio.biz.safe.fido.GTCheckFingerPrintCallback
            public void onSuccess(boolean isSupport, boolean isVisible) {
                booleanRef.element = isSupport;
            }

            @Override // com.gateio.biz.safe.fido.GTCheckFingerPrintCallback
            public void showFingerChanged() {
                if (isDelete) {
                    this.deleteFidoDevice(activity, fragmentManager, safeApi, usageType, loginPass, callback);
                }
            }
        });
        return booleanRef.element;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void getFidoDeviceSuccess(Activity activity, FragmentManager fragmentManager, SafeApi safeApi, Function1<? super Result<Boolean>, Unit> callback, SafeQridEntity p02) {
        Ref.BooleanRef booleanRef = new Ref.BooleanRef();
        List<String> useages = p02.getUseages();
        if (!(useages == null || useages.isEmpty()) && p02.getUseages().contains(SafeUsageType.LOGIN.getValue())) {
            booleanRef.element = true;
        }
        BuildersKt__Builders_commonKt.launch$default(GTGlobalIOCoroutine.INSTANCE, null, null, new C17781(booleanRef, this, activity, fragmentManager, safeApi, callback, null), 3, null);
    }

    public final void changeBiometryLoginSwitch(@NotNull Activity activity, @NotNull FragmentManager fragmentManager, boolean open, @Nullable String password, @NotNull Function1<? super Result<Boolean>, Unit> callback) {
        SafeApi safeApi = (SafeApi) GTRouter.serviceAPI(RouterConst.Safe.PROVIDER_SAFE);
        if (password == null || password.length() == 0) {
            showLoginPass(activity, fragmentManager, safeApi, callback, open, "");
        } else {
            postFidoDevice(activity, fragmentManager, safeApi, callback, password);
        }
    }

    public final void getBiologyLoginSwitch(@NotNull Activity activity, @NotNull FragmentManager fragmentManager, @NotNull Function1<? super Result<Boolean>, Unit> callback) {
        getFidoDevice(activity, fragmentManager, (SafeApi) GTRouter.serviceAPI(RouterConst.Safe.PROVIDER_SAFE), callback);
    }

    public final void showLoginPass(@NotNull final Activity activity, @NotNull final FragmentManager fragmentManager, @NotNull final SafeApi safeApi, @NotNull final Function1<? super Result<Boolean>, Unit> callback, final boolean open, @Nullable String message) {
        SafeSecurityVerificationFragment callback2 = new SafeSecurityVerificationFragment().setCallback(new ISuccessCallBack() { // from class: com.gateio.biz.account.a
            @Override // com.gateio.common.listener.ISuccessCallBack
            public final void onSuccess(Object obj) {
                LoginFingerUtils.showLoginPass$lambda$0(open, this, activity, fragmentManager, safeApi, callback, (String) obj);
            }
        });
        if (message == null) {
            message = "";
        }
        callback2.setErrorStatus(message).show(fragmentManager, "");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void deleteFidoDevice(final Activity activity, final FragmentManager fragmentManager, final SafeApi safeApi, SafeUsageType usageType, final String loginPass, final Function1<? super Result<Boolean>, Unit> callback) {
        SafeHttpMethodsV3.getInstance().deleteFidoDevice(usageType, loginPass).compose(SchedulerConfig.io_main_detach()).subscribe(new CustomObserver<HttpResultV2<SafeQridEntity>>() { // from class: com.gateio.biz.account.LoginFingerUtils.deleteFidoDevice.1
            @Override // com.gateio.rxjava.CustomObserver, io.reactivex.rxjava3.core.z, org.reactivestreams.Subscriber
            public void onNext(@NotNull HttpResultV2<SafeQridEntity> item) {
                if (!item.isSuccess()) {
                    this.showLoginPass(activity, fragmentManager, safeApi, callback, true, item.getMessage());
                    return;
                }
                if (!TextUtils.isEmpty(loginPass)) {
                    ToastUtils.INSTANCE.show(ToastType.SUCCESS, R.string.safe_register_login_closed);
                }
                GTCipherHelper.getInstance().saveFingerKey(SafeUsageType.LOGIN, false);
                Function1<Result<Boolean>, Unit> function1 = callback;
                Result.Companion companion = Result.INSTANCE;
                function1.invoke(Result.m4829boximpl(Result.m4830constructorimpl(Boolean.FALSE)));
            }
        });
    }

    private final void getFidoDevice(final Activity activity, final FragmentManager fragmentManager, final SafeApi safeApi, final Function1<? super Result<Boolean>, Unit> callback) {
        SafeHttpMethodsV3.getInstance().getFidoDevice().compose(SchedulerConfig.io_main_detach()).subscribe(new CustomObserver<SafeQridEntity>() { // from class: com.gateio.biz.account.LoginFingerUtils.getFidoDevice.1
            @Override // com.gateio.rxjava.CustomObserver, io.reactivex.rxjava3.core.z, org.reactivestreams.Subscriber
            public void onNext(@NotNull SafeQridEntity p02) {
                LoginFingerUtils.this.getFidoDeviceSuccess(activity, fragmentManager, safeApi, callback, p02);
            }

            @Override // com.gateio.rxjava.CustomObserver, io.reactivex.rxjava3.core.z, org.reactivestreams.Subscriber, io.reactivex.rxjava3.core.m, io.reactivex.rxjava3.core.c0
            public void onError(@NotNull Throwable e10) {
                super.onError(e10);
                Function1<Result<Boolean>, Unit> function1 = callback;
                Result.Companion companion = Result.INSTANCE;
                function1.invoke(Result.m4829boximpl(Result.m4830constructorimpl(Boolean.FALSE)));
            }
        });
    }

    private final void postFidoDevice(final Activity activity, final FragmentManager fragmentManager, final SafeApi safeApi, final Function1<? super Result<Boolean>, Unit> callback, String loginPass) {
        SafeHttpMethodsV3.getInstance().postFidoDevice(SafeUsageType.LOGIN, loginPass).compose(SchedulerConfig.io_main_detach()).subscribe(new CustomObserver<HttpResultV2<SafeQridEntity>>() { // from class: com.gateio.biz.account.LoginFingerUtils.postFidoDevice.1
            @Override // com.gateio.rxjava.CustomObserver, io.reactivex.rxjava3.core.z, org.reactivestreams.Subscriber
            public void onNext(@NotNull HttpResultV2<SafeQridEntity> item) {
                if (!item.isSuccess() || item.getData() == null) {
                    LoginFingerUtils.this.showLoginPass(activity, fragmentManager, safeApi, callback, true, item.getMessage());
                } else {
                    LoginFingerUtils.this.showFingerPrint(activity, safeApi, callback, item.getData().getQrid());
                }
            }

            @Override // com.gateio.rxjava.CustomObserver, io.reactivex.rxjava3.core.z, org.reactivestreams.Subscriber, io.reactivex.rxjava3.core.m, io.reactivex.rxjava3.core.c0
            public void onError(@NotNull Throwable e10) {
                super.onError(e10);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void postFidoDeviceConfirm(final Function1<? super Result<Boolean>, Unit> callback, String qrid) {
        SafeHttpMethodsV3.getInstance().postFidoDeviceConfirm(SafeUsageType.LOGIN, qrid).compose(SchedulerConfig.io_main_detach()).subscribe(new CustomObserver<SafeQridEntity>() { // from class: com.gateio.biz.account.LoginFingerUtils.postFidoDeviceConfirm.1
            @Override // com.gateio.rxjava.CustomObserver, io.reactivex.rxjava3.core.z, org.reactivestreams.Subscriber
            public void onNext(@NotNull SafeQridEntity item) {
                Function1<Result<Boolean>, Unit> function1 = callback;
                Result.Companion companion = Result.INSTANCE;
                function1.invoke(Result.m4829boximpl(Result.m4830constructorimpl(Boolean.TRUE)));
                ToastUtils.INSTANCE.show(ToastType.SUCCESS, R.string.safe_register_login_success);
            }

            @Override // com.gateio.rxjava.CustomObserver, io.reactivex.rxjava3.core.z, org.reactivestreams.Subscriber, io.reactivex.rxjava3.core.m, io.reactivex.rxjava3.core.c0
            public void onError(@NotNull Throwable e10) {
                super.onError(e10);
                ToastUtils.INSTANCE.show(ToastType.ERROR, String.valueOf(e10.getMessage()));
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showLoginPass$lambda$0(boolean z10, LoginFingerUtils loginFingerUtils, Activity activity, FragmentManager fragmentManager, SafeApi safeApi, Function1 function1, String str) {
        if (!TextUtils.isEmpty(str)) {
            if (z10) {
                loginFingerUtils.postFidoDevice(activity, fragmentManager, safeApi, function1, str);
            } else {
                loginFingerUtils.deleteFidoDevice(activity, fragmentManager, safeApi, SafeUsageType.LOGIN, str, function1);
            }
        }
    }
}