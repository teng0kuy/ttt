package com.gateio.biz.account;

import android.app.Activity;
import androidx.fragment.app.FragmentManager;
import com.gateio.biz.safe.service.router.provider.SafeApi;
import com.gateio.common.listener.ISuccessCallBack;
import kotlin.jvm.functions.Function1;

/* compiled from: R8$$SyntheticClass */
/* loaded from: classes4.dex */
public final /* synthetic */ class a implements ISuccessCallBack {

    /* renamed from: a */
    public final /* synthetic */ boolean f10890a;

    /* renamed from: b */
    public final /* synthetic */ LoginFingerUtils f10891b;

    /* renamed from: c */
    public final /* synthetic */ Activity f10892c;

    /* renamed from: d */
    public final /* synthetic */ FragmentManager f10893d;

    /* renamed from: e */
    public final /* synthetic */ SafeApi f10894e;

    /* renamed from: f */
    public final /* synthetic */ Function1 f10895f;

    @Override // com.gateio.common.listener.ISuccessCallBack
    public final void onSuccess(Object obj) {
        LoginFingerUtils.showLoginPass$lambda$0(open, this, activity, fragmentManager, safeApi, callback, (String) obj);
    }

    public /* synthetic */ a(boolean z10, LoginFingerUtils loginFingerUtils, Activity activity, FragmentManager fragmentManager, SafeApi safeApi, Function1 function1) {
        open = z10;
        this = loginFingerUtils;
        activity = activity;
        fragmentManager = fragmentManager;
        safeApi = safeApi;
        callback = function1;
    }
}