package com.gateio.biz.account.service.router;

import com.gateio.biz.account.service.router.provider.AccountApi;
import com.gateio.biz.account.service.router.provider.AccountKycApi;
import com.gateio.biz.account.service.router.provider.AccountLoginApi;
import com.gateio.biz.account.service.router.provider.AccountReferralApi;
import com.gateio.biz.account.service.router.provider.AppTypeApi;
import com.gateio.biz.account.service.router.provider.TestnetUserApi;
import com.gateio.biz.account.service.router.provider.UserUtilsApi;
import com.gateio.biz.base.router.RouterConst;
import com.gateio.lib.router.GTRouter;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import org.jetbrains.annotations.NotNull;

/* compiled from: AccountApiProvider.kt */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0012\u0010\u000b\u001a\u00020\f2\b\b\u0002\u0010\r\u001a\u00020\u0004H\u0007J\u0012\u0010\u000e\u001a\u00020\u000f2\b\b\u0002\u0010\r\u001a\u00020\u0004H\u0007J\u0012\u0010\u0010\u001a\u00020\u00112\b\b\u0002\u0010\r\u001a\u00020\u0004H\u0007J\b\u0010\u0012\u001a\u00020\u0013H\u0007J\u0010\u0010\u0012\u001a\u00020\u00132\u0006\u0010\r\u001a\u00020\u0004H\u0007J\b\u0010\u0014\u001a\u00020\fH\u0007J\b\u0010\u0015\u001a\u00020\u000fH\u0007J\b\u0010\u0016\u001a\u00020\u0011H\u0007J\b\u0010\u0017\u001a\u00020\u0018H\u0007J\b\u0010\u0019\u001a\u00020\u001aH\u0007J\u0012\u0010\u001b\u001a\u00020\u00182\b\b\u0002\u0010\r\u001a\u00020\u0004H\u0007J\b\u0010\u001c\u001a\u00020\u001dH\u0007J\u0012\u0010\u001e\u001a\u00020\u001a2\b\b\u0002\u0010\r\u001a\u00020\u0004H\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001f"}, d2 = {"Lcom/gateio/biz/account/service/router/AccountApiProvider;", "", "()V", "defaultAccountKycRoutePath", "", "defaultAccountLoginRoutePath", "defaultAccountReferralRoutePath", "defaultAccountRoutePath", "defaultAppTypeApiRoutePath", "defaultTestnetAccountRoutePath", "defaultUserUtilsRoutePath", "getAccountApi", "Lcom/gateio/biz/account/service/router/provider/AccountApi;", "path", "getAccountKycApi", "Lcom/gateio/biz/account/service/router/provider/AccountKycApi;", "getAccountLoginApi", "Lcom/gateio/biz/account/service/router/provider/AccountLoginApi;", "getAppTypeApi", "Lcom/gateio/biz/account/service/router/provider/AppTypeApi;", "getDefaultAccountApi", "getDefaultAccountKycApi", "getDefaultAccountLoginApi", "getDefaultReferralApi", "Lcom/gateio/biz/account/service/router/provider/AccountReferralApi;", "getDefaultUserUtilsApi", "Lcom/gateio/biz/account/service/router/provider/UserUtilsApi;", "getReferralApi", "getTestnetAccountApi", "Lcom/gateio/biz/account/service/router/provider/TestnetUserApi;", "getUserUtilsApi", "biz_account_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class AccountApiProvider {

    @NotNull
    public static final AccountApiProvider INSTANCE = new AccountApiProvider();

    @NotNull
    private static String defaultAccountRoutePath = RouterConst.RegisterLogin.PROVIDER_ACCOUNT;

    @NotNull
    private static String defaultTestnetAccountRoutePath = RouterConst.RegisterLogin.PROVIDER_ACCOUNT_TESTNET;

    @NotNull
    private static String defaultAccountKycRoutePath = RouterConst.RegisterLogin.PROVIDER_KYC;

    @NotNull
    private static String defaultAccountLoginRoutePath = RouterConst.RegisterLogin.PROVIDER_ACCOUNT_LOGIN;

    @NotNull
    private static String defaultUserUtilsRoutePath = RouterConst.RegisterLogin.PROVIDER_USER_UTILS;

    @NotNull
    private static String defaultAccountReferralRoutePath = RouterConst.RegisterLogin.PROVIDER_REFERRAL;

    @NotNull
    private static String defaultAppTypeApiRoutePath = RouterConst.RegisterLogin.PROVIDER_APP_TYPE_EVENT;

    private AccountApiProvider() {
    }

    @JvmStatic
    @NotNull
    public static final AppTypeApi getAppTypeApi() {
        return getAppTypeApi(defaultAppTypeApiRoutePath);
    }

    @JvmStatic
    @NotNull
    public static final AccountApi getDefaultAccountApi() {
        return getAccountApi$default(null, 1, null);
    }

    @JvmStatic
    @NotNull
    public static final AccountKycApi getDefaultAccountKycApi() {
        return getAccountKycApi$default(null, 1, null);
    }

    @JvmStatic
    @NotNull
    public static final AccountLoginApi getDefaultAccountLoginApi() {
        return getAccountLoginApi$default(null, 1, null);
    }

    @JvmStatic
    @NotNull
    public static final AccountReferralApi getDefaultReferralApi() {
        return getReferralApi$default(null, 1, null);
    }

    @JvmStatic
    @NotNull
    public static final UserUtilsApi getDefaultUserUtilsApi() {
        return getUserUtilsApi$default(null, 1, null);
    }

    public static /* synthetic */ AccountApi getAccountApi$default(String str, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = defaultAccountRoutePath;
        }
        return getAccountApi(str);
    }

    public static /* synthetic */ AccountKycApi getAccountKycApi$default(String str, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = defaultAccountKycRoutePath;
        }
        return getAccountKycApi(str);
    }

    public static /* synthetic */ AccountLoginApi getAccountLoginApi$default(String str, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = defaultAccountLoginRoutePath;
        }
        return getAccountLoginApi(str);
    }

    @JvmStatic
    @NotNull
    public static final AppTypeApi getAppTypeApi(@NotNull String path) {
        return (AppTypeApi) GTRouter.serviceAPI(path);
    }

    public static /* synthetic */ AccountReferralApi getReferralApi$default(String str, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = defaultAccountReferralRoutePath;
        }
        return getReferralApi(str);
    }

    @JvmStatic
    @NotNull
    public static final TestnetUserApi getTestnetAccountApi() {
        return (TestnetUserApi) GTRouter.serviceAPI(defaultTestnetAccountRoutePath);
    }

    public static /* synthetic */ UserUtilsApi getUserUtilsApi$default(String str, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = defaultUserUtilsRoutePath;
        }
        return getUserUtilsApi(str);
    }

    @JvmStatic
    @NotNull
    public static final AccountApi getAccountApi(@NotNull String path) {
        return (AccountApi) GTRouter.serviceAPI(path);
    }

    @JvmStatic
    @NotNull
    public static final AccountKycApi getAccountKycApi(@NotNull String path) {
        return (AccountKycApi) GTRouter.serviceAPI(path);
    }

    @JvmStatic
    @NotNull
    public static final AccountLoginApi getAccountLoginApi(@NotNull String path) {
        return (AccountLoginApi) GTRouter.serviceAPI(path);
    }

    @JvmStatic
    @NotNull
    public static final AccountReferralApi getReferralApi(@NotNull String path) {
        return (AccountReferralApi) GTRouter.serviceAPI(path);
    }

    @JvmStatic
    @NotNull
    public static final UserUtilsApi getUserUtilsApi(@NotNull String path) {
        return (UserUtilsApi) GTRouter.serviceAPI(path);
    }
}