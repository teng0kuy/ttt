package com.gateio.biz.account.service.router;

import com.gateio.biz.account.service.model.LoginAuthDto;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: VerifyActionSubject.kt */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010%\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002RR\u0010\u0003\u001a:\u0012\u0012\u0012\u0010\u0012\u0004\u0012\u00020\u0006\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0005\u0012\u001a\u0012\u0018\u0012\u0006\u0012\u0004\u0018\u00010\u0007\u0012\u0006\u0012\u0004\u0018\u00010\u0006\u0012\u0004\u0012\u00020\b0\u0004\u0012\u0004\u0012\u00020\b\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\f¨\u0006\r"}, d2 = {"Lcom/gateio/biz/account/service/router/VerifyActionSubject;", "", "()V", "authAction", "Lkotlin/Function2;", "", "", "Lcom/gateio/biz/account/service/model/LoginAuthDto;", "", "getAuthAction", "()Lkotlin/jvm/functions/Function2;", "setAuthAction", "(Lkotlin/jvm/functions/Function2;)V", "biz_account_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class VerifyActionSubject {

    @NotNull
    public static final VerifyActionSubject INSTANCE = new VerifyActionSubject();

    @Nullable
    private static Function2<? super Map<String, String>, ? super Function2<? super LoginAuthDto, ? super String, Unit>, Unit> authAction;

    private VerifyActionSubject() {
    }

    @Nullable
    public final Function2<Map<String, String>, Function2<? super LoginAuthDto, ? super String, Unit>, Unit> getAuthAction() {
        return authAction;
    }

    public final void setAuthAction(@Nullable Function2<? super Map<String, String>, ? super Function2<? super LoginAuthDto, ? super String, Unit>, Unit> function2) {
        authAction = function2;
    }
}