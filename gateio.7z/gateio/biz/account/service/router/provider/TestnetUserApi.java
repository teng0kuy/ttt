package com.gateio.biz.account.service.router.provider;

import com.alibaba.android.arouter.facade.template.IProvider;
import com.gateio.biz.account.service.model.LoginResult;
import com.gateio.biz.account.service.model.TestnetUserInfo;
import com.gateio.biz.account.service.model.UserInfo;
import java.util.List;

/* loaded from: classes4.dex */
public interface TestnetUserApi extends IProvider {
    void clearAll();

    void clearPver();

    void clearToken();

    void exit();

    int getAgencyType();

    List<TestnetUserInfo> getAllLoginedAccounts();

    int getCountryId();

    String getEmail();

    String getNick();

    String getPhone();

    String getPver();

    String getPverWS();

    String getRealName();

    TestnetUserInfo getTestnetUserInfo();

    String getToken();

    String getUserId();

    String getUserName();

    void initUser(TestnetUserInfo testnetUserInfo);

    boolean isSubUser();

    boolean isValid();

    boolean isValid(String str);

    void logOut();

    void login(TestnetUserInfo testnetUserInfo);

    void loginUser(LoginResult loginResult, boolean z10);

    void logoutAccount(String str);

    boolean switchUser(TestnetUserInfo testnetUserInfo);

    boolean switchUser(UserInfo userInfo);

    boolean switchUser(String str);

    void updateAgencyType(int i10);

    void updateCountryId(int i10);

    void updateEmail(String str);

    void updateIsSub(boolean z10);

    void updateNickname(String str);

    void updatePhone(String str);

    void updatePver(String str);

    void updateRealName(String str);

    void updateToken(String str);

    void updateUser(TestnetUserInfo testnetUserInfo);
}