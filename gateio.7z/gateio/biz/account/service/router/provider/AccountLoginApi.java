package com.gateio.biz.account.service.router.provider;

import android.content.Context;
import com.alibaba.android.arouter.facade.template.IProvider;
import com.gateio.common.listener.ISuccessCallBack;
import com.gateio.rxjava.basemvp.IBaseView;

/* loaded from: classes4.dex */
public interface AccountLoginApi extends IProvider {
    void appLogSetUserUniqueID(String str);

    void changeAssertStatus(boolean z10);

    void clearAll();

    void clearToken();

    void exit();

    void fundPasswordReset(Context context);

    String getInviteCode();

    String getIsHadSecurePassword();

    String getKyc3Status();

    String getMomentsToken();

    String getNickName();

    String getToken();

    String getUserAvatar();

    String getUserCuid();

    String getUserId();

    String getUserName();

    String getUserNick();

    String getUserPverWs();

    String getUserRole();

    String getUserTimId();

    boolean isCustomer();

    boolean isHideAssert();

    boolean isHost();

    void isIdentityAuth(IBaseView iBaseView, ISuccessCallBack<Boolean> iSuccessCallBack);

    void isKyc2(IBaseView iBaseView, ISuccessCallBack<Boolean> iSuccessCallBack);

    boolean isNftAvatar();

    boolean isNotIdentityAuth();

    boolean isSub();

    boolean isValid();

    void logOut();

    void loginSuccess(String str);

    void logoutAccount(String str);

    void registerSuccess(String str);

    void showLogin(Context context);

    void showLogin(Context context, String str, String str2);

    void showVerifyType(Context context, String str);

    void temptUser(String str);

    void updateUser(String str);

    default void navToHomePage() {
    }

    default void navToWalletPage() {
    }

    default void navToBankBuyPage(Context context) {
    }

    default void navToCreditBuyPage(Context context) {
    }

    default void navToServicePage(Context context) {
    }

    default void navToWebPage(Context context, String str, String str2) {
    }
}