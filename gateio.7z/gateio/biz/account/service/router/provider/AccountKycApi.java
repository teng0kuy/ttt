package com.gateio.biz.account.service.router.provider;

import android.content.Context;
import com.alibaba.android.arouter.facade.template.IProvider;
import com.gateio.common.listener.ISuccessCallBack;
import com.gateio.rxjava.basemvp.IBaseView;

/* loaded from: classes4.dex */
public interface AccountKycApi extends IProvider {
    void isNeedIdentityAuth(IBaseView iBaseView, ISuccessCallBack<Boolean> iSuccessCallBack);

    void isNeedKyc2(IBaseView iBaseView, ISuccessCallBack<Boolean> iSuccessCallBack);

    void showIdentityDialog(Context context, String str);

    void showIdentityDialog(Context context, String str, ISuccessCallBack<Boolean> iSuccessCallBack);

    void showIdentityDialogV5(Context context, String str);

    void showKYCCertificationSheet(Context context, String str, String str2);

    void showKyc2Dialog(Context context, ISuccessCallBack<Boolean> iSuccessCallBack);
}