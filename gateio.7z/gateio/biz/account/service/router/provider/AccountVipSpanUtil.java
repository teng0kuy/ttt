package com.gateio.biz.account.service.router.provider;

import android.content.Context;
import android.text.SpannableString;

/* loaded from: classes4.dex */
public interface AccountVipSpanUtil {
    SpannableString build(Context context);

    AccountVipSpanUtil setNameColor(int i10);

    AccountVipSpanUtil setOffical(boolean z10);

    AccountVipSpanUtil setUsername(String str);

    AccountVipSpanUtil setVipLevel(int i10);

    AccountVipSpanUtil setVipRight(boolean z10);

    AccountVipSpanUtil setVipSize(int i10);
}