package com.gateio.biz.account.service.router.provider;

import androidx.lifecycle.MutableLiveData;
import com.alibaba.android.arouter.facade.template.IProvider;
import com.gateio.biz.account.service.model.AppTypeChangeEvent;
import com.gateio.biz.account.service.model.ConfigUpdateEvent;
import com.gateio.biz.account.service.router.AccountApiProvider;
import com.tencent.qcloud.tuicore.TUIConstants;
import java.util.Map;
import kotlin.Metadata;
import kotlinx.coroutines.flow.SharedFlow;
import org.apache.commons.codec.language.bm.Languages;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: AppTypeApi.kt */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\n\n\u0002\u0010$\n\u0000\bf\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H&J\u0012\u0010\u0002\u001a\u0004\u0018\u00010\u00032\u0006\u0010\u0004\u001a\u00020\u0003H&J\u000e\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006H&J\u000e\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00070\tH&J\u000e\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u000b0\tH&J\b\u0010\f\u001a\u00020\rH&J\b\u0010\u000e\u001a\u00020\rH&J\b\u0010\u000f\u001a\u00020\rH&J\b\u0010\u0010\u001a\u00020\u0011H&J\u0010\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u0013\u001a\u00020\u0014H&JB\u0010\u0015\u001a\u00020\u00112\n\b\u0002\u0010\u0016\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0017\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0018\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0019\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u001a\u001a\u00020\rH&J\u0010\u0010\u001b\u001a\u00020\u00112\u0006\u0010\u0013\u001a\u00020\u0014H&J\u0012\u0010\u001c\u001a\u00020\u00112\b\u0010\u001d\u001a\u0004\u0018\u00010\u0003H&J\u001e\u0010\u001c\u001a\u00020\u00112\u0014\u0010\u001e\u001a\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0014\u0018\u00010\u001fH&¨\u0006 "}, d2 = {"Lcom/gateio/biz/account/service/router/provider/AppTypeApi;", "Lcom/alibaba/android/arouter/facade/template/IProvider;", "getAppType", "", "userId", "getAppTypeBus", "Landroidx/lifecycle/MutableLiveData;", "Lcom/gateio/biz/account/service/model/AppTypeChangeEvent;", "getAppTypeFlow", "Lkotlinx/coroutines/flow/SharedFlow;", "getConfigUpateFlow", "Lcom/gateio/biz/account/service/model/ConfigUpdateEvent;", "isAppTypeFeatureEnable", "", "isMainSite", "isUsSite", "refreshComplianceConfig", "", "registerAppTypeChangeEvent", Languages.ANY, "", "setAppType", "fromUid", "fromType", "toUid", "toType", TUIConstants.TUIGroupNotePlugin.PLUGIN_GROUP_NOTE_ENABLE_NOTIFICATION, "unregisterAppTypeChangeEvent", "updateComplianceConfigAsync", "config", "complianceMap", "", "biz_account_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public interface AppTypeApi extends IProvider {

    /* compiled from: AppTypeApi.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class DefaultImpls {
        public static /* synthetic */ void setAppType$default(AppTypeApi appTypeApi, String str, String str2, String str3, String str4, boolean z10, int i10, Object obj) {
            if (obj != null) {
                throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: setAppType");
            }
            if ((i10 & 1) != 0) {
                str = AccountApiProvider.getDefaultUserUtilsApi().getUserId();
            }
            String str5 = (i10 & 2) != 0 ? null : str2;
            if ((i10 & 4) != 0) {
                str3 = AccountApiProvider.getDefaultUserUtilsApi().getUserId();
            }
            String str6 = str3;
            String str7 = (i10 & 8) == 0 ? str4 : null;
            if ((i10 & 16) != 0) {
                z10 = true;
            }
            appTypeApi.setAppType(str, str5, str6, str7, z10);
        }
    }

    @NotNull
    String getAppType();

    @Nullable
    String getAppType(@NotNull String userId);

    @NotNull
    MutableLiveData<AppTypeChangeEvent> getAppTypeBus();

    @NotNull
    SharedFlow<AppTypeChangeEvent> getAppTypeFlow();

    @NotNull
    SharedFlow<ConfigUpdateEvent> getConfigUpateFlow();

    boolean isAppTypeFeatureEnable();

    boolean isMainSite();

    boolean isUsSite();

    void refreshComplianceConfig();

    void registerAppTypeChangeEvent(@NotNull Object any);

    void setAppType(@Nullable String fromUid, @Nullable String fromType, @Nullable String toUid, @Nullable String toType, boolean notify);

    void unregisterAppTypeChangeEvent(@NotNull Object any);

    void updateComplianceConfigAsync(@Nullable String config);

    void updateComplianceConfigAsync(@Nullable Map<String, ? extends Object> complianceMap);
}