package com.gateio.biz.account.service.router.provider;

import com.alibaba.android.arouter.facade.template.IProvider;
import com.gateio.biz.account.service.model.IdentityAuthStatus;
import com.gateio.biz.account.service.model.LoginResult;
import com.gateio.biz.account.service.model.RegisterResult;
import com.gateio.biz.account.service.model.UserInfo;
import java.util.List;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;

/* loaded from: classes4.dex */
public interface UserUtilsApi extends IProvider {
    void changeAssertStatus(String str, boolean z10);

    void changeAssertStatus(boolean z10);

    void clearAll();

    void clearToken();

    void exit();

    List<UserInfo> getAllLoginedAccounts();

    String getInviteCode();

    String getMomentsToken();

    String getNickName();

    String getPver();

    String getToken();

    String getUserAvatar();

    String getUserId();

    void getUserId(Function1<String, Unit> function1);

    UserInfo getUserInfo();

    String getUserName();

    String getUserNick();

    String getUserPverWs();

    String getUserRole();

    String getUserTimId();

    void initUser();

    void initUser(Function1<UserInfo, Unit> function1);

    boolean isCustomer();

    boolean isHideAssert();

    boolean isHideAssert(String str);

    boolean isHost();

    boolean isNftAvatar();

    boolean isSub();

    @Deprecated
    boolean isValid();

    boolean isValidForToken();

    void logOut();

    void loginUser(LoginResult loginResult);

    void loginUser(LoginResult loginResult, boolean z10);

    void logoutAccount(String str);

    boolean switchUser(String str);

    void temptUser(UserInfo userInfo);

    void updateAvatar(String str);

    void updateAvatar(String str, boolean z10);

    void updateIdentityAuthStatus(IdentityAuthStatus identityAuthStatus);

    void updateLogin2Config(String str);

    void updateMToken(String str);

    void updateTier(String str);

    void updateUser(RegisterResult registerResult);

    void updateUserNick(String str);

    void updateUserNickEn(String str);

    void updatelivenessStatus(String str);
}