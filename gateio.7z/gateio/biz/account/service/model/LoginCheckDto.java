package com.gateio.biz.account.service.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.gateio.biz_options.datafinder.GTOptionsEvent;
import com.gateio.fiatotclib.function.order.block.BlockActivity;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: LoginCheckDto.kt */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b0\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0016\u0018\u0000 A2\u00020\u00012\u00020\u0002:\u0001AB\u000f\b\u0016\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0005B\u0005¢\u0006\u0002\u0010\u0006J\b\u00108\u001a\u000209H\u0016J\u0006\u0010:\u001a\u000209J\b\u0010;\u001a\u00020\bH\u0016J\u0006\u0010<\u001a\u00020=J\u0018\u0010>\u001a\u00020?2\u0006\u0010\u0003\u001a\u00020\u00042\u0006\u0010@\u001a\u000209H\u0016R\u001c\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\fR\u001c\u0010\r\u001a\u0004\u0018\u00010\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\n\"\u0004\b\u000f\u0010\fR\u001c\u0010\u0010\u001a\u0004\u0018\u00010\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\n\"\u0004\b\u0012\u0010\fR\u001c\u0010\u0013\u001a\u0004\u0018\u00010\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\n\"\u0004\b\u0015\u0010\fR\u001e\u0010\u0016\u001a\u0004\u0018\u00010\b8FX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0017\u0010\n\"\u0004\b\u0018\u0010\fR\u001c\u0010\u0019\u001a\u0004\u0018\u00010\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001a\u0010\n\"\u0004\b\u001b\u0010\fR\u001c\u0010\u001c\u001a\u0004\u0018\u00010\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\n\"\u0004\b\u001e\u0010\fR\u001c\u0010\u001f\u001a\u0004\u0018\u00010\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b \u0010\n\"\u0004\b!\u0010\fR\u001c\u0010\"\u001a\u0004\u0018\u00010\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b#\u0010\n\"\u0004\b$\u0010\fR\u001c\u0010%\u001a\u0004\u0018\u00010\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b&\u0010\n\"\u0004\b'\u0010\fR\u001c\u0010(\u001a\u0004\u0018\u00010\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b)\u0010\n\"\u0004\b*\u0010\fR\u001c\u0010+\u001a\u0004\u0018\u00010\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b,\u0010\n\"\u0004\b-\u0010\fR\u001c\u0010.\u001a\u0004\u0018\u00010\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b/\u0010\n\"\u0004\b0\u0010\fR\u001c\u00101\u001a\u0004\u0018\u00010\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b2\u0010\n\"\u0004\b3\u0010\fR\u001c\u00104\u001a\u0004\u0018\u00010\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b5\u0010\n\"\u0004\b6\u0010\fR\u0010\u00107\u001a\u0004\u0018\u00010\bX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006B"}, d2 = {"Lcom/gateio/biz/account/service/model/LoginCheckDto;", "Lcom/gateio/biz/account/service/model/LoginAuthDto;", "Landroid/os/Parcelable;", "parcel", "Landroid/os/Parcel;", "(Landroid/os/Parcel;)V", "()V", "anti_phishing_code", "", "getAnti_phishing_code", "()Ljava/lang/String;", "setAnti_phishing_code", "(Ljava/lang/String;)V", "country_code", "getCountry_code", "setCountry_code", "email", "getEmail", "setEmail", "email_encrypted", "getEmail_encrypted", "setEmail_encrypted", "nickname", "getNickname", "setNickname", "password", "getPassword", "setPassword", "phone", "getPhone", "setPhone", "phone_encrypted", "getPhone_encrypted", "setPhone_encrypted", "show_anti_phishing_verification", "getShow_anti_phishing_verification", "setShow_anti_phishing_verification", "show_email_code", "getShow_email_code", "setShow_email_code", "show_sms", "getShow_sms", "setShow_sms", "show_totp", "getShow_totp", "setShow_totp", "show_webauthn", "getShow_webauthn", "setShow_webauthn", "sms_id", "getSms_id", "setSms_id", "url", "getUrl", "setUrl", BlockActivity.USER_NAME, "describeContents", "", "getVerifyNum", "getVerifyType", "showAntiCode", "", "writeToParcel", "", "flags", "CREATOR", "biz_account_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public class LoginCheckDto extends LoginAuthDto implements Parcelable {

    /* renamed from: CREATOR, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @Nullable
    private String anti_phishing_code;

    @Nullable
    private String country_code;

    @Nullable
    private String email;

    @Nullable
    private String email_encrypted;

    @Nullable
    private String nickname;

    @Nullable
    private String password;

    @Nullable
    private String phone;

    @Nullable
    private String phone_encrypted;

    @Nullable
    private String show_anti_phishing_verification;

    @Nullable
    private String show_email_code;

    @Nullable
    private String show_sms;

    @Nullable
    private String show_totp;

    @Nullable
    private String show_webauthn;

    @Nullable
    private String sms_id;

    @Nullable
    private String url;

    @Nullable
    private String userName;

    /* compiled from: LoginCheckDto.kt */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u0006H\u0016J\u001d\u0010\u0007\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0016¢\u0006\u0002\u0010\u000b¨\u0006\f"}, d2 = {"Lcom/gateio/biz/account/service/model/LoginCheckDto$CREATOR;", "Landroid/os/Parcelable$Creator;", "Lcom/gateio/biz/account/service/model/LoginCheckDto;", "()V", "createFromParcel", "parcel", "Landroid/os/Parcel;", "newArray", "", GTOptionsEvent.value_size, "", "(I)[Lcom/gateio/biz/account/service/model/LoginCheckDto;", "biz_account_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    /* renamed from: com.gateio.biz.account.service.model.LoginCheckDto$CREATOR, reason: from kotlin metadata */
    public static final class Companion implements Parcelable.Creator<LoginCheckDto> {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        @NotNull
        public LoginCheckDto createFromParcel(@NotNull Parcel parcel) {
            return new LoginCheckDto(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        @NotNull
        public LoginCheckDto[] newArray(int size) {
            return new LoginCheckDto[size];
        }
    }

    public LoginCheckDto() {
        this.sms_id = "0";
        this.show_sms = "0";
        this.show_totp = "0";
        this.show_email_code = "0";
        this.show_webauthn = "0";
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Nullable
    public final String getAnti_phishing_code() {
        return this.anti_phishing_code;
    }

    @Nullable
    public final String getCountry_code() {
        return this.country_code;
    }

    @Nullable
    public final String getEmail() {
        return this.email;
    }

    @Nullable
    public final String getEmail_encrypted() {
        return this.email_encrypted;
    }

    @Nullable
    public final String getNickname() {
        String str = this.nickname;
        return str == null || str.length() == 0 ? this.userName : this.nickname;
    }

    @Nullable
    public final String getPassword() {
        return this.password;
    }

    @Nullable
    public final String getPhone() {
        return this.phone;
    }

    @Nullable
    public final String getPhone_encrypted() {
        return this.phone_encrypted;
    }

    @Nullable
    public final String getShow_anti_phishing_verification() {
        return this.show_anti_phishing_verification;
    }

    @Nullable
    public final String getShow_email_code() {
        return this.show_email_code;
    }

    @Nullable
    public final String getShow_sms() {
        return this.show_sms;
    }

    @Nullable
    public final String getShow_totp() {
        return this.show_totp;
    }

    @Nullable
    public final String getShow_webauthn() {
        return this.show_webauthn;
    }

    @Nullable
    public final String getSms_id() {
        return this.sms_id;
    }

    @Nullable
    public final String getUrl() {
        return this.url;
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [boolean, int] */
    public final int getVerifyNum() {
        ?? AreEqual = Intrinsics.areEqual(this.show_sms, "1");
        int i10 = AreEqual;
        if (Intrinsics.areEqual(this.show_totp, "1")) {
            i10 = AreEqual + 1;
        }
        int i11 = i10;
        if (Intrinsics.areEqual(this.show_webauthn, "1")) {
            i11 = i10 + 1;
        }
        return Intrinsics.areEqual(this.show_email_code, "1") ? i11 + 1 : i11;
    }

    @NotNull
    public String getVerifyType() {
        return Intrinsics.areEqual(this.show_sms, "1") ? LoginAuthDto.VERIFY_TYPE_PHONE_FOR_LOGIN : Intrinsics.areEqual(this.show_totp, "1") ? LoginAuthDto.VERIFY_TYPE_GOOGLE : Intrinsics.areEqual(this.show_email_code, "1") ? LoginAuthDto.VERIFY_TYPE_EMAIL_FOR_LOGIN : "";
    }

    public final void setAnti_phishing_code(@Nullable String str) {
        this.anti_phishing_code = str;
    }

    public final void setCountry_code(@Nullable String str) {
        this.country_code = str;
    }

    public final void setEmail(@Nullable String str) {
        this.email = str;
    }

    public final void setEmail_encrypted(@Nullable String str) {
        this.email_encrypted = str;
    }

    public final void setNickname(@Nullable String str) {
        this.nickname = str;
    }

    public final void setPassword(@Nullable String str) {
        this.password = str;
    }

    public final void setPhone(@Nullable String str) {
        this.phone = str;
    }

    public final void setPhone_encrypted(@Nullable String str) {
        this.phone_encrypted = str;
    }

    public final void setShow_anti_phishing_verification(@Nullable String str) {
        this.show_anti_phishing_verification = str;
    }

    public final void setShow_email_code(@Nullable String str) {
        this.show_email_code = str;
    }

    public final void setShow_sms(@Nullable String str) {
        this.show_sms = str;
    }

    public final void setShow_totp(@Nullable String str) {
        this.show_totp = str;
    }

    public final void setShow_webauthn(@Nullable String str) {
        this.show_webauthn = str;
    }

    public final void setSms_id(@Nullable String str) {
        this.sms_id = str;
    }

    public final void setUrl(@Nullable String str) {
        this.url = str;
    }

    public final boolean showAntiCode() {
        return Intrinsics.areEqual(this.show_anti_phishing_verification, "1");
    }

    @Override // android.os.Parcelable
    public void writeToParcel(@NotNull Parcel parcel, int flags) {
        parcel.writeString(this.email);
        parcel.writeString(this.email_encrypted);
        parcel.writeString(this.phone);
        parcel.writeString(this.phone_encrypted);
        parcel.writeString(this.password);
        parcel.writeString(this.sms_id);
        parcel.writeString(this.show_sms);
        parcel.writeString(this.show_totp);
        parcel.writeString(this.show_email_code);
        parcel.writeString(this.show_webauthn);
        parcel.writeString(this.anti_phishing_code);
        parcel.writeString(this.show_anti_phishing_verification);
        parcel.writeString(this.url);
        parcel.writeString(this.country_code);
        parcel.writeString(getNickname());
    }

    public LoginCheckDto(@NotNull Parcel parcel) {
        this();
        this.email = parcel.readString();
        this.email_encrypted = parcel.readString();
        this.phone = parcel.readString();
        this.phone_encrypted = parcel.readString();
        this.password = parcel.readString();
        this.sms_id = parcel.readString();
        this.show_sms = parcel.readString();
        this.show_totp = parcel.readString();
        this.show_email_code = parcel.readString();
        this.show_webauthn = parcel.readString();
        this.anti_phishing_code = parcel.readString();
        this.show_anti_phishing_verification = parcel.readString();
        this.url = parcel.readString();
        this.country_code = parcel.readString();
        this.nickname = parcel.readString();
    }
}