package com.gateio.biz.account.service.model;

import com.gateio.common.tool.StringUtils;
import com.gateio.lib.encrypt.GTEncrypt;
import com.gateio.lib.storage.GTStorage;
import com.gateio.lib.storage.annotation.GTStorageClass;
import com.gateio.lib.storage.annotation.GTStorageGroup;
import com.gateio.lib.storage.protocol.IGTStorageObject;
import io.realm.annotations.Ignore;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.RealmClass;
import io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface;
import io.realm.internal.RealmObjectProxy;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;

@GTStorageClass(group = GTStorageGroup.Account)
@RealmClass
/* loaded from: classes4.dex */
public class UserInfo implements IGTStorageObject, com_gateio_biz_account_service_model_UserInfoRealmProxyInterface {
    private String CUID;

    @Ignore
    private String agencyType;
    private String anonymous;
    private String avatar;
    private String btr;
    private String companyAuthStatus;
    private String compliance_type;
    private String countryCode;
    private String countryId;
    private String email;
    private String email_tail;
    private int flag;
    private int float_rate;
    private String googleAuth;
    private String hasDMOVEWithdraw;
    private int have_sub;
    private String hide_asserts;
    private String identityAuthMemo;
    private String identityAuthStatus;
    private String invite_code;
    private int isChangeSub;
    private String isHadSecurePassword;
    private boolean isQuickLogin;
    private String isSub;
    private boolean is_host;
    private int is_nft_avatar;
    private String is_online;
    private String kyc3Status;
    private String livenessStatus;
    private String loginDoubleAuth;
    private String loginDoubleConfig;
    private String loginTimest;
    private String main_uid;
    private String moments_token;
    private String moments_user_role;
    private String needPushTest;
    private String nick;
    private String nick_en;
    private String pnumber;
    private String pnumber_tail;
    private String pver;
    private String pver_ws;
    private String realName;
    private String regTimest;
    private int residenceCountryId;
    private String safePwdPeriod;
    private String tier;
    private String timId;
    private String token;

    @PrimaryKey
    private String userId;
    private String userName;
    private String user_verified;
    private String vip_tier;
    private int webauthnStatus;

    public void setLoginTimest() {
        realmSet$loginTimest(String.valueOf(System.currentTimeMillis() / 1000));
    }

    public String getAgencyType() {
        return this.agencyType;
    }

    public boolean isCompanyAuth() {
        return StringUtils.equals("1", realmGet$companyAuthStatus());
    }

    public boolean isIdentityAuth() {
        return StringUtils.equals("2", realmGet$identityAuthStatus());
    }

    public boolean isKyc2() {
        return StringUtils.equals("1", realmGet$livenessStatus());
    }

    public boolean isNotIdentityAuth() {
        return (StringUtils.equals("1", realmGet$identityAuthStatus()) || StringUtils.equals("2", realmGet$identityAuthStatus())) ? false : true;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$CUID() {
        return this.CUID;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$anonymous() {
        return this.anonymous;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$avatar() {
        return this.avatar;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$btr() {
        return this.btr;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$companyAuthStatus() {
        return this.companyAuthStatus;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$compliance_type() {
        return this.compliance_type;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$countryCode() {
        return this.countryCode;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$countryId() {
        return this.countryId;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$email() {
        return this.email;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$email_tail() {
        return this.email_tail;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public int realmGet$flag() {
        return this.flag;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public int realmGet$float_rate() {
        return this.float_rate;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$googleAuth() {
        return this.googleAuth;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$hasDMOVEWithdraw() {
        return this.hasDMOVEWithdraw;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public int realmGet$have_sub() {
        return this.have_sub;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$hide_asserts() {
        return this.hide_asserts;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$identityAuthMemo() {
        return this.identityAuthMemo;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$identityAuthStatus() {
        return this.identityAuthStatus;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$invite_code() {
        return this.invite_code;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public int realmGet$isChangeSub() {
        return this.isChangeSub;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$isHadSecurePassword() {
        return this.isHadSecurePassword;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public boolean realmGet$isQuickLogin() {
        return this.isQuickLogin;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$isSub() {
        return this.isSub;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public boolean realmGet$is_host() {
        return this.is_host;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public int realmGet$is_nft_avatar() {
        return this.is_nft_avatar;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$is_online() {
        return this.is_online;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$kyc3Status() {
        return this.kyc3Status;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$livenessStatus() {
        return this.livenessStatus;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$loginDoubleAuth() {
        return this.loginDoubleAuth;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$loginDoubleConfig() {
        return this.loginDoubleConfig;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$loginTimest() {
        return this.loginTimest;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$main_uid() {
        return this.main_uid;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$moments_token() {
        return this.moments_token;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$moments_user_role() {
        return this.moments_user_role;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$needPushTest() {
        return this.needPushTest;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$nick() {
        return this.nick;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$nick_en() {
        return this.nick_en;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$pnumber() {
        return this.pnumber;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$pnumber_tail() {
        return this.pnumber_tail;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$pver() {
        return this.pver;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$pver_ws() {
        return this.pver_ws;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$realName() {
        return this.realName;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$regTimest() {
        return this.regTimest;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public int realmGet$residenceCountryId() {
        return this.residenceCountryId;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$safePwdPeriod() {
        return this.safePwdPeriod;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$tier() {
        return this.tier;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$timId() {
        return this.timId;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$token() {
        return this.token;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$userId() {
        return this.userId;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$userName() {
        return this.userName;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$user_verified() {
        return this.user_verified;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public String realmGet$vip_tier() {
        return this.vip_tier;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public int realmGet$webauthnStatus() {
        return this.webauthnStatus;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$CUID(String str) {
        this.CUID = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$anonymous(String str) {
        this.anonymous = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$avatar(String str) {
        this.avatar = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$btr(String str) {
        this.btr = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$companyAuthStatus(String str) {
        this.companyAuthStatus = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$compliance_type(String str) {
        this.compliance_type = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$countryCode(String str) {
        this.countryCode = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$countryId(String str) {
        this.countryId = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$email(String str) {
        this.email = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$email_tail(String str) {
        this.email_tail = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$flag(int i10) {
        this.flag = i10;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$float_rate(int i10) {
        this.float_rate = i10;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$googleAuth(String str) {
        this.googleAuth = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$hasDMOVEWithdraw(String str) {
        this.hasDMOVEWithdraw = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$have_sub(int i10) {
        this.have_sub = i10;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$hide_asserts(String str) {
        this.hide_asserts = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$identityAuthMemo(String str) {
        this.identityAuthMemo = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$identityAuthStatus(String str) {
        this.identityAuthStatus = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$invite_code(String str) {
        this.invite_code = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$isChangeSub(int i10) {
        this.isChangeSub = i10;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$isHadSecurePassword(String str) {
        this.isHadSecurePassword = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$isQuickLogin(boolean z10) {
        this.isQuickLogin = z10;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$isSub(String str) {
        this.isSub = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$is_host(boolean z10) {
        this.is_host = z10;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$is_nft_avatar(int i10) {
        this.is_nft_avatar = i10;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$is_online(String str) {
        this.is_online = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$kyc3Status(String str) {
        this.kyc3Status = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$livenessStatus(String str) {
        this.livenessStatus = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$loginDoubleAuth(String str) {
        this.loginDoubleAuth = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$loginDoubleConfig(String str) {
        this.loginDoubleConfig = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$loginTimest(String str) {
        this.loginTimest = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$main_uid(String str) {
        this.main_uid = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$moments_token(String str) {
        this.moments_token = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$moments_user_role(String str) {
        this.moments_user_role = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$needPushTest(String str) {
        this.needPushTest = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$nick(String str) {
        this.nick = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$nick_en(String str) {
        this.nick_en = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$pnumber(String str) {
        this.pnumber = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$pnumber_tail(String str) {
        this.pnumber_tail = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$pver(String str) {
        this.pver = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$pver_ws(String str) {
        this.pver_ws = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$realName(String str) {
        this.realName = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$regTimest(String str) {
        this.regTimest = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$residenceCountryId(int i10) {
        this.residenceCountryId = i10;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$safePwdPeriod(String str) {
        this.safePwdPeriod = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$tier(String str) {
        this.tier = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$timId(String str) {
        this.timId = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$token(String str) {
        this.token = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$userId(String str) {
        this.userId = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$userName(String str) {
        this.userName = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$user_verified(String str) {
        this.user_verified = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$vip_tier(String str) {
        this.vip_tier = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxyInterface
    public void realmSet$webauthnStatus(int i10) {
        this.webauthnStatus = i10;
    }

    public void setAgencyType(String str) {
        this.agencyType = str;
    }

    public void setLoginTimest(String str) {
        realmSet$loginTimest(str);
    }

    public String toString() {
        return "UserInfo{token='" + realmGet$token() + "', is_online='" + realmGet$is_online() + "', userId='" + realmGet$userId() + "', anonymous='" + realmGet$anonymous() + "', userName='" + realmGet$userName() + "', pnumber='" + realmGet$pnumber() + "', email='" + realmGet$email() + "', emial_tail='" + realmGet$email_tail() + "', btr='" + realmGet$btr() + "', isHadSecurePassword='" + realmGet$isHadSecurePassword() + "', safePwdPeriod='" + realmGet$safePwdPeriod() + "', realName='" + realmGet$realName() + "', googleAuth='" + realmGet$googleAuth() + "', loginDoubleAuth='" + realmGet$loginDoubleAuth() + "', identityAuthStatus='" + realmGet$identityAuthStatus() + "', livenessStatus='" + realmGet$livenessStatus() + "', companyAuthStatus='" + realmGet$companyAuthStatus() + "', identityAuthMemo='" + realmGet$identityAuthMemo() + "', countryCode='" + realmGet$countryCode() + "', hasDMOVEWithdraw='" + realmGet$hasDMOVEWithdraw() + "', needPushTest='" + realmGet$needPushTest() + "', hide_asserts='" + realmGet$hide_asserts() + "', pver_ws='" + realmGet$pver_ws() + "', countryId='" + realmGet$countryId() + "', regTimest='" + realmGet$regTimest() + "', nick='" + realmGet$nick() + "', avatar='" + realmGet$avatar() + "', moments_token='" + realmGet$moments_token() + "', timId='" + realmGet$timId() + "', loginDoubleConfig='" + realmGet$loginDoubleConfig() + "', moments_user_role='" + realmGet$moments_user_role() + "', is_host=" + realmGet$is_host() + ", float_rate=" + realmGet$float_rate() + ", isSub='" + realmGet$isSub() + "', isQuickLogin=" + realmGet$isQuickLogin() + ", tier=" + realmGet$tier() + "', vip_tier=" + realmGet$vip_tier() + "', main_uid=" + realmGet$main_uid() + "', have_sub=" + realmGet$have_sub() + "', isChangeSub=" + realmGet$isChangeSub() + "', flag=" + realmGet$flag() + "', pnumber_tail=" + realmGet$flag() + '\'' + AbstractJsonLexerKt.END_OBJ;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public UserInfo() {
        if (this instanceof RealmObjectProxy) {
            ((RealmObjectProxy) this).realm$injectObjectContext();
        }
        realmSet$isChangeSub(0);
        realmSet$flag(0);
    }

    public String getAnonymous() {
        return realmGet$anonymous();
    }

    public String getAvatar() {
        return realmGet$avatar();
    }

    public String getBtr() {
        return realmGet$btr();
    }

    public String getCUID() {
        return realmGet$CUID();
    }

    public String getCompanyAuthStatus() {
        return realmGet$companyAuthStatus();
    }

    public String getCompliance_type() {
        return realmGet$compliance_type();
    }

    public String getCountryCode() {
        return realmGet$countryCode();
    }

    public String getCountryId() {
        return realmGet$countryId();
    }

    public String getEmail() {
        return realmGet$email();
    }

    public String getEmail_tail() {
        return realmGet$email_tail();
    }

    public int getFlag() {
        return realmGet$flag();
    }

    public int getFloat_rate() {
        return realmGet$float_rate();
    }

    public String getGoogleAuth() {
        return realmGet$googleAuth();
    }

    public String getHasDMOVEWithdraw() {
        return realmGet$hasDMOVEWithdraw();
    }

    public int getHave_sub() {
        return realmGet$have_sub();
    }

    public String getHide_asserts() {
        return realmGet$hide_asserts();
    }

    public String getIdentityAuthMemo() {
        return realmGet$identityAuthMemo();
    }

    public String getIdentityAuthStatus() {
        return realmGet$identityAuthStatus();
    }

    public String getInvite_code() {
        return realmGet$invite_code();
    }

    public int getIsChangeSub() {
        return realmGet$isChangeSub();
    }

    public String getIsHadSecurePassword() {
        return realmGet$isHadSecurePassword();
    }

    public String getIsSub() {
        return realmGet$isSub();
    }

    public String getIs_online() {
        return realmGet$is_online();
    }

    public String getKyc3Status() {
        return realmGet$kyc3Status();
    }

    public String getLivenessStatus() {
        return realmGet$livenessStatus();
    }

    public String getLoginDoubleAuth() {
        return realmGet$loginDoubleAuth();
    }

    public String getLoginDoubleConfig() {
        return realmGet$loginDoubleConfig();
    }

    public String getLoginTimest() {
        return realmGet$loginTimest();
    }

    public String getMain_uid() {
        return realmGet$main_uid();
    }

    public String getMoments_token() {
        return realmGet$moments_token();
    }

    public String getMoments_user_role() {
        return realmGet$moments_user_role();
    }

    public String getNeedPushTest() {
        return realmGet$needPushTest();
    }

    public String getNick() {
        return realmGet$nick();
    }

    public String getNick_en() {
        return realmGet$nick_en();
    }

    public String getPnumber() {
        return realmGet$pnumber();
    }

    public String getPnumber_tail() {
        return realmGet$pnumber_tail();
    }

    public String getPver() {
        return realmGet$pver();
    }

    public String getPver_ws() {
        return realmGet$pver_ws();
    }

    public String getRealName() {
        return realmGet$realName();
    }

    public String getRegTimest() {
        return realmGet$regTimest();
    }

    public int getResidenceCountryId() {
        return realmGet$residenceCountryId();
    }

    public String getSafePwdPeriod() {
        return realmGet$safePwdPeriod();
    }

    public String getTier() {
        return realmGet$tier();
    }

    public String getTimId() {
        return realmGet$timId();
    }

    public String getToken() {
        return realmGet$token();
    }

    public String getUserId() {
        return realmGet$userId();
    }

    public String getUserName() {
        return realmGet$userName();
    }

    public String getUser_verified() {
        return realmGet$user_verified();
    }

    public String getVip_tier() {
        return realmGet$vip_tier();
    }

    public int getWebauthnStatus() {
        return realmGet$webauthnStatus();
    }

    public boolean isIs_host() {
        return realmGet$is_host();
    }

    public boolean isNftAvatar() {
        if (realmGet$is_nft_avatar() == 1) {
            return true;
        }
        return false;
    }

    public boolean isQuickLogin() {
        return realmGet$isQuickLogin();
    }

    public void setAnonymous(String str) {
        realmSet$anonymous(str);
    }

    public void setAvatar(String str) {
        realmSet$avatar(str);
    }

    public void setBtr(String str) {
        realmSet$btr(str);
    }

    public void setCUID(String str) {
        realmSet$CUID(str);
    }

    public void setCompanyAuthStatus(String str) {
        realmSet$companyAuthStatus(str);
    }

    public void setCompliance_type(String str) {
        realmSet$compliance_type(str);
    }

    public void setCountryCode(String str) {
        realmSet$countryCode(str);
    }

    public void setCountryId(String str) {
        realmSet$countryId(str);
    }

    public void setEmail(String str) {
        realmSet$email(str);
    }

    public void setEmail_tail(String str) {
        realmSet$email_tail(str);
    }

    public void setFlag(int i10) {
        realmSet$flag(i10);
    }

    public void setFloat_rate(int i10) {
        realmSet$float_rate(i10);
    }

    public void setGoogleAuth(String str) {
        realmSet$googleAuth(str);
    }

    public void setHasDMOVEWithdraw(String str) {
        realmSet$hasDMOVEWithdraw(str);
    }

    public void setHave_sub(int i10) {
        realmSet$have_sub(i10);
    }

    public void setHide_asserts(String str) {
        realmSet$hide_asserts(str);
    }

    public void setIdentityAuthMemo(String str) {
        realmSet$identityAuthMemo(str);
    }

    public void setIdentityAuthStatus(String str) {
        realmSet$identityAuthStatus(str);
    }

    public void setInvite_code(String str) {
        realmSet$invite_code(str);
    }

    public void setIsChangeSub(int i10) {
        realmSet$isChangeSub(i10);
    }

    public void setIsHadSecurePassword(String str) {
        realmSet$isHadSecurePassword(str);
    }

    public void setIsSub(String str) {
        realmSet$isSub(str);
    }

    public void setIs_host(boolean z10) {
        realmSet$is_host(z10);
    }

    public void setIs_online(String str) {
        realmSet$is_online(str);
    }

    public void setKyc3Status(String str) {
        realmSet$kyc3Status(str);
    }

    public void setLivenessStatus(String str) {
        realmSet$livenessStatus(str);
    }

    public void setLoginDoubleAuth(String str) {
        realmSet$loginDoubleAuth(str);
    }

    public void setLoginDoubleConfig(String str) {
        realmSet$loginDoubleConfig(str);
    }

    public void setMain_uid(String str) {
        realmSet$main_uid(str);
    }

    public void setMoments_token(String str) {
        realmSet$moments_token(str);
        GTStorage.saveKV("user_moments_token_encry", GTEncrypt.DESEncrypt(realmGet$token()));
    }

    public void setMoments_user_role(String str) {
        realmSet$moments_user_role(str);
        GTStorage.saveKV("user_moments_user_role_encry", GTEncrypt.DESEncrypt(realmGet$token()));
    }

    public void setNeedPushTest(String str) {
        realmSet$needPushTest(str);
    }

    public void setNftAvatar(boolean z10) {
        realmSet$is_nft_avatar(z10 ? 1 : 0);
    }

    public void setNick(String str) {
        realmSet$nick(str);
    }

    public void setNick_en(String str) {
        realmSet$nick_en(str);
    }

    public void setPnumber(String str) {
        realmSet$pnumber(str);
    }

    public void setPnumber_tail(String str) {
        realmSet$pnumber_tail(str);
    }

    public void setPver(String str) {
        realmSet$pver(str);
    }

    public void setPver_ws(String str) {
        realmSet$pver_ws(str);
    }

    public void setQuickLogin(boolean z10) {
        realmSet$isQuickLogin(z10);
    }

    public void setRealName(String str) {
        realmSet$realName(str);
    }

    public void setRegTimest(String str) {
        realmSet$regTimest(str);
    }

    public void setResidenceCountryId(int i10) {
        realmSet$residenceCountryId(i10);
    }

    public void setSafePwdPeriod(String str) {
        realmSet$safePwdPeriod(str);
    }

    public void setTier(String str) {
        realmSet$tier(str);
    }

    public void setTimId(String str) {
        realmSet$timId(str);
        GTStorage.saveKV("user_tim_id_encry", GTEncrypt.DESEncrypt(realmGet$token()));
    }

    public void setToken(String str) {
        realmSet$token(str);
        GTStorage.saveKV("line_new", GTEncrypt.DESEncrypt(str));
    }

    public void setUserId(String str) {
        realmSet$userId(str);
    }

    public void setUserName(String str) {
        realmSet$userName(str);
    }

    public void setUser_verified(String str) {
        realmSet$user_verified(str);
    }

    public void setVip_tier(String str) {
        realmSet$vip_tier(str);
    }

    public void setWebauthnStatus(int i10) {
        realmSet$webauthnStatus(i10);
    }
}