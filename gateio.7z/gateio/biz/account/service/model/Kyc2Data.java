package com.gateio.biz.account.service.model;

/* loaded from: classes4.dex */
public class Kyc2Data {
    private String address;
    private String city;
    private String memo;
    private String post_code;
    private String province;
    private String residence_country_id;
    private String residence_country_name;
    private String status;
    private String tips;

    public String getAddress() {
        return this.address;
    }

    public String getCity() {
        return this.city;
    }

    public String getMemo() {
        return this.memo;
    }

    public String getPost_code() {
        return this.post_code;
    }

    public String getProvince() {
        return this.province;
    }

    public String getResidence_country_id() {
        return this.residence_country_id;
    }

    public String getResidence_country_name() {
        return this.residence_country_name;
    }

    public String getStatus() {
        return this.status;
    }

    public String getTips() {
        return this.tips;
    }

    public void setAddress(String str) {
        this.address = str;
    }

    public void setCity(String str) {
        this.city = str;
    }

    public void setMemo(String str) {
        this.memo = str;
    }

    public void setPost_code(String str) {
        this.post_code = str;
    }

    public void setProvince(String str) {
        this.province = str;
    }

    public void setResidence_country_id(String str) {
        this.residence_country_id = str;
    }

    public void setResidence_country_name(String str) {
        this.residence_country_name = str;
    }

    public void setStatus(String str) {
        this.status = str;
    }

    public void setTips(String str) {
        this.tips = str;
    }
}