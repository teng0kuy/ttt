package com.gateio.biz.account.service.model;

/* loaded from: classes4.dex */
public class TestnetUserInfo {
    public String CUID;
    public int agencyType;
    public String avatar;
    public int btr;
    public int companyAuthStatus;
    public int compliance_type;
    public String countryCode;
    public int countryId;
    public String email;
    public String email_tail;
    public int googleAuth;
    public int hasDMOVEWithdraw;
    public int have_sub;
    public String identityAuthMemo;
    public int identityAuthStatus;
    public String invite_code;
    public int isHadSecurePassword;
    public int isSub;
    public boolean is_host;
    public int is_nft_avatar;
    public int is_sub;
    public int kyc3Status;
    public int livenessStatus;
    public int loginDoubleAuth;
    public int main_uid;
    public String moments_token;
    public int moments_user_role;
    public int needPushTest;
    public String nick;
    public String pnumber;
    public String pnumber_tail;
    public String pver;
    public String pver_ws;
    public String realName;
    public String regTimest;
    public int residenceCountryId;
    public int safePwdPeriod;
    public String timId;
    public String token;
    public int userId;
    public String userName;
    public int user_verified;
    public int vip_tier;
    public int webauthnStatus;

    public TestnetUserInfo() {
    }

    public TestnetUserInfo(UserInfo userInfo) {
        if (userInfo == null) {
            return;
        }
        this.token = userInfo.getToken();
        this.pver = userInfo.getPver();
        this.pver_ws = userInfo.getPver_ws();
        this.userId = toInt(userInfo.getUserId());
        this.CUID = userInfo.getCUID();
        this.userName = userInfo.getUserName();
        this.agencyType = toInt(userInfo.getAgencyType());
        this.pnumber = userInfo.getPnumber();
        this.pnumber_tail = userInfo.getPnumber_tail();
        this.countryCode = userInfo.getCountryCode();
        this.email = userInfo.getEmail();
        this.email_tail = userInfo.getEmail_tail();
        this.btr = toInt(userInfo.getBtr());
        this.isHadSecurePassword = toInt(userInfo.getIsHadSecurePassword());
        this.safePwdPeriod = toInt(userInfo.getSafePwdPeriod());
        this.realName = userInfo.getRealName();
        this.googleAuth = toInt(userInfo.getGoogleAuth());
        this.loginDoubleAuth = toInt(userInfo.getLoginDoubleAuth());
        this.identityAuthStatus = toInt(userInfo.getIdentityAuthStatus());
        this.livenessStatus = toInt(userInfo.getLivenessStatus());
        this.kyc3Status = toInt(userInfo.getKyc3Status());
        this.companyAuthStatus = toInt(userInfo.getCompanyAuthStatus());
        this.identityAuthMemo = userInfo.getIdentityAuthMemo();
        this.hasDMOVEWithdraw = toInt(userInfo.getHasDMOVEWithdraw());
        this.needPushTest = toInt(userInfo.getNeedPushTest());
        int i10 = toInt(userInfo.getIsSub());
        this.isSub = i10;
        this.is_sub = i10;
        this.countryId = toInt(userInfo.getCountryId());
        this.regTimest = userInfo.getRegTimest();
        this.nick = userInfo.getNick();
        this.avatar = userInfo.getAvatar();
        this.is_nft_avatar = userInfo.isNftAvatar() ? 1 : 0;
        this.moments_user_role = toInt(userInfo.getMoments_user_role());
        this.timId = userInfo.getTimId();
        this.moments_token = userInfo.getMoments_token();
        this.is_host = userInfo.isIs_host();
        this.user_verified = toInt(userInfo.getUser_verified());
        this.compliance_type = toInt(userInfo.getCompliance_type());
        this.vip_tier = toInt(userInfo.getVip_tier());
        this.main_uid = toInt(userInfo.getMain_uid());
        this.have_sub = userInfo.getHave_sub();
        this.invite_code = userInfo.getInvite_code();
        this.webauthnStatus = userInfo.getWebauthnStatus();
        this.residenceCountryId = userInfo.getResidenceCountryId();
    }

    private static int toInt(String str) {
        if (str != null && str.length() != 0) {
            try {
                return Integer.parseInt(str);
            } catch (Throwable unused) {
            }
        }
        return 0;
    }

    public String getToken() {
        return this.token;
    }

    public String getUid() {
        return String.valueOf(this.userId);
    }
}