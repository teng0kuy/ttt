package com.gateio.biz.account.service.model;

/* loaded from: classes4.dex */
public class KycHome {
    private String user_verified;

    public String getUser_verified() {
        return this.user_verified;
    }

    public void setUser_verified(String str) {
        this.user_verified = str;
    }
}