package com.gateio.biz.account.service.model;

/* loaded from: classes4.dex */
public class Login2Config {
    private String sms;
    private String totp;

    public String getSms() {
        return this.sms;
    }

    public String getTotp() {
        return this.totp;
    }

    public void setSms(String str) {
        this.sms = str;
    }

    public void setTotp(String str) {
        this.totp = str;
    }
}