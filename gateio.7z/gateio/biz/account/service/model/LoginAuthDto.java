package com.gateio.biz.account.service.model;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: LoginAuthDto.kt */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0017\n\u0002\u0018\u0002\n\u0002\b\n\b\u0016\u0018\u0000 62\u00020\u0001:\u000256B\u0005¢\u0006\u0002\u0010\u0002J\b\u00102\u001a\u0004\u0018\u00010\u0004J\u0006\u00103\u001a\u00020\u0010J\u0006\u00104\u001a\u00020\u0010R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001c\u0010\t\u001a\u0004\u0018\u00010\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000f\u0010\u0011\"\u0004\b\u0012\u0010\u0013R\u001c\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u0017\"\u0004\b\u0018\u0010\u0019R\u001c\u0010\u001a\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001b\u0010\u0006\"\u0004\b\u001c\u0010\bR\u001c\u0010\u001d\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001e\u0010\u0006\"\u0004\b\u001f\u0010\bR\u001c\u0010 \u001a\u0004\u0018\u00010\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b!\u0010\f\"\u0004\b\"\u0010\u000eR\u001c\u0010#\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b$\u0010\u0006\"\u0004\b%\u0010\bR\u001c\u0010&\u001a\u0004\u0018\u00010\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b'\u0010\f\"\u0004\b(\u0010\u000eR\u001c\u0010)\u001a\u0004\u0018\u00010\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b*\u0010\f\"\u0004\b+\u0010\u000eR\u001c\u0010,\u001a\u0004\u0018\u00010-X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b.\u0010/\"\u0004\b0\u00101¨\u00067"}, d2 = {"Lcom/gateio/biz/account/service/model/LoginAuthDto;", "", "()V", "account_unique_key", "", "getAccount_unique_key", "()Ljava/lang/String;", "setAccount_unique_key", "(Ljava/lang/String;)V", "email_result", "Lcom/gateio/biz/account/service/model/LoginAuthDto$CodeErrorDTO;", "getEmail_result", "()Lcom/gateio/biz/account/service/model/LoginAuthDto$CodeErrorDTO;", "setEmail_result", "(Lcom/gateio/biz/account/service/model/LoginAuthDto$CodeErrorDTO;)V", "isThirdLogin", "", "()Z", "setThirdLogin", "(Z)V", "login2", "Lcom/gateio/biz/account/service/model/LoginCheckDto;", "getLogin2", "()Lcom/gateio/biz/account/service/model/LoginCheckDto;", "setLogin2", "(Lcom/gateio/biz/account/service/model/LoginCheckDto;)V", "pver", "getPver", "setPver", "pver_ws", "getPver_ws", "setPver_ws", "sms_result", "getSms_result", "setSms_result", "token", "getToken", "setToken", "totp_result", "getTotp_result", "setTotp_result", "ukey_result", "getUkey_result", "setUkey_result", "userInfo", "Lcom/gateio/biz/account/service/model/UserInfo;", "getUserInfo", "()Lcom/gateio/biz/account/service/model/UserInfo;", "setUserInfo", "(Lcom/gateio/biz/account/service/model/UserInfo;)V", "getMessageForSingleVerify", "hasLogin", "needBind", "CodeErrorDTO", "Companion", "biz_account_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public class LoginAuthDto {

    @NotNull
    public static final String PAGE_DATA = "PAGE_DATA";

    @NotNull
    public static final String SENSE_DATA = "SENSE_DATA";

    @NotNull
    public static final String VERIFY_TYPE_EMAIL_FOR_LOGIN = "VERIFY_TYPE_EMAIL_FOR_LOGIN";

    @NotNull
    public static final String VERIFY_TYPE_GOOGLE = "VERIFY_TYPE_GOOGLE";

    @NotNull
    public static final String VERIFY_TYPE_PHONE_FOR_LOGIN = "VERIFY_TYPE_PHONE_FOR_LOGIN";

    @Nullable
    private String account_unique_key;

    @Nullable
    private CodeErrorDTO email_result;
    private boolean isThirdLogin;

    @Nullable
    private LoginCheckDto login2;

    @Nullable
    private String pver;

    @Nullable
    private String pver_ws;

    @Nullable
    private CodeErrorDTO sms_result;

    @Nullable
    private String token;

    @Nullable
    private CodeErrorDTO totp_result;

    @Nullable
    private CodeErrorDTO ukey_result;

    @Nullable
    private UserInfo userInfo;

    /* compiled from: LoginAuthDto.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\u0002\u0010\u0004R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/account/service/model/LoginAuthDto$CodeErrorDTO;", "", "message", "", "(Ljava/lang/String;)V", "getMessage", "()Ljava/lang/String;", "biz_account_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class CodeErrorDTO {

        @Nullable
        private final String message;

        @Nullable
        public final String getMessage() {
            return this.message;
        }

        public CodeErrorDTO(@Nullable String str) {
            this.message = str;
        }
    }

    @Nullable
    public final String getAccount_unique_key() {
        return this.account_unique_key;
    }

    @Nullable
    public final CodeErrorDTO getEmail_result() {
        return this.email_result;
    }

    @Nullable
    public final LoginCheckDto getLogin2() {
        return this.login2;
    }

    @Nullable
    public final String getMessageForSingleVerify() {
        CodeErrorDTO codeErrorDTO = this.sms_result;
        if (codeErrorDTO != null) {
            if (codeErrorDTO != null) {
                return codeErrorDTO.getMessage();
            }
            return null;
        }
        CodeErrorDTO codeErrorDTO2 = this.email_result;
        if (codeErrorDTO2 != null) {
            if (codeErrorDTO2 != null) {
                return codeErrorDTO2.getMessage();
            }
            return null;
        }
        CodeErrorDTO codeErrorDTO3 = this.totp_result;
        if (codeErrorDTO3 != null) {
            if (codeErrorDTO3 != null) {
                return codeErrorDTO3.getMessage();
            }
            return null;
        }
        CodeErrorDTO codeErrorDTO4 = this.ukey_result;
        if (codeErrorDTO4 == null) {
            return "";
        }
        if (codeErrorDTO4 != null) {
            return codeErrorDTO4.getMessage();
        }
        return null;
    }

    @Nullable
    public final String getPver() {
        return this.pver;
    }

    @Nullable
    public final String getPver_ws() {
        return this.pver_ws;
    }

    @Nullable
    public final CodeErrorDTO getSms_result() {
        return this.sms_result;
    }

    @Nullable
    public final String getToken() {
        return this.token;
    }

    @Nullable
    public final CodeErrorDTO getTotp_result() {
        return this.totp_result;
    }

    @Nullable
    public final CodeErrorDTO getUkey_result() {
        return this.ukey_result;
    }

    @Nullable
    public final UserInfo getUserInfo() {
        return this.userInfo;
    }

    public final boolean hasLogin() {
        if (this.userInfo == null) {
            return false;
        }
        String str = this.token;
        return !(str == null || str.length() == 0);
    }

    /* renamed from: isThirdLogin, reason: from getter */
    public final boolean getIsThirdLogin() {
        return this.isThirdLogin;
    }

    public final boolean needBind() {
        String str = this.account_unique_key;
        return !(str == null || str.length() == 0);
    }

    public final void setAccount_unique_key(@Nullable String str) {
        this.account_unique_key = str;
    }

    public final void setEmail_result(@Nullable CodeErrorDTO codeErrorDTO) {
        this.email_result = codeErrorDTO;
    }

    public final void setLogin2(@Nullable LoginCheckDto loginCheckDto) {
        this.login2 = loginCheckDto;
    }

    public final void setPver(@Nullable String str) {
        this.pver = str;
    }

    public final void setPver_ws(@Nullable String str) {
        this.pver_ws = str;
    }

    public final void setSms_result(@Nullable CodeErrorDTO codeErrorDTO) {
        this.sms_result = codeErrorDTO;
    }

    public final void setThirdLogin(boolean z10) {
        this.isThirdLogin = z10;
    }

    public final void setToken(@Nullable String str) {
        this.token = str;
    }

    public final void setTotp_result(@Nullable CodeErrorDTO codeErrorDTO) {
        this.totp_result = codeErrorDTO;
    }

    public final void setUkey_result(@Nullable CodeErrorDTO codeErrorDTO) {
        this.ukey_result = codeErrorDTO;
    }

    public final void setUserInfo(@Nullable UserInfo userInfo) {
        this.userInfo = userInfo;
    }
}