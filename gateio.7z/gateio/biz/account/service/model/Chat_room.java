package com.gateio.biz.account.service.model;

/* loaded from: classes4.dex */
public class Chat_room {
    private String accountType;
    private String roomId;
    private String sdkAppID;

    public String getAccountType() {
        return this.accountType;
    }

    public String getRoomId() {
        return this.roomId;
    }

    public String getSdkAppID() {
        return this.sdkAppID;
    }

    public void setAccountType(String str) {
        this.accountType = str;
    }

    public void setRoomId(String str) {
        this.roomId = str;
    }

    public void setSdkAppID(String str) {
        this.sdkAppID = str;
    }

    public String toString() {
        return "chartRoom :{,accountType :" + this.accountType + " ,roomId: " + this.roomId + ",sdkAppID: " + this.sdkAppID + "}";
    }
}