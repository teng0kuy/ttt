package com.gateio.biz.account.service.model;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes4.dex */
public class LivenessBizToken implements Parcelable {
    public static final Parcelable.Creator<LivenessBizToken> CREATOR = new Parcelable.Creator<LivenessBizToken>() { // from class: com.gateio.biz.account.service.model.LivenessBizToken.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LivenessBizToken createFromParcel(Parcel parcel) {
            return new LivenessBizToken(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public LivenessBizToken[] newArray(int i10) {
            return new LivenessBizToken[i10];
        }
    };
    private String applicantId;
    private String country;
    private String host;
    private String id_type;
    private String liveness_type;
    private String token;
    private String type;

    public LivenessBizToken() {
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    protected LivenessBizToken(Parcel parcel) {
        this.token = parcel.readString();
        this.type = parcel.readString();
        this.host = parcel.readString();
        this.liveness_type = parcel.readString();
    }

    public String getApplicantId() {
        return this.applicantId;
    }

    public String getCountry() {
        return this.country;
    }

    public String getHost() {
        return this.host;
    }

    public String getId_type() {
        return this.id_type;
    }

    public String getLiveness_type() {
        return this.liveness_type;
    }

    public String getToken() {
        return this.token;
    }

    public String getType() {
        return this.type;
    }

    public void setApplicantId(String str) {
        this.applicantId = str;
    }

    public void setCountry(String str) {
        this.country = str;
    }

    public void setHost(String str) {
        this.host = str;
    }

    public void setId_type(String str) {
        this.id_type = str;
    }

    public void setLiveness_type(String str) {
        this.liveness_type = str;
    }

    public void setToken(String str) {
        this.token = str;
    }

    public void setType(String str) {
        this.type = str;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeString(this.token);
        parcel.writeString(this.type);
        parcel.writeString(this.host);
        parcel.writeString(this.liveness_type);
    }

    public void readFromParcel(Parcel parcel) {
        this.token = parcel.readString();
        this.type = parcel.readString();
        this.host = parcel.readString();
        this.liveness_type = parcel.readString();
    }
}