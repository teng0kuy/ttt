package com.gateio.biz.account.service.model;

/* loaded from: classes4.dex */
public class RegisterResult {
    private Chat_room chat_room;
    private LivenessBizToken liveness;
    private String pver;
    private String pver_ws;
    private String sms;
    private String token;
    private String totp;
    private UserInfo userInfo;

    public Chat_room getChatroom() {
        return this.chat_room;
    }

    public LivenessBizToken getLiveness() {
        return this.liveness;
    }

    public String getPver() {
        return this.pver;
    }

    public String getPver_ws() {
        return this.pver_ws;
    }

    public String getSms() {
        return this.sms;
    }

    public String getToken() {
        return this.token;
    }

    public String getTotp() {
        return this.totp;
    }

    public UserInfo getUserInfo() {
        return this.userInfo;
    }

    public void setChatroom(Chat_room chat_room) {
        this.chat_room = chat_room;
    }

    public void setLiveness(LivenessBizToken livenessBizToken) {
        this.liveness = livenessBizToken;
    }

    public void setPver(String str) {
        this.pver = str;
    }

    public void setPver_ws(String str) {
        this.pver_ws = str;
    }

    public void setSms(String str) {
        this.sms = str;
    }

    public void setToken(String str) {
        this.token = str;
    }

    public void setTotp(String str) {
        this.totp = str;
    }

    public void setUserInfo(UserInfo userInfo) {
        this.userInfo = userInfo;
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("token=" + this.token);
        if (this.userInfo != null) {
            stringBuffer.append(" userInfo:" + this.userInfo.toString());
        }
        Chat_room chat_room = this.chat_room;
        if (chat_room != null) {
            stringBuffer.append(chat_room.toString());
        }
        return stringBuffer.toString();
    }
}