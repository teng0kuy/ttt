package com.gateio.biz.account.service.model;

/* loaded from: classes4.dex */
public class Kyc1Data {
    private String LN_tips;
    private String country_id;
    private String country_name;
    private String id_number;
    private String memo;
    private String realname_ex;
    private String residence_country_id;
    private String residence_country_name;
    private String status;
    private String tips;

    public String getCountry_id() {
        return this.country_id;
    }

    public String getCountry_name() {
        return this.country_name;
    }

    public String getId_number() {
        return this.id_number;
    }

    public String getLN_tips() {
        return this.LN_tips;
    }

    public String getMemo() {
        return this.memo;
    }

    public String getRealname_ex() {
        return this.realname_ex;
    }

    public String getResidence_country_id() {
        return this.residence_country_id;
    }

    public String getResidence_country_name() {
        return this.residence_country_name;
    }

    public String getStatus() {
        return this.status;
    }

    public String getTips() {
        return this.tips;
    }

    public void setCountry_id(String str) {
        this.country_id = str;
    }

    public void setCountry_name(String str) {
        this.country_name = str;
    }

    public void setId_number(String str) {
        this.id_number = str;
    }

    public void setLN_tips(String str) {
        this.LN_tips = str;
    }

    public void setMemo(String str) {
        this.memo = str;
    }

    public void setRealname_ex(String str) {
        this.realname_ex = str;
    }

    public void setResidence_country_id(String str) {
        this.residence_country_id = str;
    }

    public void setResidence_country_name(String str) {
        this.residence_country_name = str;
    }

    public void setStatus(String str) {
        this.status = str;
    }

    public void setTips(String str) {
        this.tips = str;
    }
}