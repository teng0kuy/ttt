package com.gateio.biz.account.service.model;

/* loaded from: classes4.dex */
public class KycComplianceTip {
    private String tips;
    private String type;

    public String getTips() {
        return this.tips;
    }

    public String getType() {
        return this.type;
    }

    public void setTips(String str) {
        this.tips = str;
    }

    public void setType(String str) {
        this.type = str;
    }
}