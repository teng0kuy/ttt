package com.gateio.biz.account.service.model;

import com.gateio.lib.storage.annotation.GTStorageClass;
import com.gateio.lib.storage.annotation.GTStorageGroup;
import com.gateio.lib.storage.protocol.IGTStorageObject;
import io.realm.annotations.Ignore;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.RealmClass;
import io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface;
import io.realm.internal.RealmObjectProxy;

@GTStorageClass(group = GTStorageGroup.Account)
@RealmClass
/* loaded from: classes4.dex */
public class TierInfo implements IGTStorageObject, com_gateio_biz_account_service_model_TierInfoRealmProxyInterface {
    private String asset_btc;
    private String asset_cny;
    private String asset_idr;
    private String asset_krw;
    private String asset_usdt;
    private String asset_vnd;
    private String discount;

    @Ignore
    private String futures_trade_btc;

    @Ignore
    private String futures_trade_cny;

    @Ignore
    private String futures_trade_krw;

    @Ignore
    private String futures_trade_usdt;
    private int level;
    private String maker_discount;
    private String next_btc;
    private String next_cny;
    private String next_idr;
    private String next_krw;
    private String next_progress;
    private String next_usdt;
    private String next_vnd;

    @Ignore
    private TierInfo tierInfo;
    private String tier_next_gt_min;
    private String tier_next_gt_only;
    private long time;
    private String trade_btc;
    private String trade_cny;
    private String trade_idr;
    private String trade_krw;
    private String trade_usdt;
    private String trade_vnd;

    @Ignore
    private String[] upgrade_emphasis;

    @Ignore
    private String upgrade_info;

    @Ignore
    private String upgrade_vip_trade_btc;

    @Ignore
    private String upgrade_vip_trade_cny;

    @Ignore
    private String upgrade_vip_trade_krw;

    @Ignore
    private String upgrade_vip_trade_usdt;

    @PrimaryKey
    private String userId;

    public String getFutures_trade_btc() {
        return this.futures_trade_btc;
    }

    public String getFutures_trade_cny() {
        return this.futures_trade_cny;
    }

    public String getFutures_trade_krw() {
        return this.futures_trade_krw;
    }

    public String getFutures_trade_usdt() {
        String str = this.futures_trade_usdt;
        return str == null ? "-" : str;
    }

    public TierInfo getTierInfo() {
        return this.tierInfo;
    }

    public String[] getUpgrade_emphasis() {
        return this.upgrade_emphasis;
    }

    public String getUpgrade_info() {
        return this.upgrade_info;
    }

    public String getUpgrade_vip_trade_btc() {
        return this.upgrade_vip_trade_btc;
    }

    public String getUpgrade_vip_trade_cny() {
        return this.upgrade_vip_trade_cny;
    }

    public String getUpgrade_vip_trade_krw() {
        return this.upgrade_vip_trade_krw;
    }

    public String getUpgrade_vip_trade_usdt() {
        return this.upgrade_vip_trade_usdt;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$asset_btc() {
        return this.asset_btc;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$asset_cny() {
        return this.asset_cny;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$asset_idr() {
        return this.asset_idr;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$asset_krw() {
        return this.asset_krw;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$asset_usdt() {
        return this.asset_usdt;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$asset_vnd() {
        return this.asset_vnd;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$discount() {
        return this.discount;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public int realmGet$level() {
        return this.level;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$maker_discount() {
        return this.maker_discount;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$next_btc() {
        return this.next_btc;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$next_cny() {
        return this.next_cny;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$next_idr() {
        return this.next_idr;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$next_krw() {
        return this.next_krw;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$next_progress() {
        return this.next_progress;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$next_usdt() {
        return this.next_usdt;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$next_vnd() {
        return this.next_vnd;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$tier_next_gt_min() {
        return this.tier_next_gt_min;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$tier_next_gt_only() {
        return this.tier_next_gt_only;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public long realmGet$time() {
        return this.time;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$trade_btc() {
        return this.trade_btc;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$trade_cny() {
        return this.trade_cny;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$trade_idr() {
        return this.trade_idr;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$trade_krw() {
        return this.trade_krw;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$trade_usdt() {
        return this.trade_usdt;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$trade_vnd() {
        return this.trade_vnd;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public String realmGet$userId() {
        return this.userId;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$asset_btc(String str) {
        this.asset_btc = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$asset_cny(String str) {
        this.asset_cny = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$asset_idr(String str) {
        this.asset_idr = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$asset_krw(String str) {
        this.asset_krw = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$asset_usdt(String str) {
        this.asset_usdt = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$asset_vnd(String str) {
        this.asset_vnd = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$discount(String str) {
        this.discount = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$level(int i10) {
        this.level = i10;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$maker_discount(String str) {
        this.maker_discount = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$next_btc(String str) {
        this.next_btc = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$next_cny(String str) {
        this.next_cny = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$next_idr(String str) {
        this.next_idr = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$next_krw(String str) {
        this.next_krw = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$next_progress(String str) {
        this.next_progress = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$next_usdt(String str) {
        this.next_usdt = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$next_vnd(String str) {
        this.next_vnd = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$tier_next_gt_min(String str) {
        this.tier_next_gt_min = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$tier_next_gt_only(String str) {
        this.tier_next_gt_only = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$time(long j10) {
        this.time = j10;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$trade_btc(String str) {
        this.trade_btc = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$trade_cny(String str) {
        this.trade_cny = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$trade_idr(String str) {
        this.trade_idr = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$trade_krw(String str) {
        this.trade_krw = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$trade_usdt(String str) {
        this.trade_usdt = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$trade_vnd(String str) {
        this.trade_vnd = str;
    }

    @Override // io.realm.com_gateio_biz_account_service_model_TierInfoRealmProxyInterface
    public void realmSet$userId(String str) {
        this.userId = str;
    }

    public void setFutures_trade_btc(String str) {
        this.futures_trade_btc = str;
    }

    public void setFutures_trade_cny(String str) {
        this.futures_trade_cny = str;
    }

    public void setFutures_trade_krw(String str) {
        this.futures_trade_krw = str;
    }

    public void setFutures_trade_usdt(String str) {
        this.futures_trade_usdt = str;
    }

    public void setTierInfo(TierInfo tierInfo) {
        this.tierInfo = tierInfo;
    }

    public void setUpgrade_emphasis(String[] strArr) {
        this.upgrade_emphasis = strArr;
    }

    public void setUpgrade_info(String str) {
        this.upgrade_info = str;
    }

    public void setUpgrade_vip_trade_btc(String str) {
        this.upgrade_vip_trade_btc = str;
    }

    public void setUpgrade_vip_trade_cny(String str) {
        this.upgrade_vip_trade_cny = str;
    }

    public void setUpgrade_vip_trade_krw(String str) {
        this.upgrade_vip_trade_krw = str;
    }

    public void setUpgrade_vip_trade_usdt(String str) {
        this.upgrade_vip_trade_usdt = str;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public TierInfo() {
        if (this instanceof RealmObjectProxy) {
            ((RealmObjectProxy) this).realm$injectObjectContext();
        }
    }

    public String getAsset_btc() {
        return realmGet$asset_btc();
    }

    public String getAsset_cny() {
        return realmGet$asset_cny();
    }

    public String getAsset_idr() {
        return realmGet$asset_idr();
    }

    public String getAsset_krw() {
        return realmGet$asset_krw();
    }

    public String getAsset_usdt() {
        return realmGet$asset_usdt();
    }

    public String getAsset_vnd() {
        return realmGet$asset_vnd();
    }

    public String getDiscount() {
        return realmGet$discount();
    }

    public int getLevel() {
        if (realmGet$level() < 0) {
            return 0;
        }
        return realmGet$level();
    }

    public String getMaker_discount() {
        return realmGet$maker_discount();
    }

    public String getNext_btc() {
        return realmGet$next_btc();
    }

    public String getNext_cny() {
        return realmGet$next_cny();
    }

    public String getNext_idr() {
        return realmGet$next_idr();
    }

    public String getNext_krw() {
        return realmGet$next_krw();
    }

    public String getNext_progress() {
        return realmGet$next_progress();
    }

    public String getNext_usdt() {
        return realmGet$next_usdt();
    }

    public String getNext_vnd() {
        return realmGet$next_vnd();
    }

    public String getTier_next_gt_min() {
        if (realmGet$tier_next_gt_min() == null) {
            return "--";
        }
        return realmGet$tier_next_gt_min();
    }

    public String getTier_next_gt_only() {
        if (realmGet$tier_next_gt_only() == null) {
            return "--";
        }
        return realmGet$tier_next_gt_only();
    }

    public long getTime() {
        return realmGet$time();
    }

    public String getTrade_btc() {
        return realmGet$trade_btc();
    }

    public String getTrade_cny() {
        return realmGet$trade_cny();
    }

    public String getTrade_idr() {
        return realmGet$trade_idr();
    }

    public String getTrade_krw() {
        return realmGet$trade_krw();
    }

    public String getTrade_usdt() {
        return realmGet$trade_usdt();
    }

    public String getTrade_vnd() {
        return realmGet$trade_vnd();
    }

    public String getUserId() {
        return realmGet$userId();
    }

    public void setAsset_btc(String str) {
        realmSet$asset_btc(str);
    }

    public void setAsset_cny(String str) {
        realmSet$asset_cny(str);
    }

    public void setAsset_idr(String str) {
        realmSet$asset_idr(str);
    }

    public void setAsset_krw(String str) {
        realmSet$asset_krw(str);
    }

    public void setAsset_usdt(String str) {
        realmSet$asset_usdt(str);
    }

    public void setAsset_vnd(String str) {
        realmSet$asset_vnd(str);
    }

    public void setDiscount(String str) {
        realmSet$discount(str);
    }

    public void setLevel(int i10) {
        realmSet$level(i10);
    }

    public void setMaker_discount(String str) {
        realmSet$maker_discount(str);
    }

    public void setNext_btc(String str) {
        realmSet$next_btc(str);
    }

    public void setNext_cny(String str) {
        realmSet$next_cny(str);
    }

    public void setNext_idr(String str) {
        realmSet$next_idr(str);
    }

    public void setNext_krw(String str) {
        realmSet$next_krw(str);
    }

    public void setNext_progress(String str) {
        realmSet$next_progress(str);
    }

    public void setNext_usdt(String str) {
        realmSet$next_usdt(str);
    }

    public void setNext_vnd(String str) {
        realmSet$next_vnd(str);
    }

    public void setTier_next_gt_min(String str) {
        realmSet$tier_next_gt_min(str);
    }

    public void setTier_next_gt_only(String str) {
        realmSet$tier_next_gt_only(str);
    }

    public void setTime(long j10) {
        realmSet$time(j10);
    }

    public void setTrade_btc(String str) {
        realmSet$trade_btc(str);
    }

    public void setTrade_cny(String str) {
        realmSet$trade_cny(str);
    }

    public void setTrade_idr(String str) {
        realmSet$trade_idr(str);
    }

    public void setTrade_krw(String str) {
        realmSet$trade_krw(str);
    }

    public void setTrade_usdt(String str) {
        realmSet$trade_usdt(str);
    }

    public void setTrade_vnd(String str) {
        realmSet$trade_vnd(str);
    }

    public void setUserId(String str) {
        realmSet$userId(str);
    }
}