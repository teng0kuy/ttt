package com.gateio.biz.account.service.model;

import java.util.Map;

/* loaded from: classes4.dex */
public class LoginResult {
    public Map<String, Object> compliance_module;
    private Login2Lnfo login2;
    private String pver;
    private String pver_ws;
    private String token;
    private UserInfo userInfo;
    public String website_app_type;

    public String getCuid() {
        UserInfo userInfo = this.userInfo;
        return userInfo == null ? "" : userInfo.getCUID();
    }

    public Login2Lnfo getLogin2() {
        return this.login2;
    }

    public String getPver() {
        return this.pver;
    }

    public String getPver_ws() {
        return this.pver_ws;
    }

    public String getToken() {
        return this.token;
    }

    public UserInfo getUserInfo() {
        return this.userInfo;
    }

    public void setLogin2(Login2Lnfo login2Lnfo) {
        this.login2 = login2Lnfo;
    }

    public void setPver(String str) {
        this.pver = str;
    }

    public void setPver_ws(String str) {
        this.pver_ws = str;
    }

    public void setToken(String str) {
        this.token = str;
    }

    public void setUserInfo(UserInfo userInfo) {
        this.userInfo = userInfo;
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("token=" + this.token);
        if (this.login2 != null) {
            stringBuffer.append(" login2:" + this.login2.toString());
        }
        if (this.userInfo != null) {
            stringBuffer.append(" userInfo:" + this.userInfo.toString());
        }
        return stringBuffer.toString();
    }
}