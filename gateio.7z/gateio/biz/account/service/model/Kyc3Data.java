package com.gateio.biz.account.service.model;

/* loaded from: classes4.dex */
public class Kyc3Data {
    private String memo;
    private String status;
    private String tips;

    public String getMemo() {
        return this.memo;
    }

    public String getStatus() {
        return this.status;
    }

    public String getTips() {
        return this.tips;
    }

    public void setMemo(String str) {
        this.memo = str;
    }

    public void setStatus(String str) {
        this.status = str;
    }

    public void setTips(String str) {
        this.tips = str;
    }
}