package com.gateio.biz.account.service.model;

import androidx.annotation.Keep;
import com.gateio.lib.storage.annotation.GTStorageGroup;
import com.gateio.lib.storage.protocol.IGTStorageProxy;
import java.util.ArrayList;

@Keep
/* loaded from: classes4.dex */
public class TierInfo_Proxy extends IGTStorageProxy<TierInfo> {
    private ArrayList<String> filedOfRealmTypeClassList;
    private TierInfo realObj;

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public int getProxyVersion() {
        return 2;
    }

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public boolean isHavePrimaryKey() {
        return true;
    }

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public boolean isHaveRealmType() {
        return true;
    }

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public String getPrimaryKeyFieldName() {
        return "userId";
    }

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public String getPrimaryKeyValue() {
        return this.realObj.getUserId();
    }

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public TierInfo getRealObj() {
        return this.realObj;
    }

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public ArrayList<String> getRealmTypeClassList() {
        if (this.filedOfRealmTypeClassList == null) {
            ArrayList<String> arrayList = new ArrayList<>();
            this.filedOfRealmTypeClassList = arrayList;
            arrayList.add("com.gateio.biz.account.service.model.TierInfo");
        }
        return this.filedOfRealmTypeClassList;
    }

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public GTStorageGroup getStorageGroup() {
        return GTStorageGroup.Account;
    }

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public void setRealObj(TierInfo tierInfo) {
        this.realObj = tierInfo;
    }
}