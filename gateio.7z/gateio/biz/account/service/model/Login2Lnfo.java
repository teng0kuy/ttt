package com.gateio.biz.account.service.model;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes4.dex */
public class Login2Lnfo implements Parcelable {
    public static final Parcelable.Creator<Login2Lnfo> CREATOR = new Parcelable.Creator<Login2Lnfo>() { // from class: com.gateio.biz.account.service.model.Login2Lnfo.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public Login2Lnfo createFromParcel(Parcel parcel) {
            return new Login2Lnfo(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public Login2Lnfo[] newArray(int i10) {
            return new Login2Lnfo[i10];
        }
    };
    private String email;
    private String email_tail;
    private boolean isBind;
    private String password;
    private String show_email_code;
    private String show_sms;
    private String show_totp;
    private String show_webauthn;
    private String unique_id;
    private String userId;
    private String userName;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String getEmail() {
        return this.email;
    }

    public String getEmail_tail() {
        return this.email_tail;
    }

    public String getPassword() {
        return this.password;
    }

    public String getShow_email_code() {
        return this.show_email_code;
    }

    public String getShow_sms() {
        return this.show_sms;
    }

    public String getShow_totp() {
        return this.show_totp;
    }

    public String getShow_webauthn() {
        return this.show_webauthn;
    }

    public String getUnique_id() {
        return this.unique_id;
    }

    public String getUserId() {
        return this.userId;
    }

    public String getUserName() {
        return this.userName;
    }

    public boolean isBind() {
        return this.isBind;
    }

    public void setBind(boolean z10) {
        this.isBind = z10;
    }

    public void setEmail(String str) {
        this.email = str;
    }

    public void setEmail_tail(String str) {
        this.email_tail = str;
    }

    public void setPassword(String str) {
        this.password = str;
    }

    public void setShow_email_code(String str) {
        this.show_email_code = str;
    }

    public void setShow_sms(String str) {
        this.show_sms = str;
    }

    public void setShow_totp(String str) {
        this.show_totp = str;
    }

    public void setShow_webauthn(String str) {
        this.show_webauthn = str;
    }

    public void setUnique_id(String str) {
        this.unique_id = str;
    }

    public void setUserId(String str) {
        this.userId = str;
    }

    public void setUserName(String str) {
        this.userName = str;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeString(this.userId);
        parcel.writeString(this.userName);
        parcel.writeString(this.password);
        parcel.writeString(this.show_email_code);
        parcel.writeString(this.show_totp);
        parcel.writeString(this.show_sms);
        parcel.writeString(this.show_webauthn);
        parcel.writeString(this.email_tail);
        parcel.writeString(this.unique_id);
        parcel.writeString(this.email);
        parcel.writeByte(this.isBind ? (byte) 1 : (byte) 0);
    }

    protected Login2Lnfo(Parcel parcel) {
        boolean z10;
        this.userId = parcel.readString();
        this.userName = parcel.readString();
        this.password = parcel.readString();
        this.show_email_code = parcel.readString();
        this.show_totp = parcel.readString();
        this.show_sms = parcel.readString();
        this.show_webauthn = parcel.readString();
        this.email_tail = parcel.readString();
        this.unique_id = parcel.readString();
        this.email = parcel.readString();
        if (parcel.readByte() != 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        this.isBind = z10;
    }
}