package com.gateio.biz.account.service.model;

import com.gateio.common.tool.StringUtils;

/* loaded from: classes4.dex */
public class IdentityAuthStatus {
    private String companyAuthStatus;
    private String country_id;
    private String country_name;
    private String id_number;
    private String identityAuthMemo;
    private String identityAuthStatus;
    private String is_company;
    private String is_individual;
    private Kyc1Data kyc1Data;
    private Kyc2Data kyc2Data;
    private Kyc3Data kyc3Data;
    private String kyc3Status;
    private KycComplianceTip kycComplianceTip;
    private KycHome kycHome;
    private String livenessStatus;
    private String realname_ex;

    public String getCompanyAuthStatus() {
        return this.companyAuthStatus;
    }

    public String getCountry_id() {
        return this.country_id;
    }

    public String getCountry_name() {
        return this.country_name;
    }

    public String getId_number() {
        return this.id_number;
    }

    public String getIdentityAuthMemo() {
        return this.identityAuthMemo;
    }

    public String getIdentityAuthStatus() {
        return this.identityAuthStatus;
    }

    public String getIs_company() {
        return this.is_company;
    }

    public String getIs_individual() {
        return this.is_individual;
    }

    public Kyc1Data getKyc1Data() {
        return this.kyc1Data;
    }

    public Kyc2Data getKyc2Data() {
        return this.kyc2Data;
    }

    public Kyc3Data getKyc3Data() {
        return this.kyc3Data;
    }

    public String getKyc3Status() {
        return this.kyc3Status;
    }

    public KycComplianceTip getKycComplianceTip() {
        return this.kycComplianceTip;
    }

    public KycHome getKycHome() {
        return this.kycHome;
    }

    public String getLivenessStatus() {
        return this.livenessStatus;
    }

    public String getRealname_ex() {
        return this.realname_ex;
    }

    public boolean isCompanyAuth() {
        return StringUtils.equals("1", this.companyAuthStatus);
    }

    public boolean isIdentityAuth() {
        return StringUtils.equals("2", this.identityAuthStatus);
    }

    public boolean isKyc2() {
        return StringUtils.equals("1", this.livenessStatus);
    }

    public void setCompanyAuthStatus(String str) {
        this.companyAuthStatus = str;
    }

    public void setCountry_id(String str) {
        this.country_id = str;
    }

    public void setCountry_name(String str) {
        this.country_name = str;
    }

    public void setId_number(String str) {
        this.id_number = str;
    }

    public void setIdentityAuthMemo(String str) {
        this.identityAuthMemo = str;
    }

    public void setIdentityAuthStatus(String str) {
        this.identityAuthStatus = str;
    }

    public void setIs_company(String str) {
        this.is_company = str;
    }

    public void setIs_individual(String str) {
        this.is_individual = str;
    }

    public void setKyc1Data(Kyc1Data kyc1Data) {
        this.kyc1Data = kyc1Data;
    }

    public void setKyc2Data(Kyc2Data kyc2Data) {
        this.kyc2Data = kyc2Data;
    }

    public void setKyc3Data(Kyc3Data kyc3Data) {
        this.kyc3Data = kyc3Data;
    }

    public void setKyc3Status(String str) {
        this.kyc3Status = str;
    }

    public void setKycComplianceTip(KycComplianceTip kycComplianceTip) {
        this.kycComplianceTip = kycComplianceTip;
    }

    public void setKycHome(KycHome kycHome) {
        this.kycHome = kycHome;
    }

    public void setLivenessStatus(String str) {
        this.livenessStatus = str;
    }

    public void setRealname_ex(String str) {
        this.realname_ex = str;
    }
}