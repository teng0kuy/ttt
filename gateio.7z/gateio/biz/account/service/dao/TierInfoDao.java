package com.gateio.biz.account.service.dao;

import com.gateio.biz.account.service.model.TierInfo;
import com.gateio.lib.storage.GTStorage;

/* loaded from: classes4.dex */
public class TierInfoDao {
    public static TierInfo getTierInfo(String str) {
        return (TierInfo) GTStorage.query(TierInfo.class).equalTo("userId", str).findFirst();
    }

    public static void setTierInfo(TierInfo tierInfo) {
        GTStorage.save(tierInfo);
    }
}