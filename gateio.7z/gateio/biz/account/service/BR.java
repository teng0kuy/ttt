package com.gateio.biz.account.service;

/* loaded from: classes4.dex */
public class BR {
    public static final int _all = 0;
}