package com.gateio.biz.account.realm;

import com.gateio.lib.storage.realm.GTRealmMigration;
import com.pichillilorenzo.flutter_inappwebview_android.credential_database.URLProtectionSpaceContract;
import com.tencent.qcloud.tuicore.TUIConstants;
import io.realm.DynamicRealm;
import io.realm.FieldAttribute;
import io.realm.RealmObjectSchema;
import io.realm.RealmSchema;
import io.realm.com_gateio_biz_account_service_model_UserInfoRealmProxy;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* compiled from: AccountRealmMigration.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\b\u0016\u0018\u0000 \n2\u00020\u0001:\u0001\nB\u0005¢\u0006\u0002\u0010\u0002J \u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\bH\u0014¨\u0006\u000b"}, d2 = {"Lcom/gateio/biz/account/realm/AccountRealmMigration;", "Lcom/gateio/lib/storage/realm/GTRealmMigration;", "()V", "customMigrate", "", URLProtectionSpaceContract.FeedEntry.COLUMN_NAME_REALM, "Lio/realm/DynamicRealm;", "oldVersion", "", "newVersion", "Companion", "biz_account_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public class AccountRealmMigration extends GTRealmMigration {
    public static final long schemaVersion = 11;

    @Override // com.gateio.lib.storage.realm.GTRealmMigration
    protected void customMigrate(@NotNull DynamicRealm realm, long oldVersion, long newVersion) {
        RealmObjectSchema realmObjectSchema;
        RealmSchema schema = realm.getSchema();
        if (oldVersion < 2) {
            RealmObjectSchema realmObjectSchema2 = schema.get(com_gateio_biz_account_service_model_UserInfoRealmProxy.ClassNameHelper.INTERNAL_CLASS_NAME);
            if (realmObjectSchema2 != null) {
                realmObjectSchema2.addField("pver", String.class, new FieldAttribute[0]);
            }
            oldVersion++;
        }
        if (oldVersion < 3) {
            RealmObjectSchema realmObjectSchema3 = schema.get(com_gateio_biz_account_service_model_UserInfoRealmProxy.ClassNameHelper.INTERNAL_CLASS_NAME);
            if (realmObjectSchema3 != null) {
                realmObjectSchema3.addField("user_verified", String.class, new FieldAttribute[0]);
            }
            oldVersion++;
        }
        if (oldVersion < 4) {
            RealmObjectSchema realmObjectSchema4 = schema.get(com_gateio_biz_account_service_model_UserInfoRealmProxy.ClassNameHelper.INTERNAL_CLASS_NAME);
            if (realmObjectSchema4 != null) {
                realmObjectSchema4.addField("compliance_type", String.class, new FieldAttribute[0]);
            }
            oldVersion++;
        }
        if (oldVersion < 5) {
            RealmObjectSchema realmObjectSchema5 = schema.get(com_gateio_biz_account_service_model_UserInfoRealmProxy.ClassNameHelper.INTERNAL_CLASS_NAME);
            if (realmObjectSchema5 != null) {
                realmObjectSchema5.addField("invite_code", String.class, new FieldAttribute[0]);
            }
            oldVersion++;
        }
        if (oldVersion < 6) {
            RealmObjectSchema realmObjectSchema6 = schema.get(com_gateio_biz_account_service_model_UserInfoRealmProxy.ClassNameHelper.INTERNAL_CLASS_NAME);
            if (realmObjectSchema6 != null) {
                realmObjectSchema6.addField("tier", String.class, new FieldAttribute[0]);
            }
            oldVersion++;
        }
        if (oldVersion < 7) {
            RealmObjectSchema realmObjectSchema7 = schema.get(com_gateio_biz_account_service_model_UserInfoRealmProxy.ClassNameHelper.INTERNAL_CLASS_NAME);
            if (realmObjectSchema7 != null) {
                realmObjectSchema7.addField("vip_tier", String.class, new FieldAttribute[0]);
            }
            if (realmObjectSchema7 != null) {
                realmObjectSchema7.addField("main_uid", String.class, new FieldAttribute[0]);
            }
            if (realmObjectSchema7 != null) {
                realmObjectSchema7.addField("have_sub", Integer.TYPE, new FieldAttribute[0]);
            }
            if (realmObjectSchema7 != null) {
                realmObjectSchema7.addField("isChangeSub", Integer.TYPE, new FieldAttribute[0]);
            }
            if (realmObjectSchema7 != null) {
                realmObjectSchema7.addField("flag", Integer.TYPE, new FieldAttribute[0]);
            }
            oldVersion++;
        }
        if (oldVersion < 8) {
            RealmObjectSchema realmObjectSchema8 = schema.get(com_gateio_biz_account_service_model_UserInfoRealmProxy.ClassNameHelper.INTERNAL_CLASS_NAME);
            if (realmObjectSchema8 != null) {
                realmObjectSchema8.addField("webauthnStatus", Integer.TYPE, new FieldAttribute[0]);
            }
            oldVersion++;
        }
        if (oldVersion < 9) {
            RealmObjectSchema realmObjectSchema9 = schema.get(com_gateio_biz_account_service_model_UserInfoRealmProxy.ClassNameHelper.INTERNAL_CLASS_NAME);
            if (realmObjectSchema9 != null) {
                realmObjectSchema9.addField("residenceCountryId", Integer.TYPE, new FieldAttribute[0]);
            }
            oldVersion++;
        }
        if (oldVersion < 10) {
            RealmObjectSchema realmObjectSchema10 = schema.get(com_gateio_biz_account_service_model_UserInfoRealmProxy.ClassNameHelper.INTERNAL_CLASS_NAME);
            if (realmObjectSchema10 != null) {
                realmObjectSchema10.addField(TUIConstants.TUIPollPlugin.PLUGIN_POLL_ANONYMOUS, String.class, new FieldAttribute[0]);
            }
            oldVersion++;
        }
        if (oldVersion < 11 && (realmObjectSchema = schema.get(com_gateio_biz_account_service_model_UserInfoRealmProxy.ClassNameHelper.INTERNAL_CLASS_NAME)) != null) {
            realmObjectSchema.addField("pnumber_tail", String.class, new FieldAttribute[0]);
        }
    }
}