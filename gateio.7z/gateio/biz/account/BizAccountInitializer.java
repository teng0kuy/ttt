package com.gateio.biz.account;

import android.app.Application;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import org.jetbrains.annotations.NotNull;

/* compiled from: BizAccountInitializer.kt */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0018\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0003\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\nH\u0007R\u001a\u0010\u0003\u001a\u00020\u0004X\u0080.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001a\u0010\t\u001a\u00020\nX\u0080\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000e¨\u0006\u0011"}, d2 = {"Lcom/gateio/biz/account/BizAccountInitializer;", "", "()V", "context", "Landroid/app/Application;", "getContext$biz_account_release", "()Landroid/app/Application;", "setContext$biz_account_release", "(Landroid/app/Application;)V", "isDebug", "", "isDebug$biz_account_release", "()Z", "setDebug$biz_account_release", "(Z)V", "init", "", "biz_account_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class BizAccountInitializer {

    @NotNull
    public static final BizAccountInitializer INSTANCE = new BizAccountInitializer();
    public static Application context;
    private static boolean isDebug;

    private BizAccountInitializer() {
    }

    @JvmStatic
    public static final void init(@NotNull Application context2, boolean isDebug2) {
        INSTANCE.setContext$biz_account_release(context2);
        isDebug = isDebug2;
    }

    @NotNull
    public final Application getContext$biz_account_release() {
        Application application = context;
        if (application != null) {
            return application;
        }
        return null;
    }

    public final boolean isDebug$biz_account_release() {
        return isDebug;
    }

    public final void setContext$biz_account_release(@NotNull Application application) {
        context = application;
    }

    public final void setDebug$biz_account_release(boolean z10) {
        isDebug = z10;
    }
}