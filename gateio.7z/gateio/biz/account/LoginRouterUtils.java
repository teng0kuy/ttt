package com.gateio.biz.account;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import com.gate.subconfig.AppConfigHelper;
import com.gate.subconfig.GTSubConfig;
import com.gate.subconfig.SharedConstants;
import com.gate.subconfig.data.Feature;
import com.gate.subconfig.data.Module;
import com.gateio.biz.base.router.RouterConst;
import com.gateio.biz.safe.service.router.provider.SafeApi;
import com.gateio.fiatotclib.function.order.block.BlockActivity;
import com.gateio.flutter.lib_furnace.GTFlutter;
import com.gateio.flutter.lib_furnace.GTFlutterBuilder;
import com.gateio.lib.core.GTCoreApplication;
import com.gateio.lib.router.GTRouter;
import java.util.HashMap;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: LoginRouterUtils.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\u0018\u0000 \u00032\u00020\u0001:\u0001\u0003B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0004"}, d2 = {"Lcom/gateio/biz/account/LoginRouterUtils;", "", "()V", "Companion", "biz_account_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class LoginRouterUtils {

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    /* compiled from: LoginRouterUtils.kt */
    @Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\b\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0002J0\u0010\u0005\u001a\u00020\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\b2\u0006\u0010\t\u001a\u00020\n2\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\n2\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\nJJ\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\b\b\u0002\u0010\u0011\u001a\u00020\u00042\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u0012\u001a\u00020\u00042\b\b\u0002\u0010\u000b\u001a\u00020\n2\b\b\u0002\u0010\f\u001a\u00020\n2\b\b\u0002\u0010\u0013\u001a\u00020\nJ@\u0010\u0014\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\b\b\u0002\u0010\u0011\u001a\u00020\u00042\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\n2\b\b\u0002\u0010\f\u001a\u00020\n2\b\b\u0002\u0010\u0013\u001a\u00020\nJ@\u0010\u0015\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\b\b\u0002\u0010\u0011\u001a\u00020\u00042\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u0016\u001a\u00020\n2\b\b\u0002\u0010\f\u001a\u00020\n2\b\b\u0002\u0010\u0013\u001a\u00020\nJ \u0010\u0017\u001a\u00020\u000e2\u0006\u0010\u0007\u001a\u00020\b2\b\u0010\t\u001a\u0004\u0018\u00010\n2\u0006\u0010\u0018\u001a\u00020\u0019J,\u0010\u001a\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\b\b\u0002\u0010\u000b\u001a\u00020\n2\b\b\u0002\u0010\f\u001a\u00020\n2\b\b\u0002\u0010\u001b\u001a\u00020\n¨\u0006\u001c"}, d2 = {"Lcom/gateio/biz/account/LoginRouterUtils$Companion;", "", "()V", "getIsShowGateLogin", "", "getLoginIntent", "Landroid/content/Intent;", "activity", "Landroid/app/Activity;", BlockActivity.USER_NAME, "", "refUid", "refType", "showCommonLoginFlutter", "", "context", "Landroid/content/Context;", "newTask", "fromSocial", "isAddAccount", "showLoginFlutter", "showLoginFlutterBySocialRef", "refSocialUid", "showLoginFlutterForResult", "requestCode", "", "showSignUpFlutter", "ch", "biz_account_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final void showLoginFlutter(@NotNull Context context, boolean newTask, @NotNull String userName, @NotNull String refUid, @NotNull String refType, @NotNull String isAddAccount) {
            showCommonLoginFlutter(context, newTask, userName, false, refUid, refType, isAddAccount);
        }

        public final void showLoginFlutterBySocialRef(@NotNull Context context, boolean newTask, @NotNull String userName, @NotNull String refSocialUid, @NotNull String refType, @NotNull String isAddAccount) {
            showCommonLoginFlutter(context, newTask, userName, true, refSocialUid, refType, isAddAccount);
        }

        private final boolean getIsShowGateLogin() {
            Feature featureConfig;
            Feature featureConfig2;
            AppConfigHelper appConfigHelperInstance = GTSubConfig.INSTANCE.getAppConfigHelperInstance();
            Module moduleConfig = appConfigHelperInstance.getModuleConfig(SharedConstants.ModuleConstants.MODULE_ACCOUNT);
            if (moduleConfig == null || (featureConfig = appConfigHelperInstance.getFeatureConfig(moduleConfig, "login")) == null || (featureConfig2 = appConfigHelperInstance.getFeatureConfig(featureConfig, SharedConstants.FeatureModuleAccountConstants.FEATURE_LOGIN_GATE_AUTH)) == null) {
                return false;
            }
            return featureConfig2.getEnabled();
        }

        public static /* synthetic */ Intent getLoginIntent$default(Companion companion, Activity activity, String str, String str2, String str3, int i10, Object obj) {
            if ((i10 & 4) != 0) {
                str2 = "";
            }
            if ((i10 & 8) != 0) {
                str3 = "";
            }
            return companion.getLoginIntent(activity, str, str2, str3);
        }

        public static /* synthetic */ void showLoginFlutter$default(Companion companion, Context context, boolean z10, String str, String str2, String str3, String str4, int i10, Object obj) {
            if ((i10 & 2) != 0) {
                z10 = false;
            }
            boolean z11 = z10;
            String str5 = (i10 & 4) != 0 ? "" : str;
            String str6 = (i10 & 8) != 0 ? "" : str2;
            String str7 = (i10 & 16) != 0 ? "" : str3;
            if ((i10 & 32) != 0) {
                str4 = "0";
            }
            companion.showLoginFlutter(context, z11, str5, str6, str7, str4);
        }

        public static /* synthetic */ void showLoginFlutterBySocialRef$default(Companion companion, Context context, boolean z10, String str, String str2, String str3, String str4, int i10, Object obj) {
            if ((i10 & 2) != 0) {
                z10 = false;
            }
            boolean z11 = z10;
            String str5 = (i10 & 4) != 0 ? "" : str;
            String str6 = (i10 & 8) != 0 ? "" : str2;
            String str7 = (i10 & 16) != 0 ? "" : str3;
            if ((i10 & 32) != 0) {
                str4 = "0";
            }
            companion.showLoginFlutterBySocialRef(context, z11, str5, str6, str7, str4);
        }

        public static /* synthetic */ void showSignUpFlutter$default(Companion companion, Context context, String str, String str2, String str3, int i10, Object obj) {
            if ((i10 & 2) != 0) {
                str = "";
            }
            if ((i10 & 4) != 0) {
                str2 = "";
            }
            if ((i10 & 8) != 0) {
                str3 = "";
            }
            companion.showSignUpFlutter(context, str, str2, str3);
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r4v4, types: [android.content.Context] */
        @NotNull
        public final Intent getLoginIntent(@Nullable Activity activity, @NotNull String userName, @Nullable String refUid, @Nullable String refType) {
            String str = ((SafeApi) GTRouter.serviceAPI(RouterConst.Safe.PROVIDER_SAFE)).isDeviceSupported(activity != null ? activity : GTCoreApplication.INSTANCE.getAppContext()) ? "1" : "0";
            HashMap map = new HashMap();
            map.put("qridLoginDeviceEnable", str);
            map.put("loginType", "username");
            map.put("account", userName);
            if (refUid == null) {
                refUid = "";
            }
            map.put("ref_uid", refUid);
            if (refType == null) {
                refType = "";
            }
            map.put("ref_type", refType);
            GTFlutterBuilder gTFlutterBuilderSinglePage = GTFlutter.withRouterName(RouterConst.Flutter.LOGIN_CONTAINER).routeParams(map).singlePage();
            Activity appContext = activity;
            if (activity == null) {
                appContext = GTCoreApplication.INSTANCE.getAppContext();
            }
            return gTFlutterBuilderSinglePage.createIntent(appContext);
        }

        public final void showCommonLoginFlutter(@NotNull Context context, boolean newTask, @NotNull String userName, boolean fromSocial, @NotNull String refUid, @NotNull String refType, @NotNull String isAddAccount) {
            HashMap map = new HashMap();
            SafeApi safeApi = (SafeApi) GTRouter.serviceAPI(RouterConst.Safe.PROVIDER_SAFE);
            map.put("qridLoginDeviceEnable", safeApi != null && safeApi.isDeviceSupported(context) ? "1" : "0");
            map.put("isShowGateLogin", getIsShowGateLogin() ? "1" : "0");
            if (userName.length() > 0) {
                map.put("loginType", "username");
                map.put("account", userName);
            }
            if (fromSocial) {
                map.put("ref_social_uid", refUid);
            } else {
                map.put("ref_uid", refUid);
            }
            map.put("ref_type", refType);
            map.put("isAddAccount", isAddAccount);
            GTFlutterBuilder gTFlutterBuilderSinglePage = GTFlutter.withRouterName(RouterConst.Flutter.LOGIN_CONTAINER).routeParams(map).singlePage();
            if (newTask) {
                gTFlutterBuilderSinglePage.addFlags(268435456);
            }
            gTFlutterBuilderSinglePage.openPage(context);
        }

        /* JADX WARN: Removed duplicated region for block: B:24:0x0057  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final void showLoginFlutterForResult(@org.jetbrains.annotations.NotNull android.app.Activity r8, @org.jetbrains.annotations.Nullable java.lang.String r9, int r10) {
            /*
                r7 = this;
                java.util.HashMap r0 = new java.util.HashMap
                r0.<init>()
                java.lang.String r1 = "/safe/provider/safe"
                java.lang.Object r1 = com.gateio.lib.router.GTRouter.serviceAPI(r1)
                com.gateio.biz.safe.service.router.provider.SafeApi r1 = (com.gateio.biz.safe.service.router.provider.SafeApi) r1
                r2 = 1
                r3 = 0
                if (r1 == 0) goto L1a
                boolean r1 = r1.isDeviceSupported(r8)
                if (r1 != r2) goto L1a
                r1 = r2
                goto L1b
            L1a:
                r1 = r3
            L1b:
                java.lang.String r4 = "1"
                java.lang.String r5 = "0"
                if (r1 == 0) goto L25
                r1 = r4
                goto L26
            L25:
                r1 = r5
            L26:
                java.lang.String r6 = "qridLoginDeviceEnable"
                r0.put(r6, r1)
                boolean r1 = r7.getIsShowGateLogin()
                if (r1 == 0) goto L33
                goto L34
            L33:
                r4 = r5
            L34:
                java.lang.String r1 = "isShowGateLogin"
                r0.put(r1, r4)
                java.lang.String r1 = "/account/login"
                com.gateio.flutter.lib_furnace.GTFlutterBuilder r1 = com.gateio.flutter.lib_furnace.GTFlutter.withRouterName(r1)
                com.gateio.flutter.lib_furnace.GTFlutterBuilder r1 = r1.routeParams(r0)
                com.gateio.flutter.lib_furnace.GTFlutterBuilder r1 = r1.singlePage()
                if (r9 == 0) goto L57
                int r4 = r9.length()
                if (r4 <= 0) goto L53
                r4 = r2
                goto L54
            L53:
                r4 = r3
            L54:
                if (r4 != r2) goto L57
                goto L58
            L57:
                r2 = r3
            L58:
                if (r2 == 0) goto L69
                java.lang.String r2 = "loginType"
                java.lang.String r3 = "username"
                r0.put(r2, r3)
                java.lang.String r2 = "account"
                r0.put(r2, r9)
            L69:
                r1.openPageForResult(r8, r10)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.gateio.biz.account.LoginRouterUtils.Companion.showLoginFlutterForResult(android.app.Activity, java.lang.String, int):void");
        }

        public final void showSignUpFlutter(@NotNull Context context, @NotNull String refUid, @NotNull String refType, @NotNull String ch) {
            HashMap map = new HashMap();
            SafeApi safeApi = (SafeApi) GTRouter.serviceAPI(RouterConst.Safe.PROVIDER_SAFE);
            boolean z10 = false;
            if (safeApi != null && safeApi.isDeviceSupported(context)) {
                z10 = true;
            }
            map.put("qridLoginDeviceEnable", z10 ? "1" : "0");
            map.put("isShowGateLogin", getIsShowGateLogin() ? "1" : "0");
            GTFlutterBuilder gTFlutterBuilderSinglePage = GTFlutter.withRouterName(RouterConst.Flutter.REGISTER_CONTAINER).routeParams(map).singlePage();
            map.put("ref_uid", refUid);
            map.put("ref_type", refType);
            map.put("ch", ch);
            gTFlutterBuilderSinglePage.openPage(context);
        }
    }
}