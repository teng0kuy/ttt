package com.gateio.biz.base.nps.expression;

import com.gateio.biz.base.model.CastSettingUserInfo;
import com.gateio.biz.base.nps.CastSettingCondition;
import com.gateio.common.tool.LocalUtils;
import com.xiaomi.mipush.sdk.Constants;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt__StringsKt;
import org.apache.commons.codec.language.bm.Languages;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: CastSettingRuleExpression.kt */
@Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\u0018\u00002\u00020\u00012\u00020\u0002B\u000f\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004¢\u0006\u0002\u0010\u0005J \u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\rH\u0002J\b\u0010\u0010\u001a\u00020\u000bH\u0016J\u0010\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0014H\u0016R\u0013\u0010\u0003\u001a\u0004\u0018\u00010\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\b\u001a\u0004\u0018\u00010\tX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0015"}, d2 = {"Lcom/gateio/biz/base/nps/expression/CastSettingRuleExpression;", "Lcom/gateio/biz/base/nps/expression/RuleExpression;", "Lcom/gateio/biz/base/nps/expression/Recorder;", "mCastSettingBean", "Lcom/gateio/biz/base/model/CastSettingUserInfo;", "(Lcom/gateio/biz/base/model/CastSettingUserInfo;)V", "getMCastSettingBean", "()Lcom/gateio/biz/base/model/CastSettingUserInfo;", "mCastSettingCondition", "Lcom/gateio/biz/base/nps/CastSettingCondition;", "containsOperator", "", "left", "", "right", "operator", "evaluate", "record", "", Languages.ANY, "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class CastSettingRuleExpression implements RuleExpression, Recorder {

    @Nullable
    private final CastSettingUserInfo mCastSettingBean;

    @Nullable
    private CastSettingCondition mCastSettingCondition;

    private final boolean containsOperator(String left, String right, String operator) {
        List listSplit$default = StringsKt__StringsKt.split$default((CharSequence) right, new String[]{Constants.ACCEPT_TIME_SEPARATOR_SP}, false, 0, 6, (Object) null);
        if (Intrinsics.areEqual(operator, LocalUtils.IN)) {
            return listSplit$default.contains(left);
        }
        if (Intrinsics.areEqual(operator, "exclude")) {
            return !listSplit$default.contains(left);
        }
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:25:0x0090  */
    @Override // com.gateio.biz.base.nps.expression.RuleExpression
    /* renamed from: evaluate */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean getResult() {
        /*
            r7 = this;
            com.gateio.biz.base.nps.CastSettingCondition r0 = r7.mCastSettingCondition
            r1 = 0
            if (r0 != 0) goto L6
            return r1
        L6:
            com.gateio.biz.base.model.CastSettingUserInfo r2 = r7.mCastSettingBean
            r3 = 1
            if (r2 != 0) goto Lc
            return r3
        Lc:
            com.gateio.biz.base.model.UserLevel r4 = r2.getUserLevel()
            if (r4 == 0) goto L90
            com.gateio.biz.base.model.UserLevel r4 = r2.getUserLevel()
            java.lang.String r4 = r4.getOperator()
            if (r4 == 0) goto L25
            int r4 = r4.length()
            if (r4 != 0) goto L23
            goto L25
        L23:
            r4 = r1
            goto L26
        L25:
            r4 = r3
        L26:
            if (r4 != 0) goto L90
            com.gateio.biz.base.model.UserLevel r4 = r2.getUserLevel()
            java.lang.String r4 = r4.getOperator()
            java.lang.String r5 = "in"
            boolean r4 = kotlin.jvm.internal.Intrinsics.areEqual(r4, r5)
            if (r4 != 0) goto L73
            com.gateio.biz.base.model.UserLevel r4 = r2.getUserLevel()
            java.lang.String r4 = r4.getOperator()
            java.lang.String r5 = "exclude"
            boolean r4 = kotlin.jvm.internal.Intrinsics.areEqual(r4, r5)
            if (r4 == 0) goto L4b
            goto L73
        L4b:
            com.gateio.biz.base.nps.expression.OperatorExpression r4 = new com.gateio.biz.base.nps.expression.OperatorExpression
            com.gateio.biz.base.model.UserLevel r5 = r2.getUserLevel()
            java.lang.String r5 = r5.getOperator()
            r4.<init>(r5)
            java.lang.String r5 = r0.getUserLevel()
            r4.setLeft(r5)
            com.gateio.biz.base.model.UserLevel r5 = r2.getUserLevel()
            java.lang.Integer r5 = r5.getValue()
            java.lang.String r5 = java.lang.String.valueOf(r5)
            r4.setRight(r5)
            boolean r4 = r4.getResult()
            goto L91
        L73:
            java.lang.String r4 = r0.getUserLevel()
            com.gateio.biz.base.model.UserLevel r5 = r2.getUserLevel()
            java.lang.Integer r5 = r5.getValue()
            java.lang.String r5 = java.lang.String.valueOf(r5)
            com.gateio.biz.base.model.UserLevel r6 = r2.getUserLevel()
            java.lang.String r6 = r6.getOperator()
            boolean r4 = r7.containsOperator(r4, r5, r6)
            goto L91
        L90:
            r4 = r3
        L91:
            if (r4 == 0) goto Lcb
            com.gateio.biz.base.model.Area r5 = r2.getArea()
            if (r5 == 0) goto Lcb
            com.gateio.biz.base.model.Area r5 = r2.getArea()
            java.lang.String r5 = r5.getOperator()
            if (r5 == 0) goto Lac
            int r5 = r5.length()
            if (r5 != 0) goto Laa
            goto Lac
        Laa:
            r5 = r1
            goto Lad
        Lac:
            r5 = r3
        Lad:
            if (r5 != 0) goto Lcb
            java.lang.String r4 = r0.getArea()
            com.gateio.biz.base.model.Area r5 = r2.getArea()
            java.lang.String r5 = r5.getValue()
            java.lang.String r5 = java.lang.String.valueOf(r5)
            com.gateio.biz.base.model.Area r6 = r2.getArea()
            java.lang.String r6 = r6.getOperator()
            boolean r4 = r7.containsOperator(r4, r5, r6)
        Lcb:
            if (r4 == 0) goto L102
            com.gateio.biz.base.model.AppVersion r5 = r2.getAppVersion()
            if (r5 == 0) goto L102
            com.gateio.biz.base.model.AppVersion r5 = r2.getAppVersion()
            java.lang.String r5 = r5.getOperator()
            if (r5 == 0) goto Le3
            int r5 = r5.length()
            if (r5 != 0) goto Le4
        Le3:
            r1 = r3
        Le4:
            if (r1 != 0) goto L102
            java.lang.String r0 = r0.getAppVersion()
            com.gateio.biz.base.model.AppVersion r1 = r2.getAppVersion()
            java.lang.String r1 = r1.getValue()
            java.lang.String r1 = java.lang.String.valueOf(r1)
            com.gateio.biz.base.model.AppVersion r2 = r2.getAppVersion()
            java.lang.String r2 = r2.getOperator()
            boolean r4 = r7.containsOperator(r0, r1, r2)
        L102:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.gateio.biz.base.nps.expression.CastSettingRuleExpression.getResult():boolean");
    }

    @Nullable
    public final CastSettingUserInfo getMCastSettingBean() {
        return this.mCastSettingBean;
    }

    @Override // com.gateio.biz.base.nps.expression.Recorder
    public void record(@NotNull Object any) {
        if (any instanceof CastSettingCondition) {
            this.mCastSettingCondition = (CastSettingCondition) any;
        }
    }

    public CastSettingRuleExpression(@Nullable CastSettingUserInfo castSettingUserInfo) {
        this.mCastSettingBean = castSettingUserInfo;
    }
}