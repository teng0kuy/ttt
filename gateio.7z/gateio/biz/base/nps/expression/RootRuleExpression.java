package com.gateio.biz.base.nps.expression;

import com.alipay.zoloz.toyger.ToygerService;
import com.gateio.biz.base.model.CastSettingUserInfo;
import com.gateio.biz.base.model.Condition;
import com.gateio.biz.base.model.NpsLang;
import com.gateio.biz.base.model.NpsQuestion;
import com.gateio.biz.base.model.RootBean;
import com.gateio.biz.base.model.Rule;
import com.gateio.biz.base.model.RuleItem;
import com.gateio.biz.base.nps.CastSettingCondition;
import com.gateio.biz.base.nps.NPSNumberCondition;
import com.gateio.biz.base.nps.NPSTouchCondition;
import com.gateio.common.tool.LocalUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.apache.commons.codec.language.bm.Languages;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: RootRuleExpression.kt */
@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010%\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\t\u0018\u00002\u00020\u00012\u00020\u0002B\u0005¢\u0006\u0002\u0010\u0003J\b\u0010\u000f\u001a\u00020\u0010H\u0016J\b\u0010\u0011\u001a\u00020\u0012H\u0016J\u0010\u0010\u0013\u001a\u00020\u00072\u0006\u0010\u0014\u001a\u00020\u0015H\u0002J\u0010\u0010\u0016\u001a\u00020\u00012\u0006\u0010\u0017\u001a\u00020\tH\u0002J\u0012\u0010\u0018\u001a\u00020\u00012\b\u0010\u0019\u001a\u0004\u0018\u00010\u001aH\u0002J\u0012\u0010\u001b\u001a\u00020\u00012\b\u0010\u0019\u001a\u0004\u0018\u00010\u001aH\u0002J\u0010\u0010\u001c\u001a\u00020\u00012\b\u0010\u001d\u001a\u0004\u0018\u00010\u001aJ \u0010\u001e\u001a\u00020\u00102\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010 \u001a\u00020\u0002H\u0002J\u0010\u0010!\u001a\u00020\u00102\u0006\u0010\u0014\u001a\u00020\u0015H\u0016J\u0018\u0010\"\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u0010\u0014\u001a\u00020\u0015H\u0002R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0001X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R(\u0010\n\u001a\u0004\u0018\u00010\t2\b\u0010\b\u001a\u0004\u0018\u00010\t@FX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000e¨\u0006#"}, d2 = {"Lcom/gateio/biz/base/nps/expression/RootRuleExpression;", "Lcom/gateio/biz/base/nps/expression/RuleExpression;", "Lcom/gateio/biz/base/nps/expression/Recorder;", "()V", "child", "map", "", "", "value", "Lcom/gateio/biz/base/model/RootBean;", "rootBean", "getRootBean", "()Lcom/gateio/biz/base/model/RootBean;", "setRootBean", "(Lcom/gateio/biz/base/model/RootBean;)V", "clear", "", "evaluate", "", ToygerService.KEY_RES_9_KEY, Languages.ANY, "", "parse", "mNPSRuleBean", "parseCastSettingUserInfo", "ruleItem", "Lcom/gateio/biz/base/model/RuleItem;", "parseCondition", "parseLanguage", "item", "putRule", "business", "recorder", "record", "ruleKey", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nRootRuleExpression.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RootRuleExpression.kt\ncom/gateio/biz/base/nps/expression/RootRuleExpression\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 Iterators.kt\nkotlin/collections/CollectionsKt__IteratorsKt\n*L\n1#1,155:1\n1855#2,2:156\n1855#2,2:158\n1549#2:160\n1620#2,3:161\n32#3,2:164\n*S KotlinDebug\n*F\n+ 1 RootRuleExpression.kt\ncom/gateio/biz/base/nps/expression/RootRuleExpression\n*L\n30#1:156,2\n58#1:158,2\n97#1:160\n97#1:161,3\n107#1:164,2\n*E\n"})
/* loaded from: classes4.dex */
public final class RootRuleExpression implements RuleExpression, Recorder {

    @Nullable
    private RuleExpression child;

    @NotNull
    private final Map<String, Recorder> map = new LinkedHashMap();

    @Nullable
    private RootBean rootBean;

    private final String key(Object any) {
        if (any instanceof NPSNumberCondition) {
            StringBuilder sb = new StringBuilder();
            NPSNumberCondition nPSNumberCondition = (NPSNumberCondition) any;
            sb.append(nPSNumberCondition.getBusiness());
            sb.append('_');
            sb.append(nPSNumberCondition.getCode());
            return sb.toString();
        }
        if (!(any instanceof NPSTouchCondition)) {
            return any instanceof CastSettingCondition ? "CastSettingCondition" : "";
        }
        StringBuilder sb2 = new StringBuilder();
        NPSTouchCondition nPSTouchCondition = (NPSTouchCondition) any;
        sb2.append(nPSTouchCondition.getBusiness());
        sb2.append('_');
        sb2.append(nPSTouchCondition.getCode());
        return sb2.toString();
    }

    private final RuleExpression parse(RootBean mNPSRuleBean) {
        ArrayList arrayList = new ArrayList();
        List<RuleItem> ruleArray = mNPSRuleBean.getRuleArray();
        if (ruleArray != null) {
            for (RuleItem ruleItem : ruleArray) {
                arrayList.add(new AndRuleExpression(CollectionsKt__CollectionsKt.listOf((Object[]) new RuleExpression[]{parseLanguage(ruleItem), parseCondition(ruleItem), parseCastSettingUserInfo(ruleItem)})));
            }
        }
        return new AndRuleExpression(CollectionsKt__CollectionsKt.listOf((Object[]) new RuleExpression[]{new DefiniteExpression(Intrinsics.areEqual(mNPSRuleBean.getSwitch(), "open")), new OrRuleExpression(arrayList)}));
    }

    private final RuleExpression parseCastSettingUserInfo(RuleItem ruleItem) {
        if ((ruleItem != null ? ruleItem.getRule() : null) == null) {
            return new DefiniteExpression(false);
        }
        Rule rule = ruleItem.getRule();
        CastSettingRuleExpression castSettingRuleExpression = new CastSettingRuleExpression(rule.getCastSettingUserInfo());
        String businessCode = ruleItem.getBusinessCode();
        if (businessCode == null) {
            businessCode = "";
        }
        Object castSettingUserInfo = rule.getCastSettingUserInfo();
        if (castSettingUserInfo == null) {
            castSettingUserInfo = new Object();
        }
        putRule(businessCode, castSettingUserInfo, castSettingRuleExpression);
        return castSettingRuleExpression;
    }

    private final RuleExpression parseCondition(RuleItem ruleItem) {
        if ((ruleItem != null ? ruleItem.getRule() : null) == null) {
            return new DefiniteExpression(false);
        }
        Rule rule = ruleItem.getRule();
        ArrayList arrayList = new ArrayList();
        List<Condition> conditions = rule.getConditions();
        if (conditions != null) {
            for (Condition condition : conditions) {
                if (Intrinsics.areEqual(condition.getType(), "touch")) {
                    TouchRuleExpression touchRuleExpression = new TouchRuleExpression(condition);
                    String businessCode = ruleItem.getBusinessCode();
                    putRule(businessCode != null ? businessCode : "", condition, touchRuleExpression);
                    arrayList.add(touchRuleExpression);
                } else {
                    NumberRuleExpression numberRuleExpression = new NumberRuleExpression(condition);
                    String businessCode2 = ruleItem.getBusinessCode();
                    putRule(businessCode2 != null ? businessCode2 : "", condition, numberRuleExpression);
                    arrayList.add(numberRuleExpression);
                }
            }
        }
        return Intrinsics.areEqual(rule.getLogic(), "and") ? new AndRuleExpression(arrayList) : new OrRuleExpression(arrayList);
    }

    private final void putRule(String business, Object any, Recorder recorder) {
        this.map.put(ruleKey(business, any), recorder);
    }

    private final String ruleKey(String business, Object any) {
        if (!(any instanceof Condition)) {
            return any instanceof CastSettingUserInfo ? "CastSettingCondition" : "";
        }
        return business + '_' + ((Condition) any).getField();
    }

    @Override // com.gateio.biz.base.nps.expression.RuleExpression
    /* renamed from: evaluate */
    public boolean getResult() {
        RuleExpression ruleExpression = this.child;
        return ruleExpression != null && ruleExpression.getResult();
    }

    @Nullable
    public final RootBean getRootBean() {
        return this.rootBean;
    }

    @NotNull
    public final RuleExpression parseLanguage(@Nullable RuleItem item) {
        NpsQuestion npsQuestion;
        if (((item == null || (npsQuestion = item.getNpsQuestion()) == null) ? null : npsQuestion.getLang()) == null) {
            return new DefiniteExpression(false);
        }
        List<NpsLang> lang = item.getNpsQuestion().getLang();
        final ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(lang, 10));
        Iterator<T> it = lang.iterator();
        while (it.hasNext()) {
            arrayList.add(((NpsLang) it.next()).getCode());
        }
        return new RuleExpression() { // from class: com.gateio.biz.base.nps.expression.RootRuleExpression.parseLanguage.1
            @Override // com.gateio.biz.base.nps.expression.RuleExpression
            /* renamed from: evaluate */
            public boolean getResult() {
                return arrayList.contains(LocalUtils.getCurrentLanguage().getLanguageInPost());
            }
        };
    }

    @Override // com.gateio.biz.base.nps.expression.Recorder
    public void record(@NotNull Object any) {
        Recorder recorder = this.map.get(key(any));
        if (recorder != null) {
            recorder.record(any);
        }
    }

    public final void setRootBean(@Nullable RootBean rootBean) {
        this.rootBean = rootBean;
        this.map.clear();
        this.child = null;
        if (rootBean != null) {
            this.child = parse(rootBean);
        }
    }

    @Override // com.gateio.biz.base.nps.expression.Recorder
    public void clear() {
        super.clear();
        Iterator<Map.Entry<String, Recorder>> it = this.map.entrySet().iterator();
        while (it.hasNext()) {
            it.next().getValue().clear();
        }
    }
}