package com.gateio.biz.base.nps.expression;

import com.facebook.appevents.UserDataStore;
import com.gateio.common.tool.NumberUtil;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: OperatorExpression.kt */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\t\n\u0002\u0010\u000b\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\f\u001a\u00020\rH\u0016R\u001c\u0010\u0005\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\u0004R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\t\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u0007\"\u0004\b\u000b\u0010\u0004¨\u0006\u000e"}, d2 = {"Lcom/gateio/biz/base/nps/expression/OperatorExpression;", "Lcom/gateio/biz/base/nps/expression/RuleExpression;", "operator", "", "(Ljava/lang/String;)V", "left", "getLeft", "()Ljava/lang/String;", "setLeft", "right", "getRight", "setRight", "evaluate", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class OperatorExpression implements RuleExpression {

    @NotNull
    private final String operator;

    @Nullable
    private String left = "";

    @Nullable
    private String right = "";

    @Override // com.gateio.biz.base.nps.expression.RuleExpression
    /* renamed from: evaluate */
    public boolean getResult() {
        String str = this.operator;
        int iHashCode = str.hashCode();
        if (iHashCode != 3244) {
            if (iHashCode != 3294) {
                if (iHashCode != 3309) {
                    if (iHashCode != 3449) {
                        if (iHashCode != 3464) {
                            if (iHashCode == 3511 && str.equals("ne")) {
                                if (NumberUtil.parseDouble(this.left) == NumberUtil.parseDouble(this.right)) {
                                    return false;
                                }
                            }
                        } else if (str.equals("lt") && NumberUtil.parseDouble(this.left) >= NumberUtil.parseDouble(this.right)) {
                            return false;
                        }
                    } else if (str.equals("le") && NumberUtil.parseDouble(this.left) > NumberUtil.parseDouble(this.right)) {
                        return false;
                    }
                } else if (str.equals("gt") && NumberUtil.parseDouble(this.left) <= NumberUtil.parseDouble(this.right)) {
                    return false;
                }
            } else if (str.equals(UserDataStore.GENDER) && NumberUtil.parseDouble(this.left) < NumberUtil.parseDouble(this.right)) {
                return false;
            }
        } else if (str.equals("eq") && NumberUtil.parseDouble(this.left) != NumberUtil.parseDouble(this.right)) {
            return false;
        }
        return true;
    }

    @Nullable
    public final String getLeft() {
        return this.left;
    }

    @Nullable
    public final String getRight() {
        return this.right;
    }

    public final void setLeft(@Nullable String str) {
        this.left = str;
    }

    public final void setRight(@Nullable String str) {
        this.right = str;
    }

    public OperatorExpression(@NotNull String str) {
        this.operator = str;
    }
}