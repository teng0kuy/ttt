package com.gateio.biz.base.nps.expression;

import com.gateio.biz.base.model.Condition;
import com.gateio.biz.base.nps.NPSTouchCondition;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.apache.commons.codec.language.bm.Languages;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: TouchRuleExpression.kt */
@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\u0018\u00002\u00020\u00012\u00020\u0002B\r\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0005J\b\u0010\n\u001a\u00020\u000bH\u0016J\u0010\u0010\f\u001a\u00020\u00072\u0006\u0010\r\u001a\u00020\u0007H\u0002J\b\u0010\u000e\u001a\u00020\u000fH\u0016J\u0010\u0010\u0010\u001a\u00020\u000b2\u0006\u0010\u0011\u001a\u00020\u0012H\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0013"}, d2 = {"Lcom/gateio/biz/base/nps/expression/TouchRuleExpression;", "Lcom/gateio/biz/base/nps/expression/RuleExpression;", "Lcom/gateio/biz/base/nps/expression/Recorder;", "mCondition", "Lcom/gateio/biz/base/model/Condition;", "(Lcom/gateio/biz/base/model/Condition;)V", "mNPSTouchCondition", "Lcom/gateio/biz/base/nps/NPSTouchCondition;", "mOperatorExpression", "Lcom/gateio/biz/base/nps/expression/OperatorExpression;", "clear", "", "copyIf", "nPSTouchCondition", "evaluate", "", "record", Languages.ANY, "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class TouchRuleExpression implements RuleExpression, Recorder {

    @NotNull
    private final Condition mCondition;

    @Nullable
    private NPSTouchCondition mNPSTouchCondition;

    @NotNull
    private final OperatorExpression mOperatorExpression;

    private final NPSTouchCondition copyIf(NPSTouchCondition nPSTouchCondition) {
        if (this.mNPSTouchCondition == null) {
            this.mNPSTouchCondition = new NPSTouchCondition(nPSTouchCondition.getBusiness(), nPSTouchCondition.getCode(), 0);
        }
        return this.mNPSTouchCondition;
    }

    @Override // com.gateio.biz.base.nps.expression.RuleExpression
    /* renamed from: evaluate */
    public boolean getResult() {
        NPSTouchCondition nPSTouchCondition = this.mNPSTouchCondition;
        if (nPSTouchCondition == null) {
            return false;
        }
        String field = this.mCondition.getField();
        NPSTouchCondition nPSTouchCondition2 = this.mNPSTouchCondition;
        if (!Intrinsics.areEqual(field, nPSTouchCondition2 != null ? nPSTouchCondition2.getCode() : null)) {
            return false;
        }
        this.mOperatorExpression.setLeft(String.valueOf(nPSTouchCondition.getTimes()));
        OperatorExpression operatorExpression = this.mOperatorExpression;
        String threshold = this.mCondition.getThreshold();
        if (threshold == null) {
            threshold = "0";
        }
        operatorExpression.setRight(threshold);
        return this.mOperatorExpression.getResult();
    }

    @Override // com.gateio.biz.base.nps.expression.Recorder
    public void record(@NotNull Object any) {
        if (any instanceof NPSTouchCondition) {
            NPSTouchCondition nPSTouchCondition = (NPSTouchCondition) any;
            NPSTouchCondition nPSTouchConditionCopyIf = copyIf(nPSTouchCondition);
            if (Intrinsics.areEqual(nPSTouchConditionCopyIf.getBusiness(), nPSTouchCondition.getBusiness()) && Intrinsics.areEqual(nPSTouchConditionCopyIf.getCode(), nPSTouchCondition.getCode())) {
                nPSTouchConditionCopyIf.setTimes(nPSTouchConditionCopyIf.getTimes() + 1);
            }
        }
    }

    public TouchRuleExpression(@NotNull Condition condition) {
        this.mCondition = condition;
        String operator = condition.getOperator();
        this.mOperatorExpression = new OperatorExpression(operator == null ? "" : operator);
    }

    @Override // com.gateio.biz.base.nps.expression.Recorder
    public void clear() {
        super.clear();
        this.mNPSTouchCondition = null;
    }
}