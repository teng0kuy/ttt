package com.gateio.biz.base.nps.expression;

import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

/* compiled from: OrRuleExpression.kt */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\u0018\u00002\u00020\u0001B\u0013\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00010\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\u0005\u001a\u00020\u0006H\u0016R\u0014\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00010\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/base/nps/expression/OrRuleExpression;", "Lcom/gateio/biz/base/nps/expression/RuleExpression;", "children", "", "(Ljava/util/List;)V", "evaluate", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nOrRuleExpression.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OrRuleExpression.kt\ncom/gateio/biz/base/nps/expression/OrRuleExpression\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,17:1\n1855#2,2:18\n*S KotlinDebug\n*F\n+ 1 OrRuleExpression.kt\ncom/gateio/biz/base/nps/expression/OrRuleExpression\n*L\n9#1:18,2\n*E\n"})
/* loaded from: classes4.dex */
public final class OrRuleExpression implements RuleExpression {

    @NotNull
    private final List<RuleExpression> children;

    @Override // com.gateio.biz.base.nps.expression.RuleExpression
    /* renamed from: evaluate */
    public boolean getResult() {
        Iterator<T> it = this.children.iterator();
        while (it.hasNext()) {
            if (((RuleExpression) it.next()).getResult()) {
                return true;
            }
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public OrRuleExpression(@NotNull List<? extends RuleExpression> list) {
        this.children = list;
    }
}