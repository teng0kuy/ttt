package com.gateio.biz.base.nps.expression;

import com.gateio.biz.base.model.Condition;
import com.gateio.biz.base.nps.NPSNumberCondition;
import kotlin.Metadata;
import org.apache.commons.codec.language.bm.Languages;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: NumberRuleExpression.kt */
@Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\u0018\u00002\u00020\u00012\u00020\u0002B\r\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0005J\b\u0010\n\u001a\u00020\u000bH\u0016J\b\u0010\f\u001a\u00020\rH\u0016J\u0010\u0010\u000e\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0011"}, d2 = {"Lcom/gateio/biz/base/nps/expression/NumberRuleExpression;", "Lcom/gateio/biz/base/nps/expression/RuleExpression;", "Lcom/gateio/biz/base/nps/expression/Recorder;", "mCondition", "Lcom/gateio/biz/base/model/Condition;", "(Lcom/gateio/biz/base/model/Condition;)V", "mNPSNumberCondition", "Lcom/gateio/biz/base/nps/NPSNumberCondition;", "mOperatorExpression", "Lcom/gateio/biz/base/nps/expression/OperatorExpression;", "clear", "", "evaluate", "", "record", Languages.ANY, "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class NumberRuleExpression implements RuleExpression, Recorder {

    @NotNull
    private final Condition mCondition;

    @Nullable
    private NPSNumberCondition mNPSNumberCondition;

    @NotNull
    private final OperatorExpression mOperatorExpression;

    /* JADX WARN: Removed duplicated region for block: B:13:0x002a  */
    @Override // com.gateio.biz.base.nps.expression.RuleExpression
    /* renamed from: evaluate */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean getResult() {
        /*
            r4 = this;
            com.gateio.biz.base.nps.NPSNumberCondition r0 = r4.mNPSNumberCondition
            r1 = 0
            if (r0 != 0) goto L6
            return r1
        L6:
            java.lang.String r2 = r0.getCode()
            com.gateio.biz.base.model.Condition r3 = r4.mCondition
            java.lang.String r3 = r3.getField()
            boolean r2 = kotlin.jvm.internal.Intrinsics.areEqual(r2, r3)
            if (r2 != 0) goto L17
            return r1
        L17:
            com.gateio.biz.base.model.Condition r2 = r4.mCondition
            java.util.List r2 = r2.getMarket()
            if (r2 == 0) goto L2a
            java.util.Collection r2 = (java.util.Collection) r2
            boolean r2 = r2.isEmpty()
            r3 = 1
            r2 = r2 ^ r3
            if (r2 != r3) goto L2a
            goto L2b
        L2a:
            r3 = r1
        L2b:
            if (r3 == 0) goto L3e
            com.gateio.biz.base.model.Condition r2 = r4.mCondition
            java.util.List r2 = r2.getMarket()
            java.lang.String r3 = r0.getMarket()
            boolean r2 = r2.contains(r3)
            if (r2 != 0) goto L3e
            return r1
        L3e:
            com.gateio.biz.base.nps.expression.OperatorExpression r1 = r4.mOperatorExpression
            java.lang.String r0 = r0.getAmount()
            r1.setLeft(r0)
            com.gateio.biz.base.nps.expression.OperatorExpression r0 = r4.mOperatorExpression
            com.gateio.biz.base.model.Condition r1 = r4.mCondition
            java.lang.String r1 = r1.getThreshold()
            if (r1 != 0) goto L54
            java.lang.String r1 = "0"
        L54:
            r0.setRight(r1)
            com.gateio.biz.base.nps.expression.OperatorExpression r0 = r4.mOperatorExpression
            boolean r0 = r0.getResult()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.gateio.biz.base.nps.expression.NumberRuleExpression.getResult():boolean");
    }

    @Override // com.gateio.biz.base.nps.expression.Recorder
    public void record(@NotNull Object any) {
        if (any instanceof NPSNumberCondition) {
            this.mNPSNumberCondition = (NPSNumberCondition) any;
        }
    }

    public NumberRuleExpression(@NotNull Condition condition) {
        this.mCondition = condition;
        String operator = condition.getOperator();
        this.mOperatorExpression = new OperatorExpression(operator == null ? "" : operator);
    }

    @Override // com.gateio.biz.base.nps.expression.Recorder
    public void clear() {
        super.clear();
        this.mNPSNumberCondition = null;
    }
}