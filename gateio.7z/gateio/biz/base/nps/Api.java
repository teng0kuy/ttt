package com.gateio.biz.base.nps;

import com.gateio.biz.base.model.CheckBean;
import com.gateio.biz.base.model.RootBean;
import com.gateio.http.BaseApiService;
import com.gateio.http.BaseHttpMethods;
import com.gateio.http.entity.HttpResultV2;
import com.gateio.http.tool.HttpPingUtil;
import io.reactivex.rxjava3.core.s;
import java.util.Map;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Query;

/* compiled from: Api.kt */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010$\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\bf\u0018\u0000 \u00102\u00020\u0001:\u0001\u0010J\u001e\u0010\u0007\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u00050\u00042\b\b\u0001\u0010\u0003\u001a\u00020\u0002H'JC\u0010\u000f\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000e0\u00050\u00042\b\b\u0001\u0010\b\u001a\u00020\u00022\b\b\u0001\u0010\t\u001a\u00020\u00022\u0019\b\u0001\u0010\r\u001a\u0013\u0012\u0004\u0012\u00020\u0002\u0012\t\u0012\u00070\u000b¢\u0006\u0002\b\f0\nH'ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0011À\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/nps/Api;", "Lcom/gateio/http/BaseApiService;", "", "type", "Lio/reactivex/rxjava3/core/s;", "Lcom/gateio/http/entity/HttpResultV2;", "Lcom/gateio/biz/base/model/RootBean;", "questionnaireRule", "userId", "token", "", "", "Lkotlin/jvm/JvmSuppressWildcards;", "params", "Lcom/gateio/biz/base/model/CheckBean;", "check", "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0})
/* loaded from: classes4.dex */
public interface Api extends BaseApiService {

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = Companion.$$INSTANCE;

    /* compiled from: Api.kt */
    @Metadata(d1 = {"\u0000\u001b\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\b\u0003*\u0001\t\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0019\u0010\u0003\u001a\n \u0005*\u0004\u0018\u00010\u00040\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0004\n\u0002\u0010\n¨\u0006\u000b"}, d2 = {"Lcom/gateio/biz/base/nps/Api$Companion;", "", "()V", "instance", "Lcom/gateio/biz/base/nps/Api;", "kotlin.jvm.PlatformType", "getInstance", "()Lcom/gateio/biz/base/nps/Api;", "service", "com/gateio/biz/base/nps/Api$Companion$service$1", "Lcom/gateio/biz/base/nps/Api$Companion$service$1;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Companion {
        static final /* synthetic */ Companion $$INSTANCE = new Companion();
        private static final Api instance;

        @NotNull
        private static final Api$Companion$service$1 service;

        private Companion() {
        }

        /* JADX WARN: Type inference failed for: r0v1, types: [com.gateio.biz.base.nps.Api$Companion$service$1, com.gateio.http.BaseRetrofitMethods] */
        static {
            ?? r02 = new BaseHttpMethods<Api>() { // from class: com.gateio.biz.base.nps.Api$Companion$service$1
                {
                    this.apiService = (T) init(false, HttpPingUtil.getBaseUrlV2()).create(Api.class);
                }

                @Override // com.gateio.http.HttpObserver
                public void reset() {
                }
            };
            service = r02;
            instance = (Api) r02.apiService;
        }

        public final Api getInstance() {
            return instance;
        }
    }

    @POST("nps-backend/nps/questionnaire/user_check")
    @NotNull
    s<HttpResultV2<CheckBean>> check(@Header("X-Gate-User-Id") @NotNull String userId, @Header("X-Gate-Token") @NotNull String token, @Body @NotNull Map<String, Object> params);

    @GET("nps-backend/nps/questionnaire_rule/query")
    @NotNull
    s<HttpResultV2<RootBean>> questionnaireRule(@NotNull @Query("source_type") String type);
}