package com.gateio.biz.base.nps;

import com.gateio.biz.base.router.RouterConst;
import kotlin.Metadata;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;

/* compiled from: Conditions.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0010\u0002\n\u0000\u0018\u00002\u00020\u0001B!\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0006¢\u0006\u0002\u0010\u0007J\u0006\u0010\u000f\u001a\u00020\u0010R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\tR\u001a\u0010\u0005\u001a\u00020\u0006X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000e¨\u0006\u0011"}, d2 = {"Lcom/gateio/biz/base/nps/NPSTouchCondition;", "", "business", "", "code", "times", "", "(Ljava/lang/String;Ljava/lang/String;I)V", "getBusiness", "()Ljava/lang/String;", "getCode", "getTimes", "()I", "setTimes", "(I)V", RouterConst.Moments.TAB_FIRST_POST, "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class NPSTouchCondition {

    @NotNull
    private final String business;

    @NotNull
    private final String code;
    private int times;

    @JvmOverloads
    public NPSTouchCondition(@NotNull String str, @NotNull String str2) {
        this(str, str2, 0, 4, null);
    }

    @JvmOverloads
    public NPSTouchCondition(@NotNull String str, @NotNull String str2, int i10) {
        this.business = str;
        this.code = str2;
        this.times = i10;
    }

    @NotNull
    public final String getBusiness() {
        return this.business;
    }

    @NotNull
    public final String getCode() {
        return this.code;
    }

    public final int getTimes() {
        return this.times;
    }

    public final void setTimes(int i10) {
        this.times = i10;
    }

    public /* synthetic */ NPSTouchCondition(String str, String str2, int i10, int i11, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, str2, (i11 & 4) != 0 ? 1 : i10);
    }

    public final void post() {
        NPS.touch(this);
    }
}