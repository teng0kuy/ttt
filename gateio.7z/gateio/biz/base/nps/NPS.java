package com.gateio.biz.base.nps;

import android.annotation.SuppressLint;
import android.app.Activity;
import ba.b;
import ca.g;
import com.gateio.biz.base.model.CheckBean;
import com.gateio.biz.base.model.NoticeRule;
import com.gateio.biz.base.model.NpsLang;
import com.gateio.biz.base.model.NpsQuestion;
import com.gateio.biz.base.model.RootBean;
import com.gateio.biz.base.model.Rule;
import com.gateio.biz.base.model.RuleItem;
import com.gateio.biz.base.nps.expression.RootRuleExpression;
import com.gateio.common.tool.DeviceUtil;
import com.gateio.common.tool.LocalUtils;
import com.gateio.flutter.lib_furnace.AnimationType;
import com.gateio.flutter.lib_furnace.GTFlutter;
import com.gateio.flutter.lib_furnace.GTFlutterContainerType;
import com.gateio.http.entity.HttpResultV2;
import com.gateio.lib.core.GTActivityLifecycle;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import ia.a;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CancellationException;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Job;
import org.apache.commons.codec.language.bm.Languages;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: NPS.kt */
@Metadata(d1 = {"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001$B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0018\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0012H\u0002J\u0010\u0010\u0013\u001a\u00020\u00102\u0006\u0010\u0014\u001a\u00020\u0012H\u0002J\b\u0010\u0015\u001a\u00020\u000eH\u0007J\b\u0010\u0016\u001a\u00020\u0017H\u0002J\u0010\u0010\u0018\u001a\u00020\u000e2\u0006\u0010\u0019\u001a\u00020\u001aH\u0007J\u0012\u0010\u001b\u001a\u00020\u000e2\b\u0010\u001c\u001a\u0004\u0018\u00010\u001dH\u0002J\u001e\u0010\u001e\u001a\u0010\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u0001\u0018\u00010\u001f2\u0006\u0010 \u001a\u00020\u0001H\u0002J\u0010\u0010!\u001a\u00020\u000e2\u0006\u0010\"\u001a\u00020#H\u0007R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u000e\u0010\t\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006%"}, d2 = {"Lcom/gateio/biz/base/nps/NPS;", "", "()V", "mCastSetting", "Lcom/gateio/biz/base/nps/NPS$ICastSetting;", "getMCastSetting", "()Lcom/gateio/biz/base/nps/NPS$ICastSetting;", "setMCastSetting", "(Lcom/gateio/biz/base/nps/NPS$ICastSetting;)V", "mExpression", "Lcom/gateio/biz/base/nps/expression/RootRuleExpression;", "mJob", "Lkotlinx/coroutines/Job;", "check", "", "delay", "", "businessCode", "", "getDelay", "code", "init", "isPortrait", "", "number", "mNPSNumberConditions", "Lcom/gateio/biz/base/nps/NPSNumberCondition;", "showNPSDialog", "ruleItem", "Lcom/gateio/biz/base/model/RuleItem;", "toMap", "", Languages.ANY, "touch", "mNPSTouchCondition", "Lcom/gateio/biz/base/nps/NPSTouchCondition;", "ICastSetting", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nNPS.kt\nKotlin\n*S Kotlin\n*F\n+ 1 NPS.kt\ncom/gateio/biz/base/nps/NPS\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,149:1\n1855#2,2:150\n288#2,2:152\n288#2,2:154\n*S KotlinDebug\n*F\n+ 1 NPS.kt\ncom/gateio/biz/base/nps/NPS\n*L\n77#1:150,2\n86#1:152,2\n122#1:154,2\n*E\n"})
/* loaded from: classes4.dex */
public final class NPS {

    @Nullable
    private static ICastSetting mCastSetting;

    @Nullable
    private static Job mJob;

    @NotNull
    public static final NPS INSTANCE = new NPS();

    @NotNull
    private static RootRuleExpression mExpression = new RootRuleExpression();

    /* compiled from: NPS.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\bf\u0018\u00002\u00020\u0001J\n\u0010\u0002\u001a\u0004\u0018\u00010\u0003H&J\n\u0010\u0004\u001a\u0004\u0018\u00010\u0003H&J\n\u0010\u0005\u001a\u0004\u0018\u00010\u0003H&J\n\u0010\u0006\u001a\u0004\u0018\u00010\u0003H&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0007À\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/nps/NPS$ICastSetting;", "", "getArea", "", "getToken", "getUserID", "getUserLevel", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public interface ICastSetting {
        @Nullable
        String getArea();

        @Nullable
        String getToken();

        @Nullable
        String getUserID();

        @Nullable
        String getUserLevel();
    }

    /* compiled from: NPS.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.base.nps.NPS$check$1", f = "NPS.kt", i = {}, l = {93, 94}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.base.nps.NPS$check$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ long $delay;
        final /* synthetic */ RuleItem $ruleItem;
        int label;

        /* compiled from: NPS.kt */
        @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0010\u0005\u001a\u0013\u0012\u000f\u0012\r\u0012\u0004\u0012\u00020\u00030\u0002¢\u0006\u0002\b\u00040\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "Lkotlin/Result;", "Lcom/gateio/http/entity/HttpResultV2;", "Lcom/gateio/biz/base/model/CheckBean;", "Lio/reactivex/rxjava3/annotations/NonNull;", "<anonymous>"}, k = 3, mv = {1, 9, 0})
        @DebugMetadata(c = "com.gateio.biz.base.nps.NPS$check$1$1", f = "NPS.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
        /* renamed from: com.gateio.biz.base.nps.NPS$check$1$1, reason: invalid class name and collision with other inner class name */
        static final class C01351 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Result<? extends HttpResultV2<CheckBean>>>, Object> {
            final /* synthetic */ RuleItem $ruleItem;
            int label;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C01351(RuleItem ruleItem, Continuation<? super C01351> continuation) {
                super(2, continuation);
                this.$ruleItem = ruleItem;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            @NotNull
            public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
                return new C01351(this.$ruleItem, continuation);
            }

            @Override // kotlin.jvm.functions.Function2
            @Nullable
            /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
            public final Object mo2invoke(@NotNull CoroutineScope coroutineScope, @Nullable Continuation<? super Result<? extends HttpResultV2<CheckBean>>> continuation) {
                return ((C01351) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            @Nullable
            public final Object invokeSuspend(@NotNull Object obj) {
                String userID;
                String token;
                String npsId;
                Long id;
                boolean z10;
                boolean z11;
                boolean z12;
                Object objM4830constructorimpl;
                String userID2;
                String token2;
                NpsQuestion npsQuestion;
                IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                if (this.label == 0) {
                    ResultKt.throwOnFailure(obj);
                    NPS nps = NPS.INSTANCE;
                    ICastSetting mCastSetting = nps.getMCastSetting();
                    String str = "";
                    if (mCastSetting == null || (userID = mCastSetting.getUserID()) == null) {
                        userID = "";
                    }
                    ICastSetting mCastSetting2 = nps.getMCastSetting();
                    if (mCastSetting2 == null || (token = mCastSetting2.getToken()) == null) {
                        token = "";
                    }
                    RuleItem ruleItem = this.$ruleItem;
                    if (ruleItem == null || (npsQuestion = ruleItem.getNpsQuestion()) == null || (npsId = npsQuestion.getNpsId()) == null) {
                        npsId = "";
                    }
                    RuleItem ruleItem2 = this.$ruleItem;
                    if (ruleItem2 != null) {
                        id = ruleItem2.getId();
                    } else {
                        id = null;
                    }
                    if (userID.length() > 0) {
                        z10 = true;
                    } else {
                        z10 = false;
                    }
                    if (z10) {
                        if (token.length() > 0) {
                            z11 = true;
                        } else {
                            z11 = false;
                        }
                        if (z11) {
                            if (npsId.length() > 0) {
                                z12 = true;
                            } else {
                                z12 = false;
                            }
                            if (z12 && id != null) {
                                try {
                                    Result.Companion companion = Result.INSTANCE;
                                    Api companion2 = Api.INSTANCE.getInstance();
                                    ICastSetting mCastSetting3 = nps.getMCastSetting();
                                    if (mCastSetting3 == null || (userID2 = mCastSetting3.getUserID()) == null) {
                                        userID2 = "";
                                    }
                                    ICastSetting mCastSetting4 = nps.getMCastSetting();
                                    if (mCastSetting4 != null && (token2 = mCastSetting4.getToken()) != null) {
                                        str = token2;
                                    }
                                    objM4830constructorimpl = Result.m4830constructorimpl(companion2.check(userID2, str, MapsKt__MapsKt.mutableMapOf(TuplesKt.to("npsid", npsId), TuplesKt.to("cast_id", id))).blockingFirst());
                                } catch (Throwable th) {
                                    Result.Companion companion3 = Result.INSTANCE;
                                    objM4830constructorimpl = Result.m4830constructorimpl(ResultKt.createFailure(th));
                                }
                                return Result.m4829boximpl(objM4830constructorimpl);
                            }
                        }
                    }
                    Result.Companion companion4 = Result.INSTANCE;
                    return Result.m4829boximpl(Result.m4830constructorimpl(ResultKt.createFailure(new Exception())));
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(long j10, RuleItem ruleItem, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$delay = j10;
            this.$ruleItem = ruleItem;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            return new AnonymousClass1(this.$delay, this.$ruleItem, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull CoroutineScope coroutineScope, @Nullable Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Removed duplicated region for block: B:18:0x0050  */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @org.jetbrains.annotations.Nullable
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final java.lang.Object invokeSuspend(@org.jetbrains.annotations.NotNull java.lang.Object r7) throws java.lang.Throwable {
            /*
                r6 = this;
                java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r1 = r6.label
                r2 = 2
                r3 = 1
                if (r1 == 0) goto L1f
                if (r1 == r3) goto L1b
                if (r1 != r2) goto L12
                kotlin.ResultKt.throwOnFailure(r7)
                goto L42
            L12:
                java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r7.<init>(r0)
                throw r7
            L1b:
                kotlin.ResultKt.throwOnFailure(r7)
                goto L2d
            L1f:
                kotlin.ResultKt.throwOnFailure(r7)
                long r4 = r6.$delay
                r6.label = r3
                java.lang.Object r7 = kotlinx.coroutines.DelayKt.delay(r4, r6)
                if (r7 != r0) goto L2d
                return r0
            L2d:
                kotlinx.coroutines.CoroutineDispatcher r7 = kotlinx.coroutines.Dispatchers.getIO()
                com.gateio.biz.base.nps.NPS$check$1$1 r1 = new com.gateio.biz.base.nps.NPS$check$1$1
                com.gateio.biz.base.model.RuleItem r4 = r6.$ruleItem
                r5 = 0
                r1.<init>(r4, r5)
                r6.label = r2
                java.lang.Object r7 = kotlinx.coroutines.BuildersKt.withContext(r7, r1, r6)
                if (r7 != r0) goto L42
                return r0
            L42:
                kotlin.Result r7 = (kotlin.Result) r7
                java.lang.Object r7 = r7.getValue()
                com.gateio.biz.base.model.RuleItem r0 = r6.$ruleItem
                boolean r1 = kotlin.Result.m4837isSuccessimpl(r7)
                if (r1 == 0) goto L75
                com.gateio.http.entity.HttpResultV2 r7 = (com.gateio.http.entity.HttpResultV2) r7
                boolean r1 = r7.isSuccess()
                if (r1 == 0) goto L75
                java.lang.Object r7 = r7.getData()
                com.gateio.biz.base.model.CheckBean r7 = (com.gateio.biz.base.model.CheckBean) r7
                if (r7 == 0) goto L6d
                java.lang.Boolean r7 = r7.isOp()
                java.lang.Boolean r1 = kotlin.coroutines.jvm.internal.Boxing.boxBoolean(r3)
                boolean r7 = kotlin.jvm.internal.Intrinsics.areEqual(r7, r1)
                goto L6e
            L6d:
                r7 = 0
            L6e:
                if (r7 == 0) goto L75
                com.gateio.biz.base.nps.NPS r7 = com.gateio.biz.base.nps.NPS.INSTANCE
                com.gateio.biz.base.nps.NPS.access$showNPSDialog(r7, r0)
            L75:
                kotlin.Unit r7 = kotlin.Unit.INSTANCE
                return r7
            */
            throw new UnsupportedOperationException("Method not decompiled: com.gateio.biz.base.nps.NPS.AnonymousClass1.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    private NPS() {
    }

    private final void check(long delay, String businessCode) {
        RuleItem ruleItem;
        List<RuleItem> ruleArray;
        Object next;
        RootBean rootBean = mExpression.getRootBean();
        if (rootBean == null || (ruleArray = rootBean.getRuleArray()) == null) {
            ruleItem = null;
        } else {
            Iterator<T> it = ruleArray.iterator();
            while (true) {
                if (!it.hasNext()) {
                    next = null;
                    break;
                } else {
                    next = it.next();
                    if (Intrinsics.areEqual(((RuleItem) next).getBusinessCode(), businessCode)) {
                        break;
                    }
                }
            }
            ruleItem = (RuleItem) next;
        }
        mExpression.clear();
        Job job = mJob;
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        mJob = null;
        mJob = BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.MainScope(), null, null, new AnonymousClass1(delay, ruleItem, null), 3, null);
    }

    private final long getDelay(String code) {
        List<RuleItem> ruleArray;
        NoticeRule noticeRule;
        Long delaySeconds;
        RootBean rootBean = mExpression.getRootBean();
        if (rootBean == null || (ruleArray = rootBean.getRuleArray()) == null) {
            return 0L;
        }
        for (RuleItem ruleItem : ruleArray) {
            if (Intrinsics.areEqual(ruleItem.getBusinessCode(), code)) {
                Rule rule = ruleItem.getRule();
                if (rule == null || (noticeRule = rule.getNoticeRule()) == null || (delaySeconds = noticeRule.getDelaySeconds()) == null) {
                    return 0L;
                }
                return delaySeconds.longValue();
            }
        }
        return 0L;
    }

    @JvmStatic
    public static final void number(@NotNull NPSNumberCondition mNPSNumberConditions) {
        String userLevel;
        String area;
        mExpression.record(mNPSNumberConditions);
        RootRuleExpression rootRuleExpression = mExpression;
        ICastSetting iCastSetting = mCastSetting;
        String str = "";
        if (iCastSetting == null || (userLevel = iCastSetting.getUserLevel()) == null) {
            userLevel = "";
        }
        ICastSetting iCastSetting2 = mCastSetting;
        if (iCastSetting2 != null && (area = iCastSetting2.getArea()) != null) {
            str = area;
        }
        rootRuleExpression.record(new CastSettingCondition(userLevel, str, DeviceUtil.getAppVersionName()));
        if (mExpression.getResult()) {
            NPS nps = INSTANCE;
            nps.check(nps.getDelay(mNPSNumberConditions.getBusiness()), mNPSNumberConditions.getBusiness());
        }
    }

    private final Map<String, Object> toMap(Object any) {
        Gson gson = new Gson();
        try {
            return (Map) gson.fromJson(gson.toJson(any), new TypeToken<Map<String, ? extends Object>>() { // from class: com.gateio.biz.base.nps.NPS.toMap.1
            }.getType());
        } catch (Exception unused) {
            return null;
        }
    }

    @JvmStatic
    public static final void touch(@NotNull NPSTouchCondition mNPSTouchCondition) {
        String userLevel;
        String area;
        mExpression.record(mNPSTouchCondition);
        RootRuleExpression rootRuleExpression = mExpression;
        ICastSetting iCastSetting = mCastSetting;
        String str = "";
        if (iCastSetting == null || (userLevel = iCastSetting.getUserLevel()) == null) {
            userLevel = "";
        }
        ICastSetting iCastSetting2 = mCastSetting;
        if (iCastSetting2 != null && (area = iCastSetting2.getArea()) != null) {
            str = area;
        }
        rootRuleExpression.record(new CastSettingCondition(userLevel, str, DeviceUtil.getAppVersionName()));
        if (mExpression.getResult()) {
            NPS nps = INSTANCE;
            nps.check(nps.getDelay(mNPSTouchCondition.getBusiness()), mNPSTouchCondition.getBusiness());
        }
    }

    @Nullable
    public final ICastSetting getMCastSetting() {
        return mCastSetting;
    }

    @SuppressLint({"CheckResult"})
    public final void init() {
        Api.INSTANCE.getInstance().questionnaireRule("app").subscribeOn(a.c()).observeOn(b.c()).subscribe(new g() { // from class: com.gateio.biz.base.nps.NPS.init.1
            @Override // ca.g
            public final void accept(@NotNull HttpResultV2<RootBean> httpResultV2) {
                if (httpResultV2.getData() == null || !httpResultV2.isSuccess()) {
                    return;
                }
                NPS.mExpression.setRootBean(httpResultV2.getData());
            }
        });
    }

    public final void setMCastSetting(@Nullable ICastSetting iCastSetting) {
        mCastSetting = iCastSetting;
    }

    private final boolean isPortrait() {
        Activity topActivity = GTActivityLifecycle.getTopActivity();
        if (topActivity == null || topActivity.getResources().getConfiguration().orientation == 1) {
            return true;
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void showNPSDialog(RuleItem ruleItem) {
        Activity topActivity;
        NpsQuestion npsQuestion;
        List<NpsLang> lang;
        Object next;
        Map<String, Object> map;
        Map<String, ? extends Object> mutableMap;
        if (isPortrait() && (topActivity = GTActivityLifecycle.getTopActivity()) != null && ruleItem != null && (npsQuestion = ruleItem.getNpsQuestion()) != null && (lang = npsQuestion.getLang()) != null) {
            Iterator<T> it = lang.iterator();
            while (true) {
                if (it.hasNext()) {
                    next = it.next();
                    if (Intrinsics.areEqual(((NpsLang) next).getCode(), LocalUtils.getCurrentLanguage().getLanguageInPost())) {
                        break;
                    }
                } else {
                    next = null;
                    break;
                }
            }
            NpsLang npsLang = (NpsLang) next;
            if (npsLang != null && (map = toMap(npsLang)) != null && (mutableMap = MapsKt__MapsKt.toMutableMap(map)) != null) {
                String npsId = ruleItem.getNpsQuestion().getNpsId();
                Object obj = "";
                if (npsId == null) {
                    npsId = "";
                }
                mutableMap.put("npsid", npsId);
                Object id = ruleItem.getId();
                if (id != null) {
                    obj = id;
                }
                mutableMap.put("cast_id", obj);
                GTFlutter.withRouterName("/nps/commit/dialog").routeParams(mutableMap).containerType(GTFlutterContainerType.DIALOG).animationType(AnimationType.noAnimation).openPage(topActivity);
            }
        }
    }
}