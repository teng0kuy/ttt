package com.gateio.biz.base.nps;

import com.gateio.biz.safe.fido2.event.PageName;
import com.gateio.http.BaseHttpMethods;
import com.gateio.http.tool.HttpPingUtil;
import kotlin.Metadata;

/* compiled from: Api.kt */
@Metadata(d1 = {"\u0000\u0015\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001J\b\u0010\u0003\u001a\u00020\u0004H\u0016¨\u0006\u0005"}, d2 = {"com/gateio/biz/base/nps/Api$Companion$service$1", "Lcom/gateio/http/BaseHttpMethods;", "Lcom/gateio/biz/base/nps/Api;", PageName.PASSKEY_RESET, "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class Api$Companion$service$1 extends BaseHttpMethods<Api> {
    Api$Companion$service$1() {
        this.apiService = (T) init(false, HttpPingUtil.getBaseUrlV2()).create(Api.class);
    }

    @Override // com.gateio.http.HttpObserver
    public void reset() {
    }
}