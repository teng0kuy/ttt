package com.gateio.biz.base.model;

import com.google.gson.annotations.SerializedName;
import com.xiaomi.mipush.sdk.Constants;
import com.zoloz.webcontainer.env.H5Container;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: NPSModel.kt */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B#\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\u0002\u0010\bJ\u000b\u0010\u000f\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0010\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000b\u0010\u0011\u001a\u0004\u0018\u00010\u0007HÆ\u0003J-\u0010\u0012\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0017HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0019HÖ\u0001R\u0018\u0010\u0006\u001a\u0004\u0018\u00010\u00078\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0018\u0010\u0004\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0018\u0010\u0002\u001a\u0004\u0018\u00010\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000e¨\u0006\u001a"}, d2 = {"Lcom/gateio/biz/base/model/CastSettingUserInfo;", "", "userLevel", "Lcom/gateio/biz/base/model/UserLevel;", "area", "Lcom/gateio/biz/base/model/Area;", "appVersion", "Lcom/gateio/biz/base/model/AppVersion;", "(Lcom/gateio/biz/base/model/UserLevel;Lcom/gateio/biz/base/model/Area;Lcom/gateio/biz/base/model/AppVersion;)V", "getAppVersion", "()Lcom/gateio/biz/base/model/AppVersion;", "getArea", "()Lcom/gateio/biz/base/model/Area;", "getUserLevel", "()Lcom/gateio/biz/base/model/UserLevel;", "component1", "component2", "component3", H5Container.MENU_COPY, "equals", "", "other", "hashCode", "", "toString", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class CastSettingUserInfo {

    @SerializedName(Constants.EXTRA_KEY_APP_VERSION)
    @Nullable
    private final AppVersion appVersion;

    @SerializedName("area")
    @Nullable
    private final Area area;

    @SerializedName("user_level")
    @Nullable
    private final UserLevel userLevel;

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof CastSettingUserInfo)) {
            return false;
        }
        CastSettingUserInfo castSettingUserInfo = (CastSettingUserInfo) other;
        return Intrinsics.areEqual(this.userLevel, castSettingUserInfo.userLevel) && Intrinsics.areEqual(this.area, castSettingUserInfo.area) && Intrinsics.areEqual(this.appVersion, castSettingUserInfo.appVersion);
    }

    public static /* synthetic */ CastSettingUserInfo copy$default(CastSettingUserInfo castSettingUserInfo, UserLevel userLevel, Area area, AppVersion appVersion, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            userLevel = castSettingUserInfo.userLevel;
        }
        if ((i10 & 2) != 0) {
            area = castSettingUserInfo.area;
        }
        if ((i10 & 4) != 0) {
            appVersion = castSettingUserInfo.appVersion;
        }
        return castSettingUserInfo.copy(userLevel, area, appVersion);
    }

    @Nullable
    /* renamed from: component1, reason: from getter */
    public final UserLevel getUserLevel() {
        return this.userLevel;
    }

    @Nullable
    /* renamed from: component2, reason: from getter */
    public final Area getArea() {
        return this.area;
    }

    @Nullable
    /* renamed from: component3, reason: from getter */
    public final AppVersion getAppVersion() {
        return this.appVersion;
    }

    @NotNull
    public final CastSettingUserInfo copy(@Nullable UserLevel userLevel, @Nullable Area area, @Nullable AppVersion appVersion) {
        return new CastSettingUserInfo(userLevel, area, appVersion);
    }

    @Nullable
    public final AppVersion getAppVersion() {
        return this.appVersion;
    }

    @Nullable
    public final Area getArea() {
        return this.area;
    }

    @Nullable
    public final UserLevel getUserLevel() {
        return this.userLevel;
    }

    public int hashCode() {
        UserLevel userLevel = this.userLevel;
        int iHashCode = (userLevel == null ? 0 : userLevel.hashCode()) * 31;
        Area area = this.area;
        int iHashCode2 = (iHashCode + (area == null ? 0 : area.hashCode())) * 31;
        AppVersion appVersion = this.appVersion;
        return iHashCode2 + (appVersion != null ? appVersion.hashCode() : 0);
    }

    @NotNull
    public String toString() {
        return "CastSettingUserInfo(userLevel=" + this.userLevel + ", area=" + this.area + ", appVersion=" + this.appVersion + ')';
    }

    public CastSettingUserInfo(@Nullable UserLevel userLevel, @Nullable Area area, @Nullable AppVersion appVersion) {
        this.userLevel = userLevel;
        this.area = area;
        this.appVersion = appVersion;
    }
}