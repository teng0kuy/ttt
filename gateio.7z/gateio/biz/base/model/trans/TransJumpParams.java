package com.gateio.biz.base.model.trans;

import com.gateio.biz.base.model.TransV1OrderType;
import com.zoloz.webcontainer.env.H5Container;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: TransJumpParams.kt */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0015\n\u0002\u0010\b\n\u0002\b\u0003\b\u0086\b\u0018\u00002\u00020\u0001BM\u0012\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\b\u0012\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\b¢\u0006\u0002\u0010\u000bJ\u000b\u0010\u0013\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0014\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0015\u001a\u0004\u0018\u00010\u0006HÆ\u0003J\u0010\u0010\u0016\u001a\u0004\u0018\u00010\bHÆ\u0003¢\u0006\u0002\u0010\u000eJ\u0010\u0010\u0017\u001a\u0004\u0018\u00010\bHÆ\u0003¢\u0006\u0002\u0010\u000eJ\u0010\u0010\u0018\u001a\u0004\u0018\u00010\bHÆ\u0003¢\u0006\u0002\u0010\u000eJV\u0010\u0019\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00062\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\bHÆ\u0001¢\u0006\u0002\u0010\u001aJ\u0013\u0010\u001b\u001a\u00020\b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\u0006\u0010\u001d\u001a\u00020\u001eJ\t\u0010\u001f\u001a\u00020\u001eHÖ\u0001J\t\u0010 \u001a\u00020\u0003HÖ\u0001R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0015\u0010\n\u001a\u0004\u0018\u00010\b¢\u0006\n\n\u0002\u0010\u000f\u001a\u0004\b\n\u0010\u000eR\u0015\u0010\t\u001a\u0004\u0018\u00010\b¢\u0006\n\n\u0002\u0010\u000f\u001a\u0004\b\t\u0010\u000eR\u0015\u0010\u0007\u001a\u0004\u0018\u00010\b¢\u0006\n\n\u0002\u0010\u000f\u001a\u0004\b\u0007\u0010\u000eR\u0013\u0010\u0005\u001a\u0004\u0018\u00010\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\r¨\u0006!"}, d2 = {"Lcom/gateio/biz/base/model/trans/TransJumpParams;", "", "price", "", "amount", "orderType", "Lcom/gateio/biz/base/model/TransV1OrderType;", "isSelectTotal", "", "isFiatMode", "isCheckUnifiedDialog", "(Ljava/lang/String;Ljava/lang/String;Lcom/gateio/biz/base/model/TransV1OrderType;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;)V", "getAmount", "()Ljava/lang/String;", "()Ljava/lang/Boolean;", "Ljava/lang/Boolean;", "getOrderType", "()Lcom/gateio/biz/base/model/TransV1OrderType;", "getPrice", "component1", "component2", "component3", "component4", "component5", "component6", H5Container.MENU_COPY, "(Ljava/lang/String;Ljava/lang/String;Lcom/gateio/biz/base/model/TransV1OrderType;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Boolean;)Lcom/gateio/biz/base/model/trans/TransJumpParams;", "equals", "other", "getOrderPosition", "", "hashCode", "toString", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nTransJumpParams.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TransJumpParams.kt\ncom/gateio/biz/base/model/trans/TransJumpParams\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,29:1\n1#2:30\n*E\n"})
/* loaded from: classes4.dex */
public final /* data */ class TransJumpParams {

    @Nullable
    private final String amount;

    @Nullable
    private final Boolean isCheckUnifiedDialog;

    @Nullable
    private final Boolean isFiatMode;

    @Nullable
    private final Boolean isSelectTotal;

    @Nullable
    private final TransV1OrderType orderType;

    @Nullable
    private final String price;

    public TransJumpParams() {
        this(null, null, null, null, null, null, 63, null);
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof TransJumpParams)) {
            return false;
        }
        TransJumpParams transJumpParams = (TransJumpParams) other;
        return Intrinsics.areEqual(this.price, transJumpParams.price) && Intrinsics.areEqual(this.amount, transJumpParams.amount) && this.orderType == transJumpParams.orderType && Intrinsics.areEqual(this.isSelectTotal, transJumpParams.isSelectTotal) && Intrinsics.areEqual(this.isFiatMode, transJumpParams.isFiatMode) && Intrinsics.areEqual(this.isCheckUnifiedDialog, transJumpParams.isCheckUnifiedDialog);
    }

    /* compiled from: TransJumpParams.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[TransV1OrderType.values().length];
            try {
                iArr[TransV1OrderType.MARKET.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[TransV1OrderType.CONDITIONAL.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[TransV1OrderType.TWAP.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[TransV1OrderType.LIMIT.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public TransJumpParams(@Nullable String str, @Nullable String str2, @Nullable TransV1OrderType transV1OrderType, @Nullable Boolean bool, @Nullable Boolean bool2, @Nullable Boolean bool3) {
        this.price = str;
        this.amount = str2;
        this.orderType = transV1OrderType;
        this.isSelectTotal = bool;
        this.isFiatMode = bool2;
        this.isCheckUnifiedDialog = bool3;
    }

    public static /* synthetic */ TransJumpParams copy$default(TransJumpParams transJumpParams, String str, String str2, TransV1OrderType transV1OrderType, Boolean bool, Boolean bool2, Boolean bool3, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = transJumpParams.price;
        }
        if ((i10 & 2) != 0) {
            str2 = transJumpParams.amount;
        }
        String str3 = str2;
        if ((i10 & 4) != 0) {
            transV1OrderType = transJumpParams.orderType;
        }
        TransV1OrderType transV1OrderType2 = transV1OrderType;
        if ((i10 & 8) != 0) {
            bool = transJumpParams.isSelectTotal;
        }
        Boolean bool4 = bool;
        if ((i10 & 16) != 0) {
            bool2 = transJumpParams.isFiatMode;
        }
        Boolean bool5 = bool2;
        if ((i10 & 32) != 0) {
            bool3 = transJumpParams.isCheckUnifiedDialog;
        }
        return transJumpParams.copy(str, str3, transV1OrderType2, bool4, bool5, bool3);
    }

    @Nullable
    /* renamed from: component1, reason: from getter */
    public final String getPrice() {
        return this.price;
    }

    @Nullable
    /* renamed from: component2, reason: from getter */
    public final String getAmount() {
        return this.amount;
    }

    @Nullable
    /* renamed from: component3, reason: from getter */
    public final TransV1OrderType getOrderType() {
        return this.orderType;
    }

    @Nullable
    /* renamed from: component4, reason: from getter */
    public final Boolean getIsSelectTotal() {
        return this.isSelectTotal;
    }

    @Nullable
    /* renamed from: component5, reason: from getter */
    public final Boolean getIsFiatMode() {
        return this.isFiatMode;
    }

    @Nullable
    /* renamed from: component6, reason: from getter */
    public final Boolean getIsCheckUnifiedDialog() {
        return this.isCheckUnifiedDialog;
    }

    @NotNull
    public final TransJumpParams copy(@Nullable String price, @Nullable String amount, @Nullable TransV1OrderType orderType, @Nullable Boolean isSelectTotal, @Nullable Boolean isFiatMode, @Nullable Boolean isCheckUnifiedDialog) {
        return new TransJumpParams(price, amount, orderType, isSelectTotal, isFiatMode, isCheckUnifiedDialog);
    }

    @Nullable
    public final String getAmount() {
        return this.amount;
    }

    public final int getOrderPosition() {
        TransV1OrderType transV1OrderType = this.orderType;
        if (transV1OrderType == null) {
            return 0;
        }
        int i10 = WhenMappings.$EnumSwitchMapping$0[transV1OrderType.ordinal()];
        if (i10 == 1) {
            return 3;
        }
        if (i10 == 2) {
            return 1;
        }
        if (i10 == 3) {
            return 2;
        }
        if (i10 == 4) {
            return 0;
        }
        throw new NoWhenBranchMatchedException();
    }

    @Nullable
    public final TransV1OrderType getOrderType() {
        return this.orderType;
    }

    @Nullable
    public final String getPrice() {
        return this.price;
    }

    public int hashCode() {
        String str = this.price;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.amount;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        TransV1OrderType transV1OrderType = this.orderType;
        int iHashCode3 = (iHashCode2 + (transV1OrderType == null ? 0 : transV1OrderType.hashCode())) * 31;
        Boolean bool = this.isSelectTotal;
        int iHashCode4 = (iHashCode3 + (bool == null ? 0 : bool.hashCode())) * 31;
        Boolean bool2 = this.isFiatMode;
        int iHashCode5 = (iHashCode4 + (bool2 == null ? 0 : bool2.hashCode())) * 31;
        Boolean bool3 = this.isCheckUnifiedDialog;
        return iHashCode5 + (bool3 != null ? bool3.hashCode() : 0);
    }

    @Nullable
    public final Boolean isCheckUnifiedDialog() {
        return this.isCheckUnifiedDialog;
    }

    @Nullable
    public final Boolean isFiatMode() {
        return this.isFiatMode;
    }

    @Nullable
    public final Boolean isSelectTotal() {
        return this.isSelectTotal;
    }

    @NotNull
    public String toString() {
        return "TransJumpParams(price=" + this.price + ", amount=" + this.amount + ", orderType=" + this.orderType + ", isSelectTotal=" + this.isSelectTotal + ", isFiatMode=" + this.isFiatMode + ", isCheckUnifiedDialog=" + this.isCheckUnifiedDialog + ')';
    }

    public /* synthetic */ TransJumpParams(String str, String str2, TransV1OrderType transV1OrderType, Boolean bool, Boolean bool2, Boolean bool3, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? null : str, (i10 & 2) != 0 ? null : str2, (i10 & 4) == 0 ? transV1OrderType : null, (i10 & 8) != 0 ? Boolean.FALSE : bool, (i10 & 16) != 0 ? Boolean.FALSE : bool2, (i10 & 32) != 0 ? Boolean.FALSE : bool3);
    }
}