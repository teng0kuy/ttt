package com.gateio.biz.base.model.trans;

import com.gateio.biz.home.utils.HomeConst;
import com.zoloz.webcontainer.env.H5Container;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: TransMarginMarketConfig.kt */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\t\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010 \n\u0002\b\u001f\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001Bk\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\u0003\u0012\u0006\u0010\n\u001a\u00020\u0003\u0012\u0006\u0010\u000b\u001a\u00020\u0003\u0012\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\r\u0012\u0010\b\u0002\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u000f¢\u0006\u0002\u0010\u0010J\t\u0010\u001f\u001a\u00020\u0003HÆ\u0003J\u0010\u0010 \u001a\u0004\u0018\u00010\rHÆ\u0003¢\u0006\u0002\u0010\u0011J\u0011\u0010!\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u000fHÆ\u0003J\t\u0010\"\u001a\u00020\u0003HÆ\u0003J\t\u0010#\u001a\u00020\u0003HÆ\u0003J\t\u0010$\u001a\u00020\u0003HÆ\u0003J\t\u0010%\u001a\u00020\u0003HÆ\u0003J\t\u0010&\u001a\u00020\u0003HÆ\u0003J\t\u0010'\u001a\u00020\u0003HÆ\u0003J\t\u0010(\u001a\u00020\u0003HÆ\u0003J\t\u0010)\u001a\u00020\u0003HÆ\u0003J\u0086\u0001\u0010*\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00032\b\b\u0002\u0010\n\u001a\u00020\u00032\b\b\u0002\u0010\u000b\u001a\u00020\u00032\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\r2\u0010\b\u0002\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u000fHÆ\u0001¢\u0006\u0002\u0010+J\u0013\u0010,\u001a\u00020\r2\b\u0010-\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010.\u001a\u00020/HÖ\u0001J\t\u00100\u001a\u00020\u0003HÖ\u0001R\u0015\u0010\f\u001a\u0004\u0018\u00010\r¢\u0006\n\n\u0002\u0010\u0012\u001a\u0004\b\f\u0010\u0011R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0014R\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0014R\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0014R\u0011\u0010\u000b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0014R\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0014R\u0019\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u000f¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0014R\u0011\u0010\t\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0014R\u0011\u0010\n\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0014¨\u00061"}, d2 = {"Lcom/gateio/biz/base/model/trans/TransMarginMarketConfig;", "", HomeConst.HOME_PORCELAIN_STRATEGY_LEVERAGE, "", "leverage_range", "liquidate_margin_rate", "market", "warning_mr", "warning_mr_max", "warning_mr_min", "warning_mr_step", "migration_mr", "is_margin_trading", "", "warning_mr_list", "", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/util/List;)V", "()Ljava/lang/Boolean;", "Ljava/lang/Boolean;", "getLeverage", "()Ljava/lang/String;", "getLeverage_range", "getLiquidate_margin_rate", "getMarket", "getMigration_mr", "getWarning_mr", "getWarning_mr_list", "()Ljava/util/List;", "getWarning_mr_max", "getWarning_mr_min", "getWarning_mr_step", "component1", "component10", "component11", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", H5Container.MENU_COPY, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/util/List;)Lcom/gateio/biz/base/model/trans/TransMarginMarketConfig;", "equals", "other", "hashCode", "", "toString", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class TransMarginMarketConfig {

    @Nullable
    private final Boolean is_margin_trading;

    @NotNull
    private final String leverage;

    @NotNull
    private final String leverage_range;

    @NotNull
    private final String liquidate_margin_rate;

    @NotNull
    private final String market;

    @NotNull
    private final String migration_mr;

    @NotNull
    private final String warning_mr;

    @Nullable
    private final List<String> warning_mr_list;

    @NotNull
    private final String warning_mr_max;

    @NotNull
    private final String warning_mr_min;

    @NotNull
    private final String warning_mr_step;

    public TransMarginMarketConfig(@NotNull String str, @NotNull String str2, @NotNull String str3, @NotNull String str4, @NotNull String str5, @NotNull String str6, @NotNull String str7, @NotNull String str8, @NotNull String str9, @Nullable Boolean bool, @Nullable List<String> list) {
        this.leverage = str;
        this.leverage_range = str2;
        this.liquidate_margin_rate = str3;
        this.market = str4;
        this.warning_mr = str5;
        this.warning_mr_max = str6;
        this.warning_mr_min = str7;
        this.warning_mr_step = str8;
        this.migration_mr = str9;
        this.is_margin_trading = bool;
        this.warning_mr_list = list;
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof TransMarginMarketConfig)) {
            return false;
        }
        TransMarginMarketConfig transMarginMarketConfig = (TransMarginMarketConfig) other;
        return Intrinsics.areEqual(this.leverage, transMarginMarketConfig.leverage) && Intrinsics.areEqual(this.leverage_range, transMarginMarketConfig.leverage_range) && Intrinsics.areEqual(this.liquidate_margin_rate, transMarginMarketConfig.liquidate_margin_rate) && Intrinsics.areEqual(this.market, transMarginMarketConfig.market) && Intrinsics.areEqual(this.warning_mr, transMarginMarketConfig.warning_mr) && Intrinsics.areEqual(this.warning_mr_max, transMarginMarketConfig.warning_mr_max) && Intrinsics.areEqual(this.warning_mr_min, transMarginMarketConfig.warning_mr_min) && Intrinsics.areEqual(this.warning_mr_step, transMarginMarketConfig.warning_mr_step) && Intrinsics.areEqual(this.migration_mr, transMarginMarketConfig.migration_mr) && Intrinsics.areEqual(this.is_margin_trading, transMarginMarketConfig.is_margin_trading) && Intrinsics.areEqual(this.warning_mr_list, transMarginMarketConfig.warning_mr_list);
    }

    @NotNull
    /* renamed from: component1, reason: from getter */
    public final String getLeverage() {
        return this.leverage;
    }

    @Nullable
    /* renamed from: component10, reason: from getter */
    public final Boolean getIs_margin_trading() {
        return this.is_margin_trading;
    }

    @Nullable
    public final List<String> component11() {
        return this.warning_mr_list;
    }

    @NotNull
    /* renamed from: component2, reason: from getter */
    public final String getLeverage_range() {
        return this.leverage_range;
    }

    @NotNull
    /* renamed from: component3, reason: from getter */
    public final String getLiquidate_margin_rate() {
        return this.liquidate_margin_rate;
    }

    @NotNull
    /* renamed from: component4, reason: from getter */
    public final String getMarket() {
        return this.market;
    }

    @NotNull
    /* renamed from: component5, reason: from getter */
    public final String getWarning_mr() {
        return this.warning_mr;
    }

    @NotNull
    /* renamed from: component6, reason: from getter */
    public final String getWarning_mr_max() {
        return this.warning_mr_max;
    }

    @NotNull
    /* renamed from: component7, reason: from getter */
    public final String getWarning_mr_min() {
        return this.warning_mr_min;
    }

    @NotNull
    /* renamed from: component8, reason: from getter */
    public final String getWarning_mr_step() {
        return this.warning_mr_step;
    }

    @NotNull
    /* renamed from: component9, reason: from getter */
    public final String getMigration_mr() {
        return this.migration_mr;
    }

    @NotNull
    public final TransMarginMarketConfig copy(@NotNull String leverage, @NotNull String leverage_range, @NotNull String liquidate_margin_rate, @NotNull String market, @NotNull String warning_mr, @NotNull String warning_mr_max, @NotNull String warning_mr_min, @NotNull String warning_mr_step, @NotNull String migration_mr, @Nullable Boolean is_margin_trading, @Nullable List<String> warning_mr_list) {
        return new TransMarginMarketConfig(leverage, leverage_range, liquidate_margin_rate, market, warning_mr, warning_mr_max, warning_mr_min, warning_mr_step, migration_mr, is_margin_trading, warning_mr_list);
    }

    @NotNull
    public final String getLeverage() {
        return this.leverage;
    }

    @NotNull
    public final String getLeverage_range() {
        return this.leverage_range;
    }

    @NotNull
    public final String getLiquidate_margin_rate() {
        return this.liquidate_margin_rate;
    }

    @NotNull
    public final String getMarket() {
        return this.market;
    }

    @NotNull
    public final String getMigration_mr() {
        return this.migration_mr;
    }

    @NotNull
    public final String getWarning_mr() {
        return this.warning_mr;
    }

    @Nullable
    public final List<String> getWarning_mr_list() {
        return this.warning_mr_list;
    }

    @NotNull
    public final String getWarning_mr_max() {
        return this.warning_mr_max;
    }

    @NotNull
    public final String getWarning_mr_min() {
        return this.warning_mr_min;
    }

    @NotNull
    public final String getWarning_mr_step() {
        return this.warning_mr_step;
    }

    public int hashCode() {
        int iHashCode = ((((((((((((((((this.leverage.hashCode() * 31) + this.leverage_range.hashCode()) * 31) + this.liquidate_margin_rate.hashCode()) * 31) + this.market.hashCode()) * 31) + this.warning_mr.hashCode()) * 31) + this.warning_mr_max.hashCode()) * 31) + this.warning_mr_min.hashCode()) * 31) + this.warning_mr_step.hashCode()) * 31) + this.migration_mr.hashCode()) * 31;
        Boolean bool = this.is_margin_trading;
        int iHashCode2 = (iHashCode + (bool == null ? 0 : bool.hashCode())) * 31;
        List<String> list = this.warning_mr_list;
        return iHashCode2 + (list != null ? list.hashCode() : 0);
    }

    @Nullable
    public final Boolean is_margin_trading() {
        return this.is_margin_trading;
    }

    @NotNull
    public String toString() {
        return "TransMarginMarketConfig(leverage=" + this.leverage + ", leverage_range=" + this.leverage_range + ", liquidate_margin_rate=" + this.liquidate_margin_rate + ", market=" + this.market + ", warning_mr=" + this.warning_mr + ", warning_mr_max=" + this.warning_mr_max + ", warning_mr_min=" + this.warning_mr_min + ", warning_mr_step=" + this.warning_mr_step + ", migration_mr=" + this.migration_mr + ", is_margin_trading=" + this.is_margin_trading + ", warning_mr_list=" + this.warning_mr_list + ')';
    }

    public /* synthetic */ TransMarginMarketConfig(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, Boolean bool, List list, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, str2, str3, str4, str5, str6, str7, str8, str9, (i10 & 512) != 0 ? Boolean.TRUE : bool, (i10 & 1024) != 0 ? null : list);
    }
}