package com.gateio.biz.base.model.trans;

import com.zoloz.webcontainer.env.H5Container;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: TransMarginRiskParams.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\t\u0010\f\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\r\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0011\u001a\u00020\u0012HÖ\u0001J\t\u0010\u0013\u001a\u00020\u0014HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0015"}, d2 = {"Lcom/gateio/biz/base/model/trans/TransMarginRiskParams;", "", "borrowAccountResponse", "Lcom/gateio/biz/base/model/trans/BorrowAccountResponse;", "transMarginMarketConfig", "Lcom/gateio/biz/base/model/trans/TransMarginMarketConfig;", "(Lcom/gateio/biz/base/model/trans/BorrowAccountResponse;Lcom/gateio/biz/base/model/trans/TransMarginMarketConfig;)V", "getBorrowAccountResponse", "()Lcom/gateio/biz/base/model/trans/BorrowAccountResponse;", "getTransMarginMarketConfig", "()Lcom/gateio/biz/base/model/trans/TransMarginMarketConfig;", "component1", "component2", H5Container.MENU_COPY, "equals", "", "other", "hashCode", "", "toString", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class TransMarginRiskParams {

    @NotNull
    private final BorrowAccountResponse borrowAccountResponse;

    @NotNull
    private final TransMarginMarketConfig transMarginMarketConfig;

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof TransMarginRiskParams)) {
            return false;
        }
        TransMarginRiskParams transMarginRiskParams = (TransMarginRiskParams) other;
        return Intrinsics.areEqual(this.borrowAccountResponse, transMarginRiskParams.borrowAccountResponse) && Intrinsics.areEqual(this.transMarginMarketConfig, transMarginRiskParams.transMarginMarketConfig);
    }

    public static /* synthetic */ TransMarginRiskParams copy$default(TransMarginRiskParams transMarginRiskParams, BorrowAccountResponse borrowAccountResponse, TransMarginMarketConfig transMarginMarketConfig, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            borrowAccountResponse = transMarginRiskParams.borrowAccountResponse;
        }
        if ((i10 & 2) != 0) {
            transMarginMarketConfig = transMarginRiskParams.transMarginMarketConfig;
        }
        return transMarginRiskParams.copy(borrowAccountResponse, transMarginMarketConfig);
    }

    @NotNull
    /* renamed from: component1, reason: from getter */
    public final BorrowAccountResponse getBorrowAccountResponse() {
        return this.borrowAccountResponse;
    }

    @NotNull
    /* renamed from: component2, reason: from getter */
    public final TransMarginMarketConfig getTransMarginMarketConfig() {
        return this.transMarginMarketConfig;
    }

    @NotNull
    public final TransMarginRiskParams copy(@NotNull BorrowAccountResponse borrowAccountResponse, @NotNull TransMarginMarketConfig transMarginMarketConfig) {
        return new TransMarginRiskParams(borrowAccountResponse, transMarginMarketConfig);
    }

    @NotNull
    public final BorrowAccountResponse getBorrowAccountResponse() {
        return this.borrowAccountResponse;
    }

    @NotNull
    public final TransMarginMarketConfig getTransMarginMarketConfig() {
        return this.transMarginMarketConfig;
    }

    public int hashCode() {
        return (this.borrowAccountResponse.hashCode() * 31) + this.transMarginMarketConfig.hashCode();
    }

    @NotNull
    public String toString() {
        return "TransMarginRiskParams(borrowAccountResponse=" + this.borrowAccountResponse + ", transMarginMarketConfig=" + this.transMarginMarketConfig + ')';
    }

    public TransMarginRiskParams(@NotNull BorrowAccountResponse borrowAccountResponse, @NotNull TransMarginMarketConfig transMarginMarketConfig) {
        this.borrowAccountResponse = borrowAccountResponse;
        this.transMarginMarketConfig = transMarginMarketConfig;
    }
}