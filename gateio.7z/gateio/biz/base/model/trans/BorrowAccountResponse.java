package com.gateio.biz.base.model.trans;

import android.os.Parcel;
import android.os.Parcelable;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;

/* loaded from: classes4.dex */
public class BorrowAccountResponse implements Parcelable {
    public static final Parcelable.Creator<BorrowAccountResponse> CREATOR = new Parcelable.Creator<BorrowAccountResponse>() { // from class: com.gateio.biz.base.model.trans.BorrowAccountResponse.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BorrowAccountResponse createFromParcel(Parcel parcel) {
            return new BorrowAccountResponse(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public BorrowAccountResponse[] newArray(int i10) {
            return new BorrowAccountResponse[i10];
        }
    };
    private String arrears_interest_total_a;
    private String arrears_interest_total_b;
    private String available_a;
    private String available_b;
    private String available_usd;
    private String borrow_a;
    private String borrow_b;
    private String borrowed_a;
    private String borrowed_b;
    private String borrowed_total_usd;
    private String borrowed_usd;
    private String frozen_a;
    private String frozen_b;
    private String frozen_usd;
    private String interest_usd;
    private String leverage;
    private boolean locked;
    private String margin_risk_price;
    private String margin_risk_rate;
    private String market_max_amount;
    private String market_multiple;
    private String mm;
    private String mmr;
    private String net_value;
    private String total_usd;
    private String use_risk_rate;

    public BorrowAccountResponse() {
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public BorrowAccountResponse(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8) {
        this.margin_risk_rate = str;
        this.total_usd = str2;
        this.frozen_usd = str3;
        this.interest_usd = str4;
        this.available_usd = str5;
        this.borrowed_total_usd = str6;
        this.borrowed_usd = str7;
        this.use_risk_rate = str8;
    }

    public String getArrears_interest_total_a() {
        return this.arrears_interest_total_a;
    }

    public String getArrears_interest_total_b() {
        return this.arrears_interest_total_b;
    }

    public String getAvailableValue(boolean z10) {
        return z10 ? this.available_b : this.available_a;
    }

    public String getAvailable_a() {
        return this.available_a;
    }

    public String getAvailable_b() {
        return this.available_b;
    }

    public String getAvailable_usd() {
        return this.available_usd;
    }

    public String getBorrow_a() {
        return this.borrow_a;
    }

    public String getBorrow_b() {
        return this.borrow_b;
    }

    public String getBorrowedValue(boolean z10) {
        return z10 ? this.borrowed_a : this.borrowed_b;
    }

    public String getBorrowed_a() {
        return this.borrowed_a;
    }

    public String getBorrowed_b() {
        return this.borrowed_b;
    }

    public String getBorrowed_total_usd() {
        return this.borrowed_total_usd;
    }

    public String getBorrowed_usd() {
        return this.borrowed_usd;
    }

    public String getCanBorrowValue(boolean z10) {
        return z10 ? this.borrow_b : this.borrow_a;
    }

    public String getFrozen_a() {
        return this.frozen_a;
    }

    public String getFrozen_b() {
        return this.frozen_b;
    }

    public String getFrozen_usd() {
        return this.frozen_usd;
    }

    public String getInterest_usd() {
        return this.interest_usd;
    }

    public String getLeverage() {
        return this.leverage;
    }

    public String getMargin_risk_price() {
        return this.margin_risk_price;
    }

    public String getMargin_risk_rate() {
        return this.margin_risk_rate;
    }

    public String getMarket_max_amount() {
        return this.market_max_amount;
    }

    public String getMarket_multiple() {
        return this.market_multiple;
    }

    public String getMm() {
        return this.mm;
    }

    public String getMmr() {
        return this.mmr;
    }

    public String getNet_value() {
        return this.net_value;
    }

    public String getTotal_usd() {
        return this.total_usd;
    }

    public String getUse_risk_rate() {
        return this.use_risk_rate;
    }

    public boolean isLocked() {
        return this.locked;
    }

    public void setArrears_interest_total_a(String str) {
        this.arrears_interest_total_a = str;
    }

    public void setArrears_interest_total_b(String str) {
        this.arrears_interest_total_b = str;
    }

    public void setAvailable_a(String str) {
        this.available_a = str;
    }

    public void setAvailable_b(String str) {
        this.available_b = str;
    }

    public void setAvailable_usd(String str) {
        this.available_usd = str;
    }

    public void setBorrow_a(String str) {
        this.borrow_a = str;
    }

    public void setBorrow_b(String str) {
        this.borrow_b = str;
    }

    public void setBorrowed_a(String str) {
        this.borrowed_a = str;
    }

    public void setBorrowed_b(String str) {
        this.borrowed_b = str;
    }

    public void setBorrowed_total_usd(String str) {
        this.borrowed_total_usd = str;
    }

    public void setBorrowed_usd(String str) {
        this.borrowed_usd = str;
    }

    public void setFrozen_a(String str) {
        this.frozen_a = str;
    }

    public void setFrozen_b(String str) {
        this.frozen_b = str;
    }

    public void setFrozen_usd(String str) {
        this.frozen_usd = str;
    }

    public void setInterest_usd(String str) {
        this.interest_usd = str;
    }

    public void setLeverage(String str) {
        this.leverage = str;
    }

    public void setLocked(boolean z10) {
        this.locked = z10;
    }

    public void setMargin_risk_price(String str) {
        this.margin_risk_price = str;
    }

    public void setMargin_risk_rate(String str) {
        this.margin_risk_rate = str;
    }

    public void setMarket_max_amount(String str) {
        this.market_max_amount = str;
    }

    public void setMarket_multiple(String str) {
        this.market_multiple = str;
    }

    public void setMm(String str) {
        this.mm = str;
    }

    public void setMmr(String str) {
        this.mmr = str;
    }

    public void setNet_value(String str) {
        this.net_value = str;
    }

    public void setTotal_usd(String str) {
        this.total_usd = str;
    }

    public void setUse_risk_rate(String str) {
        this.use_risk_rate = str;
    }

    public String toString() {
        return "BorrowAccountResponse{margin_risk_price='" + this.margin_risk_price + "', margin_risk_rate='" + this.margin_risk_rate + "', available_a='" + this.available_a + "', available_b='" + this.available_b + "', frozen_a='" + this.frozen_a + "', frozen_b='" + this.frozen_b + "', borrowed_a='" + this.borrowed_a + "', borrowed_b='" + this.borrowed_b + "', borrow_a='" + this.borrow_a + "', borrow_b='" + this.borrow_b + "', arrears_interest_total_a='" + this.arrears_interest_total_a + "', arrears_interest_total_b='" + this.arrears_interest_total_b + "', locked=" + this.locked + ", market_max_amount='" + this.market_max_amount + "', market_multiple='" + this.market_multiple + "', total_usd='" + this.total_usd + "', frozen_usd='" + this.frozen_usd + "', interest_usd='" + this.interest_usd + "', available_usd='" + this.available_usd + "', borrowed_total_usd='" + this.borrowed_total_usd + "', borrowed_usd='" + this.borrowed_usd + "', use_risk_rate='" + this.use_risk_rate + "', net_value='" + this.net_value + "', mmr='" + this.mmr + "', mm='" + this.mm + "', leverage='" + this.leverage + '\'' + AbstractJsonLexerKt.END_OBJ;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeString(this.margin_risk_price);
        parcel.writeString(this.margin_risk_rate);
        parcel.writeString(this.available_a);
        parcel.writeString(this.available_b);
        parcel.writeString(this.frozen_a);
        parcel.writeString(this.frozen_b);
        parcel.writeString(this.borrowed_a);
        parcel.writeString(this.borrowed_b);
        parcel.writeString(this.borrow_a);
        parcel.writeString(this.borrow_b);
        parcel.writeString(this.arrears_interest_total_a);
        parcel.writeString(this.arrears_interest_total_b);
        parcel.writeString(this.market_multiple);
        parcel.writeByte(this.locked ? (byte) 1 : (byte) 0);
        parcel.writeString(this.market_max_amount);
        parcel.writeString(this.total_usd);
        parcel.writeString(this.frozen_usd);
        parcel.writeString(this.interest_usd);
        parcel.writeString(this.available_usd);
        parcel.writeString(this.borrowed_total_usd);
        parcel.writeString(this.borrowed_usd);
        parcel.writeString(this.use_risk_rate);
    }

    public boolean isCloseLoan() {
        return getMarket_max_amount().equals("0");
    }

    protected BorrowAccountResponse(Parcel parcel) {
        this.margin_risk_price = parcel.readString();
        this.margin_risk_rate = parcel.readString();
        this.available_a = parcel.readString();
        this.available_b = parcel.readString();
        this.frozen_a = parcel.readString();
        this.frozen_b = parcel.readString();
        this.borrowed_a = parcel.readString();
        this.borrowed_b = parcel.readString();
        this.borrow_a = parcel.readString();
        this.borrow_b = parcel.readString();
        this.arrears_interest_total_a = parcel.readString();
        this.arrears_interest_total_b = parcel.readString();
        this.market_multiple = parcel.readString();
        this.locked = parcel.readByte() != 0;
        this.market_max_amount = parcel.readString();
        this.total_usd = parcel.readString();
        this.frozen_usd = parcel.readString();
        this.interest_usd = parcel.readString();
        this.available_usd = parcel.readString();
        this.borrowed_total_usd = parcel.readString();
        this.borrowed_usd = parcel.readString();
        this.use_risk_rate = parcel.readString();
    }
}