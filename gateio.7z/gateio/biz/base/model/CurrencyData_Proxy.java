package com.gateio.biz.base.model;

import androidx.annotation.Keep;
import com.gateio.lib.storage.annotation.GTStorageGroup;
import com.gateio.lib.storage.protocol.IGTStorageProxy;
import java.util.ArrayList;

@Keep
/* loaded from: classes4.dex */
public class CurrencyData_Proxy extends IGTStorageProxy<CurrencyData> {
    private ArrayList<String> filedOfRealmTypeClassList;
    private CurrencyData realObj;

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public int getProxyVersion() {
        return 2;
    }

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public ArrayList<String> getRealmTypeClassList() {
        return null;
    }

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public boolean isHavePrimaryKey() {
        return true;
    }

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public boolean isHaveRealmType() {
        return false;
    }

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public String getPrimaryKeyFieldName() {
        return "currencyType";
    }

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public String getPrimaryKeyValue() {
        return this.realObj.getCurrencyType();
    }

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public CurrencyData getRealObj() {
        return this.realObj;
    }

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public GTStorageGroup getStorageGroup() {
        return GTStorageGroup.APP;
    }

    @Override // com.gateio.lib.storage.protocol.IGTStorageProxy
    public void setRealObj(CurrencyData currencyData) {
        this.realObj = currencyData;
    }
}