package com.gateio.biz.base.model;

import java.util.List;

/* loaded from: classes4.dex */
public class RateComponentAb {
    private boolean android_small_window;
    private boolean big_window;
    private List<String> country_limit;
    private boolean is_have_reward;
    private String scoring_activity_url;
    private SupportOpenStore support_open_store;
    private TimeCycle time_cycle;
    private WindowLimit window_limit;

    public static class SupportOpenStore {
        private boolean about_us;
        private boolean bearish_shark_success;
        private boolean bullish_shark_success;
        private boolean dual_investment_success;
        private boolean eth2staking_success;
        private boolean gtstaking_success;
        private boolean simple_earn_redeem_success;
        private boolean solstaking_success;
        private boolean startup_success;
        private boolean trxstaking_success;
        private boolean withdrew_success;

        public boolean isAbout_us() {
            return this.about_us;
        }

        public boolean isBearish_shark_success() {
            return this.bearish_shark_success;
        }

        public boolean isBullish_shark_success() {
            return this.bullish_shark_success;
        }

        public boolean isDual_investment_success() {
            return this.dual_investment_success;
        }

        public boolean isEth2staking_success() {
            return this.eth2staking_success;
        }

        public boolean isGtstaking_success() {
            return this.gtstaking_success;
        }

        public boolean isSimple_earn_redeem_success() {
            return this.simple_earn_redeem_success;
        }

        public boolean isSolstaking_success() {
            return this.solstaking_success;
        }

        public boolean isStartup_success() {
            return this.startup_success;
        }

        public boolean isTrxstaking_success() {
            return this.trxstaking_success;
        }

        public boolean isWithdrew_success() {
            return this.withdrew_success;
        }

        public void setAbout_us(boolean z10) {
            this.about_us = z10;
        }

        public void setBearish_shark_success(boolean z10) {
            this.bearish_shark_success = z10;
        }

        public void setBullish_shark_success(boolean z10) {
            this.bullish_shark_success = z10;
        }

        public void setDual_investment_success(boolean z10) {
            this.dual_investment_success = z10;
        }

        public void setEth2staking_success(boolean z10) {
            this.eth2staking_success = z10;
        }

        public void setGtstaking_success(boolean z10) {
            this.gtstaking_success = z10;
        }

        public void setSimple_earn_redeem_success(boolean z10) {
            this.simple_earn_redeem_success = z10;
        }

        public void setSolstaking_success(boolean z10) {
            this.solstaking_success = z10;
        }

        public void setStartup_success(boolean z10) {
            this.startup_success = z10;
        }

        public void setTrxstaking_success(boolean z10) {
            this.trxstaking_success = z10;
        }

        public void setWithdrew_success(boolean z10) {
            this.withdrew_success = z10;
        }
    }

    public static class TimeCycle {
        private int big_rate;
        private int open_store;
        private int rate;

        public int getBig_rate() {
            return this.big_rate;
        }

        public int getOpen_store() {
            return this.open_store;
        }

        public int getRate() {
            return this.rate;
        }

        public void setBig_rate(int i10) {
            this.big_rate = i10;
        }

        public void setOpen_store(int i10) {
            this.open_store = i10;
        }

        public void setRate(int i10) {
            this.rate = i10;
        }
    }

    public static class WindowLimit {
        private int market_time;

        public int getMarket_time() {
            return this.market_time;
        }

        public void setMarket_time(int i10) {
            this.market_time = i10;
        }
    }

    public boolean getAndroid_small_window() {
        return this.android_small_window;
    }

    public boolean getBig_window() {
        return this.big_window;
    }

    public List<String> getCountry_limit() {
        return this.country_limit;
    }

    public boolean getIs_have_reward() {
        return this.is_have_reward;
    }

    public String getScoring_activity_url() {
        return this.scoring_activity_url;
    }

    public SupportOpenStore getSupport_open_store() {
        return this.support_open_store;
    }

    public TimeCycle getTime_cycle() {
        return this.time_cycle;
    }

    public WindowLimit getWindow_limit() {
        return this.window_limit;
    }

    public void setAndroid_small_window(boolean z10) {
        this.android_small_window = z10;
    }

    public void setBig_window(boolean z10) {
        this.big_window = z10;
    }

    public void setCountry_limit(List<String> list) {
        this.country_limit = list;
    }

    public void setIs_have_reward(boolean z10) {
        this.is_have_reward = z10;
    }

    public void setScoring_activity_url(String str) {
        this.scoring_activity_url = str;
    }

    public void setSupport_open_store(SupportOpenStore supportOpenStore) {
        this.support_open_store = supportOpenStore;
    }

    public void setTime_cycle(TimeCycle timeCycle) {
        this.time_cycle = timeCycle;
    }

    public void setWindow_limit(WindowLimit windowLimit) {
        this.window_limit = windowLimit;
    }
}