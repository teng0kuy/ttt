package com.gateio.biz.base.model;

import androidx.annotation.Nullable;
import com.google.gson.annotations.SerializedName;

/* loaded from: classes4.dex */
public class PilotTransTradeRecord {

    @Nullable
    private String amount;

    @Nullable
    @SerializedName(alternate = {"token_address"}, value = "chain_address")
    private String chain_address;

    @Nullable
    private String chain_name;

    @Nullable
    @SerializedName(alternate = {"chain"}, value = "chain_symbol")
    private String chain_symbol;

    @Nullable
    @SerializedName(alternate = {"chain_icon"}, value = "chain_url")
    private String chain_url;
    private long deal_time;

    @Nullable
    private String fee;

    @Nullable
    private String fee_currency;

    @Nullable
    private String market;

    @Nullable
    private String order_id;

    @Nullable
    private String price;

    @Nullable
    private String role;

    @Nullable
    private String show_pair;

    @Nullable
    private String side;

    @Nullable
    private String trade_id;

    @Nullable
    private String trade_vol;

    @Nullable
    public String getAmount() {
        return this.amount;
    }

    @Nullable
    public String getChain_address() {
        return this.chain_address;
    }

    @Nullable
    public String getChain_name() {
        return this.chain_name;
    }

    @Nullable
    public String getChain_symbol() {
        return this.chain_symbol;
    }

    @Nullable
    public String getChain_url() {
        return this.chain_url;
    }

    public long getDeal_time() {
        return this.deal_time;
    }

    @Nullable
    public String getFee() {
        return this.fee;
    }

    @Nullable
    public String getFee_currency() {
        return this.fee_currency;
    }

    @Nullable
    public String getMarket() {
        return this.market;
    }

    @Nullable
    public String getOrder_id() {
        return this.order_id;
    }

    @Nullable
    public String getPrice() {
        return this.price;
    }

    @Nullable
    public String getRole() {
        return this.role;
    }

    @Nullable
    public String getShow_pair() {
        return this.show_pair;
    }

    @Nullable
    public String getSide() {
        return this.side;
    }

    @Nullable
    public String getTrade_id() {
        return this.trade_id;
    }

    @Nullable
    public String getTrade_vol() {
        return this.trade_vol;
    }

    public void setAmount(@Nullable String str) {
        this.amount = str;
    }

    public void setChain_address(@Nullable String str) {
        this.chain_address = str;
    }

    public void setChain_name(@Nullable String str) {
        this.chain_name = str;
    }

    public void setChain_symbol(@Nullable String str) {
        this.chain_symbol = str;
    }

    public void setChain_url(@Nullable String str) {
        this.chain_url = str;
    }

    public void setDeal_time(long j10) {
        this.deal_time = j10;
    }

    public void setFee(@Nullable String str) {
        this.fee = str;
    }

    public void setFee_currency(@Nullable String str) {
        this.fee_currency = str;
    }

    public void setMarket(@Nullable String str) {
        this.market = str;
    }

    public void setOrder_id(@Nullable String str) {
        this.order_id = str;
    }

    public void setPrice(@Nullable String str) {
        this.price = str;
    }

    public void setRole(@Nullable String str) {
        this.role = str;
    }

    public void setShow_pair(@Nullable String str) {
        this.show_pair = str;
    }

    public void setSide(@Nullable String str) {
        this.side = str;
    }

    public void setTrade_id(@Nullable String str) {
        this.trade_id = str;
    }

    public void setTrade_vol(@Nullable String str) {
        this.trade_vol = str;
    }
}