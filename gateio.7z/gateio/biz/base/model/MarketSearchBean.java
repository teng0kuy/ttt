package com.gateio.biz.base.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.gateio.common.tool.StringUtils;

/* loaded from: classes4.dex */
public class MarketSearchBean implements Parcelable {
    public static final Parcelable.Creator<MarketSearchBean> CREATOR = new Parcelable.Creator<MarketSearchBean>() { // from class: com.gateio.biz.base.model.MarketSearchBean.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public MarketSearchBean createFromParcel(Parcel parcel) {
            return new MarketSearchBean(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public MarketSearchBean[] newArray(int i10) {
            return new MarketSearchBean[i10];
        }
    };
    private String currency;
    private String currencyEnName;
    private String currencyName;
    private String exchange;
    private String exchangeEnName;
    private String exchangeName;
    private boolean isAll;
    private boolean isChecked;
    private boolean isContract;
    private String settle_coin;

    public MarketSearchBean() {
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    protected MarketSearchBean(Parcel parcel) {
        this.currency = parcel.readString();
        this.currencyName = parcel.readString();
        this.currencyEnName = parcel.readString();
        this.exchange = parcel.readString();
        this.exchangeName = parcel.readString();
        this.exchangeEnName = parcel.readString();
        this.isContract = parcel.readByte() != 0;
        this.isChecked = parcel.readByte() != 0;
        this.isAll = parcel.readByte() != 0;
        this.settle_coin = parcel.readString();
    }

    public String getCurrency() {
        return this.currency;
    }

    public String getCurrencyEnName() {
        return this.currencyEnName;
    }

    public String getCurrencyName() {
        return this.currencyName;
    }

    public String getExchange() {
        return this.exchange;
    }

    public String getExchangeEnName() {
        return this.exchangeEnName;
    }

    public String getExchangeName() {
        return this.exchangeName;
    }

    public String getPair() {
        return String.format("%s/%s", StringUtils.trimToEmpty(this.currency), StringUtils.trimToEmpty(this.exchange));
    }

    public String getSettle_coin() {
        return this.settle_coin;
    }

    public boolean isAll() {
        return this.isAll;
    }

    public boolean isChecked() {
        return this.isChecked;
    }

    public boolean isContract() {
        return this.isContract;
    }

    public boolean isSame(String str, String str2) {
        return StringUtils.equals(str, this.currency) && StringUtils.equals(str2, this.exchange);
    }

    public void setAll(boolean z10) {
        this.isAll = z10;
    }

    public void setChecked(boolean z10) {
        this.isChecked = z10;
    }

    public void setContract(boolean z10) {
        this.isContract = z10;
    }

    public void setCurrency(String str) {
        this.currency = str;
    }

    public void setCurrencyEnName(String str) {
        this.currencyEnName = str;
    }

    public void setCurrencyName(String str) {
        this.currencyName = str;
    }

    public void setExchange(String str) {
        this.exchange = str;
    }

    public void setExchangeEnName(String str) {
        this.exchangeEnName = str;
    }

    public void setExchangeName(String str) {
        this.exchangeName = str;
    }

    public void setSettle_coin(String str) {
        this.settle_coin = str;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeString(this.currency);
        parcel.writeString(this.currencyName);
        parcel.writeString(this.currencyEnName);
        parcel.writeString(this.exchange);
        parcel.writeString(this.exchangeName);
        parcel.writeString(this.exchangeEnName);
        parcel.writeByte(this.isContract ? (byte) 1 : (byte) 0);
        parcel.writeByte(this.isChecked ? (byte) 1 : (byte) 0);
        parcel.writeByte(this.isAll ? (byte) 1 : (byte) 0);
        parcel.writeString(this.settle_coin);
    }
}