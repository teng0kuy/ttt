package com.gateio.biz.base.model.memebox;

import androidx.profileinstaller.ProfileVerifier;
import com.gateio.biz.memebox.ui.fragments.confirm.AlphaFastOrderDialogFragment;
import com.gateio.lib.glue.GTLibGlue;
import com.gateio.lib.storage.GTStorage;
import com.gateio.lib.utils.json.GTJSONUtils;
import java.io.Serializable;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: MemeBoxTokenInfoBean.kt */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0010\n\u0002\u0010\u0011\n\u0002\b.\n\u0002\u0010\u000b\n\u0002\b\u0002\u0018\u0000 F2\u00020\u0001:\u0001FBá\u0001\u0012\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\n\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u000f\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0010\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0011\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0013\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0014\u001a\u0004\u0018\u00010\u0003\u0012\u0010\b\u0002\u0010\u0015\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u0016¢\u0006\u0002\u0010\u0017J\u0006\u0010D\u001a\u00020ER\u001c\u0010\u0002\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0019\"\u0004\b\u001a\u0010\u001bR\u001e\u0010\u0006\u001a\u0004\u0018\u00010\u0005X\u0086\u000e¢\u0006\u0010\n\u0002\u0010 \u001a\u0004\b\u001c\u0010\u001d\"\u0004\b\u001e\u0010\u001fR\u001c\u0010\u000e\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b!\u0010\u0019\"\u0004\b\"\u0010\u001bR\u001c\u0010\t\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b#\u0010\u0019\"\u0004\b$\u0010\u001bR\u001c\u0010\f\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b%\u0010\u0019\"\u0004\b&\u0010\u001bR\u001c\u0010\u000b\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b'\u0010\u0019\"\u0004\b(\u0010\u001bR\u001c\u0010\b\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b)\u0010\u0019\"\u0004\b*\u0010\u001bR\u001c\u0010\r\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b+\u0010\u0019\"\u0004\b,\u0010\u001bR\u001c\u0010\u000f\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b-\u0010\u0019\"\u0004\b.\u0010\u001bR\u001c\u0010\u0007\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b/\u0010\u0019\"\u0004\b0\u0010\u001bR\u001c\u0010\n\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b1\u0010\u0019\"\u0004\b2\u0010\u001bR\u001e\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0086\u000e¢\u0006\u0010\n\u0002\u0010 \u001a\u0004\b3\u0010\u001d\"\u0004\b4\u0010\u001fR$\u0010\u0015\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u0016X\u0086\u000e¢\u0006\u0010\n\u0002\u00109\u001a\u0004\b5\u00106\"\u0004\b7\u00108R\u001c\u0010\u0012\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b:\u0010\u0019\"\u0004\b;\u0010\u001bR\u001c\u0010\u0014\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b<\u0010\u0019\"\u0004\b=\u0010\u001bR\u001c\u0010\u0013\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b>\u0010\u0019\"\u0004\b?\u0010\u001bR\u001e\u0010\u0011\u001a\u0004\u0018\u00010\u0005X\u0086\u000e¢\u0006\u0010\n\u0002\u0010 \u001a\u0004\b@\u0010\u001d\"\u0004\bA\u0010\u001fR\u001c\u0010\u0010\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bB\u0010\u0019\"\u0004\bC\u0010\u001b¨\u0006G"}, d2 = {"Lcom/gateio/biz/base/model/memebox/MemeBoxTokenInfoBean;", "Ljava/io/Serializable;", "address", "", "quote_prec", "", "amount_prec", "meme_token", "icon", "chain_icon", "pair", "data_status", AlphaFastOrderDialogFragment.CURRENT_PRICE, "launch_price_change_24h", "chain", "market_cap", "web3_pair", "usdt_prec", "tips", "tips_url", "tips_type", "security_type", "", "(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V", "getAddress", "()Ljava/lang/String;", "setAddress", "(Ljava/lang/String;)V", "getAmount_prec", "()Ljava/lang/Integer;", "setAmount_prec", "(Ljava/lang/Integer;)V", "Ljava/lang/Integer;", "getChain", "setChain", "getChain_icon", "setChain_icon", "getCurrent_price", "setCurrent_price", "getData_status", "setData_status", "getIcon", "setIcon", "getLaunch_price_change_24h", "setLaunch_price_change_24h", "getMarket_cap", "setMarket_cap", "getMeme_token", "setMeme_token", "getPair", "setPair", "getQuote_prec", "setQuote_prec", "getSecurity_type", "()[Ljava/lang/String;", "setSecurity_type", "([Ljava/lang/String;)V", "[Ljava/lang/String;", "getTips", "setTips", "getTips_type", "setTips_type", "getTips_url", "setTips_url", "getUsdt_prec", "setUsdt_prec", "getWeb3_pair", "setWeb3_pair", "isSuspend", "", "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class MemeBoxTokenInfoBean implements Serializable {

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @NotNull
    private static final MemeBoxTokenInfoBean DEFAULT;

    @NotNull
    public static final String TIPS_TYPE_AIRDROP = "2";

    @NotNull
    public static final String TIPS_TYPE_INTEGRAL_DROP = "4";

    @NotNull
    public static final String TIPS_TYPE_LIQUIDITY_SHORTAGE = "6";

    @NotNull
    public static final String TIPS_TYPE_LUCKY_POOL = "3";

    @NotNull
    public static final String TIPS_TYPE_MIGRATION = "1";

    @NotNull
    public static final String TIPS_TYPE_RISK_COIN = "5";

    @Nullable
    private String address;

    @Nullable
    private Integer amount_prec;

    @Nullable
    private String chain;

    @Nullable
    private String chain_icon;

    @Nullable
    private String current_price;

    @Nullable
    private String data_status;

    @Nullable
    private String icon;

    @Nullable
    private String launch_price_change_24h;

    @Nullable
    private String market_cap;

    @Nullable
    private String meme_token;

    @Nullable
    private String pair;

    @Nullable
    private Integer quote_prec;

    @Nullable
    private String[] security_type;

    @Nullable
    private String tips;

    @Nullable
    private String tips_type;

    @Nullable
    private String tips_url;

    @Nullable
    private Integer usdt_prec;

    @Nullable
    private String web3_pair;

    /* compiled from: MemeBoxTokenInfoBean.kt */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\t\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u000e\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\bH\u0007J\b\u0010\u0010\u001a\u0004\u0018\u00010\u0004J\u0010\u0010\u0011\u001a\u00020\u00122\b\u0010\u0013\u001a\u0004\u0018\u00010\u0004R\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u000e\u0010\u0007\u001a\u00020\bX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\bX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\bX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\bX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\bX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\bX\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0014"}, d2 = {"Lcom/gateio/biz/base/model/memebox/MemeBoxTokenInfoBean$Companion;", "", "()V", "DEFAULT", "Lcom/gateio/biz/base/model/memebox/MemeBoxTokenInfoBean;", "getDEFAULT", "()Lcom/gateio/biz/base/model/memebox/MemeBoxTokenInfoBean;", "TIPS_TYPE_AIRDROP", "", "TIPS_TYPE_INTEGRAL_DROP", "TIPS_TYPE_LIQUIDITY_SHORTAGE", "TIPS_TYPE_LUCKY_POOL", "TIPS_TYPE_MIGRATION", "TIPS_TYPE_RISK_COIN", "fromPair", "pair", "loadCache", "save", "", "params", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nMemeBoxTokenInfoBean.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MemeBoxTokenInfoBean.kt\ncom/gateio/biz/base/model/memebox/MemeBoxTokenInfoBean$Companion\n+ 2 JSONExtensions.kt\ncom/gateio/lib/utils/json/GTJSONUtils\n*L\n1#1,108:1\n110#2,10:109\n*S KotlinDebug\n*F\n+ 1 MemeBoxTokenInfoBean.kt\ncom/gateio/biz/base/model/memebox/MemeBoxTokenInfoBean$Companion\n*L\n73#1:109,10\n*E\n"})
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @Nullable
        public final MemeBoxTokenInfoBean loadCache() {
            Object objFromJson = null;
            String strQueryStringKV$default = GTStorage.queryStringKV$default("Cache_Key_MemeBoxTokenInfoBean", null, null, 6, null);
            try {
                Result.Companion companion = Result.INSTANCE;
                objFromJson = GTJSONUtils.getGlobalGson().fromJson(strQueryStringKV$default, (Class<Object>) MemeBoxTokenInfoBean.class);
            } catch (Throwable th) {
                Result.Companion companion2 = Result.INSTANCE;
                Throwable thM4833exceptionOrNullimpl = Result.m4833exceptionOrNullimpl(Result.m4830constructorimpl(ResultKt.createFailure(th)));
                if (thM4833exceptionOrNullimpl != null) {
                    GTLibGlue.logger().w("fromJson error: " + strQueryStringKV$default, thM4833exceptionOrNullimpl);
                }
            }
            return (MemeBoxTokenInfoBean) objFromJson;
        }

        @JvmStatic
        @NotNull
        public final MemeBoxTokenInfoBean fromPair(@NotNull String pair) {
            return new MemeBoxTokenInfoBean(null, null, null, null, null, null, pair, null, null, null, null, null, null, null, null, null, null, null, 262079, null);
        }

        @NotNull
        public final MemeBoxTokenInfoBean getDEFAULT() {
            return MemeBoxTokenInfoBean.DEFAULT;
        }

        public final void save(@Nullable MemeBoxTokenInfoBean params) {
            GTStorage.saveKV$default("Cache_Key_MemeBoxTokenInfoBean", GTJSONUtils.toJsonString(params), null, 4, null);
        }
    }

    public MemeBoxTokenInfoBean(@Nullable String str, @Nullable Integer num, @Nullable Integer num2, @Nullable String str2, @Nullable String str3, @Nullable String str4, @Nullable String str5, @Nullable String str6, @Nullable String str7, @Nullable String str8, @Nullable String str9, @Nullable String str10, @Nullable String str11, @Nullable Integer num3, @Nullable String str12, @Nullable String str13, @Nullable String str14, @Nullable String[] strArr) {
        this.address = str;
        this.quote_prec = num;
        this.amount_prec = num2;
        this.meme_token = str2;
        this.icon = str3;
        this.chain_icon = str4;
        this.pair = str5;
        this.data_status = str6;
        this.current_price = str7;
        this.launch_price_change_24h = str8;
        this.chain = str9;
        this.market_cap = str10;
        this.web3_pair = str11;
        this.usdt_prec = num3;
        this.tips = str12;
        this.tips_url = str13;
        this.tips_type = str14;
        this.security_type = strArr;
    }

    static {
        int i10 = 8;
        DEFAULT = new MemeBoxTokenInfoBean(null, i10, i10, null, null, null, "DEFAULT_PAIR", "1", null, null, null, null, null, null, null, null, null, null, ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, null);
    }

    @JvmStatic
    @NotNull
    public static final MemeBoxTokenInfoBean fromPair(@NotNull String str) {
        return INSTANCE.fromPair(str);
    }

    @Nullable
    public final String getAddress() {
        return this.address;
    }

    @Nullable
    public final Integer getAmount_prec() {
        return this.amount_prec;
    }

    @Nullable
    public final String getChain() {
        return this.chain;
    }

    @Nullable
    public final String getChain_icon() {
        return this.chain_icon;
    }

    @Nullable
    public final String getCurrent_price() {
        return this.current_price;
    }

    @Nullable
    public final String getData_status() {
        return this.data_status;
    }

    @Nullable
    public final String getIcon() {
        return this.icon;
    }

    @Nullable
    public final String getLaunch_price_change_24h() {
        return this.launch_price_change_24h;
    }

    @Nullable
    public final String getMarket_cap() {
        return this.market_cap;
    }

    @Nullable
    public final String getMeme_token() {
        return this.meme_token;
    }

    @Nullable
    public final String getPair() {
        return this.pair;
    }

    @Nullable
    public final Integer getQuote_prec() {
        return this.quote_prec;
    }

    @Nullable
    public final String[] getSecurity_type() {
        return this.security_type;
    }

    @Nullable
    public final String getTips() {
        return this.tips;
    }

    @Nullable
    public final String getTips_type() {
        return this.tips_type;
    }

    @Nullable
    public final String getTips_url() {
        return this.tips_url;
    }

    @Nullable
    public final Integer getUsdt_prec() {
        return this.usdt_prec;
    }

    @Nullable
    public final String getWeb3_pair() {
        return this.web3_pair;
    }

    public final boolean isSuspend() {
        return Intrinsics.areEqual(this.data_status, "2");
    }

    public final void setAddress(@Nullable String str) {
        this.address = str;
    }

    public final void setAmount_prec(@Nullable Integer num) {
        this.amount_prec = num;
    }

    public final void setChain(@Nullable String str) {
        this.chain = str;
    }

    public final void setChain_icon(@Nullable String str) {
        this.chain_icon = str;
    }

    public final void setCurrent_price(@Nullable String str) {
        this.current_price = str;
    }

    public final void setData_status(@Nullable String str) {
        this.data_status = str;
    }

    public final void setIcon(@Nullable String str) {
        this.icon = str;
    }

    public final void setLaunch_price_change_24h(@Nullable String str) {
        this.launch_price_change_24h = str;
    }

    public final void setMarket_cap(@Nullable String str) {
        this.market_cap = str;
    }

    public final void setMeme_token(@Nullable String str) {
        this.meme_token = str;
    }

    public final void setPair(@Nullable String str) {
        this.pair = str;
    }

    public final void setQuote_prec(@Nullable Integer num) {
        this.quote_prec = num;
    }

    public final void setSecurity_type(@Nullable String[] strArr) {
        this.security_type = strArr;
    }

    public final void setTips(@Nullable String str) {
        this.tips = str;
    }

    public final void setTips_type(@Nullable String str) {
        this.tips_type = str;
    }

    public final void setTips_url(@Nullable String str) {
        this.tips_url = str;
    }

    public final void setUsdt_prec(@Nullable Integer num) {
        this.usdt_prec = num;
    }

    public final void setWeb3_pair(@Nullable String str) {
        this.web3_pair = str;
    }

    public /* synthetic */ MemeBoxTokenInfoBean(String str, Integer num, Integer num2, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, Integer num3, String str12, String str13, String str14, String[] strArr, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? null : str, (i10 & 2) != 0 ? 8 : num, (i10 & 4) != 0 ? 8 : num2, (i10 & 8) != 0 ? null : str2, (i10 & 16) != 0 ? null : str3, (i10 & 32) != 0 ? null : str4, str5, (i10 & 128) != 0 ? "1" : str6, (i10 & 256) != 0 ? null : str7, (i10 & 512) != 0 ? null : str8, (i10 & 1024) != 0 ? null : str9, (i10 & 2048) != 0 ? null : str10, (i10 & 4096) != 0 ? null : str11, (i10 & 8192) != 0 ? null : num3, (i10 & 16384) != 0 ? null : str12, (32768 & i10) != 0 ? null : str13, (65536 & i10) != 0 ? null : str14, (i10 & 131072) != 0 ? null : strArr);
    }
}