package com.gateio.biz.base.model.memebox;

import com.gateio.fiatotclib.function.order.merchant.MerchantOrderDetailActivity;
import com.zoloz.webcontainer.env.H5Container;
import java.io.Serializable;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: AlphaTPSLHeaderModel.kt */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b/\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u0087\u0001\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0003\u0012\b\b\u0002\u0010\b\u001a\u00020\u0003\u0012\b\b\u0002\u0010\t\u001a\u00020\u0003\u0012\b\b\u0002\u0010\n\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0003\u0012\b\b\u0002\u0010\f\u001a\u00020\u0003\u0012\b\b\u0002\u0010\r\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u0010¢\u0006\u0002\u0010\u0011J\t\u00100\u001a\u00020\u0003HÆ\u0003J\t\u00101\u001a\u00020\u0003HÆ\u0003J\t\u00102\u001a\u00020\u0003HÆ\u0003J\t\u00103\u001a\u00020\u0003HÆ\u0003J\t\u00104\u001a\u00020\u0010HÆ\u0003J\t\u00105\u001a\u00020\u0003HÆ\u0003J\t\u00106\u001a\u00020\u0003HÆ\u0003J\t\u00107\u001a\u00020\u0003HÆ\u0003J\t\u00108\u001a\u00020\u0003HÆ\u0003J\t\u00109\u001a\u00020\u0003HÆ\u0003J\t\u0010:\u001a\u00020\u0003HÆ\u0003J\t\u0010;\u001a\u00020\u0003HÆ\u0003J\t\u0010<\u001a\u00020\u0003HÆ\u0003J\u008b\u0001\u0010=\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00032\b\b\u0002\u0010\n\u001a\u00020\u00032\b\b\u0002\u0010\u000b\u001a\u00020\u00032\b\b\u0002\u0010\f\u001a\u00020\u00032\b\b\u0002\u0010\r\u001a\u00020\u00032\b\b\u0002\u0010\u000e\u001a\u00020\u00032\b\b\u0002\u0010\u000f\u001a\u00020\u0010HÆ\u0001J\u0013\u0010>\u001a\u00020\u00102\b\u0010?\u001a\u0004\u0018\u00010@HÖ\u0003J\t\u0010A\u001a\u00020BHÖ\u0001J\t\u0010C\u001a\u00020\u0003HÖ\u0001R\u001a\u0010\u000b\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u001a\u0010\u000f\u001a\u00020\u0010X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u0017\"\u0004\b\u0018\u0010\u0019R\u001a\u0010\u0007\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001a\u0010\u0013\"\u0004\b\u001b\u0010\u0015R\u001a\u0010\n\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001c\u0010\u0013\"\u0004\b\u001d\u0010\u0015R\u001a\u0010\u0006\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001e\u0010\u0013\"\u0004\b\u001f\u0010\u0015R\u001a\u0010\b\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b \u0010\u0013\"\u0004\b!\u0010\u0015R\u001a\u0010\t\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\"\u0010\u0013\"\u0004\b#\u0010\u0015R\u001a\u0010\u000e\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b$\u0010\u0013\"\u0004\b%\u0010\u0015R\u001a\u0010\u0004\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b&\u0010\u0013\"\u0004\b'\u0010\u0015R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b(\u0010\u0013\"\u0004\b)\u0010\u0015R\u001a\u0010\u0005\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b*\u0010\u0013\"\u0004\b+\u0010\u0015R\u001a\u0010\f\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b,\u0010\u0013\"\u0004\b-\u0010\u0015R\u001a\u0010\r\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b.\u0010\u0013\"\u0004\b/\u0010\u0015¨\u0006D"}, d2 = {"Lcom/gateio/biz/base/model/memebox/AlphaTPSLHeaderModel;", "Ljava/io/Serializable;", "orderType", "", "orderPrice", "totalPrice", "lastPrice", "extReceive", "memeToken", "memeTokenAddress", "icon", "chain_icon", "tradingFee", "tradingFeeText", MerchantOrderDetailActivity.ORDER_ID, "entrustChange", "", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V", "getChain_icon", "()Ljava/lang/String;", "setChain_icon", "(Ljava/lang/String;)V", "getEntrustChange", "()Z", "setEntrustChange", "(Z)V", "getExtReceive", "setExtReceive", "getIcon", "setIcon", "getLastPrice", "setLastPrice", "getMemeToken", "setMemeToken", "getMemeTokenAddress", "setMemeTokenAddress", "getOrderId", "setOrderId", "getOrderPrice", "setOrderPrice", "getOrderType", "setOrderType", "getTotalPrice", "setTotalPrice", "getTradingFee", "setTradingFee", "getTradingFeeText", "setTradingFeeText", "component1", "component10", "component11", "component12", "component13", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", H5Container.MENU_COPY, "equals", "other", "", "hashCode", "", "toString", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class AlphaTPSLHeaderModel implements Serializable {

    @NotNull
    private String chain_icon;
    private boolean entrustChange;

    @NotNull
    private String extReceive;

    @NotNull
    private String icon;

    @NotNull
    private String lastPrice;

    @NotNull
    private String memeToken;

    @NotNull
    private String memeTokenAddress;

    @NotNull
    private String orderId;

    @NotNull
    private String orderPrice;

    @NotNull
    private String orderType;

    @NotNull
    private String totalPrice;

    @NotNull
    private String tradingFee;

    @NotNull
    private String tradingFeeText;

    public AlphaTPSLHeaderModel() {
        this(null, null, null, null, null, null, null, null, null, null, null, null, false, 8191, null);
    }

    @NotNull
    public final AlphaTPSLHeaderModel copy(@NotNull String orderType, @NotNull String orderPrice, @NotNull String totalPrice, @NotNull String lastPrice, @NotNull String extReceive, @NotNull String memeToken, @NotNull String memeTokenAddress, @NotNull String icon, @NotNull String chain_icon, @NotNull String tradingFee, @NotNull String tradingFeeText, @NotNull String orderId, boolean entrustChange) {
        return new AlphaTPSLHeaderModel(orderType, orderPrice, totalPrice, lastPrice, extReceive, memeToken, memeTokenAddress, icon, chain_icon, tradingFee, tradingFeeText, orderId, entrustChange);
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof AlphaTPSLHeaderModel)) {
            return false;
        }
        AlphaTPSLHeaderModel alphaTPSLHeaderModel = (AlphaTPSLHeaderModel) other;
        return Intrinsics.areEqual(this.orderType, alphaTPSLHeaderModel.orderType) && Intrinsics.areEqual(this.orderPrice, alphaTPSLHeaderModel.orderPrice) && Intrinsics.areEqual(this.totalPrice, alphaTPSLHeaderModel.totalPrice) && Intrinsics.areEqual(this.lastPrice, alphaTPSLHeaderModel.lastPrice) && Intrinsics.areEqual(this.extReceive, alphaTPSLHeaderModel.extReceive) && Intrinsics.areEqual(this.memeToken, alphaTPSLHeaderModel.memeToken) && Intrinsics.areEqual(this.memeTokenAddress, alphaTPSLHeaderModel.memeTokenAddress) && Intrinsics.areEqual(this.icon, alphaTPSLHeaderModel.icon) && Intrinsics.areEqual(this.chain_icon, alphaTPSLHeaderModel.chain_icon) && Intrinsics.areEqual(this.tradingFee, alphaTPSLHeaderModel.tradingFee) && Intrinsics.areEqual(this.tradingFeeText, alphaTPSLHeaderModel.tradingFeeText) && Intrinsics.areEqual(this.orderId, alphaTPSLHeaderModel.orderId) && this.entrustChange == alphaTPSLHeaderModel.entrustChange;
    }

    public AlphaTPSLHeaderModel(@NotNull String str, @NotNull String str2, @NotNull String str3, @NotNull String str4, @NotNull String str5, @NotNull String str6, @NotNull String str7, @NotNull String str8, @NotNull String str9, @NotNull String str10, @NotNull String str11, @NotNull String str12, boolean z10) {
        this.orderType = str;
        this.orderPrice = str2;
        this.totalPrice = str3;
        this.lastPrice = str4;
        this.extReceive = str5;
        this.memeToken = str6;
        this.memeTokenAddress = str7;
        this.icon = str8;
        this.chain_icon = str9;
        this.tradingFee = str10;
        this.tradingFeeText = str11;
        this.orderId = str12;
        this.entrustChange = z10;
    }

    @NotNull
    /* renamed from: component1, reason: from getter */
    public final String getOrderType() {
        return this.orderType;
    }

    @NotNull
    /* renamed from: component10, reason: from getter */
    public final String getTradingFee() {
        return this.tradingFee;
    }

    @NotNull
    /* renamed from: component11, reason: from getter */
    public final String getTradingFeeText() {
        return this.tradingFeeText;
    }

    @NotNull
    /* renamed from: component12, reason: from getter */
    public final String getOrderId() {
        return this.orderId;
    }

    /* renamed from: component13, reason: from getter */
    public final boolean getEntrustChange() {
        return this.entrustChange;
    }

    @NotNull
    /* renamed from: component2, reason: from getter */
    public final String getOrderPrice() {
        return this.orderPrice;
    }

    @NotNull
    /* renamed from: component3, reason: from getter */
    public final String getTotalPrice() {
        return this.totalPrice;
    }

    @NotNull
    /* renamed from: component4, reason: from getter */
    public final String getLastPrice() {
        return this.lastPrice;
    }

    @NotNull
    /* renamed from: component5, reason: from getter */
    public final String getExtReceive() {
        return this.extReceive;
    }

    @NotNull
    /* renamed from: component6, reason: from getter */
    public final String getMemeToken() {
        return this.memeToken;
    }

    @NotNull
    /* renamed from: component7, reason: from getter */
    public final String getMemeTokenAddress() {
        return this.memeTokenAddress;
    }

    @NotNull
    /* renamed from: component8, reason: from getter */
    public final String getIcon() {
        return this.icon;
    }

    @NotNull
    /* renamed from: component9, reason: from getter */
    public final String getChain_icon() {
        return this.chain_icon;
    }

    @NotNull
    public final String getChain_icon() {
        return this.chain_icon;
    }

    public final boolean getEntrustChange() {
        return this.entrustChange;
    }

    @NotNull
    public final String getExtReceive() {
        return this.extReceive;
    }

    @NotNull
    public final String getIcon() {
        return this.icon;
    }

    @NotNull
    public final String getLastPrice() {
        return this.lastPrice;
    }

    @NotNull
    public final String getMemeToken() {
        return this.memeToken;
    }

    @NotNull
    public final String getMemeTokenAddress() {
        return this.memeTokenAddress;
    }

    @NotNull
    public final String getOrderId() {
        return this.orderId;
    }

    @NotNull
    public final String getOrderPrice() {
        return this.orderPrice;
    }

    @NotNull
    public final String getOrderType() {
        return this.orderType;
    }

    @NotNull
    public final String getTotalPrice() {
        return this.totalPrice;
    }

    @NotNull
    public final String getTradingFee() {
        return this.tradingFee;
    }

    @NotNull
    public final String getTradingFeeText() {
        return this.tradingFeeText;
    }

    public int hashCode() {
        return (((((((((((((((((((((((this.orderType.hashCode() * 31) + this.orderPrice.hashCode()) * 31) + this.totalPrice.hashCode()) * 31) + this.lastPrice.hashCode()) * 31) + this.extReceive.hashCode()) * 31) + this.memeToken.hashCode()) * 31) + this.memeTokenAddress.hashCode()) * 31) + this.icon.hashCode()) * 31) + this.chain_icon.hashCode()) * 31) + this.tradingFee.hashCode()) * 31) + this.tradingFeeText.hashCode()) * 31) + this.orderId.hashCode()) * 31) + Boolean.hashCode(this.entrustChange);
    }

    public final void setChain_icon(@NotNull String str) {
        this.chain_icon = str;
    }

    public final void setEntrustChange(boolean z10) {
        this.entrustChange = z10;
    }

    public final void setExtReceive(@NotNull String str) {
        this.extReceive = str;
    }

    public final void setIcon(@NotNull String str) {
        this.icon = str;
    }

    public final void setLastPrice(@NotNull String str) {
        this.lastPrice = str;
    }

    public final void setMemeToken(@NotNull String str) {
        this.memeToken = str;
    }

    public final void setMemeTokenAddress(@NotNull String str) {
        this.memeTokenAddress = str;
    }

    public final void setOrderId(@NotNull String str) {
        this.orderId = str;
    }

    public final void setOrderPrice(@NotNull String str) {
        this.orderPrice = str;
    }

    public final void setOrderType(@NotNull String str) {
        this.orderType = str;
    }

    public final void setTotalPrice(@NotNull String str) {
        this.totalPrice = str;
    }

    public final void setTradingFee(@NotNull String str) {
        this.tradingFee = str;
    }

    public final void setTradingFeeText(@NotNull String str) {
        this.tradingFeeText = str;
    }

    @NotNull
    public String toString() {
        return "AlphaTPSLHeaderModel(orderType=" + this.orderType + ", orderPrice=" + this.orderPrice + ", totalPrice=" + this.totalPrice + ", lastPrice=" + this.lastPrice + ", extReceive=" + this.extReceive + ", memeToken=" + this.memeToken + ", memeTokenAddress=" + this.memeTokenAddress + ", icon=" + this.icon + ", chain_icon=" + this.chain_icon + ", tradingFee=" + this.tradingFee + ", tradingFeeText=" + this.tradingFeeText + ", orderId=" + this.orderId + ", entrustChange=" + this.entrustChange + ')';
    }

    public /* synthetic */ AlphaTPSLHeaderModel(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12, boolean z10, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? "" : str, (i10 & 2) != 0 ? "" : str2, (i10 & 4) != 0 ? "" : str3, (i10 & 8) != 0 ? "" : str4, (i10 & 16) != 0 ? "" : str5, (i10 & 32) != 0 ? "" : str6, (i10 & 64) != 0 ? "" : str7, (i10 & 128) != 0 ? "" : str8, (i10 & 256) != 0 ? "" : str9, (i10 & 512) != 0 ? "" : str10, (i10 & 1024) != 0 ? "" : str11, (i10 & 2048) == 0 ? str12 : "", (i10 & 4096) != 0 ? false : z10);
    }
}