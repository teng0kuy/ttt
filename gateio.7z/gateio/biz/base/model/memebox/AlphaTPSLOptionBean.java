package com.gateio.biz.base.model.memebox;

import com.gateio.biz_options.datafinder.GTOptionsEvent;
import com.gateio.gateio.datafinder.eventv1.contract.ContractFutureTpslInputEvent;
import com.zoloz.webcontainer.env.H5Container;
import java.io.Serializable;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: AlphaTPSLOptionBean.kt */
@Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0016\n\u0002\u0010\u0002\n\u0002\b\t\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\t\b\u0086\b\u0018\u00002\u00020\u0001:\u000256BA\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b\u0012\b\b\u0002\u0010\t\u001a\u00020\b\u0012\b\b\u0002\u0010\n\u001a\u00020\u000b¢\u0006\u0002\u0010\fJ\u0006\u0010!\u001a\u00020\"J\t\u0010#\u001a\u00020\u0003HÆ\u0003J\t\u0010$\u001a\u00020\u0005HÆ\u0003J\t\u0010%\u001a\u00020\u0005HÆ\u0003J\t\u0010&\u001a\u00020\bHÆ\u0003J\t\u0010'\u001a\u00020\bHÆ\u0003J\t\u0010(\u001a\u00020\u000bHÆ\u0003JE\u0010)\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\b2\b\b\u0002\u0010\n\u001a\u00020\u000bHÆ\u0001J\u0013\u0010*\u001a\u00020\b2\b\u0010+\u001a\u0004\u0018\u00010,HÖ\u0003J\t\u0010-\u001a\u00020.HÖ\u0001J\u0006\u0010/\u001a\u00020\bJ\u0006\u00100\u001a\u00020\bJ\u0006\u00101\u001a\u00020\bJ\u000e\u00102\u001a\u00020\"2\u0006\u00103\u001a\u00020\bJ\t\u00104\u001a\u00020\u0003HÖ\u0001R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0010R\u001a\u0010\n\u001a\u00020\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0015\u001a\u00020\b8F¢\u0006\u0006\u001a\u0004\b\u0016\u0010\u0017R\u001a\u0010\u0007\u001a\u00020\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\u0017\"\u0004\b\u0018\u0010\u0019R\u001a\u0010\t\u001a\u00020\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\t\u0010\u0017\"\u0004\b\u001a\u0010\u0019R\u001a\u0010\u0006\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001b\u0010\u001c\"\u0004\b\u001d\u0010\u001eR\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001f\u0010\u001c\"\u0004\b \u0010\u001e¨\u00067"}, d2 = {"Lcom/gateio/biz/base/model/memebox/AlphaTPSLOptionBean;", "Ljava/io/Serializable;", "entrustPrice", "", "stop_profit", "Lcom/gateio/biz/base/model/memebox/AlphaTPSLOptionBean$AlphaOrderTPSL;", "stop_loss", "isCheck", "", "isOption", "from", "Lcom/gateio/biz/base/model/memebox/AlphaTPSLOptionBean$AlphaTPSLType;", "(Ljava/lang/String;Lcom/gateio/biz/base/model/memebox/AlphaTPSLOptionBean$AlphaOrderTPSL;Lcom/gateio/biz/base/model/memebox/AlphaTPSLOptionBean$AlphaOrderTPSL;ZZLcom/gateio/biz/base/model/memebox/AlphaTPSLOptionBean$AlphaTPSLType;)V", "getEntrustPrice", "()Ljava/lang/String;", "setEntrustPrice", "(Ljava/lang/String;)V", "getFrom", "()Lcom/gateio/biz/base/model/memebox/AlphaTPSLOptionBean$AlphaTPSLType;", "setFrom", "(Lcom/gateio/biz/base/model/memebox/AlphaTPSLOptionBean$AlphaTPSLType;)V", "hasTpsl", "getHasTpsl", "()Z", "setCheck", "(Z)V", "setOption", "getStop_loss", "()Lcom/gateio/biz/base/model/memebox/AlphaTPSLOptionBean$AlphaOrderTPSL;", "setStop_loss", "(Lcom/gateio/biz/base/model/memebox/AlphaTPSLOptionBean$AlphaOrderTPSL;)V", "getStop_profit", "setStop_profit", "check", "", "component1", "component2", "component3", "component4", "component5", "component6", H5Container.MENU_COPY, "equals", "other", "", "hashCode", "", "isSetSl", "isSetTp", "isUseAdvance", "setIsCheck", "value", "toString", "AlphaOrderTPSL", "AlphaTPSLType", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class AlphaTPSLOptionBean implements Serializable {

    @NotNull
    private String entrustPrice;

    @NotNull
    private AlphaTPSLType from;
    private boolean isCheck;
    private boolean isOption;

    @NotNull
    private AlphaOrderTPSL stop_loss;

    @NotNull
    private AlphaOrderTPSL stop_profit;

    /* compiled from: AlphaTPSLOptionBean.kt */
    @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u001f\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001BM\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\u0003\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u0003\u0012\b\b\u0002\u0010\n\u001a\u00020\u0003¢\u0006\u0002\u0010\u000bJ\t\u0010\u001d\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0003HÆ\u0003J\t\u0010 \u001a\u00020\u0007HÆ\u0003J\t\u0010!\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\"\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\t\u0010#\u001a\u00020\u0003HÆ\u0003JQ\u0010$\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00032\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\n\u001a\u00020\u0003HÆ\u0001J\u0013\u0010%\u001a\u00020\u00072\b\u0010&\u001a\u0004\u0018\u00010'HÖ\u0003J\t\u0010(\u001a\u00020)HÖ\u0001J\t\u0010*\u001a\u00020\u0003HÖ\u0001R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR\u001a\u0010\u0006\u001a\u00020\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0010\"\u0004\b\u0011\u0010\u0012R\u001a\u0010\n\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0013\u0010\r\"\u0004\b\u0014\u0010\u000fR\u001a\u0010\u0005\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\r\"\u0004\b\u0016\u0010\u000fR\u001a\u0010\b\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0017\u0010\r\"\u0004\b\u0018\u0010\u000fR\u001c\u0010\t\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0019\u0010\r\"\u0004\b\u001a\u0010\u000fR\u001a\u0010\u0004\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001b\u0010\r\"\u0004\b\u001c\u0010\u000f¨\u0006+"}, d2 = {"Lcom/gateio/biz/base/model/memebox/AlphaTPSLOptionBean$AlphaOrderTPSL;", "Ljava/io/Serializable;", "change", "", "trigger_price", "order_price", "isMarker", "", ContractFutureTpslInputEvent.pnl, "target_token_amount", GTOptionsEvent.value_order_id, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getChange", "()Ljava/lang/String;", "setChange", "(Ljava/lang/String;)V", "()Z", "setMarker", "(Z)V", "getOrder_id", "setOrder_id", "getOrder_price", "setOrder_price", "getPnl", "setPnl", "getTarget_token_amount", "setTarget_token_amount", "getTrigger_price", "setTrigger_price", "component1", "component2", "component3", "component4", "component5", "component6", "component7", H5Container.MENU_COPY, "equals", "other", "", "hashCode", "", "toString", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final /* data */ class AlphaOrderTPSL implements Serializable {

        @NotNull
        private String change;
        private boolean isMarker;

        @NotNull
        private String order_id;

        @NotNull
        private String order_price;

        @NotNull
        private String pnl;

        @Nullable
        private String target_token_amount;

        @NotNull
        private String trigger_price;

        public AlphaOrderTPSL() {
            this(null, null, null, false, null, null, null, 127, null);
        }

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof AlphaOrderTPSL)) {
                return false;
            }
            AlphaOrderTPSL alphaOrderTPSL = (AlphaOrderTPSL) other;
            return Intrinsics.areEqual(this.change, alphaOrderTPSL.change) && Intrinsics.areEqual(this.trigger_price, alphaOrderTPSL.trigger_price) && Intrinsics.areEqual(this.order_price, alphaOrderTPSL.order_price) && this.isMarker == alphaOrderTPSL.isMarker && Intrinsics.areEqual(this.pnl, alphaOrderTPSL.pnl) && Intrinsics.areEqual(this.target_token_amount, alphaOrderTPSL.target_token_amount) && Intrinsics.areEqual(this.order_id, alphaOrderTPSL.order_id);
        }

        public AlphaOrderTPSL(@NotNull String str, @NotNull String str2, @NotNull String str3, boolean z10, @NotNull String str4, @Nullable String str5, @NotNull String str6) {
            this.change = str;
            this.trigger_price = str2;
            this.order_price = str3;
            this.isMarker = z10;
            this.pnl = str4;
            this.target_token_amount = str5;
            this.order_id = str6;
        }

        public static /* synthetic */ AlphaOrderTPSL copy$default(AlphaOrderTPSL alphaOrderTPSL, String str, String str2, String str3, boolean z10, String str4, String str5, String str6, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                str = alphaOrderTPSL.change;
            }
            if ((i10 & 2) != 0) {
                str2 = alphaOrderTPSL.trigger_price;
            }
            String str7 = str2;
            if ((i10 & 4) != 0) {
                str3 = alphaOrderTPSL.order_price;
            }
            String str8 = str3;
            if ((i10 & 8) != 0) {
                z10 = alphaOrderTPSL.isMarker;
            }
            boolean z11 = z10;
            if ((i10 & 16) != 0) {
                str4 = alphaOrderTPSL.pnl;
            }
            String str9 = str4;
            if ((i10 & 32) != 0) {
                str5 = alphaOrderTPSL.target_token_amount;
            }
            String str10 = str5;
            if ((i10 & 64) != 0) {
                str6 = alphaOrderTPSL.order_id;
            }
            return alphaOrderTPSL.copy(str, str7, str8, z11, str9, str10, str6);
        }

        @NotNull
        /* renamed from: component1, reason: from getter */
        public final String getChange() {
            return this.change;
        }

        @NotNull
        /* renamed from: component2, reason: from getter */
        public final String getTrigger_price() {
            return this.trigger_price;
        }

        @NotNull
        /* renamed from: component3, reason: from getter */
        public final String getOrder_price() {
            return this.order_price;
        }

        /* renamed from: component4, reason: from getter */
        public final boolean getIsMarker() {
            return this.isMarker;
        }

        @NotNull
        /* renamed from: component5, reason: from getter */
        public final String getPnl() {
            return this.pnl;
        }

        @Nullable
        /* renamed from: component6, reason: from getter */
        public final String getTarget_token_amount() {
            return this.target_token_amount;
        }

        @NotNull
        /* renamed from: component7, reason: from getter */
        public final String getOrder_id() {
            return this.order_id;
        }

        @NotNull
        public final AlphaOrderTPSL copy(@NotNull String change, @NotNull String trigger_price, @NotNull String order_price, boolean isMarker, @NotNull String pnl, @Nullable String target_token_amount, @NotNull String order_id) {
            return new AlphaOrderTPSL(change, trigger_price, order_price, isMarker, pnl, target_token_amount, order_id);
        }

        @NotNull
        public final String getChange() {
            return this.change;
        }

        @NotNull
        public final String getOrder_id() {
            return this.order_id;
        }

        @NotNull
        public final String getOrder_price() {
            return this.order_price;
        }

        @NotNull
        public final String getPnl() {
            return this.pnl;
        }

        @Nullable
        public final String getTarget_token_amount() {
            return this.target_token_amount;
        }

        @NotNull
        public final String getTrigger_price() {
            return this.trigger_price;
        }

        public int hashCode() {
            int iHashCode = ((((((((this.change.hashCode() * 31) + this.trigger_price.hashCode()) * 31) + this.order_price.hashCode()) * 31) + Boolean.hashCode(this.isMarker)) * 31) + this.pnl.hashCode()) * 31;
            String str = this.target_token_amount;
            return ((iHashCode + (str == null ? 0 : str.hashCode())) * 31) + this.order_id.hashCode();
        }

        public final boolean isMarker() {
            return this.isMarker;
        }

        public final void setChange(@NotNull String str) {
            this.change = str;
        }

        public final void setMarker(boolean z10) {
            this.isMarker = z10;
        }

        public final void setOrder_id(@NotNull String str) {
            this.order_id = str;
        }

        public final void setOrder_price(@NotNull String str) {
            this.order_price = str;
        }

        public final void setPnl(@NotNull String str) {
            this.pnl = str;
        }

        public final void setTarget_token_amount(@Nullable String str) {
            this.target_token_amount = str;
        }

        public final void setTrigger_price(@NotNull String str) {
            this.trigger_price = str;
        }

        @NotNull
        public String toString() {
            return "AlphaOrderTPSL(change=" + this.change + ", trigger_price=" + this.trigger_price + ", order_price=" + this.order_price + ", isMarker=" + this.isMarker + ", pnl=" + this.pnl + ", target_token_amount=" + this.target_token_amount + ", order_id=" + this.order_id + ')';
        }

        public /* synthetic */ AlphaOrderTPSL(String str, String str2, String str3, boolean z10, String str4, String str5, String str6, int i10, DefaultConstructorMarker defaultConstructorMarker) {
            this((i10 & 1) != 0 ? "" : str, (i10 & 2) != 0 ? "" : str2, (i10 & 4) != 0 ? "" : str3, (i10 & 8) != 0 ? true : z10, (i10 & 16) != 0 ? "" : str4, (i10 & 32) != 0 ? "" : str5, (i10 & 64) != 0 ? "" : str6);
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: AlphaTPSLOptionBean.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/base/model/memebox/AlphaTPSLOptionBean$AlphaTPSLType;", "", "(Ljava/lang/String;I)V", "TYPE_INIT", "TYPE_MODIFY", "TYPE_EDIT", "TYPE_CREATE", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class AlphaTPSLType {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ AlphaTPSLType[] $VALUES;
        public static final AlphaTPSLType TYPE_INIT = new AlphaTPSLType("TYPE_INIT", 0);
        public static final AlphaTPSLType TYPE_MODIFY = new AlphaTPSLType("TYPE_MODIFY", 1);
        public static final AlphaTPSLType TYPE_EDIT = new AlphaTPSLType("TYPE_EDIT", 2);
        public static final AlphaTPSLType TYPE_CREATE = new AlphaTPSLType("TYPE_CREATE", 3);

        private static final /* synthetic */ AlphaTPSLType[] $values() {
            return new AlphaTPSLType[]{TYPE_INIT, TYPE_MODIFY, TYPE_EDIT, TYPE_CREATE};
        }

        static {
            AlphaTPSLType[] alphaTPSLTypeArr$values = $values();
            $VALUES = alphaTPSLTypeArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(alphaTPSLTypeArr$values);
        }

        @NotNull
        public static EnumEntries<AlphaTPSLType> getEntries() {
            return $ENTRIES;
        }

        public static AlphaTPSLType valueOf(String str) {
            return (AlphaTPSLType) Enum.valueOf(AlphaTPSLType.class, str);
        }

        public static AlphaTPSLType[] values() {
            return (AlphaTPSLType[]) $VALUES.clone();
        }

        private AlphaTPSLType(String str, int i10) {
        }
    }

    public AlphaTPSLOptionBean() {
        this(null, null, null, false, false, null, 63, null);
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof AlphaTPSLOptionBean)) {
            return false;
        }
        AlphaTPSLOptionBean alphaTPSLOptionBean = (AlphaTPSLOptionBean) other;
        return Intrinsics.areEqual(this.entrustPrice, alphaTPSLOptionBean.entrustPrice) && Intrinsics.areEqual(this.stop_profit, alphaTPSLOptionBean.stop_profit) && Intrinsics.areEqual(this.stop_loss, alphaTPSLOptionBean.stop_loss) && this.isCheck == alphaTPSLOptionBean.isCheck && this.isOption == alphaTPSLOptionBean.isOption && this.from == alphaTPSLOptionBean.from;
    }

    public AlphaTPSLOptionBean(@NotNull String str, @NotNull AlphaOrderTPSL alphaOrderTPSL, @NotNull AlphaOrderTPSL alphaOrderTPSL2, boolean z10, boolean z11, @NotNull AlphaTPSLType alphaTPSLType) {
        this.entrustPrice = str;
        this.stop_profit = alphaOrderTPSL;
        this.stop_loss = alphaOrderTPSL2;
        this.isCheck = z10;
        this.isOption = z11;
        this.from = alphaTPSLType;
    }

    public static /* synthetic */ AlphaTPSLOptionBean copy$default(AlphaTPSLOptionBean alphaTPSLOptionBean, String str, AlphaOrderTPSL alphaOrderTPSL, AlphaOrderTPSL alphaOrderTPSL2, boolean z10, boolean z11, AlphaTPSLType alphaTPSLType, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = alphaTPSLOptionBean.entrustPrice;
        }
        if ((i10 & 2) != 0) {
            alphaOrderTPSL = alphaTPSLOptionBean.stop_profit;
        }
        AlphaOrderTPSL alphaOrderTPSL3 = alphaOrderTPSL;
        if ((i10 & 4) != 0) {
            alphaOrderTPSL2 = alphaTPSLOptionBean.stop_loss;
        }
        AlphaOrderTPSL alphaOrderTPSL4 = alphaOrderTPSL2;
        if ((i10 & 8) != 0) {
            z10 = alphaTPSLOptionBean.isCheck;
        }
        boolean z12 = z10;
        if ((i10 & 16) != 0) {
            z11 = alphaTPSLOptionBean.isOption;
        }
        boolean z13 = z11;
        if ((i10 & 32) != 0) {
            alphaTPSLType = alphaTPSLOptionBean.from;
        }
        return alphaTPSLOptionBean.copy(str, alphaOrderTPSL3, alphaOrderTPSL4, z12, z13, alphaTPSLType);
    }

    public final void check() {
        setIsCheck(!this.isCheck);
    }

    @NotNull
    /* renamed from: component1, reason: from getter */
    public final String getEntrustPrice() {
        return this.entrustPrice;
    }

    @NotNull
    /* renamed from: component2, reason: from getter */
    public final AlphaOrderTPSL getStop_profit() {
        return this.stop_profit;
    }

    @NotNull
    /* renamed from: component3, reason: from getter */
    public final AlphaOrderTPSL getStop_loss() {
        return this.stop_loss;
    }

    /* renamed from: component4, reason: from getter */
    public final boolean getIsCheck() {
        return this.isCheck;
    }

    /* renamed from: component5, reason: from getter */
    public final boolean getIsOption() {
        return this.isOption;
    }

    @NotNull
    /* renamed from: component6, reason: from getter */
    public final AlphaTPSLType getFrom() {
        return this.from;
    }

    @NotNull
    public final AlphaTPSLOptionBean copy(@NotNull String entrustPrice, @NotNull AlphaOrderTPSL stop_profit, @NotNull AlphaOrderTPSL stop_loss, boolean isCheck, boolean isOption, @NotNull AlphaTPSLType from) {
        return new AlphaTPSLOptionBean(entrustPrice, stop_profit, stop_loss, isCheck, isOption, from);
    }

    @NotNull
    public final String getEntrustPrice() {
        return this.entrustPrice;
    }

    @NotNull
    public final AlphaTPSLType getFrom() {
        return this.from;
    }

    public final boolean getHasTpsl() {
        if (this.stop_profit.getChange().length() > 0) {
            return true;
        }
        return this.stop_loss.getChange().length() > 0;
    }

    @NotNull
    public final AlphaOrderTPSL getStop_loss() {
        return this.stop_loss;
    }

    @NotNull
    public final AlphaOrderTPSL getStop_profit() {
        return this.stop_profit;
    }

    public int hashCode() {
        return (((((((((this.entrustPrice.hashCode() * 31) + this.stop_profit.hashCode()) * 31) + this.stop_loss.hashCode()) * 31) + Boolean.hashCode(this.isCheck)) * 31) + Boolean.hashCode(this.isOption)) * 31) + this.from.hashCode();
    }

    public final boolean isCheck() {
        return this.isCheck;
    }

    public final boolean isOption() {
        return this.isOption;
    }

    public final boolean isSetSl() {
        return this.stop_loss.getChange().length() > 0;
    }

    public final boolean isSetTp() {
        return this.stop_profit.getChange().length() > 0;
    }

    public final boolean isUseAdvance() {
        return this.isOption || getHasTpsl();
    }

    public final void setCheck(boolean z10) {
        this.isCheck = z10;
    }

    public final void setEntrustPrice(@NotNull String str) {
        this.entrustPrice = str;
    }

    public final void setFrom(@NotNull AlphaTPSLType alphaTPSLType) {
        this.from = alphaTPSLType;
    }

    public final void setIsCheck(boolean value) {
        if (!value) {
            this.stop_profit = new AlphaOrderTPSL(null, null, null, false, null, null, null, 127, null);
            this.stop_loss = new AlphaOrderTPSL(null, null, null, false, null, null, null, 127, null);
        }
        this.isCheck = value;
    }

    public final void setOption(boolean z10) {
        this.isOption = z10;
    }

    public final void setStop_loss(@NotNull AlphaOrderTPSL alphaOrderTPSL) {
        this.stop_loss = alphaOrderTPSL;
    }

    public final void setStop_profit(@NotNull AlphaOrderTPSL alphaOrderTPSL) {
        this.stop_profit = alphaOrderTPSL;
    }

    @NotNull
    public String toString() {
        return "AlphaTPSLOptionBean(entrustPrice=" + this.entrustPrice + ", stop_profit=" + this.stop_profit + ", stop_loss=" + this.stop_loss + ", isCheck=" + this.isCheck + ", isOption=" + this.isOption + ", from=" + this.from + ')';
    }

    public /* synthetic */ AlphaTPSLOptionBean(String str, AlphaOrderTPSL alphaOrderTPSL, AlphaOrderTPSL alphaOrderTPSL2, boolean z10, boolean z11, AlphaTPSLType alphaTPSLType, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? "" : str, (i10 & 2) != 0 ? new AlphaOrderTPSL(null, null, null, false, null, null, null, 127, null) : alphaOrderTPSL, (i10 & 4) != 0 ? new AlphaOrderTPSL(null, null, null, false, null, null, null, 127, null) : alphaOrderTPSL2, (i10 & 8) != 0 ? false : z10, (i10 & 16) == 0 ? z11 : false, (i10 & 32) != 0 ? AlphaTPSLType.TYPE_INIT : alphaTPSLType);
    }
}