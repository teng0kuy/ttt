package com.gateio.biz.base.model;

import com.gateio.biz.base.datafinder.futures.event.BaseContractKLineClickEvent;
import com.tencent.qcloud.tim.push.components.StatisticDataStorage;
import com.zoloz.webcontainer.env.H5Container;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: PreMarketKlineData.kt */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0012\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B5\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\u0003¢\u0006\u0002\u0010\nJ\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\bHÆ\u0003J\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003JE\u0010\u0019\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u001a\u001a\u00020\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001d\u001a\u00020\u001eHÖ\u0001J\t\u0010\u001f\u001a\u00020 HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\fR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\fR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\fR\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\t\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\f¨\u0006!"}, d2 = {"Lcom/gateio/biz/base/model/CandlestickData;", "", "closePrice", "", "highPrice", "lowPrice", "openPrice", StatisticDataStorage.f32621g, "", BaseContractKLineClickEvent.vol, "(DDDDJD)V", "getClosePrice", "()D", "getHighPrice", "getLowPrice", "getOpenPrice", "getTime", "()J", "getVol", "component1", "component2", "component3", "component4", "component5", "component6", H5Container.MENU_COPY, "equals", "", "other", "hashCode", "", "toString", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class CandlestickData {
    private final double closePrice;
    private final double highPrice;
    private final double lowPrice;
    private final double openPrice;
    private final long time;
    private final double vol;

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof CandlestickData)) {
            return false;
        }
        CandlestickData candlestickData = (CandlestickData) other;
        return Double.compare(this.closePrice, candlestickData.closePrice) == 0 && Double.compare(this.highPrice, candlestickData.highPrice) == 0 && Double.compare(this.lowPrice, candlestickData.lowPrice) == 0 && Double.compare(this.openPrice, candlestickData.openPrice) == 0 && this.time == candlestickData.time && Double.compare(this.vol, candlestickData.vol) == 0;
    }

    /* renamed from: component1, reason: from getter */
    public final double getClosePrice() {
        return this.closePrice;
    }

    /* renamed from: component2, reason: from getter */
    public final double getHighPrice() {
        return this.highPrice;
    }

    /* renamed from: component3, reason: from getter */
    public final double getLowPrice() {
        return this.lowPrice;
    }

    /* renamed from: component4, reason: from getter */
    public final double getOpenPrice() {
        return this.openPrice;
    }

    /* renamed from: component5, reason: from getter */
    public final long getTime() {
        return this.time;
    }

    /* renamed from: component6, reason: from getter */
    public final double getVol() {
        return this.vol;
    }

    @NotNull
    public final CandlestickData copy(double closePrice, double highPrice, double lowPrice, double openPrice, long time, double vol) {
        return new CandlestickData(closePrice, highPrice, lowPrice, openPrice, time, vol);
    }

    public final double getClosePrice() {
        return this.closePrice;
    }

    public final double getHighPrice() {
        return this.highPrice;
    }

    public final double getLowPrice() {
        return this.lowPrice;
    }

    public final double getOpenPrice() {
        return this.openPrice;
    }

    public final long getTime() {
        return this.time;
    }

    public final double getVol() {
        return this.vol;
    }

    public int hashCode() {
        return (((((((((Double.hashCode(this.closePrice) * 31) + Double.hashCode(this.highPrice)) * 31) + Double.hashCode(this.lowPrice)) * 31) + Double.hashCode(this.openPrice)) * 31) + Long.hashCode(this.time)) * 31) + Double.hashCode(this.vol);
    }

    @NotNull
    public String toString() {
        return "CandlestickData(closePrice=" + this.closePrice + ", highPrice=" + this.highPrice + ", lowPrice=" + this.lowPrice + ", openPrice=" + this.openPrice + ", time=" + this.time + ", vol=" + this.vol + ')';
    }

    public CandlestickData(double d10, double d11, double d12, double d13, long j10, double d14) {
        this.closePrice = d10;
        this.highPrice = d11;
        this.lowPrice = d12;
        this.openPrice = d13;
        this.time = j10;
        this.vol = d14;
    }
}