package com.gateio.biz.base.model;

import com.fasterxml.jackson.core.JsonPointer;
import com.gateio.biz.base.BizBaseInitializer;
import com.gateio.common.tool.LocalUtils;
import com.gateio.lib.storage.annotation.GTStorageClass;
import com.gateio.lib.storage.annotation.GTStorageGroup;
import com.gateio.lib.storage.protocol.IGTStorageObject;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.RealmClass;
import io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface;
import io.realm.internal.RealmObjectProxy;
import kotlin.Deprecated;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.text.StringsKt__StringsJVMKt;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: CurrencyData.kt */
@GTStorageClass(group = GTStorageGroup.APP)
@RealmClass
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b-\n\u0002\u0010\b\n\u0002\b\u001c\n\u0002\u0010\u0002\n\u0002\b\u000f\b\u0017\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0006\u0010>\u001a\u00020\u0004J\u0006\u0010?\u001a\u00020\u0004J\u0006\u0010@\u001a\u00020\u0004J\b\u0010A\u001a\u0004\u0018\u00010\u0004J\b\u0010B\u001a\u0004\u0018\u00010\u0004J\b\u0010C\u001a\u0004\u0018\u00010\u0004J\b\u0010D\u001a\u0004\u0018\u00010\u0004J\b\u0010E\u001a\u0004\u0018\u00010\u0004J\b\u0010F\u001a\u0004\u0018\u00010\u0004J\u0006\u0010G\u001a\u00020\u0004J\b\u0010H\u001a\u0004\u0018\u00010\u0004J\u0006\u0010I\u001a\u00020\u0004J\u0006\u0010J\u001a\u00020\u0004J\u0006\u0010K\u001a\u00020\u0004J\u0010\u0010L\u001a\u00020\u00042\u0006\u0010M\u001a\u00020\u0004H\u0002J\u000e\u0010N\u001a\u00020O2\u0006\u0010\u0012\u001a\u00020\u0004J\u0010\u0010P\u001a\u00020O2\b\u0010\u0013\u001a\u0004\u0018\u00010\u0004J\u0010\u0010Q\u001a\u00020O2\b\u0010\u0014\u001a\u0004\u0018\u00010\u0004J\u000e\u0010R\u001a\u00020O2\u0006\u0010S\u001a\u00020\u0004J\u000e\u0010T\u001a\u00020O2\u0006\u0010S\u001a\u00020\u0004J\u000e\u0010U\u001a\u00020O2\u0006\u0010S\u001a\u00020\u0004J\u000e\u0010V\u001a\u00020O2\u0006\u0010S\u001a\u00020\u0004J\u000e\u0010W\u001a\u00020O2\u0006\u0010S\u001a\u00020\u0004J\u000e\u0010X\u001a\u00020O2\u0006\u0010S\u001a\u00020\u0004J\u000e\u0010Y\u001a\u00020O2\u0006\u0010S\u001a\u00020\u0004J\u000e\u0010Z\u001a\u00020O2\u0006\u0010S\u001a\u00020\u0004J\u0010\u0010[\u001a\u00020O2\b\u0010)\u001a\u0004\u0018\u00010\u0004J\u0010\u0010\\\u001a\u00020O2\b\u0010-\u001a\u0004\u0018\u00010\u0004J\b\u0010]\u001a\u00020\u0004H\u0016R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001c\u0010\t\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u0006\"\u0004\b\u000b\u0010\bR \u0010\f\u001a\u0004\u0018\u00010\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u0006\"\u0004\b\u000e\u0010\bR\u001c\u0010\u000f\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0006\"\u0004\b\u0011\u0010\bR\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010\u0015\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u0006\"\u0004\b\u0017\u0010\bR\u001c\u0010\u0018\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0006\"\u0004\b\u0019\u0010\bR\u001c\u0010\u001a\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001a\u0010\u0006\"\u0004\b\u001b\u0010\bR\u001c\u0010\u001c\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001c\u0010\u0006\"\u0004\b\u001d\u0010\bR\u001c\u0010\u001e\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001e\u0010\u0006\"\u0004\b\u001f\u0010\bR\u001c\u0010 \u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b \u0010\u0006\"\u0004\b!\u0010\bR\u001c\u0010\"\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\"\u0010\u0006\"\u0004\b#\u0010\bR$\u0010$\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u0014\n\u0000\u0012\u0004\b%\u0010\u0002\u001a\u0004\b$\u0010\u0006\"\u0004\b&\u0010\bR\u001c\u0010'\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b'\u0010\u0006\"\u0004\b(\u0010\bR\u0010\u0010)\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010*\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b+\u0010\u0006\"\u0004\b,\u0010\bR\u0010\u0010-\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010.\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b/\u0010\u0006\"\u0004\b0\u0010\bR$\u00101\u001a\u0002028\u0006@\u0006X\u0087\u000e¢\u0006\u0014\n\u0000\u0012\u0004\b3\u0010\u0002\u001a\u0004\b4\u00105\"\u0004\b6\u00107R\u001c\u00108\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b9\u0010\u0006\"\u0004\b:\u0010\bR\u001c\u0010;\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b<\u0010\u0006\"\u0004\b=\u0010\b¨\u0006^"}, d2 = {"Lcom/gateio/biz/base/model/CurrencyData;", "Lcom/gateio/lib/storage/protocol/IGTStorageObject;", "()V", "address", "", "getAddress", "()Ljava/lang/String;", "setAddress", "(Ljava/lang/String;)V", "create_time", "getCreate_time", "setCreate_time", "currencyType", "getCurrencyType", "setCurrencyType", "hasTag", "getHasTag", "setHasTag", "iconUrl16", "iconUrl32", "iconUrl64", "info", "getInfo", "setInfo", "isFiat", "setFiat", "is_delisted", "set_delisted", "is_deposit_disabled", "set_deposit_disabled", "is_fund_disabled", "set_fund_disabled", "is_lowliquidity", "set_lowliquidity", "is_trade_disabled", "set_trade_disabled", "is_visibility", "is_visibility$annotations", "set_visibility", "is_withdraw_disabled", "set_withdraw_disabled", "name", "name_alias", "getName_alias", "setName_alias", "name_en", "prizeRange", "getPrizeRange", "setPrizeRange", "seq", "", "getSeq$annotations", "getSeq", "()I", "setSeq", "(I)V", "symbol", "getSymbol", "setSymbol", "update_time", "getUpdate_time", "setUpdate_time", "getIconUrl16", "getIconUrl32", "getIconUrl64", "getIsFiat", "getIs_delisted", "getIs_deposit_disabled", "getIs_fund_disabled", "getIs_lowliquidity", "getIs_trade_disabled", "getIs_visibility", "getIs_withdraw_disabled", "getName", "getName_en", "getRealName", "getWholeUrl", "url", "setIconUrl16", "", "setIconUrl32", "setIconUrl64", "setIsFiat", "value", "setIs_delisted", "setIs_deposit_disabled", "setIs_fund_disabled", "setIs_lowliquidity", "setIs_trade_disabled", "setIs_visibility", "setIs_withdraw_disabled", "setName", "setName_en", "toString", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public class CurrencyData implements IGTStorageObject, com_gateio_biz_base_model_CurrencyDataRealmProxyInterface {

    @Nullable
    private String address;

    @Nullable
    private String create_time;

    @PrimaryKey
    @Nullable
    private String currencyType;

    @Nullable
    private String hasTag;

    @Nullable
    private String iconUrl16;

    @Nullable
    private String iconUrl32;

    @Nullable
    private String iconUrl64;

    @Nullable
    private String info;

    @Nullable
    private String isFiat;

    @Nullable
    private String is_delisted;

    @Nullable
    private String is_deposit_disabled;

    @Nullable
    private String is_fund_disabled;

    @Nullable
    private String is_lowliquidity;

    @Nullable
    private String is_trade_disabled;

    @NotNull
    private String is_visibility;

    @Nullable
    private String is_withdraw_disabled;

    @Nullable
    private String name;

    @Nullable
    private String name_alias;

    @Nullable
    private String name_en;

    @Nullable
    private String prizeRange;
    private int seq;

    @Nullable
    private String symbol;

    @Nullable
    private String update_time;

    private final String getWholeUrl(String url) {
        if (StringsKt__StringsJVMKt.startsWith$default(url, "http", false, 2, null)) {
            return url;
        }
        if (!StringsKt__StringsJVMKt.startsWith$default(url, "/", false, 2, null)) {
            url = JsonPointer.SEPARATOR + url;
        }
        StringBuilder sb = new StringBuilder();
        Function0<String> webBaseUrlProvider$biz_base_core_release = BizBaseInitializer.INSTANCE.getWebBaseUrlProvider$biz_base_core_release();
        sb.append(webBaseUrlProvider$biz_base_core_release != null ? webBaseUrlProvider$biz_base_core_release.invoke() : null);
        sb.append(url);
        return sb.toString();
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$address, reason: from getter */
    public String getAddress() {
        return this.address;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$create_time, reason: from getter */
    public String getCreate_time() {
        return this.create_time;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$currencyType, reason: from getter */
    public String getCurrencyType() {
        return this.currencyType;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$hasTag, reason: from getter */
    public String getHasTag() {
        return this.hasTag;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$iconUrl16, reason: from getter */
    public String getIconUrl16() {
        return this.iconUrl16;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$iconUrl32, reason: from getter */
    public String getIconUrl32() {
        return this.iconUrl32;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$iconUrl64, reason: from getter */
    public String getIconUrl64() {
        return this.iconUrl64;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$info, reason: from getter */
    public String getInfo() {
        return this.info;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$isFiat, reason: from getter */
    public String getIsFiat() {
        return this.isFiat;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$is_delisted, reason: from getter */
    public String getIs_delisted() {
        return this.is_delisted;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$is_deposit_disabled, reason: from getter */
    public String getIs_deposit_disabled() {
        return this.is_deposit_disabled;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$is_fund_disabled, reason: from getter */
    public String getIs_fund_disabled() {
        return this.is_fund_disabled;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$is_lowliquidity, reason: from getter */
    public String getIs_lowliquidity() {
        return this.is_lowliquidity;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$is_trade_disabled, reason: from getter */
    public String getIs_trade_disabled() {
        return this.is_trade_disabled;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$is_visibility, reason: from getter */
    public String getIs_visibility() {
        return this.is_visibility;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$is_withdraw_disabled, reason: from getter */
    public String getIs_withdraw_disabled() {
        return this.is_withdraw_disabled;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$name, reason: from getter */
    public String getName() {
        return this.name;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$name_alias, reason: from getter */
    public String getName_alias() {
        return this.name_alias;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$name_en, reason: from getter */
    public String getName_en() {
        return this.name_en;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$prizeRange, reason: from getter */
    public String getPrizeRange() {
        return this.prizeRange;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$seq, reason: from getter */
    public int getSeq() {
        return this.seq;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$symbol, reason: from getter */
    public String getSymbol() {
        return this.symbol;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    /* renamed from: realmGet$update_time, reason: from getter */
    public String getUpdate_time() {
        return this.update_time;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$address(String str) {
        this.address = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$create_time(String str) {
        this.create_time = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$currencyType(String str) {
        this.currencyType = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$hasTag(String str) {
        this.hasTag = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$iconUrl16(String str) {
        this.iconUrl16 = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$iconUrl32(String str) {
        this.iconUrl32 = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$iconUrl64(String str) {
        this.iconUrl64 = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$info(String str) {
        this.info = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$isFiat(String str) {
        this.isFiat = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$is_delisted(String str) {
        this.is_delisted = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$is_deposit_disabled(String str) {
        this.is_deposit_disabled = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$is_fund_disabled(String str) {
        this.is_fund_disabled = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$is_lowliquidity(String str) {
        this.is_lowliquidity = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$is_trade_disabled(String str) {
        this.is_trade_disabled = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$is_visibility(String str) {
        this.is_visibility = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$is_withdraw_disabled(String str) {
        this.is_withdraw_disabled = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$name(String str) {
        this.name = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$name_alias(String str) {
        this.name_alias = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$name_en(String str) {
        this.name_en = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$prizeRange(String str) {
        this.prizeRange = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$seq(int i10) {
        this.seq = i10;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$symbol(String str) {
        this.symbol = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxyInterface
    public void realmSet$update_time(String str) {
        this.update_time = str;
    }

    @NotNull
    public String toString() {
        return "CurrencyData{currencyType='" + getCurrencyType() + "', symbol='" + getSymbol() + "', name='" + getName() + "', name_en='" + getName_en() + "', address='" + getAddress() + "', info='" + getInfo() + "', prizeRange='" + getPrizeRange() + "', iconUrl16='" + getIconUrl16() + "', iconUrl32='" + getIconUrl32() + "', iconUrl64='" + getIconUrl64() + "', isFiat='" + getIsFiat() + "', hasTag='" + getHasTag() + "', is_delisted='" + getIs_delisted() + "', is_lowliquidity='" + getIs_lowliquidity() + "', is_trade_disabled='" + getIs_trade_disabled() + "', is_withdraw_disabled='" + getIs_withdraw_disabled() + "', is_deposit_disabled='" + getIs_deposit_disabled() + "', is_fund_disabled='" + getIs_fund_disabled() + "', name_alias='" + getName_alias() + "', update_time='" + getUpdate_time() + "', create_time='" + getCreate_time() + "', is_visibility='" + getIs_visibility() + "', seq=" + getSeq() + AbstractJsonLexerKt.END_OBJ;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public CurrencyData() {
        if (this instanceof RealmObjectProxy) {
            ((RealmObjectProxy) this).realm$injectObjectContext();
        }
        realmSet$is_visibility("1");
    }

    @Nullable
    public final String getAddress() {
        return getAddress();
    }

    @Nullable
    public final String getCreate_time() {
        return getCreate_time();
    }

    @Nullable
    public final String getCurrencyType() {
        return getCurrencyType();
    }

    @Nullable
    public final String getHasTag() {
        return getHasTag();
    }

    @NotNull
    public final String getIconUrl16() {
        String iconUrl16 = getIconUrl16();
        if (iconUrl16 == null) {
            iconUrl16 = "";
        }
        return getWholeUrl(iconUrl16);
    }

    @NotNull
    public final String getIconUrl32() {
        String iconUrl32 = getIconUrl32();
        if (iconUrl32 == null) {
            iconUrl32 = "";
        }
        return getWholeUrl(iconUrl32);
    }

    @NotNull
    public final String getIconUrl64() {
        String iconUrl64 = getIconUrl64();
        if (iconUrl64 == null) {
            iconUrl64 = "";
        }
        return getWholeUrl(iconUrl64);
    }

    @Nullable
    public final String getInfo() {
        return getInfo();
    }

    @Nullable
    public final String getIsFiat() {
        return getIsFiat();
    }

    @Nullable
    public final String getIs_delisted() {
        return getIs_delisted();
    }

    @Nullable
    public final String getIs_deposit_disabled() {
        return getIs_deposit_disabled();
    }

    @Nullable
    public final String getIs_fund_disabled() {
        return getIs_fund_disabled();
    }

    @Nullable
    public final String getIs_lowliquidity() {
        return getIs_lowliquidity();
    }

    @Nullable
    public final String getIs_trade_disabled() {
        return getIs_trade_disabled();
    }

    @NotNull
    public final String getIs_visibility() {
        return getIs_visibility();
    }

    @Nullable
    public final String getIs_withdraw_disabled() {
        return getIs_withdraw_disabled();
    }

    @NotNull
    public final String getName() {
        if (getName() == null) {
            return "";
        }
        return getName();
    }

    @Nullable
    public final String getName_alias() {
        return getName_alias();
    }

    @NotNull
    public final String getName_en() {
        if (getName_en() == null) {
            return "";
        }
        return getName_en();
    }

    @Nullable
    public final String getPrizeRange() {
        return getPrizeRange();
    }

    @NotNull
    public final String getRealName() {
        if (LocalUtils.getCurrentLanguage().isZhCn()) {
            return getName();
        }
        return getName_en();
    }

    public final int getSeq() {
        return getSeq();
    }

    @Nullable
    public final String getSymbol() {
        return getSymbol();
    }

    @Nullable
    public final String getUpdate_time() {
        return getUpdate_time();
    }

    @Nullable
    public final String isFiat() {
        return getIsFiat();
    }

    @Nullable
    public final String is_delisted() {
        return getIs_delisted();
    }

    @Nullable
    public final String is_deposit_disabled() {
        return getIs_deposit_disabled();
    }

    @Nullable
    public final String is_fund_disabled() {
        return getIs_fund_disabled();
    }

    @Nullable
    public final String is_lowliquidity() {
        return getIs_lowliquidity();
    }

    @Nullable
    public final String is_trade_disabled() {
        return getIs_trade_disabled();
    }

    @NotNull
    public final String is_visibility() {
        return getIs_visibility();
    }

    @Nullable
    public final String is_withdraw_disabled() {
        return getIs_withdraw_disabled();
    }

    public final void setAddress(@Nullable String str) {
        realmSet$address(str);
    }

    public final void setCreate_time(@Nullable String str) {
        realmSet$create_time(str);
    }

    public final void setCurrencyType(@Nullable String str) {
        realmSet$currencyType(str);
    }

    public final void setFiat(@Nullable String str) {
        realmSet$isFiat(str);
    }

    public final void setHasTag(@Nullable String str) {
        realmSet$hasTag(str);
    }

    public final void setIconUrl16(@NotNull String iconUrl16) {
        realmSet$iconUrl16(iconUrl16);
    }

    public final void setIconUrl32(@Nullable String iconUrl32) {
        realmSet$iconUrl32(iconUrl32);
    }

    public final void setIconUrl64(@Nullable String iconUrl64) {
        realmSet$iconUrl64(iconUrl64);
    }

    public final void setInfo(@Nullable String str) {
        realmSet$info(str);
    }

    public final void setIsFiat(@NotNull String value) {
        realmSet$isFiat(value);
    }

    public final void setIs_delisted(@NotNull String value) {
        realmSet$is_delisted(value);
    }

    public final void setIs_deposit_disabled(@NotNull String value) {
        realmSet$is_deposit_disabled(value);
    }

    public final void setIs_fund_disabled(@NotNull String value) {
        realmSet$is_fund_disabled(value);
    }

    public final void setIs_lowliquidity(@NotNull String value) {
        realmSet$is_lowliquidity(value);
    }

    public final void setIs_trade_disabled(@NotNull String value) {
        realmSet$is_trade_disabled(value);
    }

    public final void setIs_visibility(@NotNull String value) {
        realmSet$is_visibility(value);
    }

    public final void setIs_withdraw_disabled(@NotNull String value) {
        realmSet$is_withdraw_disabled(value);
    }

    public final void setName(@Nullable String name) {
        realmSet$name(name);
    }

    public final void setName_alias(@Nullable String str) {
        realmSet$name_alias(str);
    }

    public final void setName_en(@Nullable String name_en) {
        realmSet$name_en(name_en);
    }

    public final void setPrizeRange(@Nullable String str) {
        realmSet$prizeRange(str);
    }

    public final void setSeq(int i10) {
        realmSet$seq(i10);
    }

    public final void setSymbol(@Nullable String str) {
        realmSet$symbol(str);
    }

    public final void setUpdate_time(@Nullable String str) {
        realmSet$update_time(str);
    }

    public final void set_delisted(@Nullable String str) {
        realmSet$is_delisted(str);
    }

    public final void set_deposit_disabled(@Nullable String str) {
        realmSet$is_deposit_disabled(str);
    }

    public final void set_fund_disabled(@Nullable String str) {
        realmSet$is_fund_disabled(str);
    }

    public final void set_lowliquidity(@Nullable String str) {
        realmSet$is_lowliquidity(str);
    }

    public final void set_trade_disabled(@Nullable String str) {
        realmSet$is_trade_disabled(str);
    }

    public final void set_visibility(@NotNull String str) {
        realmSet$is_visibility(str);
    }

    public final void set_withdraw_disabled(@Nullable String str) {
        realmSet$is_withdraw_disabled(str);
    }

    @Deprecated(message = "")
    public static /* synthetic */ void getSeq$annotations() {
    }

    @Deprecated(message = "")
    public static /* synthetic */ void is_visibility$annotations() {
    }
}