package com.gateio.biz.base.model;

import com.alipay.blueshield.legacy.IDeviceColorModule;
import com.zoloz.webcontainer.env.H5Container;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: SpotMarginTradingSwitchStatus.kt */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0010\b\n\u0002\b\u0007\b\u0086\b\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0007HÆ\u0003J'\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00052\b\u0010\u0014\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0015\u001a\u00020\u0016HÖ\u0001J\u0006\u0010\u0017\u001a\u00020\u0005J\u0006\u0010\u0018\u001a\u00020\u0005J\u0006\u0010\u0019\u001a\u00020\u0005J\u0006\u0010\u001a\u001a\u00020\u0005J\u0006\u0010\u001b\u001a\u00020\u0005J\t\u0010\u001c\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000e¨\u0006\u001d"}, d2 = {"Lcom/gateio/biz/base/model/UnifiedAccountDigestsBean;", "", IDeviceColorModule.EDGE_MODE_KEY, "", "first_open", "", "settings", "Lcom/gateio/biz/base/model/PerpetualContract;", "(Ljava/lang/String;ZLcom/gateio/biz/base/model/PerpetualContract;)V", "getFirst_open", "()Z", "getMode", "()Ljava/lang/String;", "getSettings", "()Lcom/gateio/biz/base/model/PerpetualContract;", "component1", "component2", "component3", H5Container.MENU_COPY, "equals", "other", "hashCode", "", "isClassic", "isCombBondMode", "isMultiCurrency", "isSingleCurrency", "isSpotMarginTrading", "toString", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class UnifiedAccountDigestsBean {
    private final boolean first_open;

    @NotNull
    private final String mode;

    @NotNull
    private final PerpetualContract settings;

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof UnifiedAccountDigestsBean)) {
            return false;
        }
        UnifiedAccountDigestsBean unifiedAccountDigestsBean = (UnifiedAccountDigestsBean) other;
        return Intrinsics.areEqual(this.mode, unifiedAccountDigestsBean.mode) && this.first_open == unifiedAccountDigestsBean.first_open && Intrinsics.areEqual(this.settings, unifiedAccountDigestsBean.settings);
    }

    public static /* synthetic */ UnifiedAccountDigestsBean copy$default(UnifiedAccountDigestsBean unifiedAccountDigestsBean, String str, boolean z10, PerpetualContract perpetualContract, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = unifiedAccountDigestsBean.mode;
        }
        if ((i10 & 2) != 0) {
            z10 = unifiedAccountDigestsBean.first_open;
        }
        if ((i10 & 4) != 0) {
            perpetualContract = unifiedAccountDigestsBean.settings;
        }
        return unifiedAccountDigestsBean.copy(str, z10, perpetualContract);
    }

    @NotNull
    /* renamed from: component1, reason: from getter */
    public final String getMode() {
        return this.mode;
    }

    /* renamed from: component2, reason: from getter */
    public final boolean getFirst_open() {
        return this.first_open;
    }

    @NotNull
    /* renamed from: component3, reason: from getter */
    public final PerpetualContract getSettings() {
        return this.settings;
    }

    @NotNull
    public final UnifiedAccountDigestsBean copy(@NotNull String mode, boolean first_open, @NotNull PerpetualContract settings) {
        return new UnifiedAccountDigestsBean(mode, first_open, settings);
    }

    public final boolean getFirst_open() {
        return this.first_open;
    }

    @NotNull
    public final String getMode() {
        return this.mode;
    }

    @NotNull
    public final PerpetualContract getSettings() {
        return this.settings;
    }

    public int hashCode() {
        return (((this.mode.hashCode() * 31) + Boolean.hashCode(this.first_open)) * 31) + this.settings.hashCode();
    }

    public final boolean isClassic() {
        return Intrinsics.areEqual(this.mode, SpotMarginTradingType.CLASSIC.getType());
    }

    public final boolean isCombBondMode() {
        return Intrinsics.areEqual(this.mode, SpotMarginTradingType.PORTFOLIO.getType());
    }

    public final boolean isMultiCurrency() {
        return Intrinsics.areEqual(this.mode, SpotMarginTradingType.MULTI_CURRENCY.getType());
    }

    public final boolean isSingleCurrency() {
        return Intrinsics.areEqual(this.mode, SpotMarginTradingType.SINGLE_CURRENCY.getType());
    }

    public final boolean isSpotMarginTrading() {
        return Intrinsics.areEqual(this.mode, SpotMarginTradingType.MULTI_CURRENCY.getType()) || Intrinsics.areEqual(this.mode, SpotMarginTradingType.PORTFOLIO.getType()) || Intrinsics.areEqual(this.mode, SpotMarginTradingType.SINGLE_CURRENCY.getType());
    }

    @NotNull
    public String toString() {
        return "UnifiedAccountDigestsBean(mode=" + this.mode + ", first_open=" + this.first_open + ", settings=" + this.settings + ')';
    }

    public UnifiedAccountDigestsBean(@NotNull String str, boolean z10, @NotNull PerpetualContract perpetualContract) {
        this.mode = str;
        this.first_open = z10;
        this.settings = perpetualContract;
    }
}