package com.gateio.biz.base.model;

import com.zoloz.webcontainer.env.H5Container;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: SpotMarginTradingSwitch.kt */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\u0014\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\b\u0086\b\u0018\u00002\u00020\u0001BS\u0012\u0010\b\u0002\u0010\u0002\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003\u0012\u0010\b\u0002\u0010\u0005\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003\u0012\u0010\b\u0002\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0004\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0001¢\u0006\u0002\u0010\tJ\u0011\u0010\u0012\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003HÆ\u0003J\u0011\u0010\u0013\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003HÆ\u0003J\u0011\u0010\u0014\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0015\u001a\u0004\u0018\u00010\u0004HÆ\u0003J\u000b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÆ\u0003JW\u0010\u0017\u001a\u00020\u00002\u0010\b\u0002\u0010\u0002\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u00032\u0010\b\u0002\u0010\u0005\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u00032\u0010\b\u0002\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0001HÆ\u0001J\u0013\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001b\u001a\u00020\u001cHÖ\u0001J\u0006\u0010\u001d\u001a\u00020\u0019J\t\u0010\u001e\u001a\u00020\u0004HÖ\u0001R\u0019\u0010\u0005\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0019\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000bR\u0019\u0010\u0002\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000bR\u0013\u0010\u0007\u001a\u0004\u0018\u00010\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0013\u0010\b\u001a\u0004\u0018\u00010\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011¨\u0006\u001f"}, d2 = {"Lcom/gateio/biz/base/model/SpotMarginTradingSwitch;", "", "notice", "", "", "coins", "market", "positionType", "translate", "(Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/lang/String;Ljava/lang/Object;)V", "getCoins", "()Ljava/util/List;", "getMarket", "getNotice", "getPositionType", "()Ljava/lang/String;", "getTranslate", "()Ljava/lang/Object;", "component1", "component2", "component3", "component4", "component5", H5Container.MENU_COPY, "equals", "", "other", "hashCode", "", "isSingle", "toString", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class SpotMarginTradingSwitch {

    @Nullable
    private final List<String> coins;

    @Nullable
    private final List<String> market;

    @Nullable
    private final List<String> notice;

    @Nullable
    private final String positionType;

    @Nullable
    private final Object translate;

    public SpotMarginTradingSwitch() {
        this(null, null, null, null, null, 31, null);
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SpotMarginTradingSwitch)) {
            return false;
        }
        SpotMarginTradingSwitch spotMarginTradingSwitch = (SpotMarginTradingSwitch) other;
        return Intrinsics.areEqual(this.notice, spotMarginTradingSwitch.notice) && Intrinsics.areEqual(this.coins, spotMarginTradingSwitch.coins) && Intrinsics.areEqual(this.market, spotMarginTradingSwitch.market) && Intrinsics.areEqual(this.positionType, spotMarginTradingSwitch.positionType) && Intrinsics.areEqual(this.translate, spotMarginTradingSwitch.translate);
    }

    public SpotMarginTradingSwitch(@Nullable List<String> list, @Nullable List<String> list2, @Nullable List<String> list3, @Nullable String str, @Nullable Object obj) {
        this.notice = list;
        this.coins = list2;
        this.market = list3;
        this.positionType = str;
        this.translate = obj;
    }

    public static /* synthetic */ SpotMarginTradingSwitch copy$default(SpotMarginTradingSwitch spotMarginTradingSwitch, List list, List list2, List list3, String str, Object obj, int i10, Object obj2) {
        if ((i10 & 1) != 0) {
            list = spotMarginTradingSwitch.notice;
        }
        if ((i10 & 2) != 0) {
            list2 = spotMarginTradingSwitch.coins;
        }
        List list4 = list2;
        if ((i10 & 4) != 0) {
            list3 = spotMarginTradingSwitch.market;
        }
        List list5 = list3;
        if ((i10 & 8) != 0) {
            str = spotMarginTradingSwitch.positionType;
        }
        String str2 = str;
        if ((i10 & 16) != 0) {
            obj = spotMarginTradingSwitch.translate;
        }
        return spotMarginTradingSwitch.copy(list, list4, list5, str2, obj);
    }

    @Nullable
    public final List<String> component1() {
        return this.notice;
    }

    @Nullable
    public final List<String> component2() {
        return this.coins;
    }

    @Nullable
    public final List<String> component3() {
        return this.market;
    }

    @Nullable
    /* renamed from: component4, reason: from getter */
    public final String getPositionType() {
        return this.positionType;
    }

    @Nullable
    /* renamed from: component5, reason: from getter */
    public final Object getTranslate() {
        return this.translate;
    }

    @NotNull
    public final SpotMarginTradingSwitch copy(@Nullable List<String> notice, @Nullable List<String> coins, @Nullable List<String> market, @Nullable String positionType, @Nullable Object translate) {
        return new SpotMarginTradingSwitch(notice, coins, market, positionType, translate);
    }

    @Nullable
    public final List<String> getCoins() {
        return this.coins;
    }

    @Nullable
    public final List<String> getMarket() {
        return this.market;
    }

    @Nullable
    public final List<String> getNotice() {
        return this.notice;
    }

    @Nullable
    public final String getPositionType() {
        return this.positionType;
    }

    @Nullable
    public final Object getTranslate() {
        return this.translate;
    }

    public int hashCode() {
        List<String> list = this.notice;
        int iHashCode = (list == null ? 0 : list.hashCode()) * 31;
        List<String> list2 = this.coins;
        int iHashCode2 = (iHashCode + (list2 == null ? 0 : list2.hashCode())) * 31;
        List<String> list3 = this.market;
        int iHashCode3 = (iHashCode2 + (list3 == null ? 0 : list3.hashCode())) * 31;
        String str = this.positionType;
        int iHashCode4 = (iHashCode3 + (str == null ? 0 : str.hashCode())) * 31;
        Object obj = this.translate;
        return iHashCode4 + (obj != null ? obj.hashCode() : 0);
    }

    public final boolean isSingle() {
        return Intrinsics.areEqual(this.positionType, "SINGLE");
    }

    @NotNull
    public String toString() {
        return "SpotMarginTradingSwitch(notice=" + this.notice + ", coins=" + this.coins + ", market=" + this.market + ", positionType=" + this.positionType + ", translate=" + this.translate + ')';
    }

    public /* synthetic */ SpotMarginTradingSwitch(List list, List list2, List list3, String str, Object obj, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? null : list, (i10 & 2) != 0 ? null : list2, (i10 & 4) != 0 ? null : list3, (i10 & 8) != 0 ? null : str, (i10 & 16) != 0 ? null : obj);
    }
}