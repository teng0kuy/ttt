package com.gateio.biz.base.model;

import com.gateio.lib.storage.annotation.GTStorageClass;
import com.gateio.lib.storage.annotation.GTStorageGroup;
import com.gateio.lib.storage.protocol.IGTStorageObject;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.RealmClass;
import io.realm.com_gateio_biz_base_model_VersionDataRealmProxyInterface;
import io.realm.internal.RealmObjectProxy;

@GTStorageClass(group = GTStorageGroup.APP)
@RealmClass
/* loaded from: classes4.dex */
public class VersionData implements IGTStorageObject, com_gateio_biz_base_model_VersionDataRealmProxyInterface {

    @PrimaryKey
    private String name;
    private Long time;
    private String version;

    @Override // io.realm.com_gateio_biz_base_model_VersionDataRealmProxyInterface
    public String realmGet$name() {
        return this.name;
    }

    @Override // io.realm.com_gateio_biz_base_model_VersionDataRealmProxyInterface
    public Long realmGet$time() {
        return this.time;
    }

    @Override // io.realm.com_gateio_biz_base_model_VersionDataRealmProxyInterface
    public String realmGet$version() {
        return this.version;
    }

    @Override // io.realm.com_gateio_biz_base_model_VersionDataRealmProxyInterface
    public void realmSet$name(String str) {
        this.name = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_VersionDataRealmProxyInterface
    public void realmSet$time(Long l) {
        this.time = l;
    }

    @Override // io.realm.com_gateio_biz_base_model_VersionDataRealmProxyInterface
    public void realmSet$version(String str) {
        this.version = str;
    }

    public String toString() {
        return "name=" + realmGet$name() + " version=" + realmGet$version() + " time=" + realmGet$time() + " | ";
    }

    /* JADX WARN: Multi-variable type inference failed */
    public VersionData() {
        if (this instanceof RealmObjectProxy) {
            ((RealmObjectProxy) this).realm$injectObjectContext();
        }
    }

    public String getName() {
        return realmGet$name();
    }

    public Long getTime() {
        return realmGet$time();
    }

    public String getVersion() {
        return realmGet$version();
    }

    public void setName(String str) {
        realmSet$name(str);
    }

    public void setTime(Long l) {
        realmSet$time(l);
    }

    public void setVersion(String str) {
        realmSet$version(str);
    }
}