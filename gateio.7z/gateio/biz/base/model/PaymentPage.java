package com.gateio.biz.base.model;

import com.gate_sdk.web3_wallet.DeFiConstants;
import com.gateio.fiatotclib.constants.KeyConstantsKt;
import com.zoloz.webcontainer.plugin.impl.H5SetTitlePlugin;
import java.util.List;
import kotlin.Metadata;
import org.jetbrains.annotations.Nullable;

/* compiled from: PaymentPage.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u000e\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0015\u0018\u00002\u00020\u0001:\u0001(B\u0005¢\u0006\u0002\u0010\u0002R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001c\u0010\t\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u0006\"\u0004\b\u000b\u0010\bR\u001c\u0010\f\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u0006\"\u0004\b\u000e\u0010\bR\u001c\u0010\u000f\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0006\"\u0004\b\u0011\u0010\bR&\u0010\u0012\u001a\u000e\u0012\b\u0012\u00060\u0014R\u00020\u0000\u0018\u00010\u0013X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0016\"\u0004\b\u0017\u0010\u0018R\u001c\u0010\u0019\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001a\u0010\u0006\"\u0004\b\u001b\u0010\bR\u001c\u0010\u001c\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u0006\"\u0004\b\u001e\u0010\bR\u001c\u0010\u001f\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b \u0010\u0006\"\u0004\b!\u0010\bR\u001c\u0010\"\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b#\u0010\u0006\"\u0004\b$\u0010\bR\u001c\u0010%\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b&\u0010\u0006\"\u0004\b'\u0010\b¨\u0006)"}, d2 = {"Lcom/gateio/biz/base/model/PaymentPage;", "", "()V", "base_type", "", "getBase_type", "()Ljava/lang/String;", "setBase_type", "(Ljava/lang/String;)V", "bottom_tip", "getBottom_tip", "setBottom_tip", "image", "getImage", "setImage", "index", "getIndex", "setIndex", "param", "", "Lcom/gateio/biz/base/model/PaymentPage$PaymentPageParams;", "getParam", "()Ljava/util/List;", "setParam", "(Ljava/util/List;)V", "pay_name", "getPay_name", "setPay_name", "pay_name_prefix", "getPay_name_prefix", "setPay_name_prefix", KeyConstantsKt.PAY_TYPE, "getPay_type", "setPay_type", "title", "getTitle", H5SetTitlePlugin.H5_SET_TITLE, "top_tip", "getTop_tip", "setTop_tip", "PaymentPageParams", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class PaymentPage {

    @Nullable
    private String base_type;

    @Nullable
    private String bottom_tip;

    @Nullable
    private String image;

    @Nullable
    private String index;

    @Nullable
    private List<PaymentPageParams> param;

    @Nullable
    private String pay_name;

    @Nullable
    private String pay_name_prefix;

    @Nullable
    private String pay_type;

    @Nullable
    private String title;

    @Nullable
    private String top_tip;

    /* compiled from: PaymentPage.kt */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0013\n\u0002\u0010\u0002\n\u0000\b\u0086\u0004\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0016\u001a\u0004\u0018\u00010\u0004J\u0010\u0010\u0017\u001a\u00020\u00182\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010\u0005\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u001c\u0010\n\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\u0007\"\u0004\b\f\u0010\tR\u001c\u0010\r\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u0007\"\u0004\b\u000f\u0010\tR\u001c\u0010\u0010\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0007\"\u0004\b\u0012\u0010\tR\u001c\u0010\u0013\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u0007\"\u0004\b\u0015\u0010\t¨\u0006\u0019"}, d2 = {"Lcom/gateio/biz/base/model/PaymentPage$PaymentPageParams;", "", "(Lcom/gateio/biz/base/model/PaymentPage;)V", "hInt", "", "name", "getName", "()Ljava/lang/String;", "setName", "(Ljava/lang/String;)V", "required", "getRequired", "setRequired", "title", "getTitle", H5SetTitlePlugin.H5_SET_TITLE, "type", DeFiConstants.GetType, "setType", "value", "getValue", "setValue", "gethInt", "sethInt", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public final class PaymentPageParams {

        @Nullable
        private String hInt;

        @Nullable
        private String name;

        @Nullable
        private String required;

        @Nullable
        private String title;

        @Nullable
        private String type;

        @Nullable
        private String value;

        public PaymentPageParams() {
        }

        @Nullable
        public final String getName() {
            return this.name;
        }

        @Nullable
        public final String getRequired() {
            return this.required;
        }

        @Nullable
        public final String getTitle() {
            return this.title;
        }

        @Nullable
        public final String getType() {
            return this.type;
        }

        @Nullable
        public final String getValue() {
            return this.value;
        }

        @Nullable
        /* renamed from: gethInt, reason: from getter */
        public final String getHInt() {
            return this.hInt;
        }

        public final void setName(@Nullable String str) {
            this.name = str;
        }

        public final void setRequired(@Nullable String str) {
            this.required = str;
        }

        public final void setTitle(@Nullable String str) {
            this.title = str;
        }

        public final void setType(@Nullable String str) {
            this.type = str;
        }

        public final void setValue(@Nullable String str) {
            this.value = str;
        }

        public final void sethInt(@Nullable String hInt) {
            this.hInt = hInt;
        }
    }

    @Nullable
    public final String getBase_type() {
        return this.base_type;
    }

    @Nullable
    public final String getBottom_tip() {
        return this.bottom_tip;
    }

    @Nullable
    public final String getImage() {
        return this.image;
    }

    @Nullable
    public final String getIndex() {
        return this.index;
    }

    @Nullable
    public final List<PaymentPageParams> getParam() {
        return this.param;
    }

    @Nullable
    public final String getPay_name() {
        return this.pay_name;
    }

    @Nullable
    public final String getPay_name_prefix() {
        return this.pay_name_prefix;
    }

    @Nullable
    public final String getPay_type() {
        return this.pay_type;
    }

    @Nullable
    public final String getTitle() {
        return this.title;
    }

    @Nullable
    public final String getTop_tip() {
        return this.top_tip;
    }

    public final void setBase_type(@Nullable String str) {
        this.base_type = str;
    }

    public final void setBottom_tip(@Nullable String str) {
        this.bottom_tip = str;
    }

    public final void setImage(@Nullable String str) {
        this.image = str;
    }

    public final void setIndex(@Nullable String str) {
        this.index = str;
    }

    public final void setParam(@Nullable List<PaymentPageParams> list) {
        this.param = list;
    }

    public final void setPay_name(@Nullable String str) {
        this.pay_name = str;
    }

    public final void setPay_name_prefix(@Nullable String str) {
        this.pay_name_prefix = str;
    }

    public final void setPay_type(@Nullable String str) {
        this.pay_type = str;
    }

    public final void setTitle(@Nullable String str) {
        this.title = str;
    }

    public final void setTop_tip(@Nullable String str) {
        this.top_tip = str;
    }
}