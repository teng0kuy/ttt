package com.gateio.biz.base.model;

import com.zoloz.webcontainer.env.H5Container;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: SpotMarginTradingSwitchStatus.kt */
@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0013\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B-\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003¢\u0006\u0002\u0010\u0007J\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J1\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00032\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0017HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0019HÖ\u0001R\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\tR\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\t\"\u0004\b\f\u0010\rR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\t¨\u0006\u001a"}, d2 = {"Lcom/gateio/biz/base/model/PerpetualContract;", "", "usdt_futures", "", "spot_hedge", "use_funding", "options", "(ZZZZ)V", "getOptions", "()Z", "getSpot_hedge", "getUsdt_futures", "setUsdt_futures", "(Z)V", "getUse_funding", "component1", "component2", "component3", "component4", H5Container.MENU_COPY, "equals", "other", "hashCode", "", "toString", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class PerpetualContract {
    private final boolean options;
    private final boolean spot_hedge;
    private boolean usdt_futures;
    private final boolean use_funding;

    public PerpetualContract() {
        this(false, false, false, false, 15, null);
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof PerpetualContract)) {
            return false;
        }
        PerpetualContract perpetualContract = (PerpetualContract) other;
        return this.usdt_futures == perpetualContract.usdt_futures && this.spot_hedge == perpetualContract.spot_hedge && this.use_funding == perpetualContract.use_funding && this.options == perpetualContract.options;
    }

    public PerpetualContract(boolean z10, boolean z11, boolean z12, boolean z13) {
        this.usdt_futures = z10;
        this.spot_hedge = z11;
        this.use_funding = z12;
        this.options = z13;
    }

    public static /* synthetic */ PerpetualContract copy$default(PerpetualContract perpetualContract, boolean z10, boolean z11, boolean z12, boolean z13, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            z10 = perpetualContract.usdt_futures;
        }
        if ((i10 & 2) != 0) {
            z11 = perpetualContract.spot_hedge;
        }
        if ((i10 & 4) != 0) {
            z12 = perpetualContract.use_funding;
        }
        if ((i10 & 8) != 0) {
            z13 = perpetualContract.options;
        }
        return perpetualContract.copy(z10, z11, z12, z13);
    }

    /* renamed from: component1, reason: from getter */
    public final boolean getUsdt_futures() {
        return this.usdt_futures;
    }

    /* renamed from: component2, reason: from getter */
    public final boolean getSpot_hedge() {
        return this.spot_hedge;
    }

    /* renamed from: component3, reason: from getter */
    public final boolean getUse_funding() {
        return this.use_funding;
    }

    /* renamed from: component4, reason: from getter */
    public final boolean getOptions() {
        return this.options;
    }

    @NotNull
    public final PerpetualContract copy(boolean usdt_futures, boolean spot_hedge, boolean use_funding, boolean options) {
        return new PerpetualContract(usdt_futures, spot_hedge, use_funding, options);
    }

    public final boolean getOptions() {
        return this.options;
    }

    public final boolean getSpot_hedge() {
        return this.spot_hedge;
    }

    public final boolean getUsdt_futures() {
        return this.usdt_futures;
    }

    public final boolean getUse_funding() {
        return this.use_funding;
    }

    public int hashCode() {
        return (((((Boolean.hashCode(this.usdt_futures) * 31) + Boolean.hashCode(this.spot_hedge)) * 31) + Boolean.hashCode(this.use_funding)) * 31) + Boolean.hashCode(this.options);
    }

    public final void setUsdt_futures(boolean z10) {
        this.usdt_futures = z10;
    }

    @NotNull
    public String toString() {
        return "PerpetualContract(usdt_futures=" + this.usdt_futures + ", spot_hedge=" + this.spot_hedge + ", use_funding=" + this.use_funding + ", options=" + this.options + ')';
    }

    public /* synthetic */ PerpetualContract(boolean z10, boolean z11, boolean z12, boolean z13, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? false : z10, (i10 & 2) != 0 ? false : z11, (i10 & 4) != 0 ? false : z12, (i10 & 8) != 0 ? false : z13);
    }
}