package com.gateio.biz.base.model.futures.entity;

/* loaded from: classes4.dex */
public class BillFutureInfo {
    private String balance;
    private String change;
    private String text;
    private String time;
    private String timest;
    private String type;
    private String type_i18n;

    public String getBalance() {
        return this.balance;
    }

    public String getChange() {
        return this.change;
    }

    public String getText() {
        return this.text;
    }

    public String getTime() {
        return this.time;
    }

    public String getTimest() {
        return this.timest;
    }

    public String getType() {
        return this.type;
    }

    public String getType_i18n() {
        return this.type_i18n;
    }

    public boolean isOUt() {
        return this.change.contains("-");
    }

    public void setBalance(String str) {
        this.balance = str;
    }

    public void setChange(String str) {
        this.change = str;
    }

    public void setText(String str) {
        this.text = str;
    }

    public void setTime(String str) {
        this.time = str;
    }

    public void setTimest(String str) {
        this.timest = str;
    }

    public void setType(String str) {
        this.type = str;
    }

    public void setType_i18n(String str) {
        this.type_i18n = str;
    }
}