package com.gateio.biz.base.model.futures.entity;

/* loaded from: classes4.dex */
public class TransTrigPrice {
    public static final String RULE_LESS = "2";
    public static final String RULE_MORE = "1";
    public static final String SELECTED_GTE = "gte";
    public static final String SELECTED_LTE = "lte";
    private int position;
    private int resId;
    private String rule;
    private String selected;

    public int getPosition() {
        return this.position;
    }

    public int getResId() {
        return this.resId;
    }

    public String getRule() {
        return this.rule;
    }

    public String getSelected() {
        return this.selected;
    }

    public void setPosition(int i10) {
        this.position = i10;
    }

    public void setResId(int i10) {
        this.resId = i10;
    }

    public void setRule(String str) {
        this.rule = str;
    }

    public void setSelected(String str) {
        this.selected = str;
    }
}