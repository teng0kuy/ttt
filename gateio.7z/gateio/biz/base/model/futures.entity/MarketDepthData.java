package com.gateio.biz.base.model.futures.entity;

import androidx.camera.video.AudioStats;
import com.alipay.mobile.security.bio.utils.HanziToPinyin;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;

/* loaded from: classes4.dex */
public class MarketDepthData {
    private String USDTCount;
    private String USDTNumber;
    private Double count = Double.valueOf(AudioStats.AUDIO_AMPLITUDE_NONE);
    private boolean dotVisible;
    private String id;
    private String lastIndexPrice;
    private int moreWidth;
    private String number;
    private String price;
    private String showAmount;
    private String showPrice;
    private int width;

    public Double getCount() {
        Double d10 = this.count;
        return Double.valueOf(d10 == null ? AudioStats.AUDIO_AMPLITUDE_NONE : d10.doubleValue());
    }

    public String getId() {
        return this.id;
    }

    public String getLastIndexPrice() {
        return this.lastIndexPrice;
    }

    public int getMoreWidth() {
        return this.moreWidth;
    }

    public String getNumber() {
        return this.number;
    }

    public String getPrice() {
        return this.price;
    }

    public String getShowAmount() {
        return this.showAmount;
    }

    public String getShowPrice() {
        return this.showPrice;
    }

    public String getStrId() {
        StringBuilder sb;
        String str;
        String str2 = this.id;
        if (str2 == null || str2.trim().length() == 1) {
            sb = new StringBuilder();
            sb.append(HanziToPinyin.Token.SEPARATOR);
            sb.append(this.id);
            str = "   ";
        } else {
            sb = new StringBuilder();
            sb.append(this.id);
            str = "  ";
        }
        sb.append(str);
        return sb.toString();
    }

    public String getUSDTCount() {
        return this.USDTCount;
    }

    public String getUSDTNumber() {
        return this.USDTNumber;
    }

    public int getWidth() {
        return this.width;
    }

    public boolean isDotVisible() {
        return this.dotVisible;
    }

    public void setCount(Double d10) {
        this.count = d10;
    }

    public void setDotVisible(boolean z10) {
        this.dotVisible = z10;
    }

    public void setId(String str) {
        this.id = str;
    }

    public void setLastIndexPrice(String str) {
        this.lastIndexPrice = str;
    }

    public void setMoreWidth(int i10) {
        this.moreWidth = i10;
    }

    public void setNumber(String str) {
        this.number = str;
    }

    public void setPrice(String str) {
        this.price = str;
    }

    public void setShowAmount(String str) {
        this.showAmount = str;
    }

    public void setShowPrice(String str) {
        this.showPrice = str;
    }

    public void setUSDTCount(String str) {
        this.USDTCount = str;
    }

    public void setUSDTNumber(String str) {
        this.USDTNumber = str;
    }

    public void setWidth(int i10) {
        this.width = i10;
    }

    public String toString() {
        return "MarketDepthData{id='" + this.id + "', number='" + this.number + "', price='" + this.price + "', width=" + this.width + ", count=" + this.count + AbstractJsonLexerKt.END_OBJ;
    }
}