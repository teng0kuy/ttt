package com.gateio.biz.base.model.futures.entity;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes4.dex */
public class JumpEnity implements Parcelable {
    public static final Parcelable.Creator<JumpEnity> CREATOR = new Parcelable.Creator<JumpEnity>() { // from class: com.gateio.biz.base.model.futures.entity.JumpEnity.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public JumpEnity createFromParcel(Parcel parcel) {
            return new JumpEnity(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public JumpEnity[] newArray(int i10) {
            return new JumpEnity[i10];
        }
    };
    private String avatar;
    private String canShare;
    private String code;
    private String content;
    private String contract;
    private int count;
    private String currencyType;
    private String exchangeType;
    private String imageUrl;
    private int imgRes;
    private int index;
    private boolean isDex;
    private boolean isHot;
    private String is_testnet;
    private String mId;
    private String needLogin;
    private String nickname;
    private boolean oval_notice;
    private String skipType;
    private int tier;
    private String timid;
    private String title;
    private String type;
    private String url;

    public JumpEnity() {
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    protected JumpEnity(Parcel parcel) {
        this.index = parcel.readInt();
        this.skipType = parcel.readString();
        this.code = parcel.readString();
        this.url = parcel.readString();
        this.title = parcel.readString();
        this.imgRes = parcel.readInt();
        this.currencyType = parcel.readString();
        this.exchangeType = parcel.readString();
        this.contract = parcel.readString();
        this.is_testnet = parcel.readString();
        this.imageUrl = parcel.readString();
        this.needLogin = parcel.readString();
        this.canShare = parcel.readString();
        this.content = parcel.readString();
        this.type = parcel.readString();
        this.avatar = parcel.readString();
        this.tier = parcel.readInt();
        this.nickname = parcel.readString();
        this.timid = parcel.readString();
        this.mId = parcel.readString();
        this.isHot = parcel.readByte() != 0;
        this.oval_notice = parcel.readByte() != 0;
        this.count = parcel.readInt();
    }

    public String getAvatar() {
        return this.avatar;
    }

    public String getCanShare() {
        return this.canShare;
    }

    public String getCode() {
        return this.code;
    }

    public String getContent() {
        return this.content;
    }

    public String getContract() {
        return this.contract;
    }

    public int getCount() {
        return this.count;
    }

    public String getCurrencyType() {
        return this.currencyType;
    }

    public String getExchangeType() {
        return this.exchangeType;
    }

    public String getImageUrl() {
        return this.imageUrl;
    }

    public int getImgRes() {
        return this.imgRes;
    }

    public int getIndex() {
        return this.index;
    }

    public String getIs_testnet() {
        return this.is_testnet;
    }

    public String getNeedLogin() {
        return this.needLogin;
    }

    public String getNickname() {
        return this.nickname;
    }

    public String getSkipType() {
        return this.skipType;
    }

    public int getTier() {
        return this.tier;
    }

    public String getTimid() {
        return this.timid;
    }

    public String getTitle() {
        return this.title;
    }

    public String getType() {
        return this.type;
    }

    public String getUrl() {
        return this.url;
    }

    public String getmId() {
        return this.mId;
    }

    public boolean isDex() {
        return this.isDex;
    }

    public boolean isHot() {
        return this.isHot;
    }

    public boolean isOval_notice() {
        return this.oval_notice;
    }

    public JumpEnity needLogin(String str) {
        this.needLogin = str;
        return this;
    }

    public void setAvatar(String str) {
        this.avatar = str;
    }

    public void setCanShare(String str) {
        this.canShare = str;
    }

    public JumpEnity setCode(String str) {
        this.code = str;
        return this;
    }

    public void setContent(String str) {
        this.content = str;
    }

    public JumpEnity setContract(String str) {
        this.contract = str;
        return this;
    }

    public JumpEnity setCurrencyType(String str) {
        this.currencyType = str;
        return this;
    }

    public JumpEnity setDex(boolean z10) {
        this.isDex = z10;
        return this;
    }

    public JumpEnity setExchangeType(String str) {
        this.exchangeType = str;
        return this;
    }

    public JumpEnity setHot(boolean z10) {
        this.isHot = z10;
        return this;
    }

    public JumpEnity setImageUrl(String str) {
        this.imageUrl = str;
        return this;
    }

    public JumpEnity setImgRes(int i10) {
        this.imgRes = i10;
        return this;
    }

    public JumpEnity setIndex(int i10) {
        this.index = i10;
        return this;
    }

    public JumpEnity setIs_testnet(String str) {
        this.is_testnet = str;
        return this;
    }

    public void setNeedLogin(String str) {
        this.needLogin = str;
    }

    public void setNickname(String str) {
        this.nickname = str;
    }

    public JumpEnity setOval_notice(boolean z10) {
        this.oval_notice = z10;
        return this;
    }

    public JumpEnity setShow_count(int i10) {
        this.count = i10;
        return this;
    }

    public void setSkipType(String str) {
        this.skipType = str;
    }

    public void setTier(int i10) {
        this.tier = i10;
    }

    public void setTimid(String str) {
        this.timid = str;
    }

    public JumpEnity setTitle(String str) {
        this.title = str;
        return this;
    }

    public void setType(String str) {
        this.type = str;
    }

    public JumpEnity setUrl(String str) {
        this.url = str;
        return this;
    }

    public void setmId(String str) {
        this.mId = str;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.index);
        parcel.writeString(this.skipType);
        parcel.writeString(this.code);
        parcel.writeString(this.url);
        parcel.writeString(this.title);
        parcel.writeInt(this.imgRes);
        parcel.writeString(this.currencyType);
        parcel.writeString(this.exchangeType);
        parcel.writeString(this.contract);
        parcel.writeString(this.is_testnet);
        parcel.writeString(this.imageUrl);
        parcel.writeString(this.needLogin);
        parcel.writeString(this.canShare);
        parcel.writeString(this.content);
        parcel.writeString(this.type);
        parcel.writeString(this.avatar);
        parcel.writeInt(this.tier);
        parcel.writeString(this.nickname);
        parcel.writeString(this.timid);
        parcel.writeString(this.mId);
        parcel.writeByte(this.isHot ? (byte) 1 : (byte) 0);
        parcel.writeByte(this.oval_notice ? (byte) 1 : (byte) 0);
        parcel.writeInt(this.count);
    }
}