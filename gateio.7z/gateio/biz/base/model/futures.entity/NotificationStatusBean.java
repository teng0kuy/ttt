package com.gateio.biz.base.model.futures.entity;

import com.gateio.common.tool.StringUtils;

/* loaded from: classes4.dex */
public class NotificationStatusBean {
    public static String STATUS_OPEN = "1";
    private String activity_status;
    private String auto_open_status;
    private String c2c_status;
    private String future_status;
    private String futures_funding_rate;
    private String futures_profit_loss;
    private String large_transfers_status;
    private String live_status;
    private String margin_status;
    private String market_status;
    private String personal_status;
    private String platform_status;
    private String rise_slump_status;
    private String unified_account_switch;

    public String getActivity_status() {
        return this.activity_status;
    }

    public String getAuto_open_status() {
        return this.auto_open_status;
    }

    public String getC2c_status() {
        return this.c2c_status;
    }

    public String getFuture_status() {
        return this.future_status;
    }

    public String getFutures_funding_rate() {
        return this.futures_funding_rate;
    }

    public String getFutures_profit_loss() {
        return this.futures_profit_loss;
    }

    public String getLarge_transfers_status() {
        return this.large_transfers_status;
    }

    public String getLive_status() {
        return this.live_status;
    }

    public String getMargin_status() {
        return this.margin_status;
    }

    public String getMarket_status() {
        return this.market_status;
    }

    public String getPersonal_status() {
        return this.personal_status;
    }

    public String getPlatform_status() {
        return this.platform_status;
    }

    public String getRise_slump_status() {
        return this.rise_slump_status;
    }

    public String getUnified_account_switch() {
        return this.unified_account_switch;
    }

    public boolean isActivityEnabled() {
        return StringUtils.equals(STATUS_OPEN, this.activity_status);
    }

    public boolean isBzBdEnabled() {
        return StringUtils.equals(STATUS_OPEN, this.rise_slump_status);
    }

    public boolean isC2cEnabled() {
        return StringUtils.equals(STATUS_OPEN, this.c2c_status);
    }

    public boolean isChainChangeEnabled() {
        return StringUtils.equals(STATUS_OPEN, this.large_transfers_status);
    }

    public boolean isFutureEnabled() {
        return StringUtils.equals(STATUS_OPEN, this.future_status);
    }

    public boolean isFutureFundingRateEnabled() {
        return StringUtils.equals(STATUS_OPEN, this.futures_funding_rate);
    }

    public boolean isFutureProfitLossEnabled() {
        return StringUtils.equals(STATUS_OPEN, this.futures_profit_loss);
    }

    public boolean isLiveStatus() {
        return StringUtils.equals(STATUS_OPEN, this.live_status);
    }

    public boolean isMarginEnabled() {
        return StringUtils.equals(STATUS_OPEN, this.margin_status);
    }

    public boolean isMarketEnabled() {
        return StringUtils.equals(STATUS_OPEN, this.market_status);
    }

    public boolean isNoticeEnabled() {
        return StringUtils.equals(STATUS_OPEN, this.platform_status);
    }

    public boolean isPersonalEnabled() {
        return StringUtils.equals(STATUS_OPEN, this.personal_status);
    }

    public boolean isUnifiedAccount() {
        return StringUtils.equals(STATUS_OPEN, this.unified_account_switch);
    }

    public void setActivity_status(String str) {
        this.activity_status = str;
    }

    public void setAuto_open_status(String str) {
        this.auto_open_status = str;
    }

    public void setC2c_status(String str) {
        this.c2c_status = str;
    }

    public void setFuture_status(String str) {
        this.future_status = str;
    }

    public void setFutures_funding_rate(String str) {
        this.futures_funding_rate = str;
    }

    public void setFutures_profit_loss(String str) {
        this.futures_profit_loss = str;
    }

    public void setLarge_transfers_status(String str) {
        this.large_transfers_status = str;
    }

    public void setLive_status(String str) {
        this.live_status = str;
    }

    public void setMargin_status(String str) {
        this.margin_status = str;
    }

    public void setMarket_status(String str) {
        this.market_status = str;
    }

    public void setPersonal_status(String str) {
        this.personal_status = str;
    }

    public void setPlatform_status(String str) {
        this.platform_status = str;
    }

    public void setRise_slump_status(String str) {
        this.rise_slump_status = str;
    }

    public void setUnified_account_switch(String str) {
        this.unified_account_switch = str;
    }
}