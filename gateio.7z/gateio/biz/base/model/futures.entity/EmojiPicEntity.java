package com.gateio.biz.base.model.futures.entity;

import android.os.Parcel;
import android.os.Parcelable;
import com.gateio.common.tool.StringUtils;
import com.gateio.keyboard.data.Emoticon;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;

/* loaded from: classes4.dex */
public class EmojiPicEntity implements Parcelable {
    public static final Parcelable.Creator<EmojiPicEntity> CREATOR = new Parcelable.Creator<EmojiPicEntity>() { // from class: com.gateio.biz.base.model.futures.entity.EmojiPicEntity.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public EmojiPicEntity createFromParcel(Parcel parcel) {
            return new EmojiPicEntity(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public EmojiPicEntity[] newArray(int i10) {
            return new EmojiPicEntity[i10];
        }
    };
    public static final String TYPE_GATE = "gate";
    public static final String TYPE_USER = "user";
    public static final String TYPE_VIDEO = "vedio";
    private boolean isNeedUpload;
    private String key;
    private String localPath;
    private int resId;
    private int sort;
    private String thumbnail_url;
    private String type;
    private String url;

    public static class UploadEntity implements Parcelable {
        public static final Parcelable.Creator<UploadEntity> CREATOR = new Parcelable.Creator<UploadEntity>() { // from class: com.gateio.biz.base.model.futures.entity.EmojiPicEntity.UploadEntity.1
            /* JADX WARN: Can't rename method to resolve collision */
            @Override // android.os.Parcelable.Creator
            public UploadEntity createFromParcel(Parcel parcel) {
                return new UploadEntity(parcel);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // android.os.Parcelable.Creator
            public UploadEntity[] newArray(int i10) {
                return new UploadEntity[i10];
            }
        };
        private int sort;
        private String type;
        private String url;

        public UploadEntity() {
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        protected UploadEntity(Parcel parcel) {
            this.type = parcel.readString();
            this.url = parcel.readString();
            this.sort = parcel.readInt();
        }

        public int getSort() {
            return this.sort;
        }

        public String getType() {
            return this.type;
        }

        public String getUrl() {
            return this.url;
        }

        public void setSort(int i10) {
            this.sort = i10;
        }

        public void setType(String str) {
            this.type = str;
        }

        public void setUrl(String str) {
            this.url = str;
        }

        public String toString() {
            return "UploadEntity{type='" + this.type + "', url='" + this.url + "', sort=" + this.sort + AbstractJsonLexerKt.END_OBJ;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i10) {
            parcel.writeString(this.type);
            parcel.writeString(this.url);
            parcel.writeInt(this.sort);
        }
    }

    public EmojiPicEntity() {
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    protected EmojiPicEntity(Parcel parcel) {
        this.type = parcel.readString();
        this.url = parcel.readString();
        this.thumbnail_url = parcel.readString();
        this.sort = parcel.readInt();
        this.key = parcel.readString();
        this.isNeedUpload = parcel.readByte() != 0;
        this.localPath = parcel.readString();
        this.resId = parcel.readInt();
    }

    public UploadEntity buildEmojiEntity(EmojiPicEntity emojiPicEntity, int i10) {
        UploadEntity uploadEntity = new UploadEntity();
        uploadEntity.setSort(i10);
        uploadEntity.setType(emojiPicEntity.getType());
        uploadEntity.setUrl(emojiPicEntity.getUrl());
        return uploadEntity;
    }

    public EmojiPicEntity buildGateEmoje(Emoticon emoticon) {
        EmojiPicEntity emojiPicEntity = new EmojiPicEntity();
        emojiPicEntity.setType(TYPE_GATE);
        emojiPicEntity.setUrl(String.valueOf(emoticon.getCode()));
        return emojiPicEntity;
    }

    public EmojiPicEntity buildRemoteNative(int i10) {
        EmojiPicEntity emojiPicEntity = new EmojiPicEntity();
        emojiPicEntity.setType(TYPE_USER);
        emojiPicEntity.setResId(i10);
        return emojiPicEntity;
    }

    public EmojiPicEntity buildRemotePathEmoje(String str, String str2) {
        EmojiPicEntity emojiPicEntity = new EmojiPicEntity();
        emojiPicEntity.setType(str2);
        emojiPicEntity.setUrl(str);
        emojiPicEntity.setNeedUpload(true);
        return emojiPicEntity;
    }

    public UploadEntity buildUploadEntity(String str, int i10, String str2) {
        UploadEntity uploadEntity = new UploadEntity();
        uploadEntity.setSort(i10);
        uploadEntity.setType(str);
        uploadEntity.setUrl(str2);
        return uploadEntity;
    }

    public EmojiPicEntity buildVideo(String str, String str2) {
        EmojiPicEntity emojiPicEntity = new EmojiPicEntity();
        emojiPicEntity.setType(TYPE_VIDEO);
        emojiPicEntity.setUrl(str);
        emojiPicEntity.setNeedUpload(true);
        emojiPicEntity.setKey(str2);
        return emojiPicEntity;
    }

    public String getKey() {
        return this.key;
    }

    public String getLocalPath() {
        return this.localPath;
    }

    public int getResId() {
        return this.resId;
    }

    public int getSort() {
        return this.sort;
    }

    public String getThumbnailUrl() {
        String str = this.thumbnail_url;
        return (str == null || str.length() == 0) ? this.url : this.thumbnail_url;
    }

    public String getThumbnail_url() {
        return this.thumbnail_url;
    }

    public String getType() {
        return this.type;
    }

    public String getUrl() {
        return this.url;
    }

    public boolean isNeedUpload() {
        return this.isNeedUpload;
    }

    public void setKey(String str) {
        this.key = str;
    }

    public void setLocalPath(String str) {
        this.localPath = str;
    }

    public void setNeedUpload(boolean z10) {
        this.isNeedUpload = z10;
    }

    public void setResId(int i10) {
        this.resId = i10;
    }

    public void setSort(int i10) {
        this.sort = i10;
    }

    public void setThumbnail_url(String str) {
        this.thumbnail_url = str;
    }

    public void setType(String str) {
        this.type = str;
    }

    public void setUrl(String str) {
        this.url = str;
    }

    public String toString() {
        return "EmojiPicEntity{type='" + this.type + "', url='" + this.url + "', thumbnail_url='" + this.thumbnail_url + "', sort=" + this.sort + ", key='" + this.key + "', isNeedUpload=" + this.isNeedUpload + ", localPath='" + this.localPath + "', resId=" + this.resId + AbstractJsonLexerKt.END_OBJ;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeString(this.type);
        parcel.writeString(this.url);
        parcel.writeString(this.thumbnail_url);
        parcel.writeInt(this.sort);
        parcel.writeString(this.key);
        parcel.writeByte(this.isNeedUpload ? (byte) 1 : (byte) 0);
        parcel.writeString(this.localPath);
        parcel.writeInt(this.resId);
    }

    public boolean isAdd() {
        return StringUtils.isEmpty(getUrl());
    }

    public boolean isGate() {
        return StringUtils.trimToEmpty(getType()).equals(TYPE_GATE);
    }

    public boolean isRemoteImg() {
        return StringUtils.trimToEmpty(getType()).equals(TYPE_USER);
    }

    public boolean isVideo() {
        return StringUtils.trimToEmpty(getType()).equals(TYPE_VIDEO);
    }

    public void readFromParcel(Parcel parcel) {
        boolean z10;
        this.type = parcel.readString();
        this.url = parcel.readString();
        this.thumbnail_url = parcel.readString();
        this.sort = parcel.readInt();
        this.key = parcel.readString();
        if (parcel.readByte() != 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        this.isNeedUpload = z10;
        this.localPath = parcel.readString();
        this.resId = parcel.readInt();
    }
}