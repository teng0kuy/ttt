package com.gateio.biz.base.model.futures.entity;

/* loaded from: classes4.dex */
public class DepthCountPrice {
    private String depthCount;
    private String depthPrice;
    private int width;

    public DepthCountPrice() {
    }

    public DepthCountPrice(String str, String str2, int i10) {
        this.depthCount = str;
        this.depthPrice = str2;
        this.width = i10;
    }

    public String getDepthCount() {
        return this.depthCount;
    }

    public String getDepthPrice() {
        return this.depthPrice;
    }

    public int getWidth() {
        return this.width;
    }

    public void setDepthCount(String str) {
        this.depthCount = str;
    }

    public void setDepthPrice(String str) {
        this.depthPrice = str;
    }

    public void setWidth(int i10) {
        this.width = i10;
    }
}