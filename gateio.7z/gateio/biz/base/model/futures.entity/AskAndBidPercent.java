package com.gateio.biz.base.model.futures.entity;

/* loaded from: classes4.dex */
public class AskAndBidPercent {
    private String ask_percent;
    private String bid_percent;
    private String loan_situation_ask;
    private String loan_situation_bid;

    public String getAsk_percent() {
        return this.ask_percent;
    }

    public String getBid_percent() {
        return this.bid_percent;
    }

    public String getLoan_situation_ask() {
        return this.loan_situation_ask;
    }

    public String getLoan_situation_bid() {
        return this.loan_situation_bid;
    }

    public void setAsk_percent(String str) {
        this.ask_percent = str;
    }

    public void setBid_percent(String str) {
        this.bid_percent = str;
    }

    public void setLoan_situation_ask(String str) {
        this.loan_situation_ask = str;
    }

    public void setLoan_situation_bid(String str) {
        this.loan_situation_bid = str;
    }
}