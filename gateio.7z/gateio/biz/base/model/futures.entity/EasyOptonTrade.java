package com.gateio.biz.base.model.futures.entity;

import com.alipay.mobile.security.bio.utils.HanziToPinyin;
import com.gateio.common.tool.StringUtils;

/* loaded from: classes4.dex */
public class EasyOptonTrade {
    private String contract;
    private String create_time;
    private String id;
    private String order;
    private String order_id;
    private String price;
    private String role;
    private int size;
    private String symbol;
    private String time;

    public String getContract() {
        String str;
        StringBuilder sb = new StringBuilder();
        sb.append(StringUtils.trimToEmpty(this.contract));
        if (StringUtils.isEmpty(this.symbol)) {
            str = "";
        } else {
            str = HanziToPinyin.Token.SEPARATOR + this.symbol;
        }
        sb.append(str);
        return sb.toString();
    }

    public String getCreate_time() {
        return this.create_time;
    }

    public String getId() {
        return this.id;
    }

    public String getOrder() {
        return this.order;
    }

    public String getOrder_id() {
        return this.order_id;
    }

    public String getPrice() {
        return this.price;
    }

    public String getRole() {
        return this.role;
    }

    public int getSize() {
        return this.size;
    }

    public String getSymbol() {
        return this.symbol;
    }

    public String getTime() {
        return this.time;
    }

    public boolean isAsk() {
        return this.size < 0;
    }

    public boolean isCContract() {
        try {
            return StringUtils.trimToEmpty(this.contract).split("-")[r0.length - 1].equalsIgnoreCase("C");
        } catch (Exception e10) {
            e10.printStackTrace();
            return false;
        }
    }

    public boolean isPContract() {
        try {
            return StringUtils.trimToEmpty(this.contract).split("-")[r0.length - 1].equalsIgnoreCase("P");
        } catch (Exception e10) {
            e10.printStackTrace();
            return false;
        }
    }

    public void setContract(String str) {
        this.contract = str;
    }

    public void setCreate_time(String str) {
        this.create_time = str;
    }

    public void setId(String str) {
        this.id = str;
    }

    public void setOrder(String str) {
        this.order = str;
    }

    public void setOrder_id(String str) {
        this.order_id = str;
    }

    public void setPrice(String str) {
        this.price = str;
    }

    public void setRole(String str) {
        this.role = str;
    }

    public void setSize(int i10) {
        this.size = i10;
    }

    public void setSymbol(String str) {
        this.symbol = str;
    }

    public void setTime(String str) {
        this.time = str;
    }
}