package com.gateio.biz.base.model.futures.entity;

import com.gateio.common.tool.StringUtils;

/* loaded from: classes4.dex */
public class WcTcEntity {
    private String image;
    private String name;
    private String show;
    private String url;

    public String getImage() {
        return this.image;
    }

    public String getName() {
        return this.name;
    }

    public String getShow() {
        return this.show;
    }

    public String getUrl() {
        return this.url;
    }

    public boolean isShow() {
        return StringUtils.equals("1", this.show);
    }

    public void setImage(String str) {
        this.image = str;
    }

    public void setName(String str) {
        this.name = str;
    }

    public void setShow(String str) {
        this.show = str;
    }

    public void setUrl(String str) {
        this.url = str;
    }
}