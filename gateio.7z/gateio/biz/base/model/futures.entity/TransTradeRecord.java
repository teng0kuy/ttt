package com.gateio.biz.base.model.futures.entity;

import com.gateio.biz.base.model.PilotTransTradeRecord;
import com.gateio.common.tool.StringUtils;
import java.util.Objects;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;

/* loaded from: classes4.dex */
public class TransTradeRecord {
    private String amount;
    private String currency_type;
    private String exchange_type;
    private String fee_key;
    private String fee_value;
    private String order_id;
    private String price;
    private String role;
    private String time_unix;
    private String total;
    private String trade_id;
    private String type;

    public static TransTradeRecord covert(PilotTransTradeRecord pilotTransTradeRecord) {
        TransTradeRecord transTradeRecord = new TransTradeRecord();
        transTradeRecord.amount = pilotTransTradeRecord.getAmount();
        transTradeRecord.price = pilotTransTradeRecord.getPrice();
        transTradeRecord.role = pilotTransTradeRecord.getRole();
        transTradeRecord.type = Objects.equals(pilotTransTradeRecord.getSide(), "buy") ? "1" : "0";
        transTradeRecord.time_unix = String.valueOf(pilotTransTradeRecord.getDeal_time() / 1000);
        transTradeRecord.setTradeID(pilotTransTradeRecord.getTrade_id());
        return transTradeRecord;
    }

    public String getAmount() {
        return this.amount;
    }

    public String getCurrencyType() {
        return this.currency_type;
    }

    public String getExchangeType() {
        return this.exchange_type;
    }

    public String getFee_key() {
        return this.fee_key;
    }

    public String getFee_value() {
        return this.fee_value;
    }

    public String getOrderNumber() {
        return this.order_id;
    }

    public String getPrice() {
        return this.price;
    }

    public String getRole() {
        return this.role;
    }

    public String getRoleStr() {
        return StringUtils.equals("1", this.role) ? "Maker" : StringUtils.equals("2", this.role) ? "Taker" : "";
    }

    public String getTime_unix() {
        return this.time_unix;
    }

    public String getTotal() {
        return this.total;
    }

    public String getTradeID() {
        return this.trade_id;
    }

    public String getType() {
        return this.type;
    }

    public boolean isBuy() {
        return StringUtils.equals("1", this.type);
    }

    public void setAmount(String str) {
        this.amount = str;
    }

    public void setCurrencyType(String str) {
        this.currency_type = str;
    }

    public void setExchangeType(String str) {
        this.exchange_type = str;
    }

    public void setFee_key(String str) {
        this.fee_key = str;
    }

    public void setFee_value(String str) {
        this.fee_value = str;
    }

    public void setOrderNumber(String str) {
        this.order_id = str;
    }

    public void setPrice(String str) {
        this.price = str;
    }

    public void setRole(String str) {
        this.role = str;
    }

    public void setTime_unix(String str) {
        this.time_unix = str;
    }

    public void setTotal(String str) {
        this.total = str;
    }

    public void setTradeID(String str) {
        this.trade_id = str;
    }

    public void setType(String str) {
        this.type = str;
    }

    public String toString() {
        return "TransTradeRecord{trade_id='" + this.trade_id + "', order_id='" + this.order_id + "', type='" + this.type + "', price='" + this.price + "', amount='" + this.amount + "', total='" + this.total + "', time_unix='" + this.time_unix + "', currency_type='" + this.currency_type + "', exchange_type='" + this.exchange_type + "', role='" + this.role + "', fee_key='" + this.fee_key + "', fee_value='" + this.fee_value + '\'' + AbstractJsonLexerKt.END_OBJ;
    }
}