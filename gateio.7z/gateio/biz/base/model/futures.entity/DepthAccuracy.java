package com.gateio.biz.base.model.futures.entity;

import kotlinx.serialization.json.internal.AbstractJsonLexerKt;

/* loaded from: classes4.dex */
public class DepthAccuracy {
    private String accurary;
    private int decimal;

    public String getAccurary() {
        return this.accurary;
    }

    public int getDecimal() {
        return this.decimal;
    }

    public void setAccurary(String str) {
        this.accurary = str;
    }

    public void setDecimal(int i10) {
        this.decimal = i10;
    }

    public String toString() {
        return "DepthAccuracy{accurary='" + this.accurary + "', decimal=" + this.decimal + AbstractJsonLexerKt.END_OBJ;
    }

    public DepthAccuracy(String str, int i10) {
        this.accurary = str;
        this.decimal = i10;
    }
}