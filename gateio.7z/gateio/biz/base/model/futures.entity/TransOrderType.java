package com.gateio.biz.base.model.futures.entity;

/* loaded from: classes4.dex */
public class TransOrderType {
    private String name;
    private int position;

    public String getName() {
        return this.name;
    }

    public int getPosition() {
        return this.position;
    }

    public void setName(String str) {
        this.name = str;
    }

    public void setPosition(int i10) {
        this.position = i10;
    }
}