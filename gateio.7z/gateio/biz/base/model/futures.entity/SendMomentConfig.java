package com.gateio.biz.base.model.futures.entity;

/* loaded from: classes4.dex */
public class SendMomentConfig {
    private int is_allow_image;
    private int is_allow_video;
    private int limit_image_min_balance;

    public int getIs_allow_image() {
        return this.is_allow_image;
    }

    public int getIs_allow_video() {
        return this.is_allow_video;
    }

    public int getLimit_image_min_balance() {
        return this.limit_image_min_balance;
    }

    public void setIs_allow_image(int i10) {
        this.is_allow_image = i10;
    }

    public void setIs_allow_video(int i10) {
        this.is_allow_video = i10;
    }

    public void setLimit_image_min_balance(int i10) {
        this.limit_image_min_balance = i10;
    }
}