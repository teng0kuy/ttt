package com.gateio.biz.base.model.futures.entity;

import android.view.View;

/* loaded from: classes4.dex */
public class TipsPopBean {
    private int horizontalGravity;
    private int popOffsetX;
    private int radiusW;
    private int strokeWidth;
    private String text;
    private int verticalGravity;
    private View view;

    public TipsPopBean(View view, int i10, int i11, String str) {
        this.view = view;
        this.verticalGravity = i10;
        this.horizontalGravity = i11;
        this.text = str;
    }

    public int getHorizontalGravity() {
        return this.horizontalGravity;
    }

    public int getPopOffsetX() {
        return this.popOffsetX;
    }

    public int getRadiusW() {
        return this.radiusW;
    }

    public int getStrokeWidth() {
        return this.strokeWidth;
    }

    public String getText() {
        return this.text;
    }

    public int getVerticalGravity() {
        return this.verticalGravity;
    }

    public View getView() {
        return this.view;
    }

    public void setHorizontalGravity(int i10) {
        this.horizontalGravity = i10;
    }

    public void setPopOffsetX(int i10) {
        this.popOffsetX = i10;
    }

    public void setRadiusW(int i10) {
        this.radiusW = i10;
    }

    public void setStrokeWidth(int i10) {
        this.strokeWidth = i10;
    }

    public void setText(String str) {
        this.text = str;
    }

    public void setVerticalGravity(int i10) {
        this.verticalGravity = i10;
    }

    public void setView(View view) {
        this.view = view;
    }

    public TipsPopBean(View view, int i10, int i11, String str, int i12) {
        this.view = view;
        this.verticalGravity = i10;
        this.horizontalGravity = i11;
        this.text = str;
        this.popOffsetX = i12;
    }

    public TipsPopBean(View view, int i10, int i11, int i12, int i13, String str) {
        this.view = view;
        this.verticalGravity = i10;
        this.horizontalGravity = i11;
        this.radiusW = i12;
        this.strokeWidth = i13;
        this.text = str;
    }
}