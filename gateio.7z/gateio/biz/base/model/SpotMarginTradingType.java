package com.gateio.biz.base.model;

import com.gate_sdk.web3_wallet.DeFiConstants;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: SpotMarginTradingType.kt */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\b\t\b\u0086\u0081\u0002\u0018\u0000 \u000b2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u000bB\u000f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\n¨\u0006\f"}, d2 = {"Lcom/gateio/biz/base/model/SpotMarginTradingType;", "", "type", "", "(Ljava/lang/String;ILjava/lang/String;)V", DeFiConstants.GetType, "()Ljava/lang/String;", "CLASSIC", "MULTI_CURRENCY", "PORTFOLIO", "SINGLE_CURRENCY", "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class SpotMarginTradingType {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ SpotMarginTradingType[] $VALUES;

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE;

    @NotNull
    private final String type;
    public static final SpotMarginTradingType CLASSIC = new SpotMarginTradingType("CLASSIC", 0, "classic");
    public static final SpotMarginTradingType MULTI_CURRENCY = new SpotMarginTradingType("MULTI_CURRENCY", 1, "multi_currency");
    public static final SpotMarginTradingType PORTFOLIO = new SpotMarginTradingType("PORTFOLIO", 2, "portfolio");
    public static final SpotMarginTradingType SINGLE_CURRENCY = new SpotMarginTradingType("SINGLE_CURRENCY", 3, "single_currency");

    /* compiled from: SpotMarginTradingType.kt */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/base/model/SpotMarginTradingType$Companion;", "", "()V", "fromType", "Lcom/gateio/biz/base/model/SpotMarginTradingType;", "type", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nSpotMarginTradingType.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SpotMarginTradingType.kt\ncom/gateio/biz/base/model/SpotMarginTradingType$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,19:1\n1#2:20\n*E\n"})
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final SpotMarginTradingType fromType(@NotNull String type) {
            SpotMarginTradingType spotMarginTradingType;
            SpotMarginTradingType[] spotMarginTradingTypeArrValues = SpotMarginTradingType.values();
            int length = spotMarginTradingTypeArrValues.length;
            int i10 = 0;
            while (true) {
                if (i10 < length) {
                    spotMarginTradingType = spotMarginTradingTypeArrValues[i10];
                    if (Intrinsics.areEqual(spotMarginTradingType.getType(), type)) {
                        break;
                    }
                    i10++;
                } else {
                    spotMarginTradingType = null;
                    break;
                }
            }
            if (spotMarginTradingType == null) {
                return SpotMarginTradingType.PORTFOLIO;
            }
            return spotMarginTradingType;
        }
    }

    private static final /* synthetic */ SpotMarginTradingType[] $values() {
        return new SpotMarginTradingType[]{CLASSIC, MULTI_CURRENCY, PORTFOLIO, SINGLE_CURRENCY};
    }

    static {
        SpotMarginTradingType[] spotMarginTradingTypeArr$values = $values();
        $VALUES = spotMarginTradingTypeArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(spotMarginTradingTypeArr$values);
        INSTANCE = new Companion(null);
    }

    @NotNull
    public static EnumEntries<SpotMarginTradingType> getEntries() {
        return $ENTRIES;
    }

    public static SpotMarginTradingType valueOf(String str) {
        return (SpotMarginTradingType) Enum.valueOf(SpotMarginTradingType.class, str);
    }

    public static SpotMarginTradingType[] values() {
        return (SpotMarginTradingType[]) $VALUES.clone();
    }

    @NotNull
    public final String getType() {
        return this.type;
    }

    private SpotMarginTradingType(String str, int i10, String str2) {
        this.type = str2;
    }
}