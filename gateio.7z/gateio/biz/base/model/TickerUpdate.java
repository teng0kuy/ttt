package com.gateio.biz.base.model;

/* loaded from: classes4.dex */
public class TickerUpdate {
    private String baseVolume;
    private String change;
    private String close;
    private String high;
    private String last;
    private String low;
    private String open;
    private int period;
    private String quoteVolume;

    public String getBaseVolume() {
        return this.baseVolume;
    }

    public String getChange() {
        return this.change;
    }

    public String getClose() {
        return this.close;
    }

    public String getHigh() {
        return this.high;
    }

    public String getLast() {
        return this.last;
    }

    public String getLow() {
        return this.low;
    }

    public String getOpen() {
        return this.open;
    }

    public int getPeriod() {
        return this.period;
    }

    public String getQuoteVolume() {
        return this.quoteVolume;
    }

    public void setBaseVolume(String str) {
        this.baseVolume = str;
    }

    public void setChange(String str) {
        this.change = str;
    }

    public void setClose(String str) {
        this.close = str;
    }

    public void setHigh(String str) {
        this.high = str;
    }

    public void setLast(String str) {
        this.last = str;
    }

    public void setLow(String str) {
        this.low = str;
    }

    public void setOpen(String str) {
        this.open = str;
    }

    public void setPeriod(int i10) {
        this.period = i10;
    }

    public void setQuoteVolume(String str) {
        this.quoteVolume = str;
    }

    public String toString() {
        return "last " + getLast() + "close " + getClose();
    }
}