package com.gateio.biz.base.model.enums;

import com.gateio.biz.market.MarketFragment;
import com.sumsub.sns.internal.core.data.model.p;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: EnumMiniKLineType.kt */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\b\n\u0002\b\n\b\u0086\u0081\u0002\u0018\u0000 \f2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\fB\u000f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000b¨\u0006\r"}, d2 = {"Lcom/gateio/biz/base/model/enums/EnumMiniKLineType;", "", "value", "", "(Ljava/lang/String;II)V", "getValue", "()I", "SPOT", "CONTRACT", "PILOT", MarketFragment.TAB_ALPHA, p.f26646d, "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class EnumMiniKLineType {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ EnumMiniKLineType[] $VALUES;

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE;
    private final int value;
    public static final EnumMiniKLineType SPOT = new EnumMiniKLineType("SPOT", 0, 1);
    public static final EnumMiniKLineType CONTRACT = new EnumMiniKLineType("CONTRACT", 1, 2);
    public static final EnumMiniKLineType PILOT = new EnumMiniKLineType("PILOT", 2, 3);
    public static final EnumMiniKLineType ALPHA = new EnumMiniKLineType(MarketFragment.TAB_ALPHA, 3, 4);
    public static final EnumMiniKLineType OTHER = new EnumMiniKLineType(p.f26646d, 4, 0);

    /* compiled from: EnumMiniKLineType.kt */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0015\u0010\u0003\u001a\u00020\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006¢\u0006\u0002\u0010\u0007¨\u0006\b"}, d2 = {"Lcom/gateio/biz/base/model/enums/EnumMiniKLineType$Companion;", "", "()V", "fromValue", "Lcom/gateio/biz/base/model/enums/EnumMiniKLineType;", "value", "", "(Ljava/lang/Integer;)Lcom/gateio/biz/base/model/enums/EnumMiniKLineType;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nEnumMiniKLineType.kt\nKotlin\n*S Kotlin\n*F\n+ 1 EnumMiniKLineType.kt\ncom/gateio/biz/base/model/enums/EnumMiniKLineType$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,19:1\n1#2:20\n*E\n"})
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final EnumMiniKLineType fromValue(@Nullable Integer value) {
            EnumMiniKLineType next;
            boolean z10;
            Iterator<EnumMiniKLineType> it = EnumMiniKLineType.getEntries().iterator();
            while (true) {
                if (it.hasNext()) {
                    next = it.next();
                    int value2 = next.getValue();
                    if (value != null && value2 == value.intValue()) {
                        z10 = true;
                    } else {
                        z10 = false;
                    }
                    if (z10) {
                        break;
                    }
                } else {
                    next = null;
                    break;
                }
            }
            EnumMiniKLineType enumMiniKLineType = next;
            if (enumMiniKLineType == null) {
                return EnumMiniKLineType.OTHER;
            }
            return enumMiniKLineType;
        }
    }

    private static final /* synthetic */ EnumMiniKLineType[] $values() {
        return new EnumMiniKLineType[]{SPOT, CONTRACT, PILOT, ALPHA, OTHER};
    }

    static {
        EnumMiniKLineType[] enumMiniKLineTypeArr$values = $values();
        $VALUES = enumMiniKLineTypeArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(enumMiniKLineTypeArr$values);
        INSTANCE = new Companion(null);
    }

    @NotNull
    public static EnumEntries<EnumMiniKLineType> getEntries() {
        return $ENTRIES;
    }

    public static EnumMiniKLineType valueOf(String str) {
        return (EnumMiniKLineType) Enum.valueOf(EnumMiniKLineType.class, str);
    }

    public static EnumMiniKLineType[] values() {
        return (EnumMiniKLineType[]) $VALUES.clone();
    }

    public final int getValue() {
        return this.value;
    }

    private EnumMiniKLineType(String str, int i10, int i11) {
        this.value = i11;
    }
}