package com.gateio.biz.base.model;

/* loaded from: classes4.dex */
public class SocketPrice {
    public String change;
    public String price;

    public SocketPrice() {
    }

    public SocketPrice(String str, String str2) {
        this.price = str;
        this.change = str2;
    }
}