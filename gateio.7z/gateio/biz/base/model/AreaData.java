package com.gateio.biz.base.model;

import com.gateio.lib.storage.annotation.GTStorageClass;
import com.gateio.lib.storage.annotation.GTStorageGroup;
import com.gateio.lib.storage.protocol.IGTStorageObject;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.RealmClass;
import io.realm.com_gateio_biz_base_model_AreaDataRealmProxyInterface;
import io.realm.internal.RealmObjectProxy;

@GTStorageClass(group = GTStorageGroup.APP)
@RealmClass
/* loaded from: classes4.dex */
public class AreaData implements IGTStorageObject, com_gateio_biz_base_model_AreaDataRealmProxyInterface {

    @PrimaryKey
    private String id;
    private String name;
    private String parentId;

    @Override // io.realm.com_gateio_biz_base_model_AreaDataRealmProxyInterface
    public String realmGet$id() {
        return this.id;
    }

    @Override // io.realm.com_gateio_biz_base_model_AreaDataRealmProxyInterface
    public String realmGet$name() {
        return this.name;
    }

    @Override // io.realm.com_gateio_biz_base_model_AreaDataRealmProxyInterface
    public String realmGet$parentId() {
        return this.parentId;
    }

    @Override // io.realm.com_gateio_biz_base_model_AreaDataRealmProxyInterface
    public void realmSet$id(String str) {
        this.id = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_AreaDataRealmProxyInterface
    public void realmSet$name(String str) {
        this.name = str;
    }

    @Override // io.realm.com_gateio_biz_base_model_AreaDataRealmProxyInterface
    public void realmSet$parentId(String str) {
        this.parentId = str;
    }

    public String toString() {
        return "AreaData.id=" + realmGet$id() + " AreaData.name=" + realmGet$name() + " AreaData.parentId=" + realmGet$parentId() + " | ";
    }

    /* JADX WARN: Multi-variable type inference failed */
    public AreaData() {
        if (this instanceof RealmObjectProxy) {
            ((RealmObjectProxy) this).realm$injectObjectContext();
        }
    }

    public String getId() {
        return realmGet$id();
    }

    public String getName() {
        return realmGet$name();
    }

    public String getParentId() {
        return realmGet$parentId();
    }

    public void setId(String str) {
        realmSet$id(str);
    }

    public void setName(String str) {
        realmSet$name(str);
    }

    public void setParentId(String str) {
        realmSet$parentId(str);
    }
}