package com.gateio.biz.base.model.datafinder;

import androidx.media3.extractor.text.ttml.TtmlNode;
import com.gate_sdk.web3_wallet.DeFiConstants;
import com.gateio.biz.market.datafinder.MarketDataFinderConst;
import com.gateio.lib.datafinder.protocol.GTBaseFinderEvent;
import com.zoloz.webcontainer.env.H5Container;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: MarketTradeSearchResultClickEvent.kt */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\r\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0010B%\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0006\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0004¢\u0006\u0002\u0010\bJ\b\u0010\u000e\u001a\u00020\u0002H\u0016J\b\u0010\u000f\u001a\u00020\u0004H\u0016R\u0011\u0010\u0006\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0005\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\nR\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\nR\u0011\u0010\u0007\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\n¨\u0006\u0011"}, d2 = {"Lcom/gateio/biz/base/model/datafinder/TradeSearchResultClickEvent;", "Lcom/gateio/lib/datafinder/protocol/GTBaseFinderEvent;", "Lcom/gateio/biz/base/model/datafinder/TradeSearchResultClickEvent$TradePullDown;", "moduleSource", "", "exchangeName", "currencyName", "resultSource", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getCurrencyName", "()Ljava/lang/String;", "getExchangeName", "getModuleSource", "getResultSource", TtmlNode.TAG_BODY, DeFiConstants.EventName, "TradePullDown", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class TradeSearchResultClickEvent implements GTBaseFinderEvent<TradePullDown> {

    @NotNull
    private final String currencyName;

    @NotNull
    private final String exchangeName;

    @NotNull
    private final String moduleSource;

    @NotNull
    private final String resultSource;

    /* compiled from: MarketTradeSearchResultClickEvent.kt */
    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0014\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003¢\u0006\u0002\u0010\u0007J\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J1\u0010\u0016\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0017\u001a\u00020\u00182\b\u0010\u0019\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001a\u001a\u00020\u001bHÖ\u0001J\t\u0010\u001c\u001a\u00020\u0003HÖ\u0001R\u001a\u0010\u0005\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\b\u0010\t\"\u0004\b\n\u0010\u000bR\u001a\u0010\u0004\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\t\"\u0004\b\r\u0010\u000bR\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\t\"\u0004\b\u000f\u0010\u000bR\u001a\u0010\u0006\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\t\"\u0004\b\u0011\u0010\u000b¨\u0006\u001d"}, d2 = {"Lcom/gateio/biz/base/model/datafinder/TradeSearchResultClickEvent$TradePullDown;", "", "module_source", "", MarketDataFinderConst.EXCHANGE_NAME, MarketDataFinderConst.CURRENCY_NAME, MarketDataFinderConst.RESULT_SOURCE, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getCurrency_name", "()Ljava/lang/String;", "setCurrency_name", "(Ljava/lang/String;)V", "getExchange_name", "setExchange_name", "getModule_source", "setModule_source", "getResult_source", "setResult_source", "component1", "component2", "component3", "component4", H5Container.MENU_COPY, "equals", "", "other", "hashCode", "", "toString", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final /* data */ class TradePullDown {

        @NotNull
        private String currency_name;

        @NotNull
        private String exchange_name;

        @NotNull
        private String module_source;

        @NotNull
        private String result_source;

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof TradePullDown)) {
                return false;
            }
            TradePullDown tradePullDown = (TradePullDown) other;
            return Intrinsics.areEqual(this.module_source, tradePullDown.module_source) && Intrinsics.areEqual(this.exchange_name, tradePullDown.exchange_name) && Intrinsics.areEqual(this.currency_name, tradePullDown.currency_name) && Intrinsics.areEqual(this.result_source, tradePullDown.result_source);
        }

        public static /* synthetic */ TradePullDown copy$default(TradePullDown tradePullDown, String str, String str2, String str3, String str4, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                str = tradePullDown.module_source;
            }
            if ((i10 & 2) != 0) {
                str2 = tradePullDown.exchange_name;
            }
            if ((i10 & 4) != 0) {
                str3 = tradePullDown.currency_name;
            }
            if ((i10 & 8) != 0) {
                str4 = tradePullDown.result_source;
            }
            return tradePullDown.copy(str, str2, str3, str4);
        }

        @NotNull
        /* renamed from: component1, reason: from getter */
        public final String getModule_source() {
            return this.module_source;
        }

        @NotNull
        /* renamed from: component2, reason: from getter */
        public final String getExchange_name() {
            return this.exchange_name;
        }

        @NotNull
        /* renamed from: component3, reason: from getter */
        public final String getCurrency_name() {
            return this.currency_name;
        }

        @NotNull
        /* renamed from: component4, reason: from getter */
        public final String getResult_source() {
            return this.result_source;
        }

        @NotNull
        public final TradePullDown copy(@NotNull String module_source, @NotNull String exchange_name, @NotNull String currency_name, @NotNull String result_source) {
            return new TradePullDown(module_source, exchange_name, currency_name, result_source);
        }

        @NotNull
        public final String getCurrency_name() {
            return this.currency_name;
        }

        @NotNull
        public final String getExchange_name() {
            return this.exchange_name;
        }

        @NotNull
        public final String getModule_source() {
            return this.module_source;
        }

        @NotNull
        public final String getResult_source() {
            return this.result_source;
        }

        public int hashCode() {
            return (((((this.module_source.hashCode() * 31) + this.exchange_name.hashCode()) * 31) + this.currency_name.hashCode()) * 31) + this.result_source.hashCode();
        }

        public final void setCurrency_name(@NotNull String str) {
            this.currency_name = str;
        }

        public final void setExchange_name(@NotNull String str) {
            this.exchange_name = str;
        }

        public final void setModule_source(@NotNull String str) {
            this.module_source = str;
        }

        public final void setResult_source(@NotNull String str) {
            this.result_source = str;
        }

        @NotNull
        public String toString() {
            return "TradePullDown(module_source=" + this.module_source + ", exchange_name=" + this.exchange_name + ", currency_name=" + this.currency_name + ", result_source=" + this.result_source + ')';
        }

        public TradePullDown(@NotNull String str, @NotNull String str2, @NotNull String str3, @NotNull String str4) {
            this.module_source = str;
            this.exchange_name = str2;
            this.currency_name = str3;
            this.result_source = str4;
        }
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    @NotNull
    /* renamed from: body */
    public TradePullDown get$jsonObject() {
        return new TradePullDown(this.moduleSource, this.exchangeName, this.currencyName, this.resultSource);
    }

    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    @NotNull
    /* renamed from: eventName */
    public String getEventName() {
        return "trade_search_result_click";
    }

    @NotNull
    public final String getCurrencyName() {
        return this.currencyName;
    }

    @NotNull
    public final String getExchangeName() {
        return this.exchangeName;
    }

    @NotNull
    public final String getModuleSource() {
        return this.moduleSource;
    }

    @NotNull
    public final String getResultSource() {
        return this.resultSource;
    }

    public TradeSearchResultClickEvent(@NotNull String str, @NotNull String str2, @NotNull String str3, @NotNull String str4) {
        this.moduleSource = str;
        this.exchangeName = str2;
        this.currencyName = str3;
        this.resultSource = str4;
    }
}