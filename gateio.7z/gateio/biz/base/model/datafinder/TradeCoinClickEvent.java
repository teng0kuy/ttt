package com.gateio.biz.base.model.datafinder;

import com.gateio.lib.datafinder.protocol.GTBaseFinderEvent;

/* loaded from: classes4.dex */
public class TradeCoinClickEvent implements GTBaseFinderEvent<TradeCoin> {
    String currencyName;
    String exchangeName;
    String moduleSource;

    static class TradeCoin {
        String currency_name;
        String exchange_name;
        String module_source;

        public TradeCoin(String str, String str2, String str3) {
            this.exchange_name = str;
            this.currency_name = str2;
            this.module_source = str3;
        }
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    /* renamed from: body */
    public TradeCoin get$jsonObject() {
        return new TradeCoin(this.exchangeName, this.currencyName, this.moduleSource);
    }

    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    public String eventName() {
        return "trade_coin_click";
    }

    public TradeCoinClickEvent(String str, String str2, String str3) {
        this.exchangeName = str;
        this.currencyName = str2;
        this.moduleSource = str3;
    }
}