package com.gateio.biz.base.model.datafinder;

import androidx.annotation.NonNull;
import com.gateio.lib.datafinder.protocol.GTBaseFinderEvent;

/* loaded from: classes4.dex */
public class TransV1TradeMarginTradeOpenClickEvent implements GTBaseFinderEvent<TradeButton> {
    String buttonName;
    String errorMessage;
    String isSuccess;
    String pageKey;
    String tradeType;

    public TransV1TradeMarginTradeOpenClickEvent(String str, String str2, String str3, String str4) {
        this.buttonName = str;
        this.isSuccess = str2;
        this.tradeType = str3;
        this.errorMessage = str4;
    }

    static class TradeButton {
        String button_name;
        String error_message;
        String is_success;
        String page_key;
        String trade_type;

        public TradeButton(String str, String str2, String str3, String str4, String str5) {
            this.button_name = str;
            this.is_success = str2;
            this.trade_type = str3;
            this.error_message = str4;
            this.page_key = str5;
        }
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    /* renamed from: body */
    public TradeButton get$jsonObject() {
        return new TradeButton(this.buttonName, this.isSuccess, this.tradeType, this.errorMessage, this.pageKey);
    }

    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    @NonNull
    /* renamed from: eventName */
    public String getEventName() {
        return "trade_margin_trade_open";
    }

    public TransV1TradeMarginTradeOpenClickEvent(String str, String str2, String str3) {
        this.buttonName = str;
        this.isSuccess = str2;
        this.tradeType = str3;
    }

    public TransV1TradeMarginTradeOpenClickEvent(String str, String str2) {
        this.buttonName = str;
        this.tradeType = str2;
    }

    public TransV1TradeMarginTradeOpenClickEvent(String str) {
        this.pageKey = str;
    }
}