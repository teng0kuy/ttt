package com.gateio.biz.base.model.datafinder;

import androidx.media3.extractor.text.ttml.TtmlNode;
import com.gate_sdk.web3_wallet.DeFiConstants;
import com.gateio.lib.datafinder.protocol.GTBaseFinderEvent;
import com.zoloz.webcontainer.env.H5Container;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: TradeTradingClickEvent.kt */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\t\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\fB\u0015\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0002\u0010\u0006J\b\u0010\n\u001a\u00020\u0002H\u0016J\b\u0010\u000b\u001a\u00020\u0004H\u0016R\u0011\u0010\u0005\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\b¨\u0006\r"}, d2 = {"Lcom/gateio/biz/base/model/datafinder/TradeTradingClickEvent;", "Lcom/gateio/lib/datafinder/protocol/GTBaseFinderEvent;", "Lcom/gateio/biz/base/model/datafinder/TradeTradingClickEvent$TradeTrading;", "type", "", "buttonName", "(Ljava/lang/String;Ljava/lang/String;)V", "getButtonName", "()Ljava/lang/String;", DeFiConstants.GetType, TtmlNode.TAG_BODY, DeFiConstants.EventName, "TradeTrading", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class TradeTradingClickEvent implements GTBaseFinderEvent<TradeTrading> {

    @NotNull
    private final String buttonName;

    @NotNull
    private final String type;

    /* compiled from: TradeTradingClickEvent.kt */
    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\t\u0010\r\u001a\u00020\u0003HÆ\u0003J\u001d\u0010\u000e\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0012\u001a\u00020\u0013HÖ\u0001J\t\u0010\u0014\u001a\u00020\u0003HÖ\u0001R\u001a\u0010\u0004\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u0007\"\u0004\b\u000b\u0010\t¨\u0006\u0015"}, d2 = {"Lcom/gateio/biz/base/model/datafinder/TradeTradingClickEvent$TradeTrading;", "", "module_source", "", "button_name", "(Ljava/lang/String;Ljava/lang/String;)V", "getButton_name", "()Ljava/lang/String;", "setButton_name", "(Ljava/lang/String;)V", "getModule_source", "setModule_source", "component1", "component2", H5Container.MENU_COPY, "equals", "", "other", "hashCode", "", "toString", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final /* data */ class TradeTrading {

        @NotNull
        private String button_name;

        @NotNull
        private String module_source;

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof TradeTrading)) {
                return false;
            }
            TradeTrading tradeTrading = (TradeTrading) other;
            return Intrinsics.areEqual(this.module_source, tradeTrading.module_source) && Intrinsics.areEqual(this.button_name, tradeTrading.button_name);
        }

        public static /* synthetic */ TradeTrading copy$default(TradeTrading tradeTrading, String str, String str2, int i10, Object obj) {
            if ((i10 & 1) != 0) {
                str = tradeTrading.module_source;
            }
            if ((i10 & 2) != 0) {
                str2 = tradeTrading.button_name;
            }
            return tradeTrading.copy(str, str2);
        }

        @NotNull
        /* renamed from: component1, reason: from getter */
        public final String getModule_source() {
            return this.module_source;
        }

        @NotNull
        /* renamed from: component2, reason: from getter */
        public final String getButton_name() {
            return this.button_name;
        }

        @NotNull
        public final TradeTrading copy(@NotNull String module_source, @NotNull String button_name) {
            return new TradeTrading(module_source, button_name);
        }

        @NotNull
        public final String getButton_name() {
            return this.button_name;
        }

        @NotNull
        public final String getModule_source() {
            return this.module_source;
        }

        public int hashCode() {
            return (this.module_source.hashCode() * 31) + this.button_name.hashCode();
        }

        public final void setButton_name(@NotNull String str) {
            this.button_name = str;
        }

        public final void setModule_source(@NotNull String str) {
            this.module_source = str;
        }

        @NotNull
        public String toString() {
            return "TradeTrading(module_source=" + this.module_source + ", button_name=" + this.button_name + ')';
        }

        public TradeTrading(@NotNull String str, @NotNull String str2) {
            this.module_source = str;
            this.button_name = str2;
        }
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    @NotNull
    /* renamed from: body */
    public TradeTrading get$jsonObject() {
        return new TradeTrading(this.type, this.buttonName);
    }

    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    @NotNull
    /* renamed from: eventName */
    public String getEventName() {
        return "trade_trading_click";
    }

    @NotNull
    public final String getButtonName() {
        return this.buttonName;
    }

    @NotNull
    public final String getType() {
        return this.type;
    }

    public TradeTradingClickEvent(@NotNull String str, @NotNull String str2) {
        this.type = str;
        this.buttonName = str2;
    }
}