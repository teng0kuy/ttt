package com.gateio.biz.base.model.datafinder;

import com.gateio.lib.datafinder.protocol.GTBaseFinderEvent;

/* loaded from: classes4.dex */
public class TradeSelectClickEvent implements GTBaseFinderEvent<TradeSelect> {
    String currencyName;
    String exchangeName;
    boolean isSelect;
    String moduleSource;
    String selectType;

    static class TradeSelect {
        String currency_name;
        String exchange_name;
        String is_select;
        String module_source;
        String select_type;

        public String getSelect(boolean z10) {
            return z10 ? "1" : "0";
        }

        public TradeSelect(String str, String str2, boolean z10, String str3, String str4) {
            this.exchange_name = str;
            this.currency_name = str2;
            this.is_select = getSelect(z10);
            this.module_source = str3;
            this.select_type = str4;
        }
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    /* renamed from: body */
    public TradeSelect get$jsonObject() {
        return new TradeSelect(this.exchangeName, this.currencyName, this.isSelect, this.moduleSource, this.selectType);
    }

    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    public String eventName() {
        return "trade_select_click";
    }

    public TradeSelectClickEvent(String str, String str2, boolean z10, String str3, String str4) {
        this.exchangeName = str;
        this.currencyName = str2;
        this.isSelect = z10;
        this.moduleSource = str3;
        this.selectType = str4;
    }
}