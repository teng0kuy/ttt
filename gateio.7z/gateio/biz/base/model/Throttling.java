package com.gateio.biz.base.model;

import com.google.gson.annotations.SerializedName;
import com.zoloz.webcontainer.env.H5Container;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: NPSModel.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u000e\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\b\u0018\u00002\u00020\u0001B#\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005¢\u0006\u0002\u0010\u0007J\u000b\u0010\u000e\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0002\u0010\tJ\u0010\u0010\u0010\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0002\u0010\tJ2\u0010\u0011\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0005HÆ\u0001¢\u0006\u0002\u0010\u0012J\u0013\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0017\u001a\u00020\u0003HÖ\u0001R\u001a\u0010\u0004\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004¢\u0006\n\n\u0002\u0010\n\u001a\u0004\b\b\u0010\tR\u001a\u0010\u0006\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004¢\u0006\n\n\u0002\u0010\n\u001a\u0004\b\u000b\u0010\tR\u0018\u0010\u0002\u001a\u0004\u0018\u00010\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\r¨\u0006\u0018"}, d2 = {"Lcom/gateio/biz/base/model/Throttling;", "", "unit", "", "interval", "", "maxOccurrences", "(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;)V", "getInterval", "()Ljava/lang/Integer;", "Ljava/lang/Integer;", "getMaxOccurrences", "getUnit", "()Ljava/lang/String;", "component1", "component2", "component3", H5Container.MENU_COPY, "(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;)Lcom/gateio/biz/base/model/Throttling;", "equals", "", "other", "hashCode", "toString", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class Throttling {

    @SerializedName("interval")
    @Nullable
    private final Integer interval;

    @SerializedName("max_occurrences")
    @Nullable
    private final Integer maxOccurrences;

    @SerializedName("unit")
    @Nullable
    private final String unit;

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Throttling)) {
            return false;
        }
        Throttling throttling = (Throttling) other;
        return Intrinsics.areEqual(this.unit, throttling.unit) && Intrinsics.areEqual(this.interval, throttling.interval) && Intrinsics.areEqual(this.maxOccurrences, throttling.maxOccurrences);
    }

    public static /* synthetic */ Throttling copy$default(Throttling throttling, String str, Integer num, Integer num2, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = throttling.unit;
        }
        if ((i10 & 2) != 0) {
            num = throttling.interval;
        }
        if ((i10 & 4) != 0) {
            num2 = throttling.maxOccurrences;
        }
        return throttling.copy(str, num, num2);
    }

    @Nullable
    /* renamed from: component1, reason: from getter */
    public final String getUnit() {
        return this.unit;
    }

    @Nullable
    /* renamed from: component2, reason: from getter */
    public final Integer getInterval() {
        return this.interval;
    }

    @Nullable
    /* renamed from: component3, reason: from getter */
    public final Integer getMaxOccurrences() {
        return this.maxOccurrences;
    }

    @NotNull
    public final Throttling copy(@Nullable String unit, @Nullable Integer interval, @Nullable Integer maxOccurrences) {
        return new Throttling(unit, interval, maxOccurrences);
    }

    @Nullable
    public final Integer getInterval() {
        return this.interval;
    }

    @Nullable
    public final Integer getMaxOccurrences() {
        return this.maxOccurrences;
    }

    @Nullable
    public final String getUnit() {
        return this.unit;
    }

    public int hashCode() {
        String str = this.unit;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        Integer num = this.interval;
        int iHashCode2 = (iHashCode + (num == null ? 0 : num.hashCode())) * 31;
        Integer num2 = this.maxOccurrences;
        return iHashCode2 + (num2 != null ? num2.hashCode() : 0);
    }

    @NotNull
    public String toString() {
        return "Throttling(unit=" + this.unit + ", interval=" + this.interval + ", maxOccurrences=" + this.maxOccurrences + ')';
    }

    public Throttling(@Nullable String str, @Nullable Integer num, @Nullable Integer num2) {
        this.unit = str;
        this.interval = num;
        this.maxOccurrences = num2;
    }
}