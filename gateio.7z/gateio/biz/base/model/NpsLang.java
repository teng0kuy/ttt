package com.gateio.biz.base.model;

import com.google.gson.annotations.SerializedName;
import com.tencent.qcloud.tuicore.TUIConstants;
import com.zoloz.webcontainer.env.H5Container;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: NPSModel.kt */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B=\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0003\u0012\u000e\u0010\u0007\u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010\b¢\u0006\u0002\u0010\nJ\u000b\u0010\u0012\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0013\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0014\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0015\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u0011\u0010\u0016\u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010\bHÆ\u0003JK\u0010\u0017\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00032\u0010\b\u0002\u0010\u0007\u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010\bHÆ\u0001J\u0013\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001b\u001a\u00020\u001cHÖ\u0001J\t\u0010\u001d\u001a\u00020\u0003HÖ\u0001R\u0018\u0010\u0002\u001a\u0004\u0018\u00010\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0018\u0010\u0004\u001a\u0004\u0018\u00010\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\fR\u001e\u0010\u0007\u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010\b8\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0018\u0010\u0006\u001a\u0004\u0018\u00010\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\fR\u0018\u0010\u0005\u001a\u0004\u0018\u00010\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\f¨\u0006\u001e"}, d2 = {"Lcom/gateio/biz/base/model/NpsLang;", "", "code", "", "name", "title", "question", TUIConstants.TUIPollPlugin.PLUGIN_POLL_OPTION_CONTENT, "", "Lcom/gateio/biz/base/model/NpsOption;", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V", "getCode", "()Ljava/lang/String;", "getName", "getOption", "()Ljava/util/List;", "getQuestion", "getTitle", "component1", "component2", "component3", "component4", "component5", H5Container.MENU_COPY, "equals", "", "other", "hashCode", "", "toString", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class NpsLang {

    @SerializedName("code")
    @Nullable
    private final String code;

    @SerializedName("name")
    @Nullable
    private final String name;

    @SerializedName(TUIConstants.TUIPollPlugin.PLUGIN_POLL_OPTION_CONTENT)
    @Nullable
    private final List<NpsOption> option;

    @SerializedName("question")
    @Nullable
    private final String question;

    @SerializedName("title")
    @Nullable
    private final String title;

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof NpsLang)) {
            return false;
        }
        NpsLang npsLang = (NpsLang) other;
        return Intrinsics.areEqual(this.code, npsLang.code) && Intrinsics.areEqual(this.name, npsLang.name) && Intrinsics.areEqual(this.title, npsLang.title) && Intrinsics.areEqual(this.question, npsLang.question) && Intrinsics.areEqual(this.option, npsLang.option);
    }

    public static /* synthetic */ NpsLang copy$default(NpsLang npsLang, String str, String str2, String str3, String str4, List list, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = npsLang.code;
        }
        if ((i10 & 2) != 0) {
            str2 = npsLang.name;
        }
        String str5 = str2;
        if ((i10 & 4) != 0) {
            str3 = npsLang.title;
        }
        String str6 = str3;
        if ((i10 & 8) != 0) {
            str4 = npsLang.question;
        }
        String str7 = str4;
        if ((i10 & 16) != 0) {
            list = npsLang.option;
        }
        return npsLang.copy(str, str5, str6, str7, list);
    }

    @Nullable
    /* renamed from: component1, reason: from getter */
    public final String getCode() {
        return this.code;
    }

    @Nullable
    /* renamed from: component2, reason: from getter */
    public final String getName() {
        return this.name;
    }

    @Nullable
    /* renamed from: component3, reason: from getter */
    public final String getTitle() {
        return this.title;
    }

    @Nullable
    /* renamed from: component4, reason: from getter */
    public final String getQuestion() {
        return this.question;
    }

    @Nullable
    public final List<NpsOption> component5() {
        return this.option;
    }

    @NotNull
    public final NpsLang copy(@Nullable String code, @Nullable String name, @Nullable String title, @Nullable String question, @Nullable List<NpsOption> option) {
        return new NpsLang(code, name, title, question, option);
    }

    @Nullable
    public final String getCode() {
        return this.code;
    }

    @Nullable
    public final String getName() {
        return this.name;
    }

    @Nullable
    public final List<NpsOption> getOption() {
        return this.option;
    }

    @Nullable
    public final String getQuestion() {
        return this.question;
    }

    @Nullable
    public final String getTitle() {
        return this.title;
    }

    public int hashCode() {
        String str = this.code;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.name;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.title;
        int iHashCode3 = (iHashCode2 + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.question;
        int iHashCode4 = (iHashCode3 + (str4 == null ? 0 : str4.hashCode())) * 31;
        List<NpsOption> list = this.option;
        return iHashCode4 + (list != null ? list.hashCode() : 0);
    }

    @NotNull
    public String toString() {
        return "NpsLang(code=" + this.code + ", name=" + this.name + ", title=" + this.title + ", question=" + this.question + ", option=" + this.option + ')';
    }

    public NpsLang(@Nullable String str, @Nullable String str2, @Nullable String str3, @Nullable String str4, @Nullable List<NpsOption> list) {
        this.code = str;
        this.name = str2;
        this.title = str3;
        this.question = str4;
        this.option = list;
    }
}