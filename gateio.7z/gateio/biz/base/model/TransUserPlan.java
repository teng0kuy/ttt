package com.gateio.biz.base.model;

import com.gate.subconfig.SharedConstants;
import com.zoloz.webcontainer.env.H5Container;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: TransUserPlan.kt */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u000e\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B1\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\b¢\u0006\u0002\u0010\nJ\u000f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\u000f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\bHÆ\u0003J\t\u0010\u0014\u001a\u00020\bHÆ\u0003J=\u0010\u0015\u001a\u00020\u00002\u000e\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u000e\b\u0002\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00060\u00032\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\bHÆ\u0001J\u0013\u0010\u0016\u001a\u00020\u00172\b\u0010\u0018\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0019\u001a\u00020\u001aHÖ\u0001J\t\u0010\u001b\u001a\u00020\bHÖ\u0001R\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0017\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\fR\u0011\u0010\t\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000f¨\u0006\u001c"}, d2 = {"Lcom/gateio/biz/base/model/TransUserPlan;", "", SharedConstants.FeatureModuleHomeConstants.FEATURE_BANNER, "", "Lcom/gateio/biz/base/model/Banner;", "card", "Lcom/gateio/biz/base/model/Card;", "spread_scene", "", "currency", "(Ljava/util/List;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)V", "getBanner", "()Ljava/util/List;", "getCard", "getCurrency", "()Ljava/lang/String;", "getSpread_scene", "component1", "component2", "component3", "component4", H5Container.MENU_COPY, "equals", "", "other", "hashCode", "", "toString", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class TransUserPlan {

    @NotNull
    private final List<Banner> banner;

    @NotNull
    private final List<Card> card;

    @NotNull
    private final String currency;

    @NotNull
    private final String spread_scene;

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof TransUserPlan)) {
            return false;
        }
        TransUserPlan transUserPlan = (TransUserPlan) other;
        return Intrinsics.areEqual(this.banner, transUserPlan.banner) && Intrinsics.areEqual(this.card, transUserPlan.card) && Intrinsics.areEqual(this.spread_scene, transUserPlan.spread_scene) && Intrinsics.areEqual(this.currency, transUserPlan.currency);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ TransUserPlan copy$default(TransUserPlan transUserPlan, List list, List list2, String str, String str2, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            list = transUserPlan.banner;
        }
        if ((i10 & 2) != 0) {
            list2 = transUserPlan.card;
        }
        if ((i10 & 4) != 0) {
            str = transUserPlan.spread_scene;
        }
        if ((i10 & 8) != 0) {
            str2 = transUserPlan.currency;
        }
        return transUserPlan.copy(list, list2, str, str2);
    }

    @NotNull
    public final List<Banner> component1() {
        return this.banner;
    }

    @NotNull
    public final List<Card> component2() {
        return this.card;
    }

    @NotNull
    /* renamed from: component3, reason: from getter */
    public final String getSpread_scene() {
        return this.spread_scene;
    }

    @NotNull
    /* renamed from: component4, reason: from getter */
    public final String getCurrency() {
        return this.currency;
    }

    @NotNull
    public final TransUserPlan copy(@NotNull List<Banner> banner, @NotNull List<Card> card, @NotNull String spread_scene, @NotNull String currency) {
        return new TransUserPlan(banner, card, spread_scene, currency);
    }

    @NotNull
    public final List<Banner> getBanner() {
        return this.banner;
    }

    @NotNull
    public final List<Card> getCard() {
        return this.card;
    }

    @NotNull
    public final String getCurrency() {
        return this.currency;
    }

    @NotNull
    public final String getSpread_scene() {
        return this.spread_scene;
    }

    public int hashCode() {
        return (((((this.banner.hashCode() * 31) + this.card.hashCode()) * 31) + this.spread_scene.hashCode()) * 31) + this.currency.hashCode();
    }

    @NotNull
    public String toString() {
        return "TransUserPlan(banner=" + this.banner + ", card=" + this.card + ", spread_scene=" + this.spread_scene + ", currency=" + this.currency + ')';
    }

    public TransUserPlan(@NotNull List<Banner> list, @NotNull List<Card> list2, @NotNull String str, @NotNull String str2) {
        this.banner = list;
        this.card = list2;
        this.spread_scene = str;
        this.currency = str2;
    }
}