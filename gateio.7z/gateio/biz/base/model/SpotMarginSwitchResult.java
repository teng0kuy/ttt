package com.gateio.biz.base.model;

import com.gateio.gateio.datafinder.DataFinderConstant;
import com.zoloz.webcontainer.env.H5Container;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: SpotMarginSwitchResult.kt */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u001d\u0012\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\u0002\u0010\u0006J\u0010\u0010\u000b\u001a\u0004\u0018\u00010\u0003HÆ\u0003¢\u0006\u0002\u0010\tJ\u000b\u0010\f\u001a\u0004\u0018\u00010\u0005HÆ\u0003J&\u0010\r\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005HÆ\u0001¢\u0006\u0002\u0010\u000eJ\u0013\u0010\u000f\u001a\u00020\u00032\b\u0010\u0010\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0011\u001a\u00020\u0012HÖ\u0001J\t\u0010\u0013\u001a\u00020\u0014HÖ\u0001R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0015\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\n\n\u0002\u0010\n\u001a\u0004\b\u0002\u0010\t¨\u0006\u0015"}, d2 = {"Lcom/gateio/biz/base/model/SpotMarginSwitchResult;", "", DataFinderConstant.DataFinderParamsKey.key_is_success, "", "fail_data", "Lcom/gateio/biz/base/model/SpotMarginTradingSwitch;", "(Ljava/lang/Boolean;Lcom/gateio/biz/base/model/SpotMarginTradingSwitch;)V", "getFail_data", "()Lcom/gateio/biz/base/model/SpotMarginTradingSwitch;", "()Ljava/lang/Boolean;", "Ljava/lang/Boolean;", "component1", "component2", H5Container.MENU_COPY, "(Ljava/lang/Boolean;Lcom/gateio/biz/base/model/SpotMarginTradingSwitch;)Lcom/gateio/biz/base/model/SpotMarginSwitchResult;", "equals", "other", "hashCode", "", "toString", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class SpotMarginSwitchResult {

    @Nullable
    private final SpotMarginTradingSwitch fail_data;

    @Nullable
    private final Boolean is_success;

    public SpotMarginSwitchResult() {
        this(null, 0 == true ? 1 : 0, 3, 0 == true ? 1 : 0);
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SpotMarginSwitchResult)) {
            return false;
        }
        SpotMarginSwitchResult spotMarginSwitchResult = (SpotMarginSwitchResult) other;
        return Intrinsics.areEqual(this.is_success, spotMarginSwitchResult.is_success) && Intrinsics.areEqual(this.fail_data, spotMarginSwitchResult.fail_data);
    }

    public SpotMarginSwitchResult(@Nullable Boolean bool, @Nullable SpotMarginTradingSwitch spotMarginTradingSwitch) {
        this.is_success = bool;
        this.fail_data = spotMarginTradingSwitch;
    }

    public static /* synthetic */ SpotMarginSwitchResult copy$default(SpotMarginSwitchResult spotMarginSwitchResult, Boolean bool, SpotMarginTradingSwitch spotMarginTradingSwitch, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            bool = spotMarginSwitchResult.is_success;
        }
        if ((i10 & 2) != 0) {
            spotMarginTradingSwitch = spotMarginSwitchResult.fail_data;
        }
        return spotMarginSwitchResult.copy(bool, spotMarginTradingSwitch);
    }

    @Nullable
    /* renamed from: component1, reason: from getter */
    public final Boolean getIs_success() {
        return this.is_success;
    }

    @Nullable
    /* renamed from: component2, reason: from getter */
    public final SpotMarginTradingSwitch getFail_data() {
        return this.fail_data;
    }

    @NotNull
    public final SpotMarginSwitchResult copy(@Nullable Boolean is_success, @Nullable SpotMarginTradingSwitch fail_data) {
        return new SpotMarginSwitchResult(is_success, fail_data);
    }

    @Nullable
    public final SpotMarginTradingSwitch getFail_data() {
        return this.fail_data;
    }

    public int hashCode() {
        Boolean bool = this.is_success;
        int iHashCode = (bool == null ? 0 : bool.hashCode()) * 31;
        SpotMarginTradingSwitch spotMarginTradingSwitch = this.fail_data;
        return iHashCode + (spotMarginTradingSwitch != null ? spotMarginTradingSwitch.hashCode() : 0);
    }

    @Nullable
    public final Boolean is_success() {
        return this.is_success;
    }

    @NotNull
    public String toString() {
        return "SpotMarginSwitchResult(is_success=" + this.is_success + ", fail_data=" + this.fail_data + ')';
    }

    public /* synthetic */ SpotMarginSwitchResult(Boolean bool, SpotMarginTradingSwitch spotMarginTradingSwitch, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? null : bool, (i10 & 2) != 0 ? null : spotMarginTradingSwitch);
    }
}