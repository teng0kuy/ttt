package com.gateio.biz.base.model;

import com.zoloz.webcontainer.env.H5Container;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: TransUserPlan.kt */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0018\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B=\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\u0003¢\u0006\u0002\u0010\nJ\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0003HÆ\u0003JO\u0010\u001a\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u001b\u001a\u00020\u001c2\b\u0010\u001d\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001e\u001a\u00020\u001fHÖ\u0001J\t\u0010 \u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\fR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\fR\u0011\u0010\t\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\fR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\fR\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\fR\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\f¨\u0006!"}, d2 = {"Lcom/gateio/biz/base/model/Card;", "", "id", "", "img", "img_v2", "sort", "title", "url", "plan_name", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getId", "()Ljava/lang/String;", "getImg", "getImg_v2", "getPlan_name", "getSort", "getTitle", "getUrl", "component1", "component2", "component3", "component4", "component5", "component6", "component7", H5Container.MENU_COPY, "equals", "", "other", "hashCode", "", "toString", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class Card {

    @NotNull
    private final String id;

    @NotNull
    private final String img;

    @NotNull
    private final String img_v2;

    @NotNull
    private final String plan_name;

    @NotNull
    private final String sort;

    @NotNull
    private final String title;

    @NotNull
    private final String url;

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Card)) {
            return false;
        }
        Card card = (Card) other;
        return Intrinsics.areEqual(this.id, card.id) && Intrinsics.areEqual(this.img, card.img) && Intrinsics.areEqual(this.img_v2, card.img_v2) && Intrinsics.areEqual(this.sort, card.sort) && Intrinsics.areEqual(this.title, card.title) && Intrinsics.areEqual(this.url, card.url) && Intrinsics.areEqual(this.plan_name, card.plan_name);
    }

    public static /* synthetic */ Card copy$default(Card card, String str, String str2, String str3, String str4, String str5, String str6, String str7, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = card.id;
        }
        if ((i10 & 2) != 0) {
            str2 = card.img;
        }
        String str8 = str2;
        if ((i10 & 4) != 0) {
            str3 = card.img_v2;
        }
        String str9 = str3;
        if ((i10 & 8) != 0) {
            str4 = card.sort;
        }
        String str10 = str4;
        if ((i10 & 16) != 0) {
            str5 = card.title;
        }
        String str11 = str5;
        if ((i10 & 32) != 0) {
            str6 = card.url;
        }
        String str12 = str6;
        if ((i10 & 64) != 0) {
            str7 = card.plan_name;
        }
        return card.copy(str, str8, str9, str10, str11, str12, str7);
    }

    @NotNull
    /* renamed from: component1, reason: from getter */
    public final String getId() {
        return this.id;
    }

    @NotNull
    /* renamed from: component2, reason: from getter */
    public final String getImg() {
        return this.img;
    }

    @NotNull
    /* renamed from: component3, reason: from getter */
    public final String getImg_v2() {
        return this.img_v2;
    }

    @NotNull
    /* renamed from: component4, reason: from getter */
    public final String getSort() {
        return this.sort;
    }

    @NotNull
    /* renamed from: component5, reason: from getter */
    public final String getTitle() {
        return this.title;
    }

    @NotNull
    /* renamed from: component6, reason: from getter */
    public final String getUrl() {
        return this.url;
    }

    @NotNull
    /* renamed from: component7, reason: from getter */
    public final String getPlan_name() {
        return this.plan_name;
    }

    @NotNull
    public final Card copy(@NotNull String id, @NotNull String img, @NotNull String img_v2, @NotNull String sort, @NotNull String title, @NotNull String url, @NotNull String plan_name) {
        return new Card(id, img, img_v2, sort, title, url, plan_name);
    }

    @NotNull
    public final String getId() {
        return this.id;
    }

    @NotNull
    public final String getImg() {
        return this.img;
    }

    @NotNull
    public final String getImg_v2() {
        return this.img_v2;
    }

    @NotNull
    public final String getPlan_name() {
        return this.plan_name;
    }

    @NotNull
    public final String getSort() {
        return this.sort;
    }

    @NotNull
    public final String getTitle() {
        return this.title;
    }

    @NotNull
    public final String getUrl() {
        return this.url;
    }

    public int hashCode() {
        return (((((((((((this.id.hashCode() * 31) + this.img.hashCode()) * 31) + this.img_v2.hashCode()) * 31) + this.sort.hashCode()) * 31) + this.title.hashCode()) * 31) + this.url.hashCode()) * 31) + this.plan_name.hashCode();
    }

    @NotNull
    public String toString() {
        return "Card(id=" + this.id + ", img=" + this.img + ", img_v2=" + this.img_v2 + ", sort=" + this.sort + ", title=" + this.title + ", url=" + this.url + ", plan_name=" + this.plan_name + ')';
    }

    public Card(@NotNull String str, @NotNull String str2, @NotNull String str3, @NotNull String str4, @NotNull String str5, @NotNull String str6, @NotNull String str7) {
        this.id = str;
        this.img = str2;
        this.img_v2 = str3;
        this.sort = str4;
        this.title = str5;
        this.url = str6;
        this.plan_name = str7;
    }
}