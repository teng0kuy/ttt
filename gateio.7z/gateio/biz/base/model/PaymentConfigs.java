package com.gateio.biz.base.model;

import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: PaymentConfigs.kt */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\u0018\u00002\u00020\u0001:\u0001\u0011B\u0005¢\u0006\u0002\u0010\u0002J\u0016\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u00042\u0006\u0010\u0010\u001a\u00020\u000fR\"\u0010\u0003\u001a\n\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\"\u0010\n\u001a\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\u0007\"\u0004\b\r\u0010\t¨\u0006\u0012"}, d2 = {"Lcom/gateio/biz/base/model/PaymentConfigs;", "", "()V", "payment_config", "", "Lcom/gateio/biz/base/model/PaymentPage;", "getPayment_config", "()Ljava/util/List;", "setPayment_config", "(Ljava/util/List;)V", "payment_fiat", "Lcom/gateio/biz/base/model/PaymentConfigs$PaymentFiat;", "getPayment_fiat", "setPayment_fiat", "getFiatPayments", "", "fiatCurrency", "PaymentFiat", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class PaymentConfigs {

    @Nullable
    private List<PaymentPage> payment_config;

    @Nullable
    private List<PaymentFiat> payment_fiat;

    /* compiled from: PaymentConfigs.kt */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010 \n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\"\u0010\t\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000e¨\u0006\u000f"}, d2 = {"Lcom/gateio/biz/base/model/PaymentConfigs$PaymentFiat;", "", "()V", "fait", "", "getFait", "()Ljava/lang/String;", "setFait", "(Ljava/lang/String;)V", "payment", "", "getPayment", "()Ljava/util/List;", "setPayment", "(Ljava/util/List;)V", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class PaymentFiat {

        @Nullable
        private String fait;

        @Nullable
        private List<String> payment;

        @Nullable
        public final String getFait() {
            return this.fait;
        }

        @Nullable
        public final List<String> getPayment() {
            return this.payment;
        }

        public final void setFait(@Nullable String str) {
            this.fait = str;
        }

        public final void setPayment(@Nullable List<String> list) {
            this.payment = list;
        }
    }

    @Nullable
    public final List<String> getFiatPayments(@NotNull String fiatCurrency) {
        for (PaymentFiat paymentFiat : this.payment_fiat) {
            if (Intrinsics.areEqual(fiatCurrency, paymentFiat.getFait())) {
                return paymentFiat.getPayment();
            }
        }
        return null;
    }

    @Nullable
    public final List<PaymentPage> getPayment_config() {
        return this.payment_config;
    }

    @Nullable
    public final List<PaymentFiat> getPayment_fiat() {
        return this.payment_fiat;
    }

    public final void setPayment_config(@Nullable List<PaymentPage> list) {
        this.payment_config = list;
    }

    public final void setPayment_fiat(@Nullable List<PaymentFiat> list) {
        this.payment_fiat = list;
    }
}