package com.gateio.biz.base.model;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes4.dex */
public class ReminderEntity implements Parcelable {
    public static final Parcelable.Creator<ReminderEntity> CREATOR = new Parcelable.Creator<ReminderEntity>() { // from class: com.gateio.biz.base.model.ReminderEntity.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ReminderEntity createFromParcel(Parcel parcel) {
            return new ReminderEntity(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public ReminderEntity[] newArray(int i10) {
            return new ReminderEntity[i10];
        }
    };
    private String change_down_5min;
    private String change_up_5min;
    private String frequency;
    private String id;
    private boolean isEdit;
    private boolean isSelect;
    private String market;
    private String price;
    private String price_fall;
    private String price_rise;

    public ReminderEntity(String str) {
        this.isEdit = false;
        this.isSelect = false;
        this.market = str;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String getChange_down_5min() {
        return this.change_down_5min;
    }

    public String getChange_up_5min() {
        return this.change_up_5min;
    }

    public String getFrequency() {
        return this.frequency;
    }

    public String getId() {
        return this.id;
    }

    public String getMarket() {
        return this.market;
    }

    public String getPrice() {
        return this.price;
    }

    public String getPrice_fall() {
        return this.price_fall;
    }

    public String getPrice_rise() {
        return this.price_rise;
    }

    public String getShowMaket() {
        return this.market.contains("_") ? this.market.replace("_", "/") : this.market;
    }

    public boolean isEdit() {
        return this.isEdit;
    }

    public boolean isSelect() {
        return this.isSelect;
    }

    public void setChange_down_5min(String str) {
        this.change_down_5min = str;
    }

    public void setChange_up_5min(String str) {
        this.change_up_5min = str;
    }

    public void setEdit(boolean z10) {
        this.isEdit = z10;
    }

    public void setFrequency(String str) {
        this.frequency = str;
    }

    public void setId(String str) {
        this.id = str;
    }

    public void setMarket(String str) {
        this.market = str;
    }

    public void setPrice(String str) {
        this.price = str;
    }

    public void setPrice_fall(String str) {
        this.price_fall = str;
    }

    public void setPrice_rise(String str) {
        this.price_rise = str;
    }

    public void setSelect(boolean z10) {
        this.isSelect = z10;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeString(this.id);
        parcel.writeString(this.market);
        parcel.writeString(this.price_rise);
        parcel.writeString(this.price_fall);
        parcel.writeString(this.change_up_5min);
        parcel.writeString(this.change_down_5min);
        parcel.writeString(this.frequency);
        parcel.writeString(this.price);
        parcel.writeByte(this.isEdit ? (byte) 1 : (byte) 0);
        parcel.writeByte(this.isSelect ? (byte) 1 : (byte) 0);
    }

    public ReminderEntity() {
        this.isEdit = false;
        this.isSelect = false;
    }

    protected ReminderEntity(Parcel parcel) {
        this.isEdit = false;
        this.isSelect = false;
        this.id = parcel.readString();
        this.market = parcel.readString();
        this.price_rise = parcel.readString();
        this.price_fall = parcel.readString();
        this.change_up_5min = parcel.readString();
        this.change_down_5min = parcel.readString();
        this.frequency = parcel.readString();
        this.price = parcel.readString();
        this.isEdit = parcel.readByte() != 0;
        this.isSelect = parcel.readByte() != 0;
    }
}