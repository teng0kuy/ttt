package com.gateio.biz.base.model;

import com.google.gson.annotations.SerializedName;
import com.zoloz.webcontainer.env.H5Container;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: NPSModel.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u001f\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u000e\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u0005¢\u0006\u0002\u0010\u0007J\u000b\u0010\f\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u0011\u0010\r\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u0005HÆ\u0003J'\u0010\u000e\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\u0010\b\u0002\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u0005HÆ\u0001J\u0013\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0012\u001a\u00020\u0013HÖ\u0001J\t\u0010\u0014\u001a\u00020\u0003HÖ\u0001R\u001e\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u00058\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0018\u0010\u0002\u001a\u0004\u0018\u00010\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\u0015"}, d2 = {"Lcom/gateio/biz/base/model/NpsQuestion;", "", "npsId", "", "lang", "", "Lcom/gateio/biz/base/model/NpsLang;", "(Ljava/lang/String;Ljava/util/List;)V", "getLang", "()Ljava/util/List;", "getNpsId", "()Ljava/lang/String;", "component1", "component2", H5Container.MENU_COPY, "equals", "", "other", "hashCode", "", "toString", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class NpsQuestion {

    @SerializedName("lang")
    @Nullable
    private final List<NpsLang> lang;

    @SerializedName("npsid")
    @Nullable
    private final String npsId;

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof NpsQuestion)) {
            return false;
        }
        NpsQuestion npsQuestion = (NpsQuestion) other;
        return Intrinsics.areEqual(this.npsId, npsQuestion.npsId) && Intrinsics.areEqual(this.lang, npsQuestion.lang);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ NpsQuestion copy$default(NpsQuestion npsQuestion, String str, List list, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = npsQuestion.npsId;
        }
        if ((i10 & 2) != 0) {
            list = npsQuestion.lang;
        }
        return npsQuestion.copy(str, list);
    }

    @Nullable
    /* renamed from: component1, reason: from getter */
    public final String getNpsId() {
        return this.npsId;
    }

    @Nullable
    public final List<NpsLang> component2() {
        return this.lang;
    }

    @NotNull
    public final NpsQuestion copy(@Nullable String npsId, @Nullable List<NpsLang> lang) {
        return new NpsQuestion(npsId, lang);
    }

    @Nullable
    public final List<NpsLang> getLang() {
        return this.lang;
    }

    @Nullable
    public final String getNpsId() {
        return this.npsId;
    }

    public int hashCode() {
        String str = this.npsId;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        List<NpsLang> list = this.lang;
        return iHashCode + (list != null ? list.hashCode() : 0);
    }

    @NotNull
    public String toString() {
        return "NpsQuestion(npsId=" + this.npsId + ", lang=" + this.lang + ')';
    }

    public NpsQuestion(@Nullable String str, @Nullable List<NpsLang> list) {
        this.npsId = str;
        this.lang = list;
    }
}