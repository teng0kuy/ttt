package com.gateio.biz.base.model;

import android.view.View;
import com.gateio.biz.base.weight.Shaper;
import com.zoloz.webcontainer.env.H5Container;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: NoviceTipPopBean.kt */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b \n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\b\u0018\u00002\u00020\u0001BA\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\u0007\u0012\b\b\u0002\u0010\n\u001a\u00020\u0007\u0012\b\b\u0002\u0010\u000b\u001a\u00020\f¢\u0006\u0002\u0010\rJ\t\u0010$\u001a\u00020\u0003HÆ\u0003J\t\u0010%\u001a\u00020\u0005HÆ\u0003J\t\u0010&\u001a\u00020\u0007HÆ\u0003J\t\u0010'\u001a\u00020\u0007HÆ\u0003J\t\u0010(\u001a\u00020\u0007HÆ\u0003J\t\u0010)\u001a\u00020\u0007HÆ\u0003J\t\u0010*\u001a\u00020\fHÆ\u0003JO\u0010+\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00072\b\b\u0002\u0010\t\u001a\u00020\u00072\b\b\u0002\u0010\n\u001a\u00020\u00072\b\b\u0002\u0010\u000b\u001a\u00020\fHÆ\u0001J\u0013\u0010,\u001a\u00020-2\b\u0010.\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010/\u001a\u00020\u0007HÖ\u0001J\t\u00100\u001a\u00020\u0005HÖ\u0001R\u001a\u0010\t\u001a\u00020\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011R\u001a\u0010\n\u001a\u00020\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u000f\"\u0004\b\u0013\u0010\u0011R\u001a\u0010\u0006\u001a\u00020\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u000f\"\u0004\b\u0015\u0010\u0011R\u001a\u0010\u000b\u001a\u00020\fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u0017\"\u0004\b\u0018\u0010\u0019R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001a\u0010\u001b\"\u0004\b\u001c\u0010\u001dR\u001a\u0010\b\u001a\u00020\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001e\u0010\u000f\"\u0004\b\u001f\u0010\u0011R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b \u0010!\"\u0004\b\"\u0010#¨\u00061"}, d2 = {"Lcom/gateio/biz/base/model/NoviceTipPopBean;", "", "view", "Landroid/view/View;", "tipText", "", "radius", "", "verticalGravity", "horizontalGravity", "popOffsetX", "shaper", "Lcom/gateio/biz/base/weight/Shaper;", "(Landroid/view/View;Ljava/lang/String;IIIILcom/gateio/biz/base/weight/Shaper;)V", "getHorizontalGravity", "()I", "setHorizontalGravity", "(I)V", "getPopOffsetX", "setPopOffsetX", "getRadius", "setRadius", "getShaper", "()Lcom/gateio/biz/base/weight/Shaper;", "setShaper", "(Lcom/gateio/biz/base/weight/Shaper;)V", "getTipText", "()Ljava/lang/String;", "setTipText", "(Ljava/lang/String;)V", "getVerticalGravity", "setVerticalGravity", "getView", "()Landroid/view/View;", "setView", "(Landroid/view/View;)V", "component1", "component2", "component3", "component4", "component5", "component6", "component7", H5Container.MENU_COPY, "equals", "", "other", "hashCode", "toString", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class NoviceTipPopBean {
    private int horizontalGravity;
    private int popOffsetX;
    private int radius;

    @NotNull
    private Shaper shaper;

    @NotNull
    private String tipText;
    private int verticalGravity;

    @NotNull
    private View view;

    public NoviceTipPopBean(@NotNull View view, @NotNull String str, int i10, int i11, int i12, int i13, @NotNull Shaper shaper) {
        this.view = view;
        this.tipText = str;
        this.radius = i10;
        this.verticalGravity = i11;
        this.horizontalGravity = i12;
        this.popOffsetX = i13;
        this.shaper = shaper;
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof NoviceTipPopBean)) {
            return false;
        }
        NoviceTipPopBean noviceTipPopBean = (NoviceTipPopBean) other;
        return Intrinsics.areEqual(this.view, noviceTipPopBean.view) && Intrinsics.areEqual(this.tipText, noviceTipPopBean.tipText) && this.radius == noviceTipPopBean.radius && this.verticalGravity == noviceTipPopBean.verticalGravity && this.horizontalGravity == noviceTipPopBean.horizontalGravity && this.popOffsetX == noviceTipPopBean.popOffsetX && this.shaper == noviceTipPopBean.shaper;
    }

    public static /* synthetic */ NoviceTipPopBean copy$default(NoviceTipPopBean noviceTipPopBean, View view, String str, int i10, int i11, int i12, int i13, Shaper shaper, int i14, Object obj) {
        if ((i14 & 1) != 0) {
            view = noviceTipPopBean.view;
        }
        if ((i14 & 2) != 0) {
            str = noviceTipPopBean.tipText;
        }
        String str2 = str;
        if ((i14 & 4) != 0) {
            i10 = noviceTipPopBean.radius;
        }
        int i15 = i10;
        if ((i14 & 8) != 0) {
            i11 = noviceTipPopBean.verticalGravity;
        }
        int i16 = i11;
        if ((i14 & 16) != 0) {
            i12 = noviceTipPopBean.horizontalGravity;
        }
        int i17 = i12;
        if ((i14 & 32) != 0) {
            i13 = noviceTipPopBean.popOffsetX;
        }
        int i18 = i13;
        if ((i14 & 64) != 0) {
            shaper = noviceTipPopBean.shaper;
        }
        return noviceTipPopBean.copy(view, str2, i15, i16, i17, i18, shaper);
    }

    @NotNull
    /* renamed from: component1, reason: from getter */
    public final View getView() {
        return this.view;
    }

    @NotNull
    /* renamed from: component2, reason: from getter */
    public final String getTipText() {
        return this.tipText;
    }

    /* renamed from: component3, reason: from getter */
    public final int getRadius() {
        return this.radius;
    }

    /* renamed from: component4, reason: from getter */
    public final int getVerticalGravity() {
        return this.verticalGravity;
    }

    /* renamed from: component5, reason: from getter */
    public final int getHorizontalGravity() {
        return this.horizontalGravity;
    }

    /* renamed from: component6, reason: from getter */
    public final int getPopOffsetX() {
        return this.popOffsetX;
    }

    @NotNull
    /* renamed from: component7, reason: from getter */
    public final Shaper getShaper() {
        return this.shaper;
    }

    @NotNull
    public final NoviceTipPopBean copy(@NotNull View view, @NotNull String tipText, int radius, int verticalGravity, int horizontalGravity, int popOffsetX, @NotNull Shaper shaper) {
        return new NoviceTipPopBean(view, tipText, radius, verticalGravity, horizontalGravity, popOffsetX, shaper);
    }

    public final int getHorizontalGravity() {
        return this.horizontalGravity;
    }

    public final int getPopOffsetX() {
        return this.popOffsetX;
    }

    public final int getRadius() {
        return this.radius;
    }

    @NotNull
    public final Shaper getShaper() {
        return this.shaper;
    }

    @NotNull
    public final String getTipText() {
        return this.tipText;
    }

    public final int getVerticalGravity() {
        return this.verticalGravity;
    }

    @NotNull
    public final View getView() {
        return this.view;
    }

    public int hashCode() {
        return (((((((((((this.view.hashCode() * 31) + this.tipText.hashCode()) * 31) + Integer.hashCode(this.radius)) * 31) + Integer.hashCode(this.verticalGravity)) * 31) + Integer.hashCode(this.horizontalGravity)) * 31) + Integer.hashCode(this.popOffsetX)) * 31) + this.shaper.hashCode();
    }

    public final void setHorizontalGravity(int i10) {
        this.horizontalGravity = i10;
    }

    public final void setPopOffsetX(int i10) {
        this.popOffsetX = i10;
    }

    public final void setRadius(int i10) {
        this.radius = i10;
    }

    public final void setShaper(@NotNull Shaper shaper) {
        this.shaper = shaper;
    }

    public final void setTipText(@NotNull String str) {
        this.tipText = str;
    }

    public final void setVerticalGravity(int i10) {
        this.verticalGravity = i10;
    }

    public final void setView(@NotNull View view) {
        this.view = view;
    }

    @NotNull
    public String toString() {
        return "NoviceTipPopBean(view=" + this.view + ", tipText=" + this.tipText + ", radius=" + this.radius + ", verticalGravity=" + this.verticalGravity + ", horizontalGravity=" + this.horizontalGravity + ", popOffsetX=" + this.popOffsetX + ", shaper=" + this.shaper + ')';
    }

    public /* synthetic */ NoviceTipPopBean(View view, String str, int i10, int i11, int i12, int i13, Shaper shaper, int i14, DefaultConstructorMarker defaultConstructorMarker) {
        this(view, str, i10, i11, i12, (i14 & 32) != 0 ? 0 : i13, (i14 & 64) != 0 ? Shaper.CIRCLE : shaper);
    }
}