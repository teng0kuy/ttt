package com.gateio.biz.base.model;

import com.gate_sdk.web3_wallet.DeFiConstants;
import com.gateio.biz.base.datafinder.futures.event.BaseContractPopupWindowClickEvent;
import com.gateio.common.Constants;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: TransV1OrderType.kt */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\b\t\b\u0086\u0081\u0002\u0018\u0000 \u000b2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u000bB\u000f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\n¨\u0006\f"}, d2 = {"Lcom/gateio/biz/base/model/TransV1OrderType;", "", "type", "", "(Ljava/lang/String;ILjava/lang/String;)V", DeFiConstants.GetType, "()Ljava/lang/String;", "LIMIT", Constants.Market.MARKET, "CONDITIONAL", BaseContractPopupWindowClickEvent.TWAP, "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class TransV1OrderType {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ TransV1OrderType[] $VALUES;

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE;

    @NotNull
    private final String type;
    public static final TransV1OrderType LIMIT = new TransV1OrderType("LIMIT", 0, "limit");
    public static final TransV1OrderType MARKET = new TransV1OrderType(Constants.Market.MARKET, 1, "market");
    public static final TransV1OrderType CONDITIONAL = new TransV1OrderType("CONDITIONAL", 2, "condition");
    public static final TransV1OrderType TWAP = new TransV1OrderType(BaseContractPopupWindowClickEvent.TWAP, 3, "twap");

    /* compiled from: TransV1OrderType.kt */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u0006¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/base/model/TransV1OrderType$Companion;", "", "()V", "fromType", "Lcom/gateio/biz/base/model/TransV1OrderType;", "type", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nTransV1OrderType.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TransV1OrderType.kt\ncom/gateio/biz/base/model/TransV1OrderType$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,17:1\n1#2:18\n*E\n"})
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @Nullable
        public final TransV1OrderType fromType(@NotNull String type) {
            TransV1OrderType next;
            Iterator<TransV1OrderType> it = TransV1OrderType.getEntries().iterator();
            while (true) {
                if (it.hasNext()) {
                    next = it.next();
                    if (Intrinsics.areEqual(next.getType(), type)) {
                        break;
                    }
                } else {
                    next = null;
                    break;
                }
            }
            return next;
        }
    }

    private static final /* synthetic */ TransV1OrderType[] $values() {
        return new TransV1OrderType[]{LIMIT, MARKET, CONDITIONAL, TWAP};
    }

    static {
        TransV1OrderType[] transV1OrderTypeArr$values = $values();
        $VALUES = transV1OrderTypeArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(transV1OrderTypeArr$values);
        INSTANCE = new Companion(null);
    }

    @NotNull
    public static EnumEntries<TransV1OrderType> getEntries() {
        return $ENTRIES;
    }

    public static TransV1OrderType valueOf(String str) {
        return (TransV1OrderType) Enum.valueOf(TransV1OrderType.class, str);
    }

    public static TransV1OrderType[] values() {
        return (TransV1OrderType[]) $VALUES.clone();
    }

    @NotNull
    public final String getType() {
        return this.type;
    }

    private TransV1OrderType(String str, int i10, String str2) {
        this.type = str2;
    }
}