package com.gateio.biz.base.model;

import com.zoloz.webcontainer.env.H5Container;
import java.io.Serializable;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: UnifiedAccountInfo.kt */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0012\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B7\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\u0003¢\u0006\u0002\u0010\bJ\u000b\u0010\u000f\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0010\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0011\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0012\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0013\u001a\u0004\u0018\u00010\u0003HÆ\u0003JE\u0010\u0014\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0003HÆ\u0001J\u0013\u0010\u0015\u001a\u00020\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\u0018HÖ\u0003J\t\u0010\u0019\u001a\u00020\u001aHÖ\u0001J\t\u0010\u001b\u001a\u00020\u0003HÖ\u0001R\u0013\u0010\u0007\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\nR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\nR\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\nR\u0013\u0010\u0005\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\n¨\u0006\u001c"}, d2 = {"Lcom/gateio/biz/base/model/UnifiedAccountInfo;", "Ljava/io/Serializable;", "total_maintenance_margin_rate", "", "total_initial_margin_rate", "total_margin_balance", "portfolio_margin_total_equity", "portfolio_margin_total_borrowed", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getPortfolio_margin_total_borrowed", "()Ljava/lang/String;", "getPortfolio_margin_total_equity", "getTotal_initial_margin_rate", "getTotal_maintenance_margin_rate", "getTotal_margin_balance", "component1", "component2", "component3", "component4", "component5", H5Container.MENU_COPY, "equals", "", "other", "", "hashCode", "", "toString", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class UnifiedAccountInfo implements Serializable {

    @Nullable
    private final String portfolio_margin_total_borrowed;

    @Nullable
    private final String portfolio_margin_total_equity;

    @Nullable
    private final String total_initial_margin_rate;

    @Nullable
    private final String total_maintenance_margin_rate;

    @Nullable
    private final String total_margin_balance;

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof UnifiedAccountInfo)) {
            return false;
        }
        UnifiedAccountInfo unifiedAccountInfo = (UnifiedAccountInfo) other;
        return Intrinsics.areEqual(this.total_maintenance_margin_rate, unifiedAccountInfo.total_maintenance_margin_rate) && Intrinsics.areEqual(this.total_initial_margin_rate, unifiedAccountInfo.total_initial_margin_rate) && Intrinsics.areEqual(this.total_margin_balance, unifiedAccountInfo.total_margin_balance) && Intrinsics.areEqual(this.portfolio_margin_total_equity, unifiedAccountInfo.portfolio_margin_total_equity) && Intrinsics.areEqual(this.portfolio_margin_total_borrowed, unifiedAccountInfo.portfolio_margin_total_borrowed);
    }

    public static /* synthetic */ UnifiedAccountInfo copy$default(UnifiedAccountInfo unifiedAccountInfo, String str, String str2, String str3, String str4, String str5, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = unifiedAccountInfo.total_maintenance_margin_rate;
        }
        if ((i10 & 2) != 0) {
            str2 = unifiedAccountInfo.total_initial_margin_rate;
        }
        String str6 = str2;
        if ((i10 & 4) != 0) {
            str3 = unifiedAccountInfo.total_margin_balance;
        }
        String str7 = str3;
        if ((i10 & 8) != 0) {
            str4 = unifiedAccountInfo.portfolio_margin_total_equity;
        }
        String str8 = str4;
        if ((i10 & 16) != 0) {
            str5 = unifiedAccountInfo.portfolio_margin_total_borrowed;
        }
        return unifiedAccountInfo.copy(str, str6, str7, str8, str5);
    }

    @Nullable
    /* renamed from: component1, reason: from getter */
    public final String getTotal_maintenance_margin_rate() {
        return this.total_maintenance_margin_rate;
    }

    @Nullable
    /* renamed from: component2, reason: from getter */
    public final String getTotal_initial_margin_rate() {
        return this.total_initial_margin_rate;
    }

    @Nullable
    /* renamed from: component3, reason: from getter */
    public final String getTotal_margin_balance() {
        return this.total_margin_balance;
    }

    @Nullable
    /* renamed from: component4, reason: from getter */
    public final String getPortfolio_margin_total_equity() {
        return this.portfolio_margin_total_equity;
    }

    @Nullable
    /* renamed from: component5, reason: from getter */
    public final String getPortfolio_margin_total_borrowed() {
        return this.portfolio_margin_total_borrowed;
    }

    @NotNull
    public final UnifiedAccountInfo copy(@Nullable String total_maintenance_margin_rate, @Nullable String total_initial_margin_rate, @Nullable String total_margin_balance, @Nullable String portfolio_margin_total_equity, @Nullable String portfolio_margin_total_borrowed) {
        return new UnifiedAccountInfo(total_maintenance_margin_rate, total_initial_margin_rate, total_margin_balance, portfolio_margin_total_equity, portfolio_margin_total_borrowed);
    }

    @Nullable
    public final String getPortfolio_margin_total_borrowed() {
        return this.portfolio_margin_total_borrowed;
    }

    @Nullable
    public final String getPortfolio_margin_total_equity() {
        return this.portfolio_margin_total_equity;
    }

    @Nullable
    public final String getTotal_initial_margin_rate() {
        return this.total_initial_margin_rate;
    }

    @Nullable
    public final String getTotal_maintenance_margin_rate() {
        return this.total_maintenance_margin_rate;
    }

    @Nullable
    public final String getTotal_margin_balance() {
        return this.total_margin_balance;
    }

    public int hashCode() {
        String str = this.total_maintenance_margin_rate;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.total_initial_margin_rate;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.total_margin_balance;
        int iHashCode3 = (iHashCode2 + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.portfolio_margin_total_equity;
        int iHashCode4 = (iHashCode3 + (str4 == null ? 0 : str4.hashCode())) * 31;
        String str5 = this.portfolio_margin_total_borrowed;
        return iHashCode4 + (str5 != null ? str5.hashCode() : 0);
    }

    @NotNull
    public String toString() {
        return "UnifiedAccountInfo(total_maintenance_margin_rate=" + this.total_maintenance_margin_rate + ", total_initial_margin_rate=" + this.total_initial_margin_rate + ", total_margin_balance=" + this.total_margin_balance + ", portfolio_margin_total_equity=" + this.portfolio_margin_total_equity + ", portfolio_margin_total_borrowed=" + this.portfolio_margin_total_borrowed + ')';
    }

    public UnifiedAccountInfo(@Nullable String str, @Nullable String str2, @Nullable String str3, @Nullable String str4, @Nullable String str5) {
        this.total_maintenance_margin_rate = str;
        this.total_initial_margin_rate = str2;
        this.total_margin_balance = str3;
        this.portfolio_margin_total_equity = str4;
        this.portfolio_margin_total_borrowed = str5;
    }
}