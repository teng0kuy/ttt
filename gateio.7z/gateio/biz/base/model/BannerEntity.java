package com.gateio.biz.base.model;

/* loaded from: classes4.dex */
public class BannerEntity {
    private String img_url;
    private String link;
    private String mini_app_link;
    private int resId;
    private String title;
    private String color = "#003098";
    private boolean isLocal = true;

    public String getColor() {
        return this.color;
    }

    public String getImg_url() {
        return this.img_url;
    }

    public String getLink() {
        return this.link;
    }

    public String getMini_app_link() {
        return this.mini_app_link;
    }

    public int getResId() {
        return this.resId;
    }

    public String getTitle() {
        return this.title;
    }

    public boolean isLocal() {
        return this.isLocal;
    }

    public void setColor(String str) {
        this.color = str;
    }

    public void setImg_url(String str) {
        this.img_url = str;
    }

    public void setLink(String str) {
        this.link = str;
    }

    public void setLocal(boolean z10) {
        this.isLocal = z10;
    }

    public void setMini_app_link(String str) {
        this.mini_app_link = str;
    }

    public void setResId(int i10) {
        this.resId = i10;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public BannerEntity(String str, int i10) {
        this.link = str;
        this.resId = i10;
    }
}