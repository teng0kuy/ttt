package com.gateio.biz.base.model;

/* loaded from: classes4.dex */
public class TradePairsBean {
    private String currentType;
    private String exchangeType;

    public String getCurrentType() {
        return this.currentType;
    }

    public String getExchangeType() {
        return this.exchangeType;
    }

    public void setCurrentType(String str) {
        this.currentType = str;
    }

    public void setExchangeType(String str) {
        this.exchangeType = str;
    }
}