package com.gateio.biz.base.model;

/* loaded from: classes4.dex */
public class MarketSearchBeanFlutter {
    private String base_currency;
    private String pair;
    private String quote_currency;

    public String getBase_currency() {
        return this.base_currency;
    }

    public String getPair() {
        return this.pair;
    }

    public String getQuote_currency() {
        return this.quote_currency;
    }

    public void setBase_currency(String str) {
        this.base_currency = str;
    }

    public void setPair(String str) {
        this.pair = str;
    }

    public void setQuote_currency(String str) {
        this.quote_currency = str;
    }
}