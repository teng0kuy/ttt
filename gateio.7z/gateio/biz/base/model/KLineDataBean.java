package com.gateio.biz.base.model;

import com.gateio.common.tool.NumberUtil;

/* loaded from: classes4.dex */
public class KLineDataBean {
    private String amountVol;

    /* renamed from: c, reason: collision with root package name */
    private String f10985c;

    /* renamed from: h, reason: collision with root package name */
    private String f10986h;
    private String l;

    /* renamed from: o, reason: collision with root package name */
    private String f10987o;
    private String sum;

    /* renamed from: t, reason: collision with root package name */
    private String f10988t;

    /* renamed from: v, reason: collision with root package name */
    private String f10989v;
    private boolean isMark = false;
    private boolean isForce = false;

    public String getAmountVol() {
        return this.amountVol;
    }

    public String getC() {
        return this.f10985c;
    }

    public String getH() {
        return this.f10986h;
    }

    public String getL() {
        return this.l;
    }

    public String getO() {
        return this.f10987o;
    }

    public String getSum() {
        return this.sum;
    }

    public String getT() {
        return this.f10988t;
    }

    public long getTime() {
        return NumberUtil.parseLong(this.f10988t);
    }

    public String getV() {
        return this.f10989v;
    }

    public boolean isForce() {
        return this.isForce;
    }

    public boolean isMark() {
        return this.isMark;
    }

    public void setAmountVol(String str) {
        this.amountVol = str;
    }

    public void setC(String str) {
        this.f10985c = str;
    }

    public void setForce(boolean z10) {
        this.isForce = z10;
    }

    public void setH(String str) {
        this.f10986h = str;
    }

    public void setL(String str) {
        this.l = str;
    }

    public void setMark(boolean z10) {
        this.isMark = z10;
    }

    public void setO(String str) {
        this.f10987o = str;
    }

    public void setSum(String str) {
        this.sum = str;
    }

    public void setT(String str) {
        this.f10988t = str;
    }

    public void setV(String str) {
        this.f10989v = str;
    }
}