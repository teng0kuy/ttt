package com.gateio.biz.base.model;

/* loaded from: classes4.dex */
public class FundPwdFrequency {
    private String freq;

    public String getFreq() {
        return this.freq;
    }

    public void setFreq(String str) {
        this.freq = str;
    }
}