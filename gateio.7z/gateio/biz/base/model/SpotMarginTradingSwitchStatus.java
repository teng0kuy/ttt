package com.gateio.biz.base.model;

import com.alipay.blueshield.legacy.IDeviceColorModule;
import com.zoloz.webcontainer.env.H5Container;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: SpotMarginTradingSwitchStatus.kt */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u001a\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B5\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0005\u0012\u0006\u0010\t\u001a\u00020\n¢\u0006\u0002\u0010\u000bJ\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001d\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0005HÆ\u0003J\t\u0010 \u001a\u00020\nHÆ\u0003JE\u0010!\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u00052\b\b\u0002\u0010\t\u001a\u00020\nHÆ\u0001J\u0013\u0010\"\u001a\u00020\u00052\b\u0010#\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010$\u001a\u00020%HÖ\u0001J\u0006\u0010&\u001a\u00020\u0005J\u0006\u0010'\u001a\u00020\u0005J\u0006\u0010(\u001a\u00020\u0005J\u0006\u0010)\u001a\u00020\u0005J\u0006\u0010*\u001a\u00020\u0005J\u0006\u0010+\u001a\u00020\u0005J\t\u0010,\u001a\u00020\u0003HÖ\u0001J\u000e\u0010-\u001a\u00020\u00002\u0006\u0010.\u001a\u00020/R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\rR\u001a\u0010\u0006\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000f\u0010\r\"\u0004\b\u0010\u0010\u0011R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u001a\u0010\t\u001a\u00020\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u0017\"\u0004\b\u0018\u0010\u0019R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\r¨\u00060"}, d2 = {"Lcom/gateio/biz/base/model/SpotMarginTradingSwitchStatus;", "", IDeviceColorModule.EDGE_MODE_KEY, "", "support_unified", "", "first_open", "auto_borrow", "auto_repay", "settings", "Lcom/gateio/biz/base/model/PerpetualContract;", "(Ljava/lang/String;ZZZZLcom/gateio/biz/base/model/PerpetualContract;)V", "getAuto_borrow", "()Z", "getAuto_repay", "getFirst_open", "setFirst_open", "(Z)V", "getMode", "()Ljava/lang/String;", "setMode", "(Ljava/lang/String;)V", "getSettings", "()Lcom/gateio/biz/base/model/PerpetualContract;", "setSettings", "(Lcom/gateio/biz/base/model/PerpetualContract;)V", "getSupport_unified", "component1", "component2", "component3", "component4", "component5", "component6", H5Container.MENU_COPY, "equals", "other", "hashCode", "", "isClassic", "isCombBondMode", "isMultiCurrency", "isSingleCurrency", "isSpotMarginTrading", "isSupportLoanType", "toString", "updateFromUnifiedAccountDigests", "bean", "Lcom/gateio/biz/base/model/UnifiedAccountDigestsBean;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class SpotMarginTradingSwitchStatus {
    private final boolean auto_borrow;
    private final boolean auto_repay;
    private boolean first_open;

    @NotNull
    private String mode;

    @NotNull
    private PerpetualContract settings;
    private final boolean support_unified;

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SpotMarginTradingSwitchStatus)) {
            return false;
        }
        SpotMarginTradingSwitchStatus spotMarginTradingSwitchStatus = (SpotMarginTradingSwitchStatus) other;
        return Intrinsics.areEqual(this.mode, spotMarginTradingSwitchStatus.mode) && this.support_unified == spotMarginTradingSwitchStatus.support_unified && this.first_open == spotMarginTradingSwitchStatus.first_open && this.auto_borrow == spotMarginTradingSwitchStatus.auto_borrow && this.auto_repay == spotMarginTradingSwitchStatus.auto_repay && Intrinsics.areEqual(this.settings, spotMarginTradingSwitchStatus.settings);
    }

    public static /* synthetic */ SpotMarginTradingSwitchStatus copy$default(SpotMarginTradingSwitchStatus spotMarginTradingSwitchStatus, String str, boolean z10, boolean z11, boolean z12, boolean z13, PerpetualContract perpetualContract, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = spotMarginTradingSwitchStatus.mode;
        }
        if ((i10 & 2) != 0) {
            z10 = spotMarginTradingSwitchStatus.support_unified;
        }
        boolean z14 = z10;
        if ((i10 & 4) != 0) {
            z11 = spotMarginTradingSwitchStatus.first_open;
        }
        boolean z15 = z11;
        if ((i10 & 8) != 0) {
            z12 = spotMarginTradingSwitchStatus.auto_borrow;
        }
        boolean z16 = z12;
        if ((i10 & 16) != 0) {
            z13 = spotMarginTradingSwitchStatus.auto_repay;
        }
        boolean z17 = z13;
        if ((i10 & 32) != 0) {
            perpetualContract = spotMarginTradingSwitchStatus.settings;
        }
        return spotMarginTradingSwitchStatus.copy(str, z14, z15, z16, z17, perpetualContract);
    }

    @NotNull
    /* renamed from: component1, reason: from getter */
    public final String getMode() {
        return this.mode;
    }

    /* renamed from: component2, reason: from getter */
    public final boolean getSupport_unified() {
        return this.support_unified;
    }

    /* renamed from: component3, reason: from getter */
    public final boolean getFirst_open() {
        return this.first_open;
    }

    /* renamed from: component4, reason: from getter */
    public final boolean getAuto_borrow() {
        return this.auto_borrow;
    }

    /* renamed from: component5, reason: from getter */
    public final boolean getAuto_repay() {
        return this.auto_repay;
    }

    @NotNull
    /* renamed from: component6, reason: from getter */
    public final PerpetualContract getSettings() {
        return this.settings;
    }

    @NotNull
    public final SpotMarginTradingSwitchStatus copy(@NotNull String mode, boolean support_unified, boolean first_open, boolean auto_borrow, boolean auto_repay, @NotNull PerpetualContract settings) {
        return new SpotMarginTradingSwitchStatus(mode, support_unified, first_open, auto_borrow, auto_repay, settings);
    }

    public final boolean getAuto_borrow() {
        return this.auto_borrow;
    }

    public final boolean getAuto_repay() {
        return this.auto_repay;
    }

    public final boolean getFirst_open() {
        return this.first_open;
    }

    @NotNull
    public final String getMode() {
        return this.mode;
    }

    @NotNull
    public final PerpetualContract getSettings() {
        return this.settings;
    }

    public final boolean getSupport_unified() {
        return this.support_unified;
    }

    public int hashCode() {
        return (((((((((this.mode.hashCode() * 31) + Boolean.hashCode(this.support_unified)) * 31) + Boolean.hashCode(this.first_open)) * 31) + Boolean.hashCode(this.auto_borrow)) * 31) + Boolean.hashCode(this.auto_repay)) * 31) + this.settings.hashCode();
    }

    public final boolean isClassic() {
        return Intrinsics.areEqual(this.mode, SpotMarginTradingType.CLASSIC.getType());
    }

    public final boolean isCombBondMode() {
        return Intrinsics.areEqual(this.mode, SpotMarginTradingType.PORTFOLIO.getType());
    }

    public final boolean isMultiCurrency() {
        return Intrinsics.areEqual(this.mode, SpotMarginTradingType.MULTI_CURRENCY.getType());
    }

    public final boolean isSingleCurrency() {
        return Intrinsics.areEqual(this.mode, SpotMarginTradingType.SINGLE_CURRENCY.getType());
    }

    public final boolean isSpotMarginTrading() {
        return Intrinsics.areEqual(this.mode, SpotMarginTradingType.MULTI_CURRENCY.getType()) || Intrinsics.areEqual(this.mode, SpotMarginTradingType.PORTFOLIO.getType()) || Intrinsics.areEqual(this.mode, SpotMarginTradingType.SINGLE_CURRENCY.getType());
    }

    public final void setFirst_open(boolean z10) {
        this.first_open = z10;
    }

    public final void setMode(@NotNull String str) {
        this.mode = str;
    }

    public final void setSettings(@NotNull PerpetualContract perpetualContract) {
        this.settings = perpetualContract;
    }

    @NotNull
    public String toString() {
        return "SpotMarginTradingSwitchStatus(mode=" + this.mode + ", support_unified=" + this.support_unified + ", first_open=" + this.first_open + ", auto_borrow=" + this.auto_borrow + ", auto_repay=" + this.auto_repay + ", settings=" + this.settings + ')';
    }

    public SpotMarginTradingSwitchStatus(@NotNull String str, boolean z10, boolean z11, boolean z12, boolean z13, @NotNull PerpetualContract perpetualContract) {
        this.mode = str;
        this.support_unified = z10;
        this.first_open = z11;
        this.auto_borrow = z12;
        this.auto_repay = z13;
        this.settings = perpetualContract;
    }

    public final boolean isSupportLoanType() {
        if (!isMultiCurrency() && !isCombBondMode()) {
            return false;
        }
        return true;
    }

    @NotNull
    public final SpotMarginTradingSwitchStatus updateFromUnifiedAccountDigests(@NotNull UnifiedAccountDigestsBean bean) {
        this.mode = bean.getMode();
        this.first_open = bean.getFirst_open();
        this.settings = bean.getSettings();
        return this;
    }
}