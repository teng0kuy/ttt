package com.gateio.biz.base.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.realm.annotations.Ignore;
import java.util.List;
import kotlin.Metadata;
import kotlinx.parcelize.Parcelize;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GridMenuSubMenusBean.kt */
@Parcelize
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0011\n\u0002\u0010 \n\u0002\b\r\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0017\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J \u00100\u001a\u00020\u00002\b\u0010\u001e\u001a\u0004\u0018\u00010\u00042\u0006\u0010!\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\nJ\t\u00101\u001a\u00020\nHÖ\u0001J\u0019\u00102\u001a\u0002032\u0006\u00104\u001a\u0002052\u0006\u00106\u001a\u00020\nHÖ\u0001R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001a\u0010\t\u001a\u00020\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u001c\u0010\u000f\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0006\"\u0004\b\u0011\u0010\bR\u001e\u0010\u0012\u001a\u00020\u00138\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0014\"\u0004\b\u0015\u0010\u0016R\u001a\u0010\u0017\u001a\u00020\u0013X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0017\u0010\u0014\"\u0004\b\u0018\u0010\u0016R\u001a\u0010\u0019\u001a\u00020\u0013X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0019\u0010\u0014\"\u0004\b\u001a\u0010\u0016R \u0010\u001b\u001a\u0004\u0018\u00010\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001c\u0010\u0006\"\u0004\b\u001d\u0010\bR\u001c\u0010\u001e\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001f\u0010\u0006\"\u0004\b \u0010\bR\u001e\u0010!\u001a\u00020\n8\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\"\u0010\f\"\u0004\b#\u0010\u000eR&\u0010$\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010%8\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b&\u0010'\"\u0004\b(\u0010)R\u001a\u0010*\u001a\u00020\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b+\u0010\f\"\u0004\b,\u0010\u000eR\u001c\u0010-\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b.\u0010\u0006\"\u0004\b/\u0010\b¨\u00067"}, d2 = {"Lcom/gateio/biz/base/model/GridMenuSubMenusBean;", "Landroid/os/Parcelable;", "()V", "code", "", "getCode", "()Ljava/lang/String;", "setCode", "(Ljava/lang/String;)V", "defaultOrder", "", "getDefaultOrder", "()I", "setDefaultOrder", "(I)V", "image", "getImage", "setImage", "isCustom", "", "()Z", "setCustom", "(Z)V", "isHot", "setHot", "isLogin", "setLogin", "menueTitle", "getMenueTitle", "setMenueTitle", "name", "getName", "setName", "resId", "getResId", "setResId", "support_lang", "", "getSupport_lang", "()Ljava/util/List;", "setSupport_lang", "(Ljava/util/List;)V", "topOrder", "getTopOrder", "setTopOrder", "url", "getUrl", "setUrl", JsonPOJOBuilder.DEFAULT_BUILD_METHOD, "describeContents", "writeToParcel", "", "parcel", "Landroid/os/Parcel;", "flags", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public class GridMenuSubMenusBean implements Parcelable {

    @NotNull
    public static final Parcelable.Creator<GridMenuSubMenusBean> CREATOR = new Creator();

    @Nullable
    private String code;
    private int defaultOrder;

    @Nullable
    private String image;

    @Ignore
    private boolean isCustom;
    private boolean isHot;
    private boolean isLogin;

    @Ignore
    @Nullable
    private String menueTitle;

    @Nullable
    private String name;

    @Ignore
    private int resId;

    @Ignore
    @Nullable
    private List<String> support_lang;
    private int topOrder;

    @Nullable
    private String url;

    /* compiled from: GridMenuSubMenusBean.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class Creator implements Parcelable.Creator<GridMenuSubMenusBean> {
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        @NotNull
        public final GridMenuSubMenusBean createFromParcel(@NotNull Parcel parcel) {
            parcel.readInt();
            return new GridMenuSubMenusBean();
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        @NotNull
        public final GridMenuSubMenusBean[] newArray(int i10) {
            return new GridMenuSubMenusBean[i10];
        }
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(@NotNull Parcel parcel, int flags) {
        parcel.writeInt(1);
    }

    @NotNull
    public final GridMenuSubMenusBean build(@Nullable String name, int resId, int defaultOrder) {
        this.name = name;
        this.resId = resId;
        this.defaultOrder = defaultOrder;
        return this;
    }

    @Nullable
    public final String getCode() {
        return this.code;
    }

    public final int getDefaultOrder() {
        return this.defaultOrder;
    }

    @Nullable
    public final String getImage() {
        return this.image;
    }

    @Nullable
    public final String getMenueTitle() {
        return this.menueTitle;
    }

    @Nullable
    public final String getName() {
        return this.name;
    }

    public final int getResId() {
        return this.resId;
    }

    @Nullable
    public final List<String> getSupport_lang() {
        return this.support_lang;
    }

    public final int getTopOrder() {
        return this.topOrder;
    }

    @Nullable
    public final String getUrl() {
        return this.url;
    }

    /* renamed from: isCustom, reason: from getter */
    public final boolean getIsCustom() {
        return this.isCustom;
    }

    /* renamed from: isHot, reason: from getter */
    public final boolean getIsHot() {
        return this.isHot;
    }

    /* renamed from: isLogin, reason: from getter */
    public final boolean getIsLogin() {
        return this.isLogin;
    }

    public final void setCode(@Nullable String str) {
        this.code = str;
    }

    public final void setCustom(boolean z10) {
        this.isCustom = z10;
    }

    public final void setDefaultOrder(int i10) {
        this.defaultOrder = i10;
    }

    public final void setHot(boolean z10) {
        this.isHot = z10;
    }

    public final void setImage(@Nullable String str) {
        this.image = str;
    }

    public final void setLogin(boolean z10) {
        this.isLogin = z10;
    }

    public final void setMenueTitle(@Nullable String str) {
        this.menueTitle = str;
    }

    public final void setName(@Nullable String str) {
        this.name = str;
    }

    public final void setResId(int i10) {
        this.resId = i10;
    }

    public final void setSupport_lang(@Nullable List<String> list) {
        this.support_lang = list;
    }

    public final void setTopOrder(int i10) {
        this.topOrder = i10;
    }

    public final void setUrl(@Nullable String str) {
        this.url = str;
    }
}