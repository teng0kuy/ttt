package com.gateio.biz.base;

import android.annotation.SuppressLint;
import android.app.Application;
import com.gateio.biz.base.datafinder.GTDateFinderActivityLifecycle;
import com.gateio.biz.base.utils.ConstUtil;
import com.gateio.biz.market.util.MarketConst;
import com.gateio.common.Constants;
import com.gateio.common.tool.BuildMap;
import com.gateio.lib.datafinder.GTDataFinder;
import com.gateio.lib.storage.GTStorage;
import com.gateio.lib.storage.mmvk.GTStoreKVDomain;
import com.google.gson.reflect.TypeToken;
import com.sumsub.sns.internal.presentation.utils.d;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlinx.coroutines.DebugKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: BizBaseInitializer.kt */
@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0002\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J0\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u000b\u001a\u00020\n2\u000e\u0010\u0016\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00180\u0017H\u0007J\b\u0010\u001f\u001a\u00020\u0010H\u0002R$\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0004@@X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR$\u0010\u000b\u001a\u00020\n2\u0006\u0010\u0003\u001a\u00020\n@@X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR,\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0003\u001a\u00020\u00108\u0006@@X\u0087\u000e¢\u0006\u0014\n\u0000\u0012\u0004\b\u0012\u0010\u0002\u001a\u0004\b\u0011\u0010\u0013\"\u0004\b\u0014\u0010\u0015R$\u0010\u0016\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0018\u0018\u00010\u0017X\u0080\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0019\u0010\u001a\"\u0004\b\u001b\u0010\u001c¨\u0006 "}, d2 = {"Lcom/gateio/biz/base/BizBaseInitializer;", "", "()V", "<set-?>", "Landroid/app/Application;", "context", "getContext", "()Landroid/app/Application;", "setContext$biz_base_core_release", "(Landroid/app/Application;)V", "Lcom/gateio/biz/base/BaseBizDataBridge;", "dataBridge", "getDataBridge", "()Lcom/gateio/biz/base/BaseBizDataBridge;", "setDataBridge$biz_base_core_release", "(Lcom/gateio/biz/base/BaseBizDataBridge;)V", "", "isDebug", "isDebug$annotations", "()Z", "setDebug$biz_base_core_release", "(Z)V", "webBaseUrlProvider", "Lkotlin/Function0;", "", "getWebBaseUrlProvider$biz_base_core_release", "()Lkotlin/jvm/functions/Function0;", "setWebBaseUrlProvider$biz_base_core_release", "(Lkotlin/jvm/functions/Function0;)V", "init", "", "isFirstTimeDaily", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SuppressLint({"StaticFieldLeak"})
@SourceDebugExtension({"SMAP\nBizBaseInitializer.kt\nKotlin\n*S Kotlin\n*F\n+ 1 BizBaseInitializer.kt\ncom/gateio/biz/base/BizBaseInitializer\n+ 2 GTStorage.kt\ncom/gateio/lib/storage/GTStorage\n*L\n1#1,96:1\n384#2,10:97\n384#2,10:107\n*S KotlinDebug\n*F\n+ 1 BizBaseInitializer.kt\ncom/gateio/biz/base/BizBaseInitializer\n*L\n50#1:97,10\n68#1:107,10\n*E\n"})
/* loaded from: classes4.dex */
public final class BizBaseInitializer {

    @NotNull
    public static final BizBaseInitializer INSTANCE = new BizBaseInitializer();
    public static Application context;
    public static BaseBizDataBridge dataBridge;
    private static boolean isDebug;

    @Nullable
    private static Function0<String> webBaseUrlProvider;

    private BizBaseInitializer() {
    }

    @JvmStatic
    public static final void init(@NotNull Application context2, boolean isDebug2, @NotNull BaseBizDataBridge dataBridge2, @NotNull Function0<String> webBaseUrlProvider2) {
        BizBaseInitializer bizBaseInitializer = INSTANCE;
        bizBaseInitializer.setContext$biz_base_core_release(context2);
        isDebug = isDebug2;
        webBaseUrlProvider = webBaseUrlProvider2;
        bizBaseInitializer.setDataBridge$biz_base_core_release(dataBridge2);
        bizBaseInitializer.isFirstTimeDaily();
        context2.registerActivityLifecycleCallbacks(new GTDateFinderActivityLifecycle());
    }

    public static final boolean isDebug() {
        return isDebug;
    }

    private final boolean isFirstTimeDaily() {
        GTStorage gTStorage = GTStorage.INSTANCE;
        GTStoreKVDomain gTStoreKVDomain = GTStoreKVDomain.Default;
        Object objQueryKV = gTStorage.isPrimitiveOrWrapper(String.class) ? GTStorage.queryKV(ConstUtil.APP_LAST_OPEN_DATE_KEY, (Class<String>) String.class, "", gTStoreKVDomain) : GTStorage.queryKV(ConstUtil.APP_LAST_OPEN_DATE_KEY, new TypeToken<String>() { // from class: com.gateio.biz.base.BizBaseInitializer$isFirstTimeDaily$$inlined$queryKV$default$1
        }.getType(), "", gTStoreKVDomain);
        String str = new SimpleDateFormat(d.f29844a, Locale.getDefault()).format(Calendar.getInstance().getTime());
        if (Intrinsics.areEqual((String) objQueryKV, str)) {
            return false;
        }
        GTStorage.saveKV$default(ConstUtil.APP_LAST_OPEN_DATE_KEY, str, null, 4, null);
        GTDataFinder.postEvent("home_setting_status", BuildMap.initStr().put((BuildMap<String, String>) "marketballsetting_status", GTStorage.queryBooleanKV$default(Constants.MarketBall.KEY_MARKETBALL_SETTING, false, null, 4, null) ? DebugKt.DEBUG_PROPERTY_VALUE_ON : DebugKt.DEBUG_PROPERTY_VALUE_OFF).build());
        String str2 = (String) (gTStorage.isPrimitiveOrWrapper(String.class) ? GTStorage.queryKV(MarketConst.MARKET_PRICE_MODE, (Class<String>) String.class, MarketConst.CURRENCY_EXCHANGE, gTStoreKVDomain) : GTStorage.queryKV(MarketConst.MARKET_PRICE_MODE, new TypeToken<String>() { // from class: com.gateio.biz.base.BizBaseInitializer$isFirstTimeDaily$$inlined$queryKV$default$2
        }.getType(), MarketConst.CURRENCY_EXCHANGE, gTStoreKVDomain));
        boolean z10 = Intrinsics.areEqual(str2, MarketConst.CURRENCY_EXCHANGE) || !Intrinsics.areEqual(str2, MarketConst.LAST_OPEN_PRICE);
        Pair[] pairArr = new Pair[1];
        pairArr[0] = z10 ? TuplesKt.to(MarketConst.CURRENCY_EXCHANGE, 1) : TuplesKt.to(MarketConst.CURRENCY_EXCHANGE, 0);
        GTDataFinder.postEvent(MarketConst.MARKET_DATA_FINDER_EVENT_HOME_MARKET_EDIT_CLICK, (Map<String, ? extends Object>) MapsKt__MapsKt.mutableMapOf(pairArr));
        Pair[] pairArr2 = new Pair[1];
        pairArr2[0] = !z10 ? TuplesKt.to("last_price_opening_price", 1) : TuplesKt.to("last_price_opening_price", 0);
        GTDataFinder.postEvent(MarketConst.MARKET_DATA_FINDER_EVENT_HOME_MARKET_EDIT_CLICK, (Map<String, ? extends Object>) MapsKt__MapsKt.mutableMapOf(pairArr2));
        return true;
    }

    @NotNull
    public final Application getContext() {
        Application application = context;
        if (application != null) {
            return application;
        }
        return null;
    }

    @NotNull
    public final BaseBizDataBridge getDataBridge() {
        BaseBizDataBridge baseBizDataBridge = dataBridge;
        if (baseBizDataBridge != null) {
            return baseBizDataBridge;
        }
        return null;
    }

    @Nullable
    public final Function0<String> getWebBaseUrlProvider$biz_base_core_release() {
        return webBaseUrlProvider;
    }

    public final void setContext$biz_base_core_release(@NotNull Application application) {
        context = application;
    }

    public final void setDataBridge$biz_base_core_release(@NotNull BaseBizDataBridge baseBizDataBridge) {
        dataBridge = baseBizDataBridge;
    }

    public final void setWebBaseUrlProvider$biz_base_core_release(@Nullable Function0<String> function0) {
        webBaseUrlProvider = function0;
    }

    @JvmStatic
    public static /* synthetic */ void isDebug$annotations() {
    }
}