package com.gateio.biz.base.router.flutter_box;

import kotlin.jvm.functions.Function3;

/* compiled from: R8$$SyntheticClass */
/* loaded from: classes37.dex */
public final /* synthetic */ class a implements Function3 {
    @Override // kotlin.jvm.functions.Function3
    public final Object invoke(Object obj, Object obj2, Object obj3) {
        return this.f10995a.lambda$new$0((String) obj, (String) obj2, (String) obj3);
    }

    public /* synthetic */ a() {
    }
}