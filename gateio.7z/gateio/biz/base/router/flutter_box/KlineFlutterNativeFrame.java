package com.gateio.biz.base.router.flutter_box;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.view.animation.Interpolator;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import androidx.core.view.NestedScrollingChild2;
import androidx.core.view.NestedScrollingChildHelper;
import com.gateio.biz.base.router.flutter_box.KlineFlutterNativeFrame;
import com.gateio.flutter.lib_core.GTFlutterMessageCenter;
import com.gateio.lib.utils.json.GTJSONUtils;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: KlineFlutterNativeFrame.kt */
@Metadata(d1 = {"\u0000j\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0015\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\f\u0018\u00002\u00020\u00012\u00020\u0002:\u0001:B\u001b\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0006¢\u0006\u0002\u0010\u0007J\b\u0010\"\u001a\u00020\u001cH\u0002J4\u0010#\u001a\u00020\u00112\u0006\u0010$\u001a\u00020\u00152\u0006\u0010%\u001a\u00020\u00152\b\u0010\b\u001a\u0004\u0018\u00010\t2\b\u0010&\u001a\u0004\u0018\u00010\t2\u0006\u0010'\u001a\u00020\u0015H\u0016J:\u0010(\u001a\u00020\u00112\u0006\u0010)\u001a\u00020\u00152\u0006\u0010*\u001a\u00020\u00152\u0006\u0010+\u001a\u00020\u00152\u0006\u0010,\u001a\u00020\u00152\b\u0010&\u001a\u0004\u0018\u00010\t2\u0006\u0010'\u001a\u00020\u0015H\u0016J\u0010\u0010-\u001a\u00020\u00112\u0006\u0010.\u001a\u00020/H\u0016J\u0010\u00100\u001a\u00020\u00152\u0006\u0010.\u001a\u00020/H\u0002J\u0010\u00101\u001a\u00020\u00112\u0006\u0010'\u001a\u00020\u0015H\u0016J\u0010\u00102\u001a\u00020\u001c2\b\u00103\u001a\u0004\u0018\u00010\u001bJ\b\u00104\u001a\u00020\u001cH\u0014J\b\u00105\u001a\u00020\u001cH\u0014J\b\u00106\u001a\u00020\u001cH\u0002J\u0018\u00107\u001a\u00020\u00112\u0006\u00108\u001a\u00020\u00152\u0006\u0010'\u001a\u00020\u0015H\u0016J\u0010\u00109\u001a\u00020\u001c2\u0006\u0010'\u001a\u00020\u0015H\u0016R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\rX\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u000fR\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\u0017\u001a\u00060\u0018R\u00020\u0000X\u0082\u0004¢\u0006\u0002\n\u0000R(\u0010\u0019\u001a\u001c\u0012\u0006\u0012\u0004\u0018\u00010\u001b\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u001b\u0012\u0004\u0012\u00020\u001c0\u001aX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u001d\u001a\u0004\u0018\u00010\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010 \u001a\u0004\u0018\u00010!X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006;"}, d2 = {"Lcom/gateio/biz/base/router/flutter_box/KlineFlutterNativeFrame;", "Landroid/widget/FrameLayout;", "Landroidx/core/view/NestedScrollingChild2;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "consumed", "", "helper", "Landroidx/core/view/NestedScrollingChildHelper;", "initXy", "", "", "[Ljava/lang/Float;", "isFlutterTop", "", "isParentMove", "mLastMotionY", "mMaxFlingVelocity", "", "mNestedOffsets", "mViewFling", "Lcom/gateio/biz/base/router/flutter_box/KlineFlutterNativeFrame$ViewFling;", "messageCenterListener", "Lkotlin/Function3;", "", "", "pageTag", "scaledTouchSlop", "scrollOrientation", "velocityTracker", "Landroid/view/VelocityTracker;", "addMessageListener", "dispatchNestedPreScroll", "dx", "dy", "offsetInWindow", "type", "dispatchNestedScroll", "dxConsumed", "dyConsumed", "dxUnconsumed", "dyUnconsumed", "dispatchTouchEvent", "ev", "Landroid/view/MotionEvent;", "draggedOrientation", "hasNestedScrollingParent", "initView", "flutterPageTag", "onAttachedToWindow", "onDetachedFromWindow", "removeMessageListener", "startNestedScroll", "axes", "stopNestedScroll", "ViewFling", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public final class KlineFlutterNativeFrame extends FrameLayout implements NestedScrollingChild2 {

    @NotNull
    private final int[] consumed;

    @NotNull
    private final NestedScrollingChildHelper helper;

    @NotNull
    private final Float[] initXy;
    private boolean isFlutterTop;
    private boolean isParentMove;
    private float mLastMotionY;
    private final int mMaxFlingVelocity;

    @NotNull
    private final int[] mNestedOffsets;

    @NotNull
    private final ViewFling mViewFling;

    @NotNull
    private final Function3<String, String, String, Unit> messageCenterListener;

    @Nullable
    private String pageTag;
    private final int scaledTouchSlop;
    private int scrollOrientation;

    @Nullable
    private VelocityTracker velocityTracker;

    /* JADX INFO: Access modifiers changed from: private */
    /* compiled from: KlineFlutterNativeFrame.kt */
    @Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u0015\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0005\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0016\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u0004J\b\u0010\u0019\u001a\u00020\u0016H\u0016J\u0006\u0010\u001a\u001a\u00020\u0016R\u001a\u0010\u0003\u001a\u00020\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u000e\u0010\t\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\u000b\u001a\u00020\f¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014¨\u0006\u001b"}, d2 = {"Lcom/gateio/biz/base/router/flutter_box/KlineFlutterNativeFrame$ViewFling;", "Ljava/lang/Runnable;", "(Lcom/gateio/biz/base/router/flutter_box/KlineFlutterNativeFrame;)V", "lastY", "", "getLastY", "()I", "setLastY", "(I)V", "noTouchConsume", "", "sQuinticInterpolator", "Landroid/view/animation/Interpolator;", "getSQuinticInterpolator", "()Landroid/view/animation/Interpolator;", "scroller", "Landroid/widget/OverScroller;", "getScroller", "()Landroid/widget/OverScroller;", "setScroller", "(Landroid/widget/OverScroller;)V", "fling", "", "velocityX", "velocityY", "run", "stop", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    final class ViewFling implements Runnable {
        private int lastY;

        @NotNull
        private final int[] noTouchConsume;

        @NotNull
        private final Interpolator sQuinticInterpolator;

        @NotNull
        private OverScroller scroller;

        public final void fling(int velocityX, int velocityY) {
            this.lastY = 0;
            if (KlineFlutterNativeFrame.this.startNestedScroll(2, 1)) {
                this.scroller.fling(0, 0, velocityX, velocityY, Integer.MIN_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MAX_VALUE);
                KlineFlutterNativeFrame.this.postOnAnimation(this);
            }
        }

        public ViewFling() {
            Interpolator interpolator = new Interpolator() { // from class: com.gateio.biz.base.router.flutter_box.b
                @Override // android.animation.TimeInterpolator
                public final float getInterpolation(float f10) {
                    return KlineFlutterNativeFrame.ViewFling.sQuinticInterpolator$lambda$0(f10);
                }
            };
            this.sQuinticInterpolator = interpolator;
            this.scroller = new OverScroller(KlineFlutterNativeFrame.this.getContext(), interpolator);
            this.noTouchConsume = new int[]{0, 0};
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final float sQuinticInterpolator$lambda$0(float f10) {
            float f11 = f10 - 1.0f;
            return (f11 * f11 * f11 * f11 * f11) + 1.0f;
        }

        public final int getLastY() {
            return this.lastY;
        }

        @NotNull
        public final Interpolator getSQuinticInterpolator() {
            return this.sQuinticInterpolator;
        }

        @NotNull
        public final OverScroller getScroller() {
            return this.scroller;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (!this.scroller.computeScrollOffset()) {
                KlineFlutterNativeFrame.this.helper.stopNestedScroll(1);
                return;
            }
            int currY = this.scroller.getCurrY();
            int i10 = currY - this.lastY;
            this.lastY = currY;
            int[] iArr = this.noTouchConsume;
            iArr[0] = 0;
            iArr[1] = 0;
            KlineFlutterNativeFrame.this.helper.dispatchNestedPreScroll(0, i10, this.noTouchConsume, null, 1);
            if (this.noTouchConsume[1] == 0) {
                KlineFlutterNativeFrame.this.helper.dispatchNestedScroll(0, i10, 0, i10, null, 1);
            }
            KlineFlutterNativeFrame.this.postOnAnimation(this);
        }

        public final void setLastY(int i10) {
            this.lastY = i10;
        }

        public final void setScroller(@NotNull OverScroller overScroller) {
            this.scroller = overScroller;
        }

        public final void stop() {
            this.scroller.abortAnimation();
            KlineFlutterNativeFrame.this.helper.stopNestedScroll(1);
        }
    }

    @JvmOverloads
    public KlineFlutterNativeFrame(@NotNull Context context) {
        this(context, null, 2, 0 == true ? 1 : 0);
    }

    public /* synthetic */ KlineFlutterNativeFrame(Context context, AttributeSet attributeSet, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, (i10 & 2) != 0 ? null : attributeSet);
    }

    private final void addMessageListener() {
        GTFlutterMessageCenter.addListener(FlutterInNativeScrollChannelEvent.flutterScrollToTop, this.messageCenterListener);
        GTFlutterMessageCenter.addListener(FlutterInNativeScrollChannelEvent.flutterScrollNotTop, this.messageCenterListener);
    }

    private final void removeMessageListener() {
        GTFlutterMessageCenter.removeListener(FlutterInNativeScrollChannelEvent.flutterScrollToTop, this.messageCenterListener);
        GTFlutterMessageCenter.removeListener(FlutterInNativeScrollChannelEvent.flutterScrollNotTop, this.messageCenterListener);
    }

    @Override // androidx.core.view.NestedScrollingChild2
    public boolean dispatchNestedPreScroll(int dx, int dy, @Nullable int[] consumed, @Nullable int[] offsetInWindow, int type) {
        return this.helper.dispatchNestedPreScroll(dx, dy, consumed, offsetInWindow, type);
    }

    @Override // androidx.core.view.NestedScrollingChild2
    public boolean dispatchNestedScroll(int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed, @Nullable int[] offsetInWindow, int type) {
        return this.helper.dispatchNestedScroll(dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed, offsetInWindow, type);
    }

    @Override // androidx.core.view.NestedScrollingChild2
    public boolean hasNestedScrollingParent(int type) {
        return this.helper.hasNestedScrollingParent(type);
    }

    public final void initView(@Nullable String flutterPageTag) {
        this.pageTag = flutterPageTag;
    }

    @Override // androidx.core.view.NestedScrollingChild2
    public boolean startNestedScroll(int axes, int type) {
        return this.helper.startNestedScroll(axes, type);
    }

    @Override // androidx.core.view.NestedScrollingChild2
    public void stopNestedScroll(int type) {
        this.helper.stopNestedScroll(type);
    }

    @JvmOverloads
    public KlineFlutterNativeFrame(@NotNull Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        this.isFlutterTop = true;
        this.pageTag = "";
        NestedScrollingChildHelper nestedScrollingChildHelper = new NestedScrollingChildHelper(this);
        nestedScrollingChildHelper.setNestedScrollingEnabled(true);
        this.helper = nestedScrollingChildHelper;
        this.consumed = new int[]{0, 0};
        this.mNestedOffsets = new int[2];
        this.mMaxFlingVelocity = ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
        this.scaledTouchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        Float fValueOf = Float.valueOf(0.0f);
        this.initXy = new Float[]{fValueOf, fValueOf};
        this.mViewFling = new ViewFling();
        this.messageCenterListener = new Function3<String, String, String, Unit>() { // from class: com.gateio.biz.base.router.flutter_box.KlineFlutterNativeFrame$messageCenterListener$1
            @Override // kotlin.jvm.functions.Function3
            public /* bridge */ /* synthetic */ Unit invoke(String str, String str2, String str3) {
                invoke2(str, str2, str3);
                return Unit.INSTANCE;
            }

            {
                super(3);
            }

            /* renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@Nullable String str, @NotNull String str2, @NotNull String str3) {
                FlutterInNativeScrollChannelEventParams flutterInNativeScrollChannelEventParams = (FlutterInNativeScrollChannelEventParams) GTJSONUtils.fromJson(str3, FlutterInNativeScrollChannelEventParams.class);
                if (flutterInNativeScrollChannelEventParams == null || !Intrinsics.areEqual(flutterInNativeScrollChannelEventParams.pageTag, this.this$0.pageTag)) {
                    return;
                }
                if (Intrinsics.areEqual(str2, "flutterScrollToTop")) {
                    this.this$0.isFlutterTop = true;
                } else if (Intrinsics.areEqual(str2, "flutterScrollNotTop")) {
                    this.this$0.isFlutterTop = false;
                }
            }
        };
    }

    private final int draggedOrientation(MotionEvent ev) {
        int i10 = 1;
        if (ev.getAction() == 0) {
            this.scrollOrientation = 0;
            this.initXy[0] = Float.valueOf(ev.getX());
            this.initXy[1] = Float.valueOf(ev.getY());
        } else if (this.scrollOrientation == 0) {
            float x10 = ev.getX() - this.initXy[0].floatValue();
            float y10 = ev.getY() - this.initXy[1].floatValue();
            if (Math.abs(x10) > this.scaledTouchSlop || Math.abs(y10) > this.scaledTouchSlop) {
                if (Math.abs(x10) <= Math.abs(y10)) {
                    i10 = 2;
                }
                this.scrollOrientation = i10;
            }
        }
        return this.scrollOrientation;
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchTouchEvent(@NotNull MotionEvent ev) {
        boolean z10;
        int yVelocity;
        int iDraggedOrientation = draggedOrientation(ev);
        MotionEvent motionEventObtain = MotionEvent.obtain(ev);
        boolean z11 = false;
        if (ev.getAction() == 0) {
            this.mViewFling.stop();
            this.velocityTracker = VelocityTracker.obtain();
            int[] iArr = this.consumed;
            iArr[0] = 0;
            iArr[1] = 0;
            int[] iArr2 = this.mNestedOffsets;
            iArr2[0] = 0;
            iArr2[1] = 0;
            this.isParentMove = false;
        }
        int[] iArr3 = this.mNestedOffsets;
        motionEventObtain.offsetLocation(iArr3[0], iArr3[1]);
        VelocityTracker velocityTracker = this.velocityTracker;
        if (velocityTracker != null) {
            velocityTracker.addMovement(motionEventObtain);
        }
        int action = ev.getAction();
        if (action != 0) {
            if (action != 1) {
                if (action != 2) {
                    if (action == 3) {
                        VelocityTracker velocityTracker2 = this.velocityTracker;
                        if (velocityTracker2 != null) {
                            velocityTracker2.recycle();
                        }
                        this.velocityTracker = null;
                        this.helper.stopNestedScroll(0);
                    }
                } else {
                    float rawY = this.mLastMotionY - ev.getRawY();
                    int[] iArr4 = this.consumed;
                    iArr4[0] = 0;
                    iArr4[1] = 0;
                    if (iDraggedOrientation == 2 && rawY > 0.0f) {
                        if (this.helper.dispatchNestedPreScroll(0, (int) rawY, iArr4, null, 0) && this.consumed[1] != 0) {
                            this.isParentMove = true;
                            z10 = true;
                        }
                        z10 = false;
                    } else {
                        if (iDraggedOrientation == 2 && this.isFlutterTop) {
                            int i10 = (int) rawY;
                            this.helper.dispatchNestedScroll(0, i10, 0, i10, null, 0, iArr4);
                            this.isParentMove = true;
                            z10 = true;
                        }
                        z10 = false;
                    }
                    int[] iArr5 = this.mNestedOffsets;
                    int i11 = iArr5[0];
                    int[] iArr6 = this.consumed;
                    iArr5[0] = i11 + iArr6[0];
                    iArr5[1] = iArr5[1] + iArr6[1];
                    this.mLastMotionY = ev.getRawY();
                }
            } else {
                VelocityTracker velocityTracker3 = this.velocityTracker;
                if (velocityTracker3 != null) {
                    velocityTracker3.computeCurrentVelocity(1000, this.mMaxFlingVelocity);
                }
                if (iDraggedOrientation == 2 && this.isFlutterTop) {
                    ViewFling viewFling = this.mViewFling;
                    VelocityTracker velocityTracker4 = this.velocityTracker;
                    if (velocityTracker4 != null) {
                        yVelocity = (int) velocityTracker4.getYVelocity();
                    } else {
                        yVelocity = 0;
                    }
                    viewFling.fling(0, yVelocity);
                }
                VelocityTracker velocityTracker5 = this.velocityTracker;
                if (velocityTracker5 != null) {
                    velocityTracker5.recycle();
                }
                this.velocityTracker = null;
                if (this.isParentMove) {
                    ev.setAction(3);
                    super.dispatchTouchEvent(ev);
                    ev.setAction(1);
                    z10 = true;
                } else {
                    z10 = false;
                }
                this.helper.stopNestedScroll(0);
            }
            z11 = z10;
        } else {
            this.mLastMotionY = ev.getRawY();
            getParent().requestDisallowInterceptTouchEvent(true);
            this.helper.startNestedScroll(2, 0);
        }
        if (!z11) {
            super.dispatchTouchEvent(ev);
        }
        motionEventObtain.recycle();
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        addMessageListener();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        removeMessageListener();
        super.onDetachedFromWindow();
    }
}