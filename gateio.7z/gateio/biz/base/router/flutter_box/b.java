package com.gateio.biz.base.router.flutter_box;

import android.view.animation.Interpolator;
import com.gateio.biz.base.router.flutter_box.KlineFlutterNativeFrame;

/* compiled from: R8$$SyntheticClass */
/* loaded from: classes37.dex */
public final /* synthetic */ class b implements Interpolator {
    @Override // android.animation.TimeInterpolator
    public final float getInterpolation(float f10) {
        return KlineFlutterNativeFrame.ViewFling.sQuinticInterpolator$lambda$0(f10);
    }
}