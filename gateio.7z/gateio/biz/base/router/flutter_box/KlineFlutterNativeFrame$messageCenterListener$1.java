package com.gateio.biz.base.router.flutter_box;

import com.gateio.lib.utils.json.GTJSONUtils;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: KlineFlutterNativeFrame.kt */
@Metadata(d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\u0010\u0000\u001a\u00020\u00012\b\u0010\u0002\u001a\u0004\u0018\u00010\u00032\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u0003H\n¢\u0006\u0002\b\u0006"}, d2 = {"<anonymous>", "", "actionType", "", "actionName", "messageJson", "invoke"}, k = 3, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
final class KlineFlutterNativeFrame$messageCenterListener$1 extends Lambda implements Function3<String, String, String, Unit> {
    @Override // kotlin.jvm.functions.Function3
    public /* bridge */ /* synthetic */ Unit invoke(String str, String str2, String str3) {
        invoke2(str, str2, str3);
        return Unit.INSTANCE;
    }

    KlineFlutterNativeFrame$messageCenterListener$1() {
        super(3);
    }

    /* renamed from: invoke */
    public final void invoke2(@Nullable String str, @NotNull String str2, @NotNull String str3) {
        FlutterInNativeScrollChannelEventParams flutterInNativeScrollChannelEventParams = (FlutterInNativeScrollChannelEventParams) GTJSONUtils.fromJson(str3, FlutterInNativeScrollChannelEventParams.class);
        if (flutterInNativeScrollChannelEventParams == null || !Intrinsics.areEqual(flutterInNativeScrollChannelEventParams.pageTag, this.this$0.pageTag)) {
            return;
        }
        if (Intrinsics.areEqual(str2, "flutterScrollToTop")) {
            this.this$0.isFlutterTop = true;
        } else if (Intrinsics.areEqual(str2, "flutterScrollNotTop")) {
            this.this$0.isFlutterTop = false;
        }
    }
}