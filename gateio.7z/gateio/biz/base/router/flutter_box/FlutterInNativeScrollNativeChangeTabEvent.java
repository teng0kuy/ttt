package com.gateio.biz.base.router.flutter_box;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* compiled from: FlutterInNativeScrollChannelEvent.kt */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0004\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\t¨\u0006\n"}, d2 = {"Lcom/gateio/biz/base/router/flutter_box/FlutterInNativeScrollNativeChangeTabEvent;", "", "pageTag", "", "isNativeInTop", "", "(Ljava/lang/String;Z)V", "()Z", "getPageTag", "()Ljava/lang/String;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public final class FlutterInNativeScrollNativeChangeTabEvent {
    private final boolean isNativeInTop;

    @NotNull
    private final String pageTag;

    @NotNull
    public final String getPageTag() {
        return this.pageTag;
    }

    /* renamed from: isNativeInTop, reason: from getter */
    public final boolean getIsNativeInTop() {
        return this.isNativeInTop;
    }

    public FlutterInNativeScrollNativeChangeTabEvent(@NotNull String str, boolean z10) {
        this.pageTag = str;
        this.isNativeInTop = z10;
    }
}