package com.gateio.biz.base.router.flutter_box;

import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import org.jetbrains.annotations.NotNull;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: FlutterInNativeScrollChannelEvent.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/base/router/flutter_box/FlutterInNativeScrollChannelEvent;", "", "(Ljava/lang/String;I)V", "flutterScrollToTop", "flutterScrollNotTop", "nativeChangeToCurrentTab", "nativeMakeFlutterScrollTop", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public final class FlutterInNativeScrollChannelEvent {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ FlutterInNativeScrollChannelEvent[] $VALUES;
    public static final FlutterInNativeScrollChannelEvent flutterScrollToTop = new FlutterInNativeScrollChannelEvent("flutterScrollToTop", 0);
    public static final FlutterInNativeScrollChannelEvent flutterScrollNotTop = new FlutterInNativeScrollChannelEvent("flutterScrollNotTop", 1);
    public static final FlutterInNativeScrollChannelEvent nativeChangeToCurrentTab = new FlutterInNativeScrollChannelEvent("nativeChangeToCurrentTab", 2);
    public static final FlutterInNativeScrollChannelEvent nativeMakeFlutterScrollTop = new FlutterInNativeScrollChannelEvent("nativeMakeFlutterScrollTop", 3);

    private static final /* synthetic */ FlutterInNativeScrollChannelEvent[] $values() {
        return new FlutterInNativeScrollChannelEvent[]{flutterScrollToTop, flutterScrollNotTop, nativeChangeToCurrentTab, nativeMakeFlutterScrollTop};
    }

    static {
        FlutterInNativeScrollChannelEvent[] flutterInNativeScrollChannelEventArr$values = $values();
        $VALUES = flutterInNativeScrollChannelEventArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(flutterInNativeScrollChannelEventArr$values);
    }

    @NotNull
    public static EnumEntries<FlutterInNativeScrollChannelEvent> getEntries() {
        return $ENTRIES;
    }

    public static FlutterInNativeScrollChannelEvent valueOf(String str) {
        return (FlutterInNativeScrollChannelEvent) Enum.valueOf(FlutterInNativeScrollChannelEvent.class, str);
    }

    public static FlutterInNativeScrollChannelEvent[] values() {
        return (FlutterInNativeScrollChannelEvent[]) $VALUES.clone();
    }

    private FlutterInNativeScrollChannelEvent(String str, int i10) {
    }
}