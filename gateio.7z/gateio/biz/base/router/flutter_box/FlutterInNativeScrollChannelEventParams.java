package com.gateio.biz.base.router.flutter_box;

/* compiled from: FlutterInNativeScrollView.java */
/* loaded from: classes37.dex */
class FlutterInNativeScrollChannelEventParams {
    String pageTag;

    FlutterInNativeScrollChannelEventParams() {
    }
}