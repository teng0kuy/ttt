package com.gateio.biz.base.router.flutter_box;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* compiled from: FlutterInNativeScrollChannelEvent.kt */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005¢\u0006\u0002\u0010\u0007R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0004\u0010\bR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u000b"}, d2 = {"Lcom/gateio/biz/base/router/flutter_box/FlutterInNativeScrollNativeScrollTopEvent;", "", "pageTag", "", "isScrollToTop", "", "isScrollUp", "(Ljava/lang/String;ZZ)V", "()Z", "getPageTag", "()Ljava/lang/String;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public final class FlutterInNativeScrollNativeScrollTopEvent {
    private final boolean isScrollToTop;
    private final boolean isScrollUp;

    @NotNull
    private final String pageTag;

    @NotNull
    public final String getPageTag() {
        return this.pageTag;
    }

    /* renamed from: isScrollToTop, reason: from getter */
    public final boolean getIsScrollToTop() {
        return this.isScrollToTop;
    }

    /* renamed from: isScrollUp, reason: from getter */
    public final boolean getIsScrollUp() {
        return this.isScrollUp;
    }

    public FlutterInNativeScrollNativeScrollTopEvent(@NotNull String str, boolean z10, boolean z11) {
        this.pageTag = str;
        this.isScrollToTop = z10;
        this.isScrollUp = z11;
    }
}