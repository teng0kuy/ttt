package com.gateio.biz.base.router.flutter_box;

import android.content.Context;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import com.gateio.biz.base.R;
import com.gateio.flutter.lib_core.GTFlutterMessageCenter;
import com.gateio.lib.utils.json.GTJSONUtils;
import java.util.HashMap;
import kotlin.Unit;
import kotlin.jvm.functions.Function3;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

/* loaded from: classes37.dex */
public class FlutterInNativeScrollView extends NestedScrollView {
    GestureDetector gestureDetector;
    private boolean isFlutterTop;
    private boolean isHorizontalScroll;
    boolean isInterceptWhenDown;
    private boolean isNativeTop;
    boolean isScrollingDown;
    private boolean isVerticalScroll;
    private final Function3<String, String, String, Unit> messageCenterListener;
    private String pageTag;
    int touchSlop;

    public FlutterInNativeScrollView(@NonNull Context context) {
        this(context, null);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(FlutterInNativeScrollNativeScrollTopEvent flutterInNativeScrollNativeScrollTopEvent) {
        if (flutterInNativeScrollNativeScrollTopEvent.getPageTag().equals(this.pageTag)) {
            this.isNativeTop = flutterInNativeScrollNativeScrollTopEvent.getIsScrollToTop();
        }
    }

    public FlutterInNativeScrollView(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.nestedScrollViewStyle);
    }

    private void addMessageListener() {
        GTFlutterMessageCenter.addListener(FlutterInNativeScrollChannelEvent.flutterScrollToTop, this.messageCenterListener);
        GTFlutterMessageCenter.addListener(FlutterInNativeScrollChannelEvent.flutterScrollNotTop, this.messageCenterListener);
        EventBus.getDefault().register(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ Unit lambda$new$0(String str, String str2, String str3) {
        FlutterInNativeScrollChannelEventParams flutterInNativeScrollChannelEventParams = (FlutterInNativeScrollChannelEventParams) GTJSONUtils.fromJson(str3, FlutterInNativeScrollChannelEventParams.class);
        if (flutterInNativeScrollChannelEventParams != null && flutterInNativeScrollChannelEventParams.pageTag.equals(this.pageTag)) {
            if (str2.equals(FlutterInNativeScrollChannelEvent.flutterScrollToTop.name())) {
                this.isFlutterTop = true;
            } else if (str2.equals(FlutterInNativeScrollChannelEvent.flutterScrollNotTop.name())) {
                this.isFlutterTop = false;
            }
        }
        return null;
    }

    private void removeMessageListener() {
        GTFlutterMessageCenter.removeListener(FlutterInNativeScrollChannelEvent.flutterScrollToTop, this.messageCenterListener);
        GTFlutterMessageCenter.removeListener(FlutterInNativeScrollChannelEvent.flutterScrollNotTop, this.messageCenterListener);
        EventBus.getDefault().unregister(this);
    }

    public void initView(String str) {
        this.pageTag = str;
    }

    public FlutterInNativeScrollView(@NonNull Context context, @Nullable AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.pageTag = "";
        this.isFlutterTop = true;
        this.isNativeTop = false;
        this.isInterceptWhenDown = false;
        this.isHorizontalScroll = false;
        this.isVerticalScroll = false;
        this.messageCenterListener = new Function3() { // from class: com.gateio.biz.base.router.flutter_box.a
            @Override // kotlin.jvm.functions.Function3
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return this.f10995a.lambda$new$0((String) obj, (String) obj2, (String) obj3);
            }
        };
        initScrollGesture(context);
    }

    void initScrollGesture(Context context) {
        this.touchSlop = ViewConfiguration.get(getContext()).getScaledTouchSlop();
        this.gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() { // from class: com.gateio.biz.base.router.flutter_box.FlutterInNativeScrollView.1
            @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
            public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f10, float f11) {
                FlutterInNativeScrollView flutterInNativeScrollView = FlutterInNativeScrollView.this;
                flutterInNativeScrollView.isScrollingDown = f11 < 0.0f;
                if (!flutterInNativeScrollView.isHorizontalScroll && !FlutterInNativeScrollView.this.isVerticalScroll) {
                    if (Math.abs(f10) > FlutterInNativeScrollView.this.touchSlop && Math.abs(f10) > Math.abs(f11)) {
                        FlutterInNativeScrollView.this.isHorizontalScroll = true;
                    } else if (Math.abs(f11) > FlutterInNativeScrollView.this.touchSlop && Math.abs(f11) > Math.abs(f10)) {
                        FlutterInNativeScrollView.this.isVerticalScroll = true;
                    }
                }
                FlutterInNativeScrollView flutterInNativeScrollView2 = FlutterInNativeScrollView.this;
                if (flutterInNativeScrollView2.isScrollingDown && flutterInNativeScrollView2.isVerticalScroll && FlutterInNativeScrollView.this.isFlutterTop && !FlutterInNativeScrollView.this.isInterceptWhenDown) {
                    EventBus.getDefault().post(new FlutterInNativeScrollBoxTopMoveEvent(FlutterInNativeScrollView.this.pageTag, -f11));
                }
                return true;
            }
        });
    }

    @Override // androidx.core.widget.NestedScrollView, android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        addMessageListener();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        removeMessageListener();
        super.onDetachedFromWindow();
    }

    @Override // androidx.core.widget.NestedScrollView, android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z10;
        int action = motionEvent.getAction();
        if (action == 0 || action == 1 || action == 3) {
            this.isHorizontalScroll = false;
            this.isVerticalScroll = false;
        }
        this.gestureDetector.onTouchEvent(motionEvent);
        getParent().requestDisallowInterceptTouchEvent(true);
        if (this.isHorizontalScroll) {
            return false;
        }
        if (this.isNativeTop && (!this.isFlutterTop || !this.isScrollingDown)) {
            z10 = false;
        } else {
            z10 = true;
        }
        if (z10) {
            if (motionEvent.getAction() == 0) {
                this.isInterceptWhenDown = true;
            }
            return super.onInterceptTouchEvent(motionEvent);
        }
        if (motionEvent.getAction() == 0) {
            this.isInterceptWhenDown = false;
        }
        return false;
    }

    @Subscribe(sticky = true, threadMode = ThreadMode.MAIN)
    public void onMessageEvent(FlutterInNativeScrollNativeChangeTabEvent flutterInNativeScrollNativeChangeTabEvent) {
        if (flutterInNativeScrollNativeChangeTabEvent.getPageTag().equals(this.pageTag)) {
            this.isNativeTop = flutterInNativeScrollNativeChangeTabEvent.getIsNativeInTop();
            HashMap map = new HashMap();
            map.put("pageTag", this.pageTag);
            GTFlutterMessageCenter.sendMessage(FlutterInNativeScrollChannelEvent.nativeChangeToCurrentTab, map);
        }
    }
}