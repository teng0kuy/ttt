package com.gateio.biz.base.router.provider;

import com.alibaba.android.arouter.facade.template.IProvider;
import kotlin.Metadata;
import org.jetbrains.annotations.Nullable;

/* compiled from: FuturesDexUserUtilService.kt */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\bf\u0018\u00002\u00020\u0001J\n\u0010\u0002\u001a\u0004\u0018\u00010\u0003H&J\n\u0010\u0004\u001a\u0004\u0018\u00010\u0003H&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0005À\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/router/provider/FuturesDexUserUtilService;", "Lcom/alibaba/android/arouter/facade/template/IProvider;", "getEthereumAddress", "", "getWs", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public interface FuturesDexUserUtilService extends IProvider {
    @Nullable
    String getEthereumAddress();

    @Nullable
    String getWs();
}