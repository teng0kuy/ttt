package com.gateio.biz.base.router.provider;

import android.content.Context;
import android.os.Bundle;
import com.alibaba.android.arouter.facade.template.IProvider;
import com.ap.zoloz.hummer.biz.HummerConstants;
import com.gateio.biz.base.model.CurrencyData;
import com.gateio.biz.base.router.RouterConst;
import com.gateio.common.listener.ISuccessCallBack;
import com.gateio.lib.router.GTRouter;
import com.gateio.rxjava.basemvp.IBaseView;
import com.google.firebase.analytics.FirebaseAnalytics;
import io.reactivex.rxjava3.core.s;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: FuturesApi.kt */
@Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0012\bf\u0018\u0000 ,2\u00020\u0001:\u0001,J8\u0010\f\u001a\u00020\u000b2\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u0006H&J0\u0010\u000f\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0004H&J\u0010\u0010\u0011\u001a\u00020\u00042\u0006\u0010\u0010\u001a\u00020\u0004H&J\u0010\u0010\u0012\u001a\u00020\u00042\u0006\u0010\u0010\u001a\u00020\u0004H&J\"\u0010\u0017\u001a\u00020\u000b2\n\u0010\u0014\u001a\u0006\u0012\u0002\b\u00030\u00132\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00040\u0015H&J*\u0010\u0017\u001a\u00020\u000b2\n\u0010\u0014\u001a\u0006\u0012\u0002\b\u00030\u00132\u0006\u0010\u0018\u001a\u00020\u00062\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00040\u0015H&J\u0016\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001a2\u0006\u0010\u0019\u001a\u00020\u0004H&J\u0018\u0010\u001f\u001a\u00020\u000b2\u0006\u0010\u001d\u001a\u00020\u00022\u0006\u0010\u001e\u001a\u00020\u0004H&J \u0010\u001f\u001a\u00020\u000b2\u0006\u0010\u001d\u001a\u00020\u00022\u0006\u0010\u001e\u001a\u00020\u00042\u0006\u0010 \u001a\u00020\u0006H&J\b\u0010!\u001a\u00020\u000bH&J\b\u0010\"\u001a\u00020\u0006H&J\u0018\u0010$\u001a\u00020\u000b2\u0006\u0010\b\u001a\u00020\u00062\u0006\u0010#\u001a\u00020\u0004H&J\u0010\u0010&\u001a\u00020\u000b2\u0006\u0010%\u001a\u00020\u0006H&J\"\u0010'\u001a\u00020\u000b2\n\u0010\u0014\u001a\u0006\u0012\u0002\b\u00030\u00132\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00040\u0015H&J*\u0010+\u001a\u00020\u000b2\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010(\u001a\u00020\u00042\u0006\u0010)\u001a\u00020\u00042\b\u0010*\u001a\u0004\u0018\u00010\u0004H&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006-À\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/router/provider/FuturesApi;", "Lcom/alibaba/android/arouter/facade/template/IProvider;", "Landroid/content/Context;", "context", "", "contract", "", "isTestNet", "isDelivery", "closeUnit", "isNeedLocateTab", "", "showKDiagramActivity", "Landroid/os/Bundle;", HummerConstants.BUNDLE, "kLinePairSubject", "amount", "formatNumberK", "thousandthsChange", "Lcom/gateio/rxjava/basemvp/IBaseView;", "iBaseView", "Lcom/gateio/common/listener/ISuccessCallBack;", "iSuccessCallBack", "getDeliveryList", "isLoading", "currencyType", "Lio/reactivex/rxjava3/core/s;", "Lcom/gateio/biz/base/model/CurrencyData;", "getLiteCurrencies", "activity", "url", "playVideo", "repeat", "toChatRoom", "shouldShowPromotionEntry", FirebaseAnalytics.Param.ITEM_ID, "selectContent", "isBtc", "firstTradeComplete", "copyLeaderStatus", "router", "exchangeEnv", "customMarket", "gotoFuturesRule", "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0})
/* loaded from: classes37.dex */
public interface FuturesApi extends IProvider {

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = Companion.$$INSTANCE;

    /* compiled from: FuturesApi.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0003\u001a\u00020\u0004¨\u0006\u0005"}, d2 = {"Lcom/gateio/biz/base/router/provider/FuturesApi$Companion;", "", "()V", "get", "Lcom/gateio/biz/base/router/provider/FuturesApi;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Companion {
        static final /* synthetic */ Companion $$INSTANCE = new Companion();

        private Companion() {
        }

        @NotNull
        public final FuturesApi get() {
            return (FuturesApi) GTRouter.serviceAPI(RouterConst.App.APP_FUTURES);
        }
    }

    void copyLeaderStatus(@NotNull IBaseView<?> iBaseView, @NotNull ISuccessCallBack<String> iSuccessCallBack);

    void firstTradeComplete(boolean isBtc);

    @NotNull
    String formatNumberK(@NotNull String amount);

    void getDeliveryList(@NotNull IBaseView<?> iBaseView, @NotNull ISuccessCallBack<String> iSuccessCallBack);

    void getDeliveryList(@NotNull IBaseView<?> iBaseView, boolean isLoading, @NotNull ISuccessCallBack<String> iSuccessCallBack);

    @NotNull
    s<CurrencyData> getLiteCurrencies(@NotNull String currencyType);

    void gotoFuturesRule(@NotNull Context context, @NotNull String router, @NotNull String exchangeEnv, @Nullable String customMarket);

    void kLinePairSubject(@NotNull Bundle bundle, boolean isTestNet, boolean isDelivery, @NotNull String closeUnit, @NotNull String contract);

    void playVideo(@NotNull Context activity, @NotNull String url);

    void playVideo(@NotNull Context activity, @NotNull String url, boolean repeat);

    void selectContent(boolean isDelivery, @NotNull String item_id);

    boolean shouldShowPromotionEntry();

    void showKDiagramActivity(@NotNull Context context, @NotNull String contract, boolean isTestNet, boolean isDelivery, @NotNull String closeUnit, boolean isNeedLocateTab);

    @NotNull
    String thousandthsChange(@NotNull String amount);

    void toChatRoom();
}