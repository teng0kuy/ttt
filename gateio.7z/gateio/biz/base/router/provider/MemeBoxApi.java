package com.gateio.biz.base.router.provider;

import android.content.Context;
import androidx.appcompat.app.AppCompatDialogFragment;
import androidx.fragment.app.FragmentManager;
import com.alibaba.android.arouter.facade.template.IProvider;
import com.alipay.zoloz.toyger.ToygerService;
import com.gateio.biz.base.model.memebox.AlphaTPSLHeaderModel;
import com.gateio.biz.base.model.memebox.AlphaTPSLOptionBean;
import com.gateio.biz.base.model.memebox.MemeBoxJumpParams;
import com.gateio.biz.base.model.memebox.MemeBoxTokenInfoBean;
import com.gateio.biz.base.router.RouterConst;
import com.gateio.lib.router.GTRouter;
import com.tencent.qcloud.tuicore.TUIConstants;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: MemeBoxApi.kt */
@Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\bf\u0018\u0000  2\u00020\u0001:\u0001 J\u0018\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0005H&J\u001a\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\u0005H&JH\u0010\f\u001a\u00020\b2\u0006\u0010\r\u001a\u00020\u000e2\n\b\u0002\u0010\u000f\u001a\u0004\u0018\u00010\u00102\n\b\u0002\u0010\u0011\u001a\u0004\u0018\u00010\u00122\n\b\u0002\u0010\u0013\u001a\u0004\u0018\u00010\u00142\u0012\u0010\u0015\u001a\u000e\u0012\u0004\u0012\u00020\u0017\u0012\u0004\u0012\u00020\b0\u0016H&J\u0012\u0010\u0018\u001a\u00020\b2\b\u0010\u0019\u001a\u0004\u0018\u00010\u001aH&J\b\u0010\u001b\u001a\u00020\bH&J\u0018\u0010\u001c\u001a\u00020\b2\u0006\u0010\u001d\u001a\u00020\u00052\u0006\u0010\u001e\u001a\u00020\u0005H&J\u0012\u0010\u001f\u001a\u00020\b2\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005H&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006!À\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/router/provider/MemeBoxApi;", "Lcom/alibaba/android/arouter/facade/template/IProvider;", "getMemeBoxFastOrderDialogFragment", "Landroidx/appcompat/app/AppCompatDialogFragment;", "tokenPair", "", "currentPrice", "goAlphaPoint", "", "context", "Landroid/content/Context;", "source", "modifyTPSLDialogFragment", "fragmentManager", "Landroidx/fragment/app/FragmentManager;", "alphaTpslHeaderModel", "Lcom/gateio/biz/base/model/memebox/AlphaTPSLHeaderModel;", "alphaTPSLOptionBean", "Lcom/gateio/biz/base/model/memebox/AlphaTPSLOptionBean;", "memeBoxTokenInfoBean", "Lcom/gateio/biz/base/model/memebox/MemeBoxTokenInfoBean;", "callback", "Lkotlin/Function1;", "", TUIConstants.TUIGroupNotePlugin.PLUGIN_GROUP_NOTE_ENABLE_NOTIFICATION, "memeBoxJumpParams", "Lcom/gateio/biz/base/model/memebox/MemeBoxJumpParams;", "notifyDefault", "setSmartMoney", ToygerService.KEY_RES_9_KEY, "value", "updateFastSellCurrentPrice", "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public interface MemeBoxApi extends IProvider {

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = Companion.$$INSTANCE;

    /* compiled from: MemeBoxApi.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0003\u001a\u00020\u0004¨\u0006\u0005"}, d2 = {"Lcom/gateio/biz/base/router/provider/MemeBoxApi$Companion;", "", "()V", "newInstance", "Lcom/gateio/biz/base/router/provider/MemeBoxApi;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Companion {
        static final /* synthetic */ Companion $$INSTANCE = new Companion();

        private Companion() {
        }

        @NotNull
        public final MemeBoxApi newInstance() {
            return (MemeBoxApi) GTRouter.serviceAPI(RouterConst.MemeBox.PROVIDER);
        }
    }

    @NotNull
    AppCompatDialogFragment getMemeBoxFastOrderDialogFragment(@NotNull String tokenPair, @NotNull String currentPrice);

    void goAlphaPoint(@NotNull Context context, @Nullable String source);

    void modifyTPSLDialogFragment(@NotNull FragmentManager fragmentManager, @Nullable AlphaTPSLHeaderModel alphaTpslHeaderModel, @Nullable AlphaTPSLOptionBean alphaTPSLOptionBean, @Nullable MemeBoxTokenInfoBean memeBoxTokenInfoBean, @NotNull Function1<? super Boolean, Unit> callback);

    void notify(@Nullable MemeBoxJumpParams memeBoxJumpParams);

    void notifyDefault();

    void setSmartMoney(@NotNull String key, @NotNull String value);

    void updateFastSellCurrentPrice(@Nullable String currentPrice);

    static /* synthetic */ void modifyTPSLDialogFragment$default(MemeBoxApi memeBoxApi, FragmentManager fragmentManager, AlphaTPSLHeaderModel alphaTPSLHeaderModel, AlphaTPSLOptionBean alphaTPSLOptionBean, MemeBoxTokenInfoBean memeBoxTokenInfoBean, Function1 function1, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: modifyTPSLDialogFragment");
        }
        memeBoxApi.modifyTPSLDialogFragment(fragmentManager, (i10 & 2) != 0 ? null : alphaTPSLHeaderModel, (i10 & 4) != 0 ? null : alphaTPSLOptionBean, (i10 & 8) != 0 ? null : memeBoxTokenInfoBean, function1);
    }
}