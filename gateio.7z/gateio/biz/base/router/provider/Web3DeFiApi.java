package com.gateio.biz.base.router.provider;

import com.alibaba.android.arouter.facade.template.IProvider;
import com.gateio.biz.base.router.RouterConst;
import kotlin.Metadata;
import org.jetbrains.annotations.Nullable;

/* compiled from: Web3DeFiApi.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0002\bf\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H&J\n\u0010\u0004\u001a\u0004\u0018\u00010\u0005H&J\n\u0010\u0006\u001a\u0004\u0018\u00010\u0005H&J\n\u0010\u0007\u001a\u0004\u0018\u00010\u0005H&J\u0014\u0010\b\u001a\u0004\u0018\u00010\u00052\b\u0010\t\u001a\u0004\u0018\u00010\u0005H&J\b\u0010\n\u001a\u00020\u000bH&J\b\u0010\f\u001a\u00020\u000bH&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\rÀ\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/router/provider/Web3DeFiApi;", "Lcom/alibaba/android/arouter/facade/template/IProvider;", "clearToken", "", "getDefiPath", "", "getToken", "getUserId", "getWsUrl", RouterConst.AlertKey.PARAMS_SETTLE_KYE, "isDex", "", "isValid", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes5.dex */
public interface Web3DeFiApi extends IProvider {
    void clearToken();

    @Nullable
    String getDefiPath();

    @Nullable
    String getToken();

    @Nullable
    String getUserId();

    @Nullable
    String getWsUrl(@Nullable String settle);

    boolean isDex();

    boolean isValid();
}