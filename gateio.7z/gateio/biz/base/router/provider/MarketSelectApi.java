package com.gateio.biz.base.router.provider;

import androidx.fragment.app.FragmentManager;
import com.alibaba.android.arouter.facade.template.IProvider;
import com.gateio.biz.market.service.model.MarketSelectArea;
import com.gateio.biz.market.service.model.MarketTabsEnum;
import com.gateio.biz.market.service.model.MarketTradeSelectRequest;
import com.gateio.biz.market.service.model.MarketTradeSelectResult;
import com.gateio.biz.market.ui_market.MarketFragmentList;
import com.gateio.lib.network.result.GTHttpResultKotlin;
import java.util.List;
import kotlin.Deprecated;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.ReplaceWith;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function4;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: MarketSelectApi.kt */
@Metadata(d1 = {"\u0000l\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bf\u0018\u00002\u00020\u0001J,\u0010\u0002\u001a\u0018\u0012\u0012\u0012\u0010\u0012\u0004\u0012\u00020\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u0004\u0018\u00010\u00032\u0006\u0010\u0006\u001a\u00020\u0007H¦@¢\u0006\u0002\u0010\bJ:\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n2\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\f\u001a\u00020\u000b2\u0014\u0010\r\u001a\u0010\u0012\u0004\u0012\u00020\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u0004H¦@¢\u0006\u0002\u0010\u000eJN\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0006\u001a\u00020\u00072\b\u0010\u0011\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\u0012\u001a\u00020\u00132%\b\u0002\u0010\u0014\u001a\u001f\u0012\u0013\u0012\u00110\u0016¢\u0006\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b(\u0019\u0012\u0004\u0012\u00020\u0010\u0018\u00010\u0015H'¢\u0006\u0002\u0010\u001aJ\u008f\u0001\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0006\u001a\u00020\u00072\b\u0010\u0011\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\u0012\u001a\u00020\u00132f\u0010\u001b\u001ab\u0012\u0013\u0012\u00110\u0005¢\u0006\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b(\r\u0012\u0015\u0012\u0013\u0018\u00010\u0005¢\u0006\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b(\u001d\u0012\u0015\u0012\u0013\u0018\u00010\u001e¢\u0006\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b(\u001f\u0012\u0015\u0012\u0013\u0018\u00010\u0005¢\u0006\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b( \u0012\u0004\u0012\u00020\u00100\u001cH'¢\u0006\u0002\u0010!J\u0088\u0001\u0010\u000f\u001a\u00020\u00102\u0006\u0010\"\u001a\u00020#2\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0012\u001a\u00020\u00132f\u0010\u001b\u001ab\u0012\u0013\u0012\u00110\u0005¢\u0006\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b(\r\u0012\u0015\u0012\u0013\u0018\u00010\u0005¢\u0006\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b(\u001d\u0012\u0015\u0012\u0013\u0018\u00010\u001e¢\u0006\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b(\u001f\u0012\u0015\u0012\u0013\u0018\u00010\u0005¢\u0006\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b( \u0012\u0004\u0012\u00020\u00100\u001cH&J\u0097\u0001\u0010\u000f\u001a\u00020\u00102\u0006\u0010\"\u001a\u00020#2\u0006\u0010\u0006\u001a\u00020\u00072\b\u0010\u0011\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\u0012\u001a\u00020\u00132f\u0010\u001b\u001ab\u0012\u0013\u0012\u00110\u0005¢\u0006\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b(\r\u0012\u0015\u0012\u0013\u0018\u00010\u0005¢\u0006\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b(\u001d\u0012\u0015\u0012\u0013\u0018\u00010\u001e¢\u0006\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b(\u001f\u0012\u0015\u0012\u0013\u0018\u00010\u0005¢\u0006\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b( \u0012\u0004\u0012\u00020\u00100\u001cH'¢\u0006\u0002\u0010$J7\u0010\u000f\u001a\u00020\u00102\u0006\u0010%\u001a\u00020&2%\b\u0002\u0010\u0014\u001a\u001f\u0012\u0013\u0012\u00110\u0016¢\u0006\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b(\u0019\u0012\u0004\u0012\u00020\u0010\u0018\u00010\u0015H&JI\u0010\u000f\u001a\u00020\u00102\u0006\u0010%\u001a\u00020&2%\b\u0002\u0010\u0014\u001a\u001f\u0012\u0013\u0012\u00110\u0016¢\u0006\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b(\u0019\u0012\u0004\u0012\u00020\u0010\u0018\u00010\u00152\u0010\b\u0002\u0010'\u001a\n\u0012\u0004\u0012\u00020\u0010\u0018\u00010(H&¨\u0006)"}, d2 = {"Lcom/gateio/biz/base/router/provider/MarketSelectApi;", "Lcom/alibaba/android/arouter/facade/template/IProvider;", "queryAllFavPairsForExternal", "", "Lkotlin/Pair;", "", "area", "Lcom/gateio/biz/market/service/model/MarketSelectArea;", "(Lcom/gateio/biz/market/service/model/MarketSelectArea;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "setFavPairForExternal", "Lcom/gateio/lib/network/result/GTHttpResultKotlin;", "", "isFav", "pair", "(Lcom/gateio/biz/market/service/model/MarketSelectArea;ZLkotlin/Pair;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "showMarketTradeSelectV3", "", MarketFragmentList.IS_MODE_VOUCHER, "fm", "Landroidx/fragment/app/FragmentManager;", "marketTradeSelectResult", "Lkotlin/Function1;", "Lcom/gateio/biz/market/service/model/MarketTradeSelectResult;", "Lkotlin/ParameterName;", "name", "selectResult", "(Lcom/gateio/biz/market/service/model/MarketSelectArea;Ljava/lang/Boolean;Landroidx/fragment/app/FragmentManager;Lkotlin/jvm/functions/Function1;)V", "onResult", "Lkotlin/Function4;", "settleCoin", "", "type", "price", "(Lcom/gateio/biz/market/service/model/MarketSelectArea;Ljava/lang/Boolean;Landroidx/fragment/app/FragmentManager;Lkotlin/jvm/functions/Function4;)V", "marketTabsEnum", "Lcom/gateio/biz/market/service/model/MarketTabsEnum;", "(Lcom/gateio/biz/market/service/model/MarketTabsEnum;Lcom/gateio/biz/market/service/model/MarketSelectArea;Ljava/lang/Boolean;Landroidx/fragment/app/FragmentManager;Lkotlin/jvm/functions/Function4;)V", "marketTradeSelectRequest", "Lcom/gateio/biz/market/service/model/MarketTradeSelectRequest;", "onDismiss", "Lkotlin/Function0;", "biz_market_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public interface MarketSelectApi extends IProvider {

    /* compiled from: MarketSelectApi.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class DefaultImpls {
        /* JADX WARN: Multi-variable type inference failed */
        public static /* synthetic */ void showMarketTradeSelectV3$default(MarketSelectApi marketSelectApi, MarketSelectArea marketSelectArea, Boolean bool, FragmentManager fragmentManager, Function1 function1, int i10, Object obj) {
            if (obj != null) {
                throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: showMarketTradeSelectV3");
            }
            if ((i10 & 8) != 0) {
                function1 = null;
            }
            marketSelectApi.showMarketTradeSelectV3(marketSelectArea, bool, fragmentManager, (Function1<? super MarketTradeSelectResult, Unit>) function1);
        }

        /* JADX WARN: Multi-variable type inference failed */
        public static /* synthetic */ void showMarketTradeSelectV3$default(MarketSelectApi marketSelectApi, MarketTradeSelectRequest marketTradeSelectRequest, Function1 function1, int i10, Object obj) {
            if (obj != null) {
                throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: showMarketTradeSelectV3");
            }
            if ((i10 & 2) != 0) {
                function1 = null;
            }
            marketSelectApi.showMarketTradeSelectV3(marketTradeSelectRequest, function1);
        }

        /* JADX WARN: Multi-variable type inference failed */
        public static /* synthetic */ void showMarketTradeSelectV3$default(MarketSelectApi marketSelectApi, MarketTradeSelectRequest marketTradeSelectRequest, Function1 function1, Function0 function0, int i10, Object obj) {
            if (obj != null) {
                throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: showMarketTradeSelectV3");
            }
            if ((i10 & 2) != 0) {
                function1 = null;
            }
            if ((i10 & 4) != 0) {
                function0 = null;
            }
            marketSelectApi.showMarketTradeSelectV3(marketTradeSelectRequest, function1, function0);
        }
    }

    @Nullable
    Object queryAllFavPairsForExternal(@NotNull MarketSelectArea marketSelectArea, @NotNull Continuation<? super List<Pair<String, String>>> continuation);

    @Nullable
    Object setFavPairForExternal(@NotNull MarketSelectArea marketSelectArea, boolean z10, @NotNull Pair<String, String> pair, @NotNull Continuation<? super GTHttpResultKotlin<Boolean>> continuation);

    @Deprecated(message = "使用[MarketTradeSelectRequest]和MarketTradeSelectResult的方法")
    void showMarketTradeSelectV3(@NotNull MarketSelectArea area, @Nullable Boolean isModeVoucher, @NotNull FragmentManager fm, @Nullable Function1<? super MarketTradeSelectResult, Unit> marketTradeSelectResult);

    @Deprecated(message = "方法返回结果升级为使用实体对象形式", replaceWith = @ReplaceWith(expression = "showMarketTradeSelectV3(MarketSelectArea,Boolean?,FragmentManager,((selectResult: MarketTradeSelectResult)-> Unit)?)", imports = {}))
    void showMarketTradeSelectV3(@NotNull MarketSelectArea area, @Nullable Boolean isModeVoucher, @NotNull FragmentManager fm, @NotNull Function4<? super String, ? super String, ? super Integer, ? super String, Unit> onResult);

    void showMarketTradeSelectV3(@NotNull MarketTabsEnum marketTabsEnum, @NotNull MarketSelectArea area, @NotNull FragmentManager fm, @NotNull Function4<? super String, ? super String, ? super Integer, ? super String, Unit> onResult);

    @Deprecated(message = "使用[MarketTradeSelectRequest]和MarketTradeSelectResult的方法")
    void showMarketTradeSelectV3(@NotNull MarketTabsEnum marketTabsEnum, @NotNull MarketSelectArea area, @Nullable Boolean isModeVoucher, @NotNull FragmentManager fm, @NotNull Function4<? super String, ? super String, ? super Integer, ? super String, Unit> onResult);

    void showMarketTradeSelectV3(@NotNull MarketTradeSelectRequest marketTradeSelectRequest, @Nullable Function1<? super MarketTradeSelectResult, Unit> marketTradeSelectResult);

    void showMarketTradeSelectV3(@NotNull MarketTradeSelectRequest marketTradeSelectRequest, @Nullable Function1<? super MarketTradeSelectResult, Unit> marketTradeSelectResult, @Nullable Function0<Unit> onDismiss);
}