package com.gateio.biz.base.router.provider;

import android.content.Context;
import androidx.fragment.app.FragmentManager;
import com.alibaba.android.arouter.facade.template.IProvider;
import com.alipay.blueshield.legacy.IDeviceColorModule;
import com.gate_sdk.web3_wallet.DeFiConstants;
import com.gateio.biz.base.model.SpotMarginTradingSwitchStatus;
import com.gateio.biz.base.model.TransUserPlan;
import com.gateio.biz.base.model.UnifiedSettingsStatus;
import com.gateio.biz.base.model.trans.TransJumpParams;
import com.gateio.biz.base.model.trans.TransTradeTypeEnum;
import com.gateio.biz.base.router.RouterConst;
import com.gateio.biz.base.router.page.ITransQuickOrderFragment;
import com.gateio.biz.kline.KlineUIHelper;
import com.gateio.fiatotclib.function.order.appeal.GetHelpActivity;
import com.gateio.gateio.datafinder.eventv1.contract.ContractMoreChooseClickEvent;
import com.gateio.lib.router.GTRouter;
import com.gateio.rxjava.basemvp.IBaseView;
import com.google.android.gms.common.internal.ServiceSpecificExtraArgs;
import com.tencent.qcloud.tuicore.TUIConstants;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: TransApi.kt */
@Metadata(d1 = {"\u0000\u0094\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u000f\bf\u0018\u0000 T2\u00020\u0001:\u0001TJ\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0003H&J\u001a\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\b\u0010\t\u001a\u0004\u0018\u00010\u0003H&J(\u0010\n\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\u00032\u0016\b\u0002\u0010\f\u001a\u0010\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u0006\u0018\u00010\rH&J$\u0010\u000f\u001a\u00020\u00062\u0006\u0010\u0004\u001a\u00020\u00032\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u00060\rH&J$\u0010\u0012\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u00032\u0012\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u00060\rH&J+\u0010\u0014\u001a\u00020\u00062!\u0010\u0015\u001a\u001d\u0012\u0013\u0012\u00110\u0016¢\u0006\f\b\u0017\u0012\b\b\u0018\u0012\u0004\b\b(\u0019\u0012\u0004\u0012\u00020\u00060\rH&J\u001e\u0010\u001a\u001a\u00020\u00062\u0014\u0010\f\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u001b\u0012\u0004\u0012\u00020\u00060\rH&J0\u0010\u001c\u001a\u00020\u00062\b\u0010\u001d\u001a\u0004\u0018\u00010\u00032\u0006\u0010\u001e\u001a\u00020\u00032\u0014\u0010\f\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u001f\u0012\u0004\u0012\u00020\u00060\rH&J\u0010\u0010 \u001a\u00020\u00062\u0006\u0010!\u001a\u00020\u0003H&J(\u0010\"\u001a\u00020\u00062\u0006\u0010#\u001a\u00020$2\u0016\u0010\f\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030%\u0012\u0004\u0012\u00020\u00060\rH&JK\u0010&\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\n\b\u0002\u0010'\u001a\u0004\u0018\u00010\u000e2\n\b\u0002\u0010(\u001a\u0004\u0018\u00010)2\u0006\u0010*\u001a\u00020\u00032\u0006\u0010+\u001a\u00020\u00032\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00060,H&¢\u0006\u0002\u0010-JS\u0010&\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\n\b\u0002\u0010'\u001a\u0004\u0018\u00010\u000e2\n\b\u0002\u0010(\u001a\u0004\u0018\u00010)2\u0006\u0010*\u001a\u00020\u00032\u0006\u0010+\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u00032\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00060,H&¢\u0006\u0002\u0010.J?\u0010&\u001a\u00020\u00062\u0006\u0010/\u001a\u00020\u000e2\n\b\u0002\u0010'\u001a\u0004\u0018\u00010\u000e2\u0006\u0010*\u001a\u00020\u00032\u0006\u0010+\u001a\u00020\u00032\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00060,H&¢\u0006\u0002\u00100JK\u0010&\u001a\u00020\u00062\u0006\u0010/\u001a\u00020\u000e2\n\b\u0002\u0010'\u001a\u0004\u0018\u00010\u000e2\u0006\u0010*\u001a\u00020\u00032\u0006\u0010+\u001a\u00020\u00032\n\b\u0002\u00101\u001a\u0004\u0018\u00010\u000e2\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00060,H&¢\u0006\u0002\u00102JS\u0010&\u001a\u00020\u00062\u0006\u0010/\u001a\u00020\u000e2\n\b\u0002\u0010'\u001a\u0004\u0018\u00010\u000e2\u0006\u0010*\u001a\u00020\u00032\u0006\u0010+\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u00032\n\b\u0002\u00101\u001a\u0004\u0018\u00010\u000e2\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00060,H&¢\u0006\u0002\u00103J\u0010\u00104\u001a\u00020\u00062\u0006\u00105\u001a\u00020\u000eH&J4\u00106\u001a\u00020\u00062\u0006\u00107\u001a\u0002082\u0006\u00109\u001a\u00020\u00032\u0006\u0010:\u001a\u00020;2\u0012\u0010\u0015\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u00060\rH&J\u001c\u0010<\u001a\u00020\u00062\n\u0010=\u001a\u0006\u0012\u0002\b\u00030>2\u0006\u00107\u001a\u000208H&J8\u0010?\u001a\u00020\u00062\u0006\u0010@\u001a\u00020A2\u0006\u0010\u000b\u001a\u00020\u00032\n\b\u0002\u0010B\u001a\u0004\u0018\u00010\u00032\u0012\u0010C\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u00060\rH&J?\u0010D\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u00032\n\b\u0002\u0010E\u001a\u0004\u0018\u00010\u000e2\u001c\b\u0002\u0010\f\u001a\u0016\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0006\u0018\u00010FH&¢\u0006\u0002\u0010GJ,\u0010H\u001a\u00020\u00062\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010I\u001a\u00020\u000e2\u0012\u0010J\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u00060\rH&J\u001e\u0010K\u001a\u00020\u00062\u0006\u0010@\u001a\u00020A2\f\u0010L\u001a\b\u0012\u0004\u0012\u00020\u00060,H&J@\u0010M\u001a\u00020\u00062\u0006\u0010@\u001a\u00020A2\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010N\u001a\u00020\u00032\b\b\u0002\u0010O\u001a\u00020\u000e2\u0010\b\u0002\u0010P\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010,H&JH\u0010Q\u001a\u00020\u00062\u0006\u0010@\u001a\u00020A2\u0006\u0010\u0007\u001a\u00020\u00032\u0006\u0010R\u001a\u00020\u00032\u0006\u0010N\u001a\u00020\u00032\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00060,2\u0010\b\u0002\u0010S\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010,H&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006UÀ\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/router/provider/TransApi;", "Lcom/alibaba/android/arouter/facade/template/IProvider;", "dealUnifiedAccountMarginRate", "", "rate", "defaultNotify", "", KlineUIHelper.EXTRA_TRADE_TRADETYPE, "Lcom/gateio/biz/base/model/trans/TransTradeTypeEnum;", "moduleSource", "getMarginInfo", "market", "result", "Lkotlin/Function1;", "", "getSpotTradingLevelColor", "colorId", "", "getUnifiedFirstUpgrade", IDeviceColorModule.EDGE_MODE_KEY, "getUnifiedSettings", "success", "Lcom/gateio/biz/base/model/UnifiedSettingsStatus;", "Lkotlin/ParameterName;", "name", "status", "getUserMarginTrading", "Lcom/gateio/biz/base/model/SpotMarginTradingSwitchStatus;", "getUserPlan", "currency", "type", "Lcom/gateio/biz/base/model/TransUserPlan;", "jumpTransChildTab", "tab", "newTransQuickOrderFragment", "params", "Lcom/gateio/biz/base/router/page/ITransQuickOrderFragment$TransQuickOrderParams;", "Lcom/gateio/biz/base/router/page/ITransQuickOrderFragment;", TUIConstants.TUIGroupNotePlugin.PLUGIN_GROUP_NOTE_ENABLE_NOTIFICATION, GetHelpActivity.IS_BUY, "transJumpParams", "Lcom/gateio/biz/base/model/trans/TransJumpParams;", "currencyType", "exchangeType", "Lkotlin/Function0;", "(Lcom/gateio/biz/base/model/trans/TransTradeTypeEnum;Ljava/lang/Boolean;Lcom/gateio/biz/base/model/trans/TransJumpParams;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V", "(Lcom/gateio/biz/base/model/trans/TransTradeTypeEnum;Ljava/lang/Boolean;Lcom/gateio/biz/base/model/trans/TransJumpParams;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V", "isSpot", "(ZLjava/lang/Boolean;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V", "isNeedCheckCrossMargin", "(ZLjava/lang/Boolean;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Lkotlin/jvm/functions/Function0;)V", "(ZLjava/lang/Boolean;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Lkotlin/jvm/functions/Function0;)V", "notifyAssetsChange", "isHide", "openModifyOrderDialogFragment", "fragmentManager", "Landroidx/fragment/app/FragmentManager;", ContractMoreChooseClickEvent.source_order, "editType", "", "openQuickRepayDialog", "baseView", "Lcom/gateio/rxjava/basemvp/IBaseView;", "openTransMarginUpgradeDialog", "context", "Landroid/content/Context;", "mmr", DeFiConstants.IsSuccess, "setSpotMarginTradingMode", "spot_hedge", "Lkotlin/Function2;", "(Ljava/lang/String;Ljava/lang/Boolean;Lkotlin/jvm/functions/Function2;)V", "setUnifiedSettings", "enabled", "state", "switchNormalAccount", ServiceSpecificExtraArgs.CastExtraArgs.LISTENER, "switchUnifiedAccountMode", "entranceType", "showSimpleEarn", "switchModeCallback", "toUpgradeUnifiedAccount", "buttonName", "error", "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public interface TransApi extends IProvider {

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = Companion.$$INSTANCE;

    /* compiled from: TransApi.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0003\u001a\u00020\u0004¨\u0006\u0005"}, d2 = {"Lcom/gateio/biz/base/router/provider/TransApi$Companion;", "", "()V", "get", "Lcom/gateio/biz/base/router/provider/TransApi;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Companion {
        static final /* synthetic */ Companion $$INSTANCE = new Companion();

        private Companion() {
        }

        @NotNull
        public final TransApi get() {
            return (TransApi) GTRouter.serviceAPI(RouterConst.Trans.PROVIDER_TRANS);
        }
    }

    static /* synthetic */ void notify$default(TransApi transApi, boolean z10, Boolean bool, String str, String str2, String str3, Boolean bool2, Function0 function0, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: notify");
        }
        transApi.notify(z10, (i10 & 2) != 0 ? null : bool, str, str2, str3, (i10 & 32) != 0 ? null : bool2, (Function0<Unit>) function0);
    }

    @NotNull
    String dealUnifiedAccountMarginRate(@NotNull String rate);

    void defaultNotify(@NotNull TransTradeTypeEnum tradeType, @Nullable String moduleSource);

    void getMarginInfo(@NotNull String market, @Nullable Function1<? super Boolean, Unit> result);

    void getSpotTradingLevelColor(@NotNull String rate, @NotNull Function1<? super Integer, Unit> colorId);

    void getUnifiedFirstUpgrade(@NotNull String mode, @NotNull Function1<? super Boolean, Unit> result);

    void getUnifiedSettings(@NotNull Function1<? super UnifiedSettingsStatus, Unit> success);

    void getUserMarginTrading(@NotNull Function1<? super SpotMarginTradingSwitchStatus, Unit> result);

    void getUserPlan(@Nullable String currency, @NotNull String type, @NotNull Function1<? super TransUserPlan, Unit> result);

    void jumpTransChildTab(@NotNull String tab);

    void newTransQuickOrderFragment(@NotNull ITransQuickOrderFragment.TransQuickOrderParams params, @NotNull Function1<? super ITransQuickOrderFragment<?>, Unit> result);

    void notify(@NotNull TransTradeTypeEnum tradeType, @Nullable Boolean isBuy, @Nullable TransJumpParams transJumpParams, @NotNull String currencyType, @NotNull String exchangeType, @NotNull String moduleSource, @NotNull Function0<Unit> success);

    void notify(@NotNull TransTradeTypeEnum tradeType, @Nullable Boolean isBuy, @Nullable TransJumpParams transJumpParams, @NotNull String currencyType, @NotNull String exchangeType, @NotNull Function0<Unit> success);

    void notify(boolean isSpot, @Nullable Boolean isBuy, @NotNull String currencyType, @NotNull String exchangeType, @Nullable Boolean isNeedCheckCrossMargin, @NotNull Function0<Unit> success);

    void notify(boolean isSpot, @Nullable Boolean isBuy, @NotNull String currencyType, @NotNull String exchangeType, @NotNull String moduleSource, @Nullable Boolean isNeedCheckCrossMargin, @NotNull Function0<Unit> success);

    void notify(boolean isSpot, @Nullable Boolean isBuy, @NotNull String currencyType, @NotNull String exchangeType, @NotNull Function0<Unit> success);

    void notifyAssetsChange(boolean isHide);

    void openModifyOrderDialogFragment(@NotNull FragmentManager fragmentManager, @NotNull String order, long editType, @NotNull Function1<? super Boolean, Unit> success);

    void openQuickRepayDialog(@NotNull IBaseView<?> baseView, @NotNull FragmentManager fragmentManager);

    void openTransMarginUpgradeDialog(@NotNull Context context, @NotNull String market, @Nullable String mmr, @NotNull Function1<? super Boolean, Unit> isSuccess);

    void setSpotMarginTradingMode(@NotNull String mode, @Nullable Boolean spot_hedge, @Nullable Function2<? super Boolean, ? super String, Unit> result);

    void setUnifiedSettings(@NotNull String rate, boolean enabled, @NotNull Function1<? super Boolean, Unit> state);

    void switchNormalAccount(@NotNull Context context, @NotNull Function0<Unit> listener);

    void switchUnifiedAccountMode(@NotNull Context context, @NotNull String tradeType, @NotNull String entranceType, boolean showSimpleEarn, @Nullable Function0<Unit> switchModeCallback);

    void toUpgradeUnifiedAccount(@NotNull Context context, @NotNull String tradeType, @NotNull String buttonName, @NotNull String entranceType, @NotNull Function0<Unit> success, @Nullable Function0<Unit> error);

    /* JADX WARN: Multi-variable type inference failed */
    static /* synthetic */ void getMarginInfo$default(TransApi transApi, String str, Function1 function1, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: getMarginInfo");
        }
        if ((i10 & 2) != 0) {
            function1 = null;
        }
        transApi.getMarginInfo(str, function1);
    }

    static /* synthetic */ void notify$default(TransApi transApi, boolean z10, Boolean bool, String str, String str2, Function0 function0, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: notify");
        }
        if ((i10 & 2) != 0) {
            bool = null;
        }
        transApi.notify(z10, bool, str, str2, function0);
    }

    static /* synthetic */ void openTransMarginUpgradeDialog$default(TransApi transApi, Context context, String str, String str2, Function1 function1, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: openTransMarginUpgradeDialog");
        }
        if ((i10 & 4) != 0) {
            str2 = null;
        }
        transApi.openTransMarginUpgradeDialog(context, str, str2, function1);
    }

    /* JADX WARN: Multi-variable type inference failed */
    static /* synthetic */ void setSpotMarginTradingMode$default(TransApi transApi, String str, Boolean bool, Function2 function2, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: setSpotMarginTradingMode");
        }
        if ((i10 & 2) != 0) {
            bool = null;
        }
        if ((i10 & 4) != 0) {
            function2 = null;
        }
        transApi.setSpotMarginTradingMode(str, bool, function2);
    }

    static /* synthetic */ void switchUnifiedAccountMode$default(TransApi transApi, Context context, String str, String str2, boolean z10, Function0 function0, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: switchUnifiedAccountMode");
        }
        String str3 = (i10 & 2) != 0 ? "" : str;
        String str4 = (i10 & 4) != 0 ? "" : str2;
        if ((i10 & 8) != 0) {
            z10 = false;
        }
        boolean z11 = z10;
        if ((i10 & 16) != 0) {
            function0 = null;
        }
        transApi.switchUnifiedAccountMode(context, str3, str4, z11, function0);
    }

    static /* synthetic */ void toUpgradeUnifiedAccount$default(TransApi transApi, Context context, String str, String str2, String str3, Function0 function0, Function0 function02, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: toUpgradeUnifiedAccount");
        }
        if ((i10 & 32) != 0) {
            function02 = null;
        }
        transApi.toUpgradeUnifiedAccount(context, str, str2, str3, function0, function02);
    }

    static /* synthetic */ void notify$default(TransApi transApi, TransTradeTypeEnum transTradeTypeEnum, Boolean bool, TransJumpParams transJumpParams, String str, String str2, Function0 function0, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: notify");
        }
        transApi.notify(transTradeTypeEnum, (i10 & 2) != 0 ? null : bool, (i10 & 4) != 0 ? null : transJumpParams, str, str2, (Function0<Unit>) function0);
    }

    static /* synthetic */ void notify$default(TransApi transApi, TransTradeTypeEnum transTradeTypeEnum, Boolean bool, TransJumpParams transJumpParams, String str, String str2, String str3, Function0 function0, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: notify");
        }
        transApi.notify(transTradeTypeEnum, (i10 & 2) != 0 ? null : bool, (i10 & 4) != 0 ? null : transJumpParams, str, str2, str3, (Function0<Unit>) function0);
    }

    static /* synthetic */ void notify$default(TransApi transApi, boolean z10, Boolean bool, String str, String str2, Boolean bool2, Function0 function0, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: notify");
        }
        transApi.notify(z10, (i10 & 2) != 0 ? null : bool, str, str2, (i10 & 16) != 0 ? null : bool2, (Function0<Unit>) function0);
    }
}