package com.gateio.biz.base.router.provider;

import android.content.Context;
import androidx.exifinterface.media.ExifInterface;
import com.alibaba.android.arouter.facade.template.IProvider;
import com.gateio.biz.base.router.RouterConst;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* compiled from: StrategyJumpUtilsService.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\r\bf\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u0002J0\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\bH&JH\u0010\f\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\r\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u000e\u001a\u00020\b2\u0006\u0010\u000f\u001a\u00020\b2\u0006\u0010\u0010\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\bH&J\u0018\u0010\u0011\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\bH&J@\u0010\u0012\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\r\u001a\u00020\b2\u0006\u0010\u0010\u001a\u00020\b2\u0006\u0010\u000f\u001a\u00020\b2\u0006\u0010\u000e\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\bH&J \u0010\u0013\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u000e\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\bH&J\u0010\u0010\u0014\u001a\u00020\u00042\u0006\u0010\u000b\u001a\u00020\bH&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0015À\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/router/provider/StrategyJumpUtilsService;", ExifInterface.GPS_DIRECTION_TRUE, "Lcom/alibaba/android/arouter/facade/template/IProvider;", "jumpToStrategyCreate", "", "context", "Landroid/content/Context;", "strategyType", "", "market", RouterConst.AlertKey.PARAMS_SETTLE_KYE, "entryModuleSource", "jumpToStrategyDetail", "strategyId", "anonymousUid", "isAi", "isCopy", "jumpToStrategyHome", "jumpToStrategyOrderDetail", "jumpToStrategyUserHome", "sendStrategyHomeEntryEvent", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public interface StrategyJumpUtilsService<T> extends IProvider {
    void jumpToStrategyCreate(@NotNull Context context, @NotNull String strategyType, @NotNull String market, @NotNull String settle, @NotNull String entryModuleSource);

    void jumpToStrategyDetail(@NotNull Context context, @NotNull String strategyType, @NotNull String strategyId, @NotNull String market, @NotNull String anonymousUid, @NotNull String isAi, @NotNull String isCopy, @NotNull String entryModuleSource);

    void jumpToStrategyHome(@NotNull Context context, @NotNull String entryModuleSource);

    void jumpToStrategyOrderDetail(@NotNull Context context, @NotNull String strategyType, @NotNull String strategyId, @NotNull String isCopy, @NotNull String isAi, @NotNull String anonymousUid, @NotNull String entryModuleSource);

    void jumpToStrategyUserHome(@NotNull Context context, @NotNull String anonymousUid, @NotNull String entryModuleSource);

    void sendStrategyHomeEntryEvent(@NotNull String entryModuleSource);
}