package com.gateio.biz.base.router.provider;

import android.content.Context;
import com.alibaba.android.arouter.facade.template.IProvider;
import kotlin.Metadata;
import org.jetbrains.annotations.Nullable;

/* compiled from: GamefiJumpService.kt */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\bf\u0018\u00002\u00020\u0001J.\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u00072\b\u0010\b\u001a\u0004\u0018\u00010\t2\b\u0010\n\u001a\u0004\u0018\u00010\tH&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u000bÀ\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/router/provider/GamefiJumpService;", "Lcom/alibaba/android/arouter/facade/template/IProvider;", "linkGamefi", "", "isNeedLoading", "", "context", "Landroid/content/Context;", "url", "", "mini_app_link", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public interface GamefiJumpService extends IProvider {
    void linkGamefi(boolean isNeedLoading, @Nullable Context context, @Nullable String url, @Nullable String mini_app_link);
}