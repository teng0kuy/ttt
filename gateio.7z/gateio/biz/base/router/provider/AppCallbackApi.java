package com.gateio.biz.base.router.provider;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import com.alibaba.android.arouter.facade.template.IProvider;

/* loaded from: classes37.dex */
public interface AppCallbackApi extends IProvider {
    void accessUtilsShare(String str, String str2);

    String getAppKey();

    String getAppSign(String str);

    String getAppUrlSign(String str);

    String getApplicationId();

    String getChannelId();

    String getChannelNumber();

    int getFiatScale();

    void getUserInfo();

    String getWalletCurrecny();

    void gotoPlayBackActivity(Context context, String str, boolean z10);

    void gotoWebH5Activity(Context context, String str, String str2);

    void reStartApp(Activity activity);

    void rejectApplicationLive(Context context);

    void showCoin2CoinCommit(Context context, String str);

    void showDeposit(@NonNull Context context);

    void showFiatOtcTrade(@NonNull Context context, int i10, @NonNull String str);

    void showHome(Activity activity);

    void showNotice(boolean z10);

    void showWebActivity(Context context, Bundle bundle);

    void showWebHelpActivity(Context context, Bundle bundle);

    void startAccounCenter(Context context);

    void startAccounCenter(Context context, String str, String str2, String str3);
}