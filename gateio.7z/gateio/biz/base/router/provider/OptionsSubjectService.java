package com.gateio.biz.base.router.provider;

import androidx.fragment.app.FragmentManager;
import cn.jiguang.privates.push.constants.JPushConstants;
import com.alibaba.android.arouter.facade.template.IProvider;
import com.gateio.biz.base.options.OptionsCoinTypeEnum;
import com.gateio.biz.base.router.RouterConst;
import com.gateio.biz_options.fragment.market_select.OptionsSelectMarketViewModel;
import com.gateio.common.listener.ISuccessCallBack;
import com.gateio.rxjava.basemvp.IBaseView;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: OptionsSubjectService.kt */
@Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0010\u0000\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bf\u0018\u00002\u00020\u0001J8\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\f\u0010\b\u001a\b\u0012\u0002\b\u0003\u0018\u00010\t2\u0010\u0010\n\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0018\u00010\u000bH&J\n\u0010\f\u001a\u0004\u0018\u00010\rH&J\u001e\u0010\u000e\u001a\u0010\u0012\u0004\u0012\u00020\u0007\u0012\u0006\u0012\u0004\u0018\u00010\u00100\u000f2\u0006\u0010\u0011\u001a\u00020\u0007H&J\u0010\u0010\u0004\u001a\u00020\u00002\u0006\u0010\u0012\u001a\u00020\u0005H&J \u0010\u0013\u001a\u00020\u00032\u0006\u0010\u0014\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0015\u001a\u00020\u0016H&J\b\u0010\u0017\u001a\u00020\u0003H&J\u0012\u0010\u0018\u001a\u00020\u00032\b\u0010\u0019\u001a\u0004\u0018\u00010\rH&J,\u0010\u001a\u001a\u00020\u00032\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u00072\u0012\u0010\u001e\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00030\u001fH&J,\u0010 \u001a\u00020\u00032\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u00072\u0012\u0010\u001e\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00030\u001fH&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006!À\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/router/provider/OptionsSubjectService;", "Lcom/alibaba/android/arouter/facade/template/IProvider;", "checkNotify", "", "isTestNet", "", "contract", "", "iBaseView", "Lcom/gateio/rxjava/basemvp/IBaseView;", "iSuccessCallBack", "Lcom/gateio/common/listener/ISuccessCallBack;", "getAmountType", "Lcom/gateio/biz/base/options/OptionsCoinTypeEnum;", "getOptionsContract", "", "", OptionsSelectMarketViewModel.UNDERLYING, "isTest", "jumpOptionsChildTab", RouterConst.AlertKey.PARAMS_SETTLE_KYE, "position", "", "notifyByMethod", "setAmountType", "amountType", "toOptionsClosePosition", "fragmentManager", "Landroidx/fragment/app/FragmentManager;", JPushConstants.Analysis.KEY_JSON, "callback", "Lkotlin/Function1;", "toOptionsOrderChanged", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public interface OptionsSubjectService extends IProvider {
    void checkNotify(boolean isTestNet, @NotNull String contract, @Nullable IBaseView<?> iBaseView, @Nullable ISuccessCallBack<Boolean> iSuccessCallBack);

    @Nullable
    OptionsCoinTypeEnum getAmountType();

    @NotNull
    Map<String, Object> getOptionsContract(@NotNull String underlying);

    @NotNull
    OptionsSubjectService isTestNet(boolean isTest);

    void jumpOptionsChildTab(@NotNull String settle, @NotNull String contract, int position);

    void notifyByMethod();

    void setAmountType(@Nullable OptionsCoinTypeEnum amountType);

    void toOptionsClosePosition(@NotNull FragmentManager fragmentManager, @NotNull String json, @NotNull Function1<? super Boolean, Unit> callback);

    void toOptionsOrderChanged(@NotNull FragmentManager fragmentManager, @NotNull String json, @NotNull Function1<? super Boolean, Unit> callback);
}