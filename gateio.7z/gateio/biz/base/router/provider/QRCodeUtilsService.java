package com.gateio.biz.base.router.provider;

import androidx.appcompat.app.AppCompatActivity;
import androidx.exifinterface.media.ExifInterface;
import com.alibaba.android.arouter.facade.template.IProvider;
import com.gateio.biz.base.listener.IScanResultHandler;
import com.gateio.rxjava.basemvp.IHostView;
import com.google.zxing.integration.android.IntentResult;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* compiled from: QRCodeUtilsService.kt */
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bf\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u0002J(\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fH&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\rÀ\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/router/provider/QRCodeUtilsService;", ExifInterface.GPS_DIRECTION_TRUE, "Lcom/alibaba/android/arouter/facade/template/IProvider;", "handleScanResult", "", "activity", "Landroidx/appcompat/app/AppCompatActivity;", "hostView", "Lcom/gateio/rxjava/basemvp/IHostView;", "intentResult", "Lcom/google/zxing/integration/android/IntentResult;", "scanResultHandler", "Lcom/gateio/biz/base/listener/IScanResultHandler;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public interface QRCodeUtilsService<T> extends IProvider {
    void handleScanResult(@NotNull AppCompatActivity activity, @NotNull IHostView hostView, @NotNull IntentResult intentResult, @NotNull IScanResultHandler scanResultHandler);
}