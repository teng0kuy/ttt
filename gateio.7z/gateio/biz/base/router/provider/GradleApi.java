package com.gateio.biz.base.router.provider;

import com.alibaba.android.arouter.facade.template.IProvider;

/* loaded from: classes37.dex */
public interface GradleApi extends IProvider {
    String getAppType();

    String getApp_store_type();

    String getBase_url_cdn_http();

    String getBase_url_future();

    String getBase_url_future_real();

    String getBase_url_future_simulate();

    String getBase_url_gamefi_http();

    String getBase_url_moments_http();

    String getBase_url_ws_cbbc();

    String getBase_url_ws_fund();

    String getBase_url_ws_live();

    String getBase_url_ws_option();

    String getBase_url_ws_real();

    String getBase_url_ws_simulate();

    String getBase_url_ws_warrant();

    String getBuildAppType();

    String getDefault_base_url();

    int getTim_default_sdkid();

    String getVersion_code();

    String getVersion_name();

    boolean isIs_encrypt_params();

    boolean isIs_release_encrypt();

    boolean isIs_release_nodes();

    boolean isIs_sandbox();

    boolean isStrict_hostname_verifier();

    boolean is_translate_key();
}