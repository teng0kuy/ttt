package com.gateio.biz.base.router.provider;

import android.app.Activity;
import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
import com.alibaba.android.arouter.facade.template.IProvider;
import com.gateio.fiatotclib.function.order.merchant.MerchantOrderDetailActivity;
import com.gateio.rxjava.basemvp.IHostView;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: MiniAppSubjectService.kt */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\bf\u0018\u00002\u00020\u0001J<\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u00072\u001a\u0010\t\u001a\u0016\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u000b\u0012\u0004\u0012\u00020\u00030\nH&J0\u0010\f\u001a\u00020\u00032\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0004\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00072\u0006\u0010\u0012\u001a\u00020\u0007H&Jf\u0010\u0013\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0014\u001a\u00020\u00072\u0006\u0010\u0015\u001a\u00020\u00072\u0006\u0010\u0016\u001a\u00020\u00072\u0006\u0010\u0017\u001a\u00020\u00072\u0006\u0010\u0018\u001a\u00020\u00072\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010\u001a\u001a\u00020\u00072\u001a\u0010\t\u001a\u0016\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u000e0\u000b\u0012\u0004\u0012\u00020\u00030\nH&J\u001c\u0010\u001b\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u00052\b\u0010\u001c\u001a\u0004\u0018\u00010\u0007H&J \u0010\u001d\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\u0007H&J \u0010\"\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\u0007H&J \u0010#\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\u0007H&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006$À\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/router/provider/MiniAppSubjectService;", "Lcom/alibaba/android/arouter/facade/template/IProvider;", "getConvertedPrice", "", "activity", "Landroid/app/Activity;", "currency", "", "amount", "callback", "Lkotlin/Function1;", "Lkotlin/Result;", "gotoGamefiCenter", "isNeedBackLife", "", "isNeedLoading", "Landroid/content/Context;", "client_id", "mini_app_link", "openPayPage", MerchantOrderDetailActivity.ORDER_ID, "clientNo", "receive", "payAmount", "payCurrency", "name", "avatar", "toGatePay", "jsonObject", "toGlc2cQrCode", "Landroidx/appcompat/app/AppCompatActivity;", "hostView", "Lcom/gateio/rxjava/basemvp/IHostView;", "qrCode", "toPayeeQrCode", "toScanCodePay", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public interface MiniAppSubjectService extends IProvider {
    void getConvertedPrice(@NotNull Activity activity, @NotNull String currency, @NotNull String amount, @NotNull Function1<? super Result<String>, Unit> callback);

    void gotoGamefiCenter(boolean isNeedBackLife, boolean isNeedLoading, @NotNull Context activity, @NotNull String client_id, @NotNull String mini_app_link);

    void openPayPage(@Nullable Activity activity, @NotNull String orderId, @NotNull String clientNo, @NotNull String receive, @NotNull String payAmount, @NotNull String payCurrency, @NotNull String name, @NotNull String avatar, @NotNull Function1<? super Result<Boolean>, Unit> callback);

    void toGatePay(@Nullable Activity activity, @Nullable String jsonObject);

    void toGlc2cQrCode(@NotNull AppCompatActivity activity, @NotNull IHostView hostView, @NotNull String qrCode);

    void toPayeeQrCode(@NotNull AppCompatActivity activity, @NotNull IHostView hostView, @NotNull String qrCode);

    void toScanCodePay(@NotNull AppCompatActivity activity, @NotNull IHostView hostView, @NotNull String qrCode);
}