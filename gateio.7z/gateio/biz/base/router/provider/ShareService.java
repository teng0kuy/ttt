package com.gateio.biz.base.router.provider;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import androidx.fragment.app.FragmentActivity;
import com.alibaba.android.arouter.facade.template.IProvider;
import com.gateio.gateio.tool.PathUtil;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: ShareService.kt */
@Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\bf\u0018\u00002\u00020\u0001J\u0018\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H&J,\u0010\b\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0012\u0010\r\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u00030\u000eH&J \u0010\u0010\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\fH&J \u0010\u0010\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u00112\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0014\u001a\u00020\fH&J \u0010\u0010\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u00112\u0006\u0010\u0015\u001a\u00020\u00172\u0006\u0010\u0014\u001a\u00020\fH&J$\u0010\u0018\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\b\u0010\u0019\u001a\u0004\u0018\u00010\u00072\b\u0010\u001a\u001a\u0004\u0018\u00010\u000fH&J\u001a\u0010\u001b\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\n2\b\u0010\u0019\u001a\u0004\u0018\u00010\u0007H&J\u001a\u0010\u001c\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\n2\b\u0010\u0019\u001a\u0004\u0018\u00010\u0007H&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u001dÀ\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/router/provider/ShareService;", "Lcom/alibaba/android/arouter/facade/template/IProvider;", "momentShare", "", "context", "Landroid/content/Context;", "momentModeJson", "", PathUtil.SCREENSHOT_PATH, "activity", "Landroidx/fragment/app/FragmentActivity;", "isIncludeNotice", "", "callBack", "Lkotlin/Function1;", "Landroid/graphics/Bitmap;", "share", "Landroid/app/Activity;", "viewGroup", "Landroid/view/ViewGroup;", "isNoticeShareCut", "view", "Landroid/widget/LinearLayout;", "Landroid/widget/ScrollView;", "shareBitmapByFlutter", "source", "bitmap", "shareByScreenshot", "shareByScreenshotIncludeNotice", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public interface ShareService extends IProvider {
    void momentShare(@NotNull Context context, @NotNull String momentModeJson);

    void screenshot(@NotNull FragmentActivity activity, boolean isIncludeNotice, @NotNull Function1<? super Bitmap, Unit> callBack);

    void share(@NotNull Activity activity, @NotNull ViewGroup viewGroup, boolean isNoticeShareCut);

    void share(@NotNull Activity activity, @NotNull LinearLayout view, boolean isNoticeShareCut);

    void share(@NotNull Activity activity, @NotNull ScrollView view, boolean isNoticeShareCut);

    void shareBitmapByFlutter(@NotNull Context context, @Nullable String source, @Nullable Bitmap bitmap);

    void shareByScreenshot(@NotNull FragmentActivity activity, @Nullable String source);

    void shareByScreenshotIncludeNotice(@NotNull FragmentActivity activity, @Nullable String source);
}