package com.gateio.biz.base.router.provider;

import android.app.Activity;
import android.content.Context;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.widget.ImageView;
import android.widget.TextView;
import cn.jiguang.privates.push.constants.JPushConstants;
import com.alibaba.android.arouter.facade.template.IProvider;
import com.facebook.share.internal.ShareConstants;
import com.gateio.biz.base.model.CurrencyData;
import com.gateio.biz.home.utils.HomeConst;
import com.gateio.fiatotclib.function.order.appeal.GetHelpActivity;
import com.gateio.rxjava.basemvp.IHostView;
import com.zoloz.webcontainer.env.H5Container;
import io.reactivex.rxjava3.core.s;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import org.ice4j.ice.sdp.IceSdpUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: AppModuleService.kt */
@Metadata(d1 = {"\u0000¦\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0013\n\u0002\u0010#\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\t\bf\u0018\u00002\u00020\u0001J \u0010\t\u001a\u00020\b2\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0006H&J \u0010\t\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u0002H&J \u0010\r\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u000b\u001a\u00020\u00062\u0006\u0010\f\u001a\u00020\u0006H&J\u001a\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u000f\u001a\u00020\u000e2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0006H&JH\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u0013\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\u00062\u0006\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0016\u001a\u00020\u00022\f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00060\u00172\b\u0010\u0019\u001a\u0004\u0018\u00010\u0011H¦@¢\u0006\u0004\b\u001b\u0010\u001cJ8\u0010\"\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u001d\u001a\u00020\u00062\u0006\u0010\u001e\u001a\u00020\u00062\u0006\u0010 \u001a\u00020\u001f2\u0006\u0010!\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\u0006H&J\u0010\u0010%\u001a\u00020\b2\u0006\u0010$\u001a\u00020#H&J\u0018\u0010'\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010&\u001a\u00020\u0006H&J \u0010*\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010(\u001a\u00020\u00062\u0006\u0010)\u001a\u00020\u001fH&J\u0018\u0010.\u001a\u00020\b2\u0006\u0010,\u001a\u00020+2\u0006\u0010-\u001a\u00020\u0006H&J\u0010\u00100\u001a\u00020\b2\u0006\u0010/\u001a\u00020\u0006H&J(\u00105\u001a\u00020\b2\u0006\u00101\u001a\u00020\u00062\u0006\u00102\u001a\u00020\u00022\u0006\u00103\u001a\u00020\u00062\u0006\u00104\u001a\u00020\u0006H&J\u0018\u00106\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010&\u001a\u00020\u0006H&J-\u0010;\u001a\u00020\b2#\u0010:\u001a\u001f\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(\u0013\u0012\u0004\u0012\u00020\b07H&J\b\u0010<\u001a\u00020\bH&JÅ\u0002\u0010I\u001a\u00020\b28\u0010@\u001a4\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(>\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(?\u0012\u0004\u0012\u00020\b0=28\u0010A\u001a4\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(>\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(?\u0012\u0004\u0012\u00020\b0=2:\u0010C\u001a6\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(>\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(B\u0012\u0004\u0012\u00020\b0=2:\u0010D\u001a6\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(>\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(B\u0012\u0004\u0012\u00020\b0=2O\u0010H\u001aK\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(>\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(F\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(G\u0012\u0004\u0012\u00020\b0EH&J\b\u0010J\u001a\u00020\bH&J¥\u0002\u0010W\u001a\u00020\b2\f\u0010L\u001a\b\u0012\u0004\u0012\u00020\b0K2!\u0010N\u001a\u001d\u0012\u0013\u0012\u00110\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(M\u0012\u0004\u0012\u00020\b0728\u0010P\u001a4\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u00110\u001f¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(O\u0012\u0004\u0012\u00020\b0=28\u0010R\u001a4\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(\u000b\u0012\u0013\u0012\u00110\u001f¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(Q\u0012\u0004\u0012\u00020\b0=2:\u0010T\u001a6\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(\u0013\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(S\u0012\u0004\u0012\u00020\b0=2:\u0010V\u001a6\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(\u0013\u0012\u0015\u0012\u0013\u0018\u00010\u0006¢\u0006\f\b8\u0012\b\b9\u0012\u0004\b\b(U\u0012\u0004\u0012\u00020\b0=H&J\b\u0010X\u001a\u00020\bH&J\u0016\u0010Y\u001a\u00020\b2\f\u0010:\u001a\b\u0012\u0004\u0012\u00020\b0KH&J\u0016\u0010Z\u001a\u00020\b2\f\u0010:\u001a\b\u0012\u0004\u0012\u00020\b0KH&J\u0010\u0010\\\u001a\u00020\u00022\u0006\u0010[\u001a\u00020\u0006H&J \u0010^\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010]\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u0006H&J\u0010\u0010`\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010_H&J\u0018\u0010c\u001a\u00020\b2\u0006\u0010a\u001a\u00020\u00042\u0006\u0010b\u001a\u00020\u0006H&J\u0010\u0010d\u001a\u00020\b2\u0006\u0010$\u001a\u00020#H&J\u0016\u0010h\u001a\b\u0012\u0004\u0012\u00020g0f2\u0006\u0010e\u001a\u00020\u0006H&J\u0010\u0010j\u001a\u00020\b2\u0006\u0010i\u001a\u00020\u0014H&J0\u0010n\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0013\u001a\u00020\u00062\u0006\u0010k\u001a\u00020\u00062\u0006\u0010l\u001a\u00020\u00062\u0006\u0010m\u001a\u00020\u0006H&JH\u0010s\u001a\u00020\b2\"\u0010q\u001a\u001e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00060oj\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u0006`p2\u001a\u0010r\u001a\u0016\u0012\u0004\u0012\u00020\u0002\u0012\u0006\u0012\u0004\u0018\u00010\u0006\u0012\u0004\u0012\u00020\b0=H&J\u0018\u0010t\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0013\u001a\u00020\u0006H&J\u0018\u0010u\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0013\u001a\u00020\u0006H&J\b\u0010v\u001a\u00020\u0002H&J\b\u0010w\u001a\u00020\bH&J\b\u0010x\u001a\u00020\bH&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006yÀ\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/router/provider/AppModuleService;", "Lcom/alibaba/android/arouter/facade/template/IProvider;", "", "isUpData", "Landroid/content/Context;", "context", "", "momentsEntityJson", "", "action2MomentCommentActivity", "autoTranslate", "uid", "source", "action2VideoPlayer", "Landroid/widget/TextView;", "textView", "content", "Landroid/text/SpannableString;", "parseEmoticon", "id", "Lcom/gateio/rxjava/basemvp/IHostView;", "hostView", "isAdmin", "", ShareConstants.STORY_DEEP_LINK_URL, "spannableString", "Landroid/text/SpannableStringBuilder;", "parseTopicCoin", "(Ljava/lang/String;Ljava/lang/String;Lcom/gateio/rxjava/basemvp/IHostView;ZLjava/util/List;Landroid/text/SpannableString;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "nickname", "avatar", "", "tier", "timId", "action2SubscribeSubActivity", "Landroid/app/Activity;", "activity", "action2Defi", JPushConstants.Analysis.KEY_JSON, "action2ShortVideoPlayerActivity", "imagesJson", "index", "action2ShowPicActivity", "Landroid/widget/ImageView;", "imageView", "url", "showEmoji", "assest", "fundingSubjectNotify", "steamId", "horizontal", "videoSource", "sourceUrl", "startVideoPlay", "action2StrategyDetail", "Lkotlin/Function1;", "Lkotlin/ParameterName;", "name", H5Container.FUNC, "subscribeVideo", "unsubscribeVideo", "Lkotlin/Function2;", IceSdpUtils.MID, "momentCommentTotal", "createCommentListener", "createReplyListener", "momentCommentEntity", "deleteCommetListener", "deleteReplyListener", "Lkotlin/Function3;", "likeEntity", "counter", "refreshZansListener", "subscribeComments", "unsubscribeComments", "Lkotlin/Function0;", "momentRefreshListener", "momentsEntity", "onItemRefreshListener", GetHelpActivity.IS_FOLLOW, "notifyFollowingStatus", "role", "notifyUserRoleStatus", "vid", "notifyVoteStatus", "isAdminTop", "notifyAdminTopStatus", "subscribeMoment", "unsubscribeMoment", "subscribeFiatExchange", "unsubscribeFiatExchange", "strategyType", "isStrategyNewType", "type", "action2StructuredDetail", "", "getMarketFiatPairs", "mContext", "leaderId", "action2TradingUser", "restartApp", "currencyType", "Lio/reactivex/rxjava3/core/s;", "Lcom/gateio/biz/base/model/CurrencyData;", "getLiteCurrencies", "mHostView", "refreshTransAccount", "currency", "exchange", HomeConst.HOME_PORCELAIN_STRATEGY_SIDE, "openTransOrderDetailActivity", "Ljava/util/HashMap;", "Lkotlin/collections/HashMap;", "map", "sendResult", "sendMoment", "action2LiveVideo", "action2Video", "isCanPush", "refreshPresetData", "backToLoan", "biz_base_core_release"}, k = 1, mv = {1, 9, 0})
/* loaded from: classes37.dex */
public interface AppModuleService extends IProvider {
    void action2Defi(@NotNull Activity activity);

    void action2LiveVideo(@NotNull Context context, @NotNull String id);

    void action2MomentCommentActivity(@NotNull Context context, @NotNull String momentsEntityJson, boolean autoTranslate);

    void action2MomentCommentActivity(boolean isUpData, @NotNull Context context, @NotNull String momentsEntityJson);

    void action2ShortVideoPlayerActivity(@NotNull Context context, @NotNull String json);

    void action2ShowPicActivity(@NotNull Context context, @NotNull String imagesJson, int index);

    void action2StrategyDetail(@NotNull Context context, @NotNull String json);

    void action2StructuredDetail(@NotNull Context context, @NotNull String type, @NotNull String id);

    void action2SubscribeSubActivity(@NotNull Context context, @NotNull String nickname, @NotNull String avatar, int tier, @NotNull String timId, @NotNull String uid);

    void action2TradingUser(@NotNull Context mContext, @NotNull String leaderId);

    void action2Video(@NotNull Context context, @NotNull String id);

    void action2VideoPlayer(@NotNull Context context, @NotNull String uid, @NotNull String source);

    void backToLoan();

    void fundingSubjectNotify(@NotNull String assest);

    @NotNull
    s<CurrencyData> getLiteCurrencies(@NotNull String currencyType);

    @Nullable
    Set<String> getMarketFiatPairs();

    boolean isCanPush();

    boolean isStrategyNewType(@NotNull String strategyType);

    void openTransOrderDetailActivity(@NotNull Context context, @NotNull String id, @NotNull String currency, @NotNull String exchange, @NotNull String side);

    @NotNull
    SpannableString parseEmoticon(@NotNull TextView textView, @Nullable String content);

    @Nullable
    Object parseTopicCoin(@NotNull String str, @NotNull String str2, @NotNull IHostView iHostView, boolean z10, @NotNull List<String> list, @Nullable SpannableString spannableString, @NotNull Continuation<? super SpannableStringBuilder> continuation);

    void refreshPresetData();

    void refreshTransAccount(@NotNull IHostView mHostView);

    void restartApp(@NotNull Activity activity);

    void sendMoment(@NotNull HashMap<String, String> map, @NotNull Function2<? super Boolean, ? super String, Unit> sendResult);

    void showEmoji(@NotNull ImageView imageView, @NotNull String url);

    void startVideoPlay(@NotNull String steamId, boolean horizontal, @NotNull String videoSource, @NotNull String sourceUrl);

    void subscribeComments(@NotNull Function2<? super String, ? super String, Unit> createCommentListener, @NotNull Function2<? super String, ? super String, Unit> createReplyListener, @NotNull Function2<? super String, ? super String, Unit> deleteCommetListener, @NotNull Function2<? super String, ? super String, Unit> deleteReplyListener, @NotNull Function3<? super String, ? super String, ? super String, Unit> refreshZansListener);

    void subscribeFiatExchange(@NotNull Function0<Unit> func);

    void subscribeMoment(@NotNull Function0<Unit> momentRefreshListener, @NotNull Function1<? super String, Unit> onItemRefreshListener, @NotNull Function2<? super String, ? super Integer, Unit> notifyFollowingStatus, @NotNull Function2<? super String, ? super Integer, Unit> notifyUserRoleStatus, @NotNull Function2<? super String, ? super String, Unit> notifyVoteStatus, @NotNull Function2<? super String, ? super String, Unit> notifyAdminTopStatus);

    void subscribeVideo(@NotNull Function1<? super String, Unit> func);

    void unsubscribeComments();

    void unsubscribeFiatExchange(@NotNull Function0<Unit> func);

    void unsubscribeMoment();

    void unsubscribeVideo();
}