package com.gateio.biz.base.router.provider;

import android.content.Context;
import com.alibaba.android.arouter.facade.template.IProvider;
import com.gateio.biz.base.router.RouterConst;
import com.gateio.fiatotclib.function.order.merchant.MerchantOrderDetailActivity;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* compiled from: FuturesModuleService.kt */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\bf\u0018\u00002\u00020\u0001J8\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\tH&J\u0018\u0010\u000b\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\tH&J8\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0010\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u0011\u001a\u00020\u0003H&J(\u0010\u0012\u001a\u00020\u00032\u0006\u0010\u0013\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\tH&¨\u0006\u0014"}, d2 = {"Lcom/gateio/biz/base/router/provider/FuturesModuleService;", "Lcom/alibaba/android/arouter/facade/template/IProvider;", "addUnitOfAmount", "", "amount", "deal_price", "contract", RouterConst.AlertKey.PARAMS_SETTLE_KYE, "isDelivery", "", "isTestNet", "getShowContract", "openFuturesOrderDetailActivity", "", "context", "Landroid/content/Context;", MerchantOrderDetailActivity.ORDER_ID, "closeUnit", "priceDecimal", "price", "biz_market_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public interface FuturesModuleService extends IProvider {
    @NotNull
    String addUnitOfAmount(@NotNull String amount, @NotNull String deal_price, @NotNull String contract, @NotNull String settle, boolean isDelivery, boolean isTestNet);

    @NotNull
    String getShowContract(@NotNull String contract, boolean isDelivery);

    void openFuturesOrderDetailActivity(@NotNull Context context, @NotNull String contract, @NotNull String orderId, boolean isTestNet, boolean isDelivery, @NotNull String closeUnit);

    @NotNull
    String priceDecimal(@NotNull String price, @NotNull String contract, @NotNull String settle, boolean isDelivery);
}