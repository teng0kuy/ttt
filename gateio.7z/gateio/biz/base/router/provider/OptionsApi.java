package com.gateio.biz.base.router.provider;

import com.alibaba.android.arouter.facade.template.IProvider;
import com.gateio.biz.base.model.CurrencyData;
import com.gateio.biz.base.router.RouterConst;
import com.gateio.lib.router.GTRouter;
import io.reactivex.rxjava3.core.s;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* compiled from: OptionsApi.kt */
@Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bf\u0018\u0000 \u00072\u00020\u0001:\u0001\u0007J\u0016\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u00042\u0006\u0010\u0003\u001a\u00020\u0002H&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\bÀ\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/router/provider/OptionsApi;", "Lcom/alibaba/android/arouter/facade/template/IProvider;", "", "currencyType", "Lio/reactivex/rxjava3/core/s;", "Lcom/gateio/biz/base/model/CurrencyData;", "getLiteCurrencies", "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0})
/* loaded from: classes37.dex */
public interface OptionsApi extends IProvider {

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = Companion.$$INSTANCE;

    /* compiled from: OptionsApi.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0003\u001a\u00020\u0004¨\u0006\u0005"}, d2 = {"Lcom/gateio/biz/base/router/provider/OptionsApi$Companion;", "", "()V", "get", "Lcom/gateio/biz/base/router/provider/OptionsApi;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Companion {
        static final /* synthetic */ Companion $$INSTANCE = new Companion();

        private Companion() {
        }

        @NotNull
        public final OptionsApi get() {
            return (OptionsApi) GTRouter.serviceAPI(RouterConst.App.APP_OPTIONS);
        }
    }

    @NotNull
    s<CurrencyData> getLiteCurrencies(@NotNull String currencyType);
}