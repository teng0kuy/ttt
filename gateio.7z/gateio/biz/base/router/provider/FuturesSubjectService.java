package com.gateio.biz.base.router.provider;

import android.os.Bundle;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import com.alibaba.android.arouter.facade.template.IProvider;
import com.ap.zoloz.hummer.biz.HummerConstants;
import com.gateio.biz.base.futures.FuturesCoinTypeEnum;
import com.gateio.biz.base.router.RouterConst;
import com.gateio.biz.market.ui_market.MarketFragmentList;
import com.gateio.common.listener.ISuccessCallBack;
import com.gateio.rxjava.basemvp.IBaseView;
import com.jumio.liveness.DaClient;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: FuturesSubjectService.kt */
@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0013\bf\u0018\u00002\u00020\u0001JT\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00052\b\u0010\u0007\u001a\u0004\u0018\u00010\b2\u0006\u0010\t\u001a\u00020\b2\b\u0010\n\u001a\u0004\u0018\u00010\u000b2\f\u0010\f\u001a\b\u0012\u0002\b\u0003\u0018\u00010\r2\u0010\u0010\u000e\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0018\u00010\u000fH&JJ\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00052\b\u0010\u0007\u001a\u0004\u0018\u00010\b2\u0006\u0010\t\u001a\u00020\b2\f\u0010\f\u001a\b\u0012\u0002\b\u0003\u0018\u00010\r2\u0010\u0010\u000e\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0018\u00010\u000fH&J:\u0010\u0002\u001a\u00020\u00032\b\u0010\u0007\u001a\u0004\u0018\u00010\b2\u0006\u0010\t\u001a\u00020\b2\f\u0010\f\u001a\b\u0012\u0002\b\u0003\u0018\u00010\r2\u0010\u0010\u000e\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0018\u00010\u000fH&J\n\u0010\u0010\u001a\u0004\u0018\u00010\u0011H&J \u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0015\u001a\u00020\u0005H&J\u0010\u0010\u0016\u001a\u00020\u00132\u0006\u0010\u0017\u001a\u00020\u0005H&J\u0018\u0010\u0018\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005H&J\u0010\u0010\u0004\u001a\u00020\u00002\u0006\u0010\u0004\u001a\u00020\u0005H&J \u0010\u001a\u001a\u00020\u00052\u0006\u0010\u0019\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0015\u001a\u00020\u0005H&J\u0018\u0010\u001b\u001a\u00020\u00052\u0006\u0010\u0019\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0005H&J\u0010\u0010\u0006\u001a\u00020\u00002\u0006\u0010\u001c\u001a\u00020\u0005H&J \u0010\u001d\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u001e\u001a\u00020\u0013H&J\b\u0010\u001f\u001a\u00020\u0003H&J\b\u0010 \u001a\u00020\u0003H&J\b\u0010!\u001a\u00020\u0003H&J\u0012\u0010\"\u001a\u00020\u00032\b\u0010#\u001a\u0004\u0018\u00010\u0011H&J\u0010\u0010$\u001a\u00020\u00002\u0006\u0010%\u001a\u00020\bH&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006&À\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/router/provider/FuturesSubjectService;", "Lcom/alibaba/android/arouter/facade/template/IProvider;", "checkNotify", "", "isDelivery", "", "isTestNet", RouterConst.AlertKey.PARAMS_SETTLE_KYE, "", "contract", HummerConstants.BUNDLE, "Landroid/os/Bundle;", "iBaseView", "Lcom/gateio/rxjava/basemvp/IBaseView;", "iSuccessCallBack", "Lcom/gateio/common/listener/ISuccessCallBack;", "getAmountType", "Lcom/gateio/biz/base/futures/FuturesCoinTypeEnum;", "getMarketVoucherMode", "", "sUSDT", "isBTC", "getTransContractType", TypedValues.Custom.S_BOOLEAN, "getVoucherMode", "isUSDT", "isMarketModeVoucher", MarketFragmentList.IS_MODE_VOUCHER, "isTest", "jumpFutureChildTab", "position", "navToDeliveryPage", "notifyByMethod", "notifyByOldMethod", "setAmountType", "amountType", DaClient.ATTR_SHIFT, "closeUnit", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public interface FuturesSubjectService extends IProvider {
    void checkNotify(@Nullable String settle, @NotNull String contract, @Nullable IBaseView<?> iBaseView, @Nullable ISuccessCallBack<Boolean> iSuccessCallBack);

    void checkNotify(boolean isDelivery, boolean isTestNet, @Nullable String settle, @NotNull String contract, @Nullable Bundle bundle, @Nullable IBaseView<?> iBaseView, @Nullable ISuccessCallBack<Boolean> iSuccessCallBack);

    void checkNotify(boolean isDelivery, boolean isTestNet, @Nullable String settle, @NotNull String contract, @Nullable IBaseView<?> iBaseView, @Nullable ISuccessCallBack<Boolean> iSuccessCallBack);

    @Nullable
    FuturesCoinTypeEnum getAmountType();

    int getMarketVoucherMode(boolean sUSDT, boolean isDelivery, boolean isBTC);

    int getTransContractType(boolean z10);

    int getVoucherMode(boolean isUSDT, boolean isDelivery);

    @NotNull
    FuturesSubjectService isDelivery(boolean isDelivery);

    boolean isMarketModeVoucher(boolean isUSDT, boolean isDelivery, boolean isBTC);

    boolean isModeVoucher(boolean isUSDT, boolean isDelivery);

    @NotNull
    FuturesSubjectService isTestNet(boolean isTest);

    void jumpFutureChildTab(@NotNull String settle, @NotNull String contract, int position);

    void navToDeliveryPage();

    void notifyByMethod();

    void notifyByOldMethod();

    void setAmountType(@Nullable FuturesCoinTypeEnum amountType);

    @NotNull
    FuturesSubjectService shift(@NotNull String closeUnit);
}