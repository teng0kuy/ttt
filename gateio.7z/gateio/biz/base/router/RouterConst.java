package com.gateio.biz.base.router;

import com.gateio.biz.market.datafinder.MarketDataFinderConst;
import com.gateio.biz.market.util.MarketConst;
import com.gateio.fiatotclib.entity.C2cOrders;
import com.jumio.core.data.UploadType;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: RouterConst.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b,\bÆ\u0002\u0018\u00002\u00020\u0001:*\u0003\u0004\u0005\u0006\u0007\b\t\n\u000b\f\r\u000e\u000f\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001a\u001b\u001c\u001d\u001e\u001f !\"#$%&'()*+,B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006-"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst;", "", "()V", "AiAgentParamsKey", "AlertKey", "App", "BuyCrypto", "Coin2Coin", "ComLib", "CopyTrading", "Earn", "EmbedForm", "Exchange", "ExchangeNative", UploadType.FACE, "FiatChannel", "FiatLoan", "FiatOtc", "Fido", "Finance", "Flutter", "Futures", "HomePage", "KYC", "Kline", "Live", "Margin", "Market", "MemeBox", "MiniApp", "Moments", "Network", "OTC", "Options", "Pilot", "RegisterLogin", "Safe", "Security", "SubApps", "Trans", "Unified", "Wallet", "Wallets", MarketConst.searchWeb3MemeTitle, "WebPath", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public final class RouterConst {

    @NotNull
    public static final RouterConst INSTANCE = new RouterConst();

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0006"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$AiAgentParamsKey;", "", "()V", "AGENT_PARAM_ANALYSE", "", "AGENT_PARAM_CODE", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class AiAgentParamsKey {

        @NotNull
        public static final String AGENT_PARAM_ANALYSE = "analyse";

        @NotNull
        public static final String AGENT_PARAM_CODE = "code";

        @NotNull
        public static final AiAgentParamsKey INSTANCE = new AiAgentParamsKey();

        private AiAgentParamsKey() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\n\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u000e"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$AlertKey;", "", "()V", "PARAMS_ALPHA", "", "PARAMS_ENTRY_SOURCE_KYE", "PARAMS_FUTURES", "PARAMS_MARKET_KYE", "PARAMS_NOTICE_TYPE_KYE", "PARAMS_PILOT", "PARAMS_PRICE_TYPE_KYE", "PARAMS_SETTLE_KYE", "PARAMS_SPOT", "PARAMS_TYPE_KYE", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class AlertKey {

        @NotNull
        public static final AlertKey INSTANCE = new AlertKey();

        @NotNull
        public static final String PARAMS_ALPHA = "memebox";

        @NotNull
        public static final String PARAMS_ENTRY_SOURCE_KYE = "entry_source";

        @NotNull
        public static final String PARAMS_FUTURES = "futures";

        @NotNull
        public static final String PARAMS_MARKET_KYE = "market";

        @NotNull
        public static final String PARAMS_NOTICE_TYPE_KYE = "notice_type";

        @NotNull
        public static final String PARAMS_PILOT = "pilot";

        @NotNull
        public static final String PARAMS_PRICE_TYPE_KYE = "price_type";

        @NotNull
        public static final String PARAMS_SETTLE_KYE = "settle";

        @NotNull
        public static final String PARAMS_SPOT = "spot";

        @NotNull
        public static final String PARAMS_TYPE_KYE = "type";

        private AlertKey() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\bI\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00100\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00101\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00102\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00103\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00104\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00105\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00106\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00107\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00108\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00109\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010:\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010;\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010<\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010=\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010>\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010?\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010@\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010A\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010B\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010C\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010D\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010E\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010F\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010G\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010H\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010I\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010J\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010K\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010L\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006M"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$App;", "", "()V", "ACTIVITY_GOOGLE_CERTIFY", "", "ACTIVITY_MARGIN_FUND", "ACTIVITY_MOMENTS_DETAIL", "ACTIVITY_MOMENTS_POINT_HISTORY", "ACTIVITY_MOMENTS_POINT_HOME", "ACTIVITY_MOMENTS_POINT_RANKING", "ACTIVITY_MOMENTS_POINT_RULES", "ACTIVITY_MOMENTS_POST_CREATION", "ACTIVITY_OPTION_HIS", "ACTIVITY_REFERRAL_AC_LIST_PAGE", "ACTIVITY_REFERRAL_MAIN_HOME", "ACTIVITY_SPACE", "ACTIVITY_VOUCHER_FUTURES_DIALOG", "APP_AMM", "APP_AMM_DETAIL", "APP_DEX_FUTURES", "APP_DUAL", "APP_FUTURES", "APP_FUTURES_MARKET_SELECT", "APP_GAMEFIJUMP", "APP_GamefiDispatcher", "APP_HOLDLIST", "APP_INFORMATION", "APP_INVEST", "APP_LIVE_CHATROOM", "APP_MAIN", "APP_MODULE_BRIDGE", "APP_MOMENTS", "APP_NOTIFICATIONJUMP", "APP_OPTIONS", "APP_POINT", "APP_SERVICE", "APP_SHARE_UTIL", "APP_STRATEGYHOME", "APP_STRATEGYSMARTPOSITIONDETAIL", "APP_STRUCTURED_FINANCE", "APP_STRUCTURED_FINANCE_DETAIL", "APP_STRUCTURED_RECORD", "APP_SUBSCRIBE_SUB", "APP_TRADE_PAIRS", "APP_TRANS_CALCULATOR", "APP_TRANS_SUBJECT", "APP_VIDEO_PLAY", "APP_WALLET_PAGE", "APP_WEB", "App_FUNDING", "FIAT_SERVICE", "NEWS_CHAT_USERINFO", "NEWS_CHAT_USERINFO_MOMENTS", "PROVIDER_APP_CALLBACK", "PROVIDER_CHATROOM_V2", "PROVIDER_GRADLE", "QR_CODE_UTILS", "RED_PACK_INPUT", "SAFETY_CENTER", "SETTING_EXCHANGE", "STRATEGY_JUMP_UTILS", "SUB_APPS_LOGIN_OAUTH", "USER_CENTER_ABOUT_US", "USER_CENTER_PREFERENCE_MARKET_DISPLAY", "USER_CENTER_PREFERENCE_PUSH_SETTINGS", "USER_CENTER_PREFERENCE_RISE_FAIL_COLOR", "USER_CENTER_PREFERENCE_SPOT_TRADING_SETTINGS", "USER_CENTER_PREFERENCE_START_END_TIME_CHANGE", "USER_CENTER_SECURITY_ANTI_PHISING_CODE", "USER_CENTER_SECURITY_DELETE_ACCOUNT", "USER_CENTER_SECURITY_MY_DEVICES", "USER_CENTER_SECURITY_PASSWORD_RESET", "USER_CENTER_SECURITY_PHONE_VERIFICATION", "USER_CENTER_SECURITY_TWO_FACTOR_AUTHENTICATION", "VIP_RIGHT_PAGE", "WALLET_STRATEGY_SELF_ACTIVITY", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class App {

        @NotNull
        public static final String ACTIVITY_GOOGLE_CERTIFY = "/mainApp/activity/google_certify";

        @NotNull
        public static final String ACTIVITY_MARGIN_FUND = "/mainApp/activity/marginFund";

        @NotNull
        public static final String ACTIVITY_MOMENTS_DETAIL = "/mainApp/activity/moments_detail";

        @NotNull
        public static final String ACTIVITY_MOMENTS_POINT_HISTORY = "/mainApp/activity/moments_point_history";

        @NotNull
        public static final String ACTIVITY_MOMENTS_POINT_HOME = "/mainApp/activity/moments_point_home";

        @NotNull
        public static final String ACTIVITY_MOMENTS_POINT_RANKING = "/mainApp/activity/moments_point_ranking";

        @NotNull
        public static final String ACTIVITY_MOMENTS_POINT_RULES = "/mainApp/activity/moments_point_rules";

        @NotNull
        public static final String ACTIVITY_MOMENTS_POST_CREATION = "/mainApp/activity/moments_post_creation";

        @NotNull
        public static final String ACTIVITY_OPTION_HIS = "/mainApp/activity/OptionHis";

        @NotNull
        public static final String ACTIVITY_REFERRAL_AC_LIST_PAGE = "/mainApp/activity/referral_ac_list_page";

        @NotNull
        public static final String ACTIVITY_REFERRAL_MAIN_HOME = "/mainApp/activity/referral_main_home";

        @NotNull
        public static final String ACTIVITY_SPACE = "/mainApp/activity/space";

        @NotNull
        public static final String ACTIVITY_VOUCHER_FUTURES_DIALOG = "/mainApp/activity/voucher_futures_dialog";

        @NotNull
        public static final String APP_AMM = "/mainApp/Amm";

        @NotNull
        public static final String APP_AMM_DETAIL = "/mainApp/amm/detail";

        @NotNull
        public static final String APP_DEX_FUTURES = "/mainApp/dex/Futures";

        @NotNull
        public static final String APP_DUAL = "/mainApp/Dual";

        @NotNull
        public static final String APP_FUTURES = "/mainApp/Futures";

        @NotNull
        public static final String APP_FUTURES_MARKET_SELECT = "/mainApp/FuturesMarketSelect";

        @NotNull
        public static final String APP_GAMEFIJUMP = "/mainApp/gamefijump";

        @NotNull
        public static final String APP_GamefiDispatcher = "/mainApp/gamefidispatcher";

        @NotNull
        public static final String APP_HOLDLIST = "/mainApp/HoldList";

        @NotNull
        public static final String APP_INFORMATION = "/mainApp/information";

        @NotNull
        public static final String APP_INVEST = "/mainApp/Invest";

        @NotNull
        public static final String APP_LIVE_CHATROOM = "/mainApp/live_chatroom";

        @NotNull
        public static final String APP_MAIN = "/mainApp/main";

        @NotNull
        public static final String APP_MODULE_BRIDGE = "/mainApp/module/bridge";

        @NotNull
        public static final String APP_MOMENTS = "/mainApp/moments";

        @NotNull
        public static final String APP_NOTIFICATIONJUMP = "/mainApp/notificationjump";

        @NotNull
        public static final String APP_OPTIONS = "/mainApp/Options";

        @NotNull
        public static final String APP_POINT = "/mainApp/Point";

        @NotNull
        public static final String APP_SERVICE = "/mainApp/Service";

        @NotNull
        public static final String APP_SHARE_UTIL = "/mainApp/share_util";

        @NotNull
        public static final String APP_STRATEGYHOME = "/mainApp/strategy/home";

        @NotNull
        public static final String APP_STRATEGYSMARTPOSITIONDETAIL = "/mainApp/strategy/smart/position/detail";

        @NotNull
        public static final String APP_STRUCTURED_FINANCE = "/mainApp/Structured_Finance";

        @NotNull
        public static final String APP_STRUCTURED_FINANCE_DETAIL = "/mainApp/Structured_Finance_Detail";

        @NotNull
        public static final String APP_STRUCTURED_RECORD = "/mainApp/Structured_Record";

        @NotNull
        public static final String APP_SUBSCRIBE_SUB = "/mainApp/subscribe_sub";

        @NotNull
        public static final String APP_TRADE_PAIRS = "/mainApp/tradePairs";

        @NotNull
        public static final String APP_TRANS_CALCULATOR = "/mainApp/tranCalculator";

        @NotNull
        public static final String APP_TRANS_SUBJECT = "/mainApp/transubject";

        @NotNull
        public static final String APP_VIDEO_PLAY = "/mainApp/video_play";

        @NotNull
        public static final String APP_WALLET_PAGE = "/mainApp/wallet/page";

        @NotNull
        public static final String APP_WEB = "/mainApp/webactivity";

        @NotNull
        public static final String App_FUNDING = "/mainApp/Funding";

        @NotNull
        public static final String FIAT_SERVICE = "/mainApp/fiat/provider";

        @NotNull
        public static final App INSTANCE = new App();

        @NotNull
        public static final String NEWS_CHAT_USERINFO = "/mainApp/news/chat/userinfo";

        @NotNull
        public static final String NEWS_CHAT_USERINFO_MOMENTS = "/mainApp/news/chat/userinfo/moments";

        @NotNull
        public static final String PROVIDER_APP_CALLBACK = "/mainApp/provider/app_callback";

        @NotNull
        public static final String PROVIDER_CHATROOM_V2 = "/mainApp/provider/chatroom_v2";

        @NotNull
        public static final String PROVIDER_GRADLE = "/mainApp/provider/gradle";

        @NotNull
        public static final String QR_CODE_UTILS = "/mainApp/qrCode/qr_utils";

        @NotNull
        public static final String RED_PACK_INPUT = "/mainApp/redpack/input";

        @NotNull
        public static final String SAFETY_CENTER = "/mainApp/activity/SafetyCenterActivity";

        @NotNull
        public static final String SETTING_EXCHANGE = "/mainApp/setting/exchange_rate_activity";

        @NotNull
        public static final String STRATEGY_JUMP_UTILS = "/mainApp/strategy/jump_utils";

        @NotNull
        public static final String SUB_APPS_LOGIN_OAUTH = "/subapps/login/oauth";

        @NotNull
        public static final String USER_CENTER_ABOUT_US = "/user_center/about_us";

        @NotNull
        public static final String USER_CENTER_PREFERENCE_MARKET_DISPLAY = "/user_center/preference/market_display";

        @NotNull
        public static final String USER_CENTER_PREFERENCE_PUSH_SETTINGS = "/user_center/preference/push_settings";

        @NotNull
        public static final String USER_CENTER_PREFERENCE_RISE_FAIL_COLOR = "/user_center/preference/rise_fail_color";

        @NotNull
        public static final String USER_CENTER_PREFERENCE_SPOT_TRADING_SETTINGS = "/user_center/preference/spot_trading_settings";

        @NotNull
        public static final String USER_CENTER_PREFERENCE_START_END_TIME_CHANGE = "/user_center/preference/start_end_time_change";

        @NotNull
        public static final String USER_CENTER_SECURITY_ANTI_PHISING_CODE = "/user_center/security/anti_phising_code";

        @NotNull
        public static final String USER_CENTER_SECURITY_DELETE_ACCOUNT = "/user_center/security/delete_account";

        @NotNull
        public static final String USER_CENTER_SECURITY_MY_DEVICES = "/user_center/security/my_devices";

        @NotNull
        public static final String USER_CENTER_SECURITY_PASSWORD_RESET = "/user_center/security/password_reset";

        @NotNull
        public static final String USER_CENTER_SECURITY_PHONE_VERIFICATION = "/user_center/security/phone_verification";

        @NotNull
        public static final String USER_CENTER_SECURITY_TWO_FACTOR_AUTHENTICATION = "/user_center/security/two_factor_authentication";

        @NotNull
        public static final String VIP_RIGHT_PAGE = "/mainApp/activity/vip_right_page";

        @NotNull
        public static final String WALLET_STRATEGY_SELF_ACTIVITY = "/mainApp/wallet/strategy_self_activity";

        @NotNull
        private static final String groupName = "mainApp";

        private App() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0014\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u001a\u0010\u0015\u001a\u00020\u00042\b\u0010\u0016\u001a\u0004\u0018\u00010\u00042\b\u0010\u0017\u001a\u0004\u0018\u00010\u0004R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0018"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$BuyCrypto;", "", "()V", "BUY_WITH_BANK_ACCOUNT", "", "BUY_WITH_CREDIT_CARD", "KEY_CHANNEL", "KEY_CRYPTO", "KEY_CRYPTO_AMOUNT", "KEY_FIAT", "KEY_FIAT_AMOUNT", "KEY_IS_BUY", "KEY_IS_DEPOSIT", "KEY_METHOD", "KEY_SUB_URL", "KEY_TITLE", "KEY_TRADE_TYPE", "KEY_TYPE_METHOD", "ROUTER", "SELL_WITH_BANK_ACCOUNT", "SELL_WITH_CREDIT_CARD", "getNewTypeMethod", "method", "type", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class BuyCrypto {

        @NotNull
        public static final String BUY_WITH_BANK_ACCOUNT = "crypto/buy/with-bank-account";

        @NotNull
        public static final String BUY_WITH_CREDIT_CARD = "crypto/buy/with-credit-card";

        @NotNull
        public static final BuyCrypto INSTANCE = new BuyCrypto();

        @NotNull
        public static final String KEY_CHANNEL = "channel";

        @NotNull
        public static final String KEY_CRYPTO = "crypto";

        @NotNull
        public static final String KEY_CRYPTO_AMOUNT = "crypto_amount";

        @NotNull
        public static final String KEY_FIAT = "fiat";

        @NotNull
        public static final String KEY_FIAT_AMOUNT = "fiat_amount";

        @NotNull
        public static final String KEY_IS_BUY = "is_buy";

        @NotNull
        public static final String KEY_IS_DEPOSIT = "is_deposit";

        @NotNull
        public static final String KEY_METHOD = "method";

        @NotNull
        public static final String KEY_SUB_URL = "subUrl";

        @NotNull
        public static final String KEY_TITLE = "title";

        @NotNull
        public static final String KEY_TRADE_TYPE = "trade_type";

        @NotNull
        public static final String KEY_TYPE_METHOD = "type_method";

        @NotNull
        public static final String ROUTER = "/buycrypto/fastRecharge";

        @NotNull
        public static final String SELL_WITH_BANK_ACCOUNT = "crypto/sell/with-bank-account";

        @NotNull
        public static final String SELL_WITH_CREDIT_CARD = "crypto/sell/with-credit-card";

        private BuyCrypto() {
        }

        @NotNull
        public final String getNewTypeMethod(@Nullable String method, @Nullable String type) {
            return Intrinsics.areEqual(method, C2cOrders.PAY_TYPE_BANK) ? Intrinsics.areEqual(type, "sell") ? SELL_WITH_BANK_ACCOUNT : BUY_WITH_BANK_ACCOUNT : Intrinsics.areEqual(type, "sell") ? SELL_WITH_CREDIT_CARD : BUY_WITH_CREDIT_CARD;
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0005"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Coin2Coin;", "", "()V", Coin2Coin.KEY_COIN_LOAN_ACTIVITY_TAB, "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Coin2Coin {

        @NotNull
        public static final Coin2Coin INSTANCE = new Coin2Coin();

        @NotNull
        public static final String KEY_COIN_LOAN_ACTIVITY_TAB = "KEY_COIN_LOAN_ACTIVITY_TAB";

        private Coin2Coin() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$ComLib;", "", "()V", "BASE_PROVIDER", "", "FLUTTER_PROVIDER", "PROVIDER", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class ComLib {

        @NotNull
        public static final String BASE_PROVIDER = "/com_lib/base/provider";

        @NotNull
        public static final String FLUTTER_PROVIDER = "/com_lib/flutter/provider";

        @NotNull
        public static final ComLib INSTANCE = new ComLib();

        @NotNull
        public static final String PROVIDER = "/com_lib/provider";

        private ComLib() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\f\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$CopyTrading;", "", "()V", "COPYTRADING_FOLLOW", "", "COPYTRADING_HOME", "COPYTRADING_SEARCH", "COPYTRADING_SELF", "COPYTRADING_UTILS", "COPY_FOLLOW_FLUTTER", "COPY_MINE_FLUTTER", "COPY_MINE_LEAD_FLUTTER", "COPY_TRADER_APPLY_FLUTTER", "COPY_TRADING_NAVS_TREND", "COPY_UNDER_REVIEW_FLUTTER", "TRADING_USER", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class CopyTrading {

        @NotNull
        public static final String COPYTRADING_FOLLOW = "/moduleCopyTrading/follow";

        @NotNull
        public static final String COPYTRADING_HOME = "/moduleCopyTrading/home";

        @NotNull
        public static final String COPYTRADING_SEARCH = "/moduleCopyTrading/search";

        @NotNull
        public static final String COPYTRADING_SELF = "/moduleCopyTrading/self";

        @NotNull
        public static final String COPYTRADING_UTILS = "/moduleCopyTrading/utils";

        @NotNull
        public static final String COPY_FOLLOW_FLUTTER = "/exchange/copy/setting";

        @NotNull
        public static final String COPY_MINE_FLUTTER = "/exchange/copy/mine";

        @NotNull
        public static final String COPY_MINE_LEAD_FLUTTER = "/exchange/copy/lead";

        @NotNull
        public static final String COPY_TRADER_APPLY_FLUTTER = "/exchange/copy/trader_apply_page";

        @NotNull
        public static final String COPY_TRADING_NAVS_TREND = "/copytrading/navs-trend";

        @NotNull
        public static final String COPY_UNDER_REVIEW_FLUTTER = "/exchange/copy/under_review";

        @NotNull
        public static final CopyTrading INSTANCE = new CopyTrading();

        @NotNull
        public static final String TRADING_USER = "/moduleCopyTrading/user";

        private CopyTrading() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\b\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\f"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Earn;", "", "()V", "FINANCE_EARN_CONTAINER", "", "FINANCE_EARN_FRAGMENT", "FINANCE_EARN_TAB", "FINANCE_LAUNCHPOOL_AIRDROP", "FINANCE_LOAN_TAB", "FINANCE_STARTUP_MINING_TAB", "FINANCE_STARTUP_TAB", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Earn {

        @NotNull
        public static final String FINANCE_EARN_CONTAINER = "/earnCoin/earnTabHome";

        @NotNull
        public static final String FINANCE_EARN_FRAGMENT = "/moduleEarn/earn/EarnFragment";

        @NotNull
        public static final String FINANCE_EARN_TAB = "/earnCoin/home";

        @NotNull
        public static final String FINANCE_LAUNCHPOOL_AIRDROP = "/holder-airdrop";

        @NotNull
        public static final String FINANCE_LOAN_TAB = "/cryptoLoan/home";

        @NotNull
        public static final String FINANCE_STARTUP_MINING_TAB = "/startupMining/home";

        @NotNull
        public static final String FINANCE_STARTUP_TAB = "/startup";

        @NotNull
        public static final Earn INSTANCE = new Earn();

        @NotNull
        private static final String groupName = "moduleEarn";

        private Earn() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0005"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$EmbedForm;", "", "()V", "PROVIDER", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class EmbedForm {

        @NotNull
        public static final EmbedForm INSTANCE = new EmbedForm();

        @NotNull
        public static final String PROVIDER = "/embed/provider";

        private EmbedForm() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\n\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u000e"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Exchange;", "", "()V", "EXCHANGE_RULE", "", "EXCHANGE_RULE_DATA_FUNDS_RATE", "EXCHANGE_RULE_DATA_INDEX", "EXCHANGE_RULE_FUTURES_INFO", "EXCHANGE_RULE_INTRODUCE", "EXCHANGE_RULE_LEVERAGE_MARGIN", "PROVIDER_FUTURE_CALLBACK", "PROVIDER_TRANSFER_UTILS", "groupName", "oldGroupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Exchange {

        @NotNull
        public static final String EXCHANGE_RULE = "/exchange/rule/home";

        @NotNull
        public static final String EXCHANGE_RULE_DATA_FUNDS_RATE = "/exchange/rule/data/funds_rate";

        @NotNull
        public static final String EXCHANGE_RULE_DATA_INDEX = "/exchange/rule/data/index";

        @NotNull
        public static final String EXCHANGE_RULE_FUTURES_INFO = "/exchange/rule/futures/info";

        @NotNull
        public static final String EXCHANGE_RULE_INTRODUCE = "/exchange/rule/introduce";

        @NotNull
        public static final String EXCHANGE_RULE_LEVERAGE_MARGIN = "/exchange/rule/futures/leverage_margin";

        @NotNull
        public static final Exchange INSTANCE = new Exchange();

        @NotNull
        public static final String PROVIDER_FUTURE_CALLBACK = "/moduleFutures/provider/future_callback";

        @NotNull
        public static final String PROVIDER_TRANSFER_UTILS = "/old_exchange/provider/transfer_utils";

        @NotNull
        private static final String groupName = "exchange";

        @NotNull
        private static final String oldGroupName = "old_exchange";

        private Exchange() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0006"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$ExchangeNative;", "", "()V", "ACTIVITY_EXCHANGE_AUTHORIZE", "", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class ExchangeNative {

        @NotNull
        public static final String ACTIVITY_EXCHANGE_AUTHORIZE = "/moduleExchangeNative/activity/exchange_authorize";

        @NotNull
        public static final ExchangeNative INSTANCE = new ExchangeNative();

        @NotNull
        private static final String groupName = "moduleExchangeNative";

        private ExchangeNative() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0005"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$FACE;", "", "()V", "PROVIDER", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class FACE {

        @NotNull
        public static final FACE INSTANCE = new FACE();

        @NotNull
        public static final String PROVIDER = "/face/provider";

        private FACE() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b&\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006*"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$FiatChannel;", "", "()V", "FIAT_AZIFY_PAYMENT", "", "FIAT_AZIFY_RESULT", "FIAT_BALANCE_PAYMENT", "FIAT_BALANCE_PROCESSING", "FIAT_BIND_CARD", "FIAT_BUY_AND_SELL_ORDER_LIST", "FIAT_CHANNEL_ORDER_LIST", "FIAT_CHANNEL_RESULT", "FIAT_CHECKOUT_FAIL", "FIAT_CHECKOUT_PAYMENT", "FIAT_CHOOSE_CHANNEL", "FIAT_DEPOSIT_ORDER_LIST", "FIAT_DEPOSIT_PAYMENT", "FIAT_DEPOSIT_WITHDRAW", "FIAT_DEPOSIT_WITHDRAW_ORDER_LIST", "FIAT_OPENPAYD_BUY_PAYMENT", "FIAT_OPENPAYD_SELL_ADD_BANK", "FIAT_OPENPAYD_SELL_CONFIRM", "FIAT_ORDER_HISTORY", "FIAT_ORDER_HISTORY_PENDING_REFUND", "FIAT_ORDER_HISTORY_TAB", "FIAT_QUICK_BUY", "FIAT_RECURRING_BUY", "FIAT_RECURRING_BUY_DETAILS", "FIAT_RECURRING_BUY_FAQ", "FIAT_RECURRING_BUY_HISTORY", "FIAT_RECURRING_BUY_PAYMENT", "FIAT_RECURRING_BUY_RESULT", "FIAT_TRADE", "FIAT_UABKYC_FAILED", "FIAT_UABKYC_FULL", "FIAT_UABKYC_FULL_ADDRESS", "FIAT_UABKYC_FULL_BASIC", "FIAT_UABKYC_NON", "FIAT_UABKYC_PENDING", "FIAT_UABKYC_STEP", "FIAT_WITHDRAW_ORDER_LIST", "FIAT_WITHDRAW_PAYMENT", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class FiatChannel {

        @NotNull
        public static final String FIAT_AZIFY_PAYMENT = "/fiat/payment";

        @NotNull
        public static final String FIAT_AZIFY_RESULT = "/fiat/azify_result";

        @NotNull
        public static final String FIAT_BALANCE_PAYMENT = "/fiat/balance_payment";

        @NotNull
        public static final String FIAT_BALANCE_PROCESSING = "/fiat/balance_processing";

        @NotNull
        public static final String FIAT_BIND_CARD = "/fiat/bind_card";

        @NotNull
        public static final String FIAT_BUY_AND_SELL_ORDER_LIST = "/fiat/buy&sell/order_list";

        @NotNull
        public static final String FIAT_CHANNEL_ORDER_LIST = "/fiat/channel/order_list";

        @NotNull
        public static final String FIAT_CHANNEL_RESULT = "/fiat/channel/result";

        @NotNull
        public static final String FIAT_CHECKOUT_FAIL = "/fiat/checkout/fail";

        @NotNull
        public static final String FIAT_CHECKOUT_PAYMENT = "/fiat/checkout_payment";

        @NotNull
        public static final String FIAT_CHOOSE_CHANNEL = "/fiat/choose_channel";

        @NotNull
        public static final String FIAT_DEPOSIT_ORDER_LIST = "/fiat/deposit/order_list";

        @NotNull
        public static final String FIAT_DEPOSIT_PAYMENT = "/fiat/deposit_payment";

        @NotNull
        public static final String FIAT_DEPOSIT_WITHDRAW = "/fiat/deposit_withdraw";

        @NotNull
        public static final String FIAT_DEPOSIT_WITHDRAW_ORDER_LIST = "/fiat/deposit_withdraw/order_list";

        @NotNull
        public static final String FIAT_OPENPAYD_BUY_PAYMENT = "/fiat/openpayd/buy_payment";

        @NotNull
        public static final String FIAT_OPENPAYD_SELL_ADD_BANK = "/fiat/openpayd/sell/add_bank";

        @NotNull
        public static final String FIAT_OPENPAYD_SELL_CONFIRM = "/fiat/openpayd/sell_confirm";

        @NotNull
        public static final String FIAT_ORDER_HISTORY = "/fiat/order_history";

        @NotNull
        public static final String FIAT_ORDER_HISTORY_PENDING_REFUND = "/fiat/order_history/pending_refund";

        @NotNull
        public static final String FIAT_ORDER_HISTORY_TAB = "/fiat/order_history/tab";

        @NotNull
        public static final String FIAT_QUICK_BUY = "/fiat/quick_buy";

        @NotNull
        public static final String FIAT_RECURRING_BUY = "/fiat/recurring_buy";

        @NotNull
        public static final String FIAT_RECURRING_BUY_DETAILS = "/fiat/recurring_buy/details";

        @NotNull
        public static final String FIAT_RECURRING_BUY_FAQ = "/fiat/recurring_buy/faq";

        @NotNull
        public static final String FIAT_RECURRING_BUY_HISTORY = "/fiat/recurring_buy/history";

        @NotNull
        public static final String FIAT_RECURRING_BUY_PAYMENT = "/fiat/recurring_buy/payment";

        @NotNull
        public static final String FIAT_RECURRING_BUY_RESULT = "/fiat/recurring_buy/result";

        @NotNull
        public static final String FIAT_TRADE = "/fiatOtc/trade";

        @NotNull
        public static final String FIAT_UABKYC_FAILED = "/fiat/uabkyc/failed";

        @NotNull
        public static final String FIAT_UABKYC_FULL = "/fiat/uabkyc/full";

        @NotNull
        public static final String FIAT_UABKYC_FULL_ADDRESS = "/fiat/uabkyc/full_address";

        @NotNull
        public static final String FIAT_UABKYC_FULL_BASIC = "/fiat/uabkyc/full_basic";

        @NotNull
        public static final String FIAT_UABKYC_NON = "/fiat/uabkyc/non";

        @NotNull
        public static final String FIAT_UABKYC_PENDING = "/fiat/uabkyc/pending";

        @NotNull
        public static final String FIAT_UABKYC_STEP = "/fiat/uabkyc/step";

        @NotNull
        public static final String FIAT_WITHDRAW_ORDER_LIST = "/fiat/withdraw/order_list";

        @NotNull
        public static final String FIAT_WITHDRAW_PAYMENT = "/fiat/withdraw_payment";

        @NotNull
        public static final FiatChannel INSTANCE = new FiatChannel();

        private FiatChannel() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0006\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\n"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$FiatLoan;", "", "()V", "FIATLOAN_APPEAL", "", "FIATLOAN_CURRENT_ORDER", "FIATLOAN_HISTORY_ORDER", "FIATLOAN_HOME", "FIATLOAN_PROVIDER", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class FiatLoan {

        @NotNull
        public static final String FIATLOAN_APPEAL = "/fiatloan/appeal";

        @NotNull
        public static final String FIATLOAN_CURRENT_ORDER = "/fiatloan/current_order";

        @NotNull
        public static final String FIATLOAN_HISTORY_ORDER = "/fiatloan/history_order";

        @NotNull
        public static final String FIATLOAN_HOME = "/fiatloan/home";

        @NotNull
        public static final String FIATLOAN_PROVIDER = "/fiatloan/provider";

        @NotNull
        public static final FiatLoan INSTANCE = new FiatLoan();

        @NotNull
        private static final String groupName = "fiatloan";

        private FiatLoan() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u000e\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0012"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$FiatOtc;", "", "()V", "FIAT_OTC_BUY_ORDER_DETAIL", "", "FIAT_OTC_MERCHANT_EXIT", "FIAT_OTC_MERCHANT_EXIT_RESULT", "FIAT_OTC_ORDER", "FIAT_OTC_P2P_DELEGATE", "FIAT_OTC_P2P_DEPOSIT", "FIAT_OTC_P2P_TRADE", "FIAT_OTC_PAYMENT_MANAGER", "FIAT_OTC_PROVIDER", "FIAT_OTC_SCAN_QR_CODE_VERIFY_BIOMETRICS", "FIAT_OTC_SELL_ORDER_DETAIL", "FIAT_OTC_TEST", "FIAT_OTC_TRADE", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class FiatOtc {

        @NotNull
        public static final String FIAT_OTC_BUY_ORDER_DETAIL = "/fiatOtc/buy/order_detail";

        @NotNull
        public static final String FIAT_OTC_MERCHANT_EXIT = "/fiatOtc/merchant_exit";

        @NotNull
        public static final String FIAT_OTC_MERCHANT_EXIT_RESULT = "/fiatOtc/merchant_exit_result";

        @NotNull
        public static final String FIAT_OTC_ORDER = "/fiatOtc/order";

        @NotNull
        public static final String FIAT_OTC_P2P_DELEGATE = "/fiatOtc/p2p_delegate";

        @NotNull
        public static final String FIAT_OTC_P2P_DEPOSIT = "/fiatOtc/p2p_deposit_component";

        @NotNull
        public static final String FIAT_OTC_P2P_TRADE = "/fiatOtc/p2p_trade";

        @NotNull
        public static final String FIAT_OTC_PAYMENT_MANAGER = "/fiatOtc/payment_manage";

        @NotNull
        public static final String FIAT_OTC_PROVIDER = "/fiatOtc/provider";

        @NotNull
        public static final String FIAT_OTC_SCAN_QR_CODE_VERIFY_BIOMETRICS = "/fiatOtc/scan_qr_code_verify_biometrics";

        @NotNull
        public static final String FIAT_OTC_SELL_ORDER_DETAIL = "/fiatOtc/sell/order_detail";

        @NotNull
        public static final String FIAT_OTC_TEST = "/fiatOtc/test";

        @NotNull
        public static final String FIAT_OTC_TRADE = "/fiatOtc/trade";

        @NotNull
        public static final FiatOtc INSTANCE = new FiatOtc();

        @NotNull
        private static final String groupName = "fiatOtc";

        private FiatOtc() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Fido;", "", "()V", "FIDO_MANAGER_HOME", "", "FIDO_PASSKEY_LOGIN_PAGE", "FIDO_PASSKEY_VERIFY_PAGE", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Fido {

        @NotNull
        public static final String FIDO_MANAGER_HOME = "/fido/manager/home";

        @NotNull
        public static final String FIDO_PASSKEY_LOGIN_PAGE = "/fido/passkey/login/page";

        @NotNull
        public static final String FIDO_PASSKEY_VERIFY_PAGE = "/fido/passkey/verify/page";

        @NotNull
        public static final Fido INSTANCE = new Fido();

        @NotNull
        private static final String groupName = "fido";

        private Fido() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Finance;", "", "()V", "ACTIVITY_INVEST_DETAIL_COPY", "", "groupName", "oldGroupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Finance {

        @NotNull
        public static final String ACTIVITY_INVEST_DETAIL_COPY = "/old_finance/provider/invest_detail_copy";

        @NotNull
        public static final Finance INSTANCE = new Finance();

        @NotNull
        private static final String groupName = "finance";

        @NotNull
        private static final String oldGroupName = "old_finance";

        private Finance() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0015\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0003\b´\u0001\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00100\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00101\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00102\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00103\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00104\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00105\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00106\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00107\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00108\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00109\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010:\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010;\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010<\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010=\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010>\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010?\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010@\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010A\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010B\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010C\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010D\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010E\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010F\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010G\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010H\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010I\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010J\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010K\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010L\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010M\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010N\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010O\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010P\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010Q\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010R\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010S\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010T\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010U\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010V\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010W\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010X\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010Y\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010Z\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010[\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\\\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010]\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010^\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010_\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010`\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010a\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010c\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010d\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010g\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010h\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010i\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010j\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010k\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010l\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010m\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010o\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010p\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010q\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010s\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010u\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010v\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010w\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010x\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010y\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010z\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010{\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010|\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010}\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010~\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u007f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0080\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0081\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0082\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0083\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0084\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0085\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0086\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0087\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0088\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0089\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u008a\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u008b\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u008c\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u008d\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u008e\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u008f\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0090\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0091\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0092\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0093\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0094\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0095\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0096\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0097\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0098\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u0099\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u009a\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u009b\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u009c\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u009d\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u009e\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u009f\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010 \u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010¡\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010¢\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010£\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010¤\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010¥\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010¦\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010§\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010¨\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010©\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010ª\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010«\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010¬\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010\u00ad\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010®\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010¯\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010°\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010±\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010²\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010³\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010´\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010µ\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010¶\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000f\u0010·\u0001\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006¸\u0001"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Flutter;", "", "()V", "AGGREGATED_SEARCH_PAGE", "", "AI_AGENT_HOME", "ALPHA_POINTS_ACTIVITIES", "ALPHA_SMART_MONEY_PRICE_DIALOG", "ALPHA_SMART_MONEY_TRANSACTION_DIRECTION_DIALOG", "ALPHA_TRADE_SETTING_PAGE", "ANNOUNCEMENT_DETAIL", "ANNOUNCEMENT_LIST", "ANNOUNCEMENT_SEARCH", "API_MANAGER_HOME_PAGE", "BIG_DATA_HOME_PAGE", "BLOG_DETAIL_PAGE", "BLOG_LIST_PAGE", "BUSINESS_RATE_POPUP", "BUSINESS_SHARE_DIALOG", "BUSINESS_SHARE_DIALOG_V3", "BUSINESS_USER_RATE_FEEDBACK_DIALOG", "BUSINESS_VIP_HOME_PAGE", "BUSINESS_VIP_UPLOAD_PAGE", "CHAIN_STAKING_EARN_HOME", "CHAIN_STAKING_HOME", "COMMAND_RED", "DUAL_TREASURE_DETAIL", "ETH2_HOME", "ETH2_REDEEM", "ETH2_SUBSCRIBE", "EXCHANGE_COPY_HOME", "EXCHANGE_FLASH_SWAP", "EXCHANGE_FUTURES_COOLING_OFF_PERIOD", "EXCHANGE_FUTURES_ORDERING_EASY", "EXCHANGE_OPTIONS_RECORD_DETAIL", "EXCHANGE_OPTIONS_RECORD_LIST", "EXCHANGE_OPTIONS_SELLING_ACCESS_QUIZ", "EXCHANGE_RECORD_DETAIL", "EXCHANGE_RECORD_LIST", "EXCHANGE_RECORD_LIST_WEB3", "EXCHANGE_RISK_LIMIT", "EXCHANGE_STRATEGY_BOT_POOL_HOME_PAGE", "EXCHANGE_STRATEGY_CREATE_PAGE", "EXCHANGE_STRATEGY_DETAIL_PAGE", "EXCHANGE_STRATEGY_HOME", "EXCHANGE_STRATEGY_ORDER_DETAIL_PAGE", "EXCHANGE_STRATEGY_PNL", "EXCHANGE_TAB_PAGE", "EXCHANGE_TRANS_HISTORY_LIST", "EXCHANGE_TRANS_ORDER_DETAIL", "EXPERT_PAGE_TAG_HOME", "EXPERT_PAGE_TAG_WEB3_MARKET", "EXPERT_PAGE_TAG_WEB3_MARKET_FAV", "FIAT_QUICK_ADDITIONAL_INFORMATION_PAGE", "FIAT_QUICK_FACILITAPAY_POPUP", "FIAT_QUICK_FACILITAPAY_STATUS_DIALOG", "FIAT_QUICK_ROUTER_CONFIRM_ORDER_PAGE", "FINANCE_AIRDROP_HISTORY", "FINANCE_AIRDROP_TOTAL_HISTORY", "FINANCE_DUAL_INVESTMENT_HOME", "FINANCE_DUAL_MY_HOLDER", "FINANCE_DUAL_ORDER_PAGE", "FINANCE_DUAL_PRICE_PAGE", "FINANCE_LEND_EARN_HOME", "FINANCE_LEND_EARN_LEND_SUBMIT", "FINANCE_LEND_EARN_MINE_LEND", "FINANCE_LOCK_EARN_ASSET", "FINANCE_LOCK_EARN_HOME", "FINANCE_LOCK_EARN_MINE_HOLD", "FLUTTER_LIVE_APPLY", "FLUTTER_SHARE_TO_NEWS", "FLUTTER_WEB3_DEX_PAGE", "FLUTTER_WEB3_MARKET", "FLUTTER_WEB3_MARKET_FAV", "FUTURES_CALCULATOR", "FUTURES_POINTS_ACTIVITIES", "GATE_CARD_3DS", "GATE_CARD_HOME", "GATE_CARD_TRANSACTION_DETAIL", "GATE_IO_VERIFICATION_HOME_PAGE", "HELP_CENTER_PAGE", "INFORMATION_CHAT_HOME", "INFORMATION_COMMAND_SHARE", "INFORMATION_LIVE_CHAT_ROOM", "INFORMATION_LIVE_CLOSENESS", "INFORMATION_LIVE_INFO", "INFORMATION_LIVE_MAIN_PAGE", "INFORMATION_LIVE_MORE", "INFORMATION_LIVE_RECORD_CHAT_ROOM", "INFORMATION_LIVE_RECORD_PLAY_LIST", "INFORMATION_LIVE_SHARE", "INNOVATION_WINDOW_MAIN_PAGE", "INSTITUTION_HOME_PAGE", "LAUNCHPAD_DETAIL_PAGE", "LAUNCHPAD_HISTORY_PAGE", "LOGIN_CONTAINER", "MARKET_AI_SELECT_PAGE", "MARKET_SENTIMENT_PAGE", "MINIAPP_C2C_TRANSFER", "MINIAPP_NEW_HOME", "MOMENTS_LIVE_COIN_SEARCH", "MOMENTS_PAGE", "MOMENTS_POST_CREATION", "MOMENTS_POST_DAILY", "MOMENTS_POST_DETAIL", "MOMENTS_POST_LIST", "MOMENTS_POST_USER_POINT_HISTORY", "MOMENTS_POST_USER_POINT_HOME", "MOMENTS_POST_USER_POINT_RANKING_LIST", "MOMENTS_POST_USER_POINT_RULES", "MOMENTS_SPACE", "MOMENTS_SPACE_PAGE", "MOMENTS_USER_HOMEPAGE", "MY_BLOCK_LIST_PAGE", "NAVIGATION_MORE_PAGE", "NAVIGATION_SETTINGS_PAGE", "OPTIONS_STRATEGY_HOME", "P2P_BLOCK_FOLLOW_LIST", "PATTEN_CANDY_DROP_DETAIL", "PATTEN_CHAIN_STAKING_EARN_REDEEM", "PATTEN_CHAIN_STAKING_EARN_SUBSCRIBE", "PATTEN_PRIVATE_WEALTH_HOME", "PATTEN_SOFT_STAKING_HOME", "PATTEN_WALLET_ASSET_EXCHANGE", "PATTEN_WALLET_BILL", "PATTEN_WALLET_GT_HOLDING", "PATTEN_WEALTH_VIP_HOME", "PAY_INTERNAL_MERCHANT_C2C", "PAY_PRE_PAGE", "PAY_ROOT_PAGE", "POST_COLLECTION_LIST_PAGE", "PREMARKET_HOME", "PRE_MINT_CREATE_ENTER_DIALOG", "PRE_MINT_DISCLAIMER_DIALOG", "PROMOTION_VOUCHERPADE", "PROMOTION_VOUCHERPADE_MARGIN", "PROMOTION_VOUCHERPADE_SPOT", "PROVIDER_MEME_BOX_ALPHA_POSITION_SHARE", "REFERRAL_MAIN_PAGE", "REFERRAL_REFERRAL_AC_LIST_PAGE", "REFERRAL_REFERRAL_MAIN_HOME", "REGISTER_CONTAINER", "RESET_PASSWORD", "RESET_SECURITY", "ROUTER_ORDER_DETAIL", "ROUTER_TPSL_DETAIL", "SETTING_ANTI_PHISING_CODE_PAGE", "SETTING_DEVICE_MANAGER_PAGE", "SETTING_FUNDPW_MAIN_PAGE", "SETTING_FUNDPW_SET_PAGE", "SETTING_FUND_FREQUENCY_PAGE", "SETTING_GATE_IO_VERIFICATION_HOME_PAGE", "SETTING_GATE_IO_VERIFICATION_PUSH_AUTH_PAGE", "SETTING_LOGIN_SETTING", "SETTING_NAVIGATION_TOOLS_PAGE", "SETTING_NO_PASSWORD_AMOUNT_PAGE", "SETTING_USER_CENTER_PAGE", "SETTING_USER_FEEDBACK_DETAIL_PAGE", "SETTING_USER_FEEDBACK_HOME_PAGE", "SETTING_VIBRATION_SETTING_PAGE", "SINGLE_CHAT", "SITE_ALERT_SELECT_PAGE", "SITE_ALERT_SETTING_PAGE", "SITE_ALL_ALERTS_PAGE", "SITE_PUSH_DIALOG", "STARTUP_DETAIL", "STARTUP_HOME", "SWITCH_ACCOUNT", "TOPIC_DETAIL", "TRANS_ACTIVITY_EXCHANGE_BORROW_DETAIL", "TRANS_ACTIVITY_MARGIN_BORROW_REPAY_DETAIL_PAGE", "TRANS_ACTIVITY_MARGIN_BORROW_REPAY_ROOT", "TRANS_ACTIVITY_TRANS_BORROW_REPAY_ROOT", "TRANS_PAGE_DUAL_EXCHANGE_HOME", "UNIFIED_ACCOUNT_MODE_SIMPLE_EARN_DIALOG", "USER_CENTER_PREFERENCE_SETTINGS", "VIP_RIGHT_PAGE", "VOUCHER_FUTURES_DIALOG_PAGE", "VOUCHER_HOME_PAGE", "WALLET_FULL_DIALOG", "WALLET_LOAN_BIG_CUSTOMER", "WALLET_STARTUP_MINING_AIRDROP_DETAIL", "WALLET_STARTUP_MINING_PROJECT_INFO", "WEB3_BROWSER_SCAN_HANDLE", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Flutter {

        @NotNull
        public static final String AGGREGATED_SEARCH_PAGE = "/site/aggregatedSearchPage";

        @NotNull
        public static final String AI_AGENT_HOME = "/agent/chat_home";

        @NotNull
        public static final String ALPHA_POINTS_ACTIVITIES = "/alpha/points/activities";

        @NotNull
        public static final String ALPHA_SMART_MONEY_PRICE_DIALOG = "/alpha/smartMoney/priceDialog";

        @NotNull
        public static final String ALPHA_SMART_MONEY_TRANSACTION_DIRECTION_DIALOG = "/alpha/smartMoney/transactionDirectionDialog";

        @NotNull
        public static final String ALPHA_TRADE_SETTING_PAGE = "/alpha/setting/page";

        @NotNull
        public static final String ANNOUNCEMENT_DETAIL = "/newsly/announcement_detail";

        @NotNull
        public static final String ANNOUNCEMENT_LIST = "/newsly/announcement_list";

        @NotNull
        public static final String ANNOUNCEMENT_SEARCH = "/newsly/announcement_search";

        @NotNull
        public static final String API_MANAGER_HOME_PAGE = "/setting/api_manager_home_page";

        @NotNull
        public static final String BIG_DATA_HOME_PAGE = "/bdm_bigdata_flutter/bdm_data_home_page";

        @NotNull
        public static final String BLOG_DETAIL_PAGE = "/newsly/blog_detail_page";

        @NotNull
        public static final String BLOG_LIST_PAGE = "/newsly/blog_home_page";

        @NotNull
        public static final String BUSINESS_RATE_POPUP = "/business/rate_popup";

        @NotNull
        public static final String BUSINESS_SHARE_DIALOG = "/business/share_dialog";

        @NotNull
        public static final String BUSINESS_SHARE_DIALOG_V3 = "/business/share_dialog_v3";

        @NotNull
        public static final String BUSINESS_USER_RATE_FEEDBACK_DIALOG = "/business/about_us_feedback_dialog";

        @NotNull
        public static final String BUSINESS_VIP_HOME_PAGE = "/business/vip_home_page";

        @NotNull
        public static final String BUSINESS_VIP_UPLOAD_PAGE = "/business/vip_upload_page";

        @NotNull
        public static final String CHAIN_STAKING_EARN_HOME = "/staking/list";

        @NotNull
        public static final String CHAIN_STAKING_HOME = "/staking/home";

        @NotNull
        public static final String COMMAND_RED = "/information/command_red";

        @NotNull
        public static final String DUAL_TREASURE_DETAIL = "/dualInvestment/sniperOrderDetail";

        @NotNull
        public static final String ETH2_HOME = "/eth2/home";

        @NotNull
        public static final String ETH2_REDEEM = "/eth2/redeem";

        @NotNull
        public static final String ETH2_SUBSCRIBE = "/eth2/staking";

        @NotNull
        public static final String EXCHANGE_COPY_HOME = "/exchange/copy/home";

        @NotNull
        public static final String EXCHANGE_FLASH_SWAP = "/exchange/flashSwap";

        @NotNull
        public static final String EXCHANGE_FUTURES_COOLING_OFF_PERIOD = "/exchange/futures/cooling_off_period";

        @NotNull
        public static final String EXCHANGE_FUTURES_ORDERING_EASY = "/exchange/futures/ordering_easy";

        @NotNull
        public static final String EXCHANGE_OPTIONS_RECORD_DETAIL = "/exchange/options/detail";

        @NotNull
        public static final String EXCHANGE_OPTIONS_RECORD_LIST = "/exchange/options/records";

        @NotNull
        public static final String EXCHANGE_OPTIONS_SELLING_ACCESS_QUIZ = "/exchange/options/selling_access_quiz";

        @NotNull
        public static final String EXCHANGE_RECORD_DETAIL = "/exchange/futures/detail";

        @NotNull
        public static final String EXCHANGE_RECORD_LIST = "/exchange/record";

        @NotNull
        public static final String EXCHANGE_RECORD_LIST_WEB3 = "/web3/exchange/record";

        @NotNull
        public static final String EXCHANGE_RISK_LIMIT = "/exchange/risk_limit";

        @NotNull
        public static final String EXCHANGE_STRATEGY_BOT_POOL_HOME_PAGE = "/exchange/strategy/bot_pool_home_page";

        @NotNull
        public static final String EXCHANGE_STRATEGY_CREATE_PAGE = "/exchange/strategy/createPage";

        @NotNull
        public static final String EXCHANGE_STRATEGY_DETAIL_PAGE = "/exchange/strategy/detail";

        @NotNull
        public static final String EXCHANGE_STRATEGY_HOME = "/exchange/strategyHome";

        @NotNull
        public static final String EXCHANGE_STRATEGY_ORDER_DETAIL_PAGE = "/exchange/strategy/order/detail";

        @NotNull
        public static final String EXCHANGE_STRATEGY_PNL = "/exchange/pnl/analysis";

        @NotNull
        public static final String EXCHANGE_TAB_PAGE = "/exchange/app_home/expert_tab";

        @NotNull
        public static final String EXCHANGE_TRANS_HISTORY_LIST = "/exchange/historical/records";

        @NotNull
        public static final String EXCHANGE_TRANS_ORDER_DETAIL = "/exchange/historical/detail";

        @NotNull
        public static final String EXPERT_PAGE_TAG_HOME = "expert_page_tag_home";

        @NotNull
        public static final String EXPERT_PAGE_TAG_WEB3_MARKET = "expert_page_tag_home_web3";

        @NotNull
        public static final String EXPERT_PAGE_TAG_WEB3_MARKET_FAV = "expert_page_tag_home_web3_fav";

        @NotNull
        public static final String FIAT_QUICK_ADDITIONAL_INFORMATION_PAGE = "/fiat_quick/additional_information_page";

        @NotNull
        public static final String FIAT_QUICK_FACILITAPAY_POPUP = "/fiat_quick/facilitapay_popup";

        @NotNull
        public static final String FIAT_QUICK_FACILITAPAY_STATUS_DIALOG = "/fiat_quick/facilitapay_status_dialog";

        @NotNull
        public static final String FIAT_QUICK_ROUTER_CONFIRM_ORDER_PAGE = "/fait_quick_router/confirm_order_page";

        @NotNull
        public static final String FINANCE_AIRDROP_HISTORY = "/startupMining/airdropHistory";

        @NotNull
        public static final String FINANCE_AIRDROP_TOTAL_HISTORY = "/wallet/earn/historyTotal";

        @NotNull
        public static final String FINANCE_DUAL_INVESTMENT_HOME = "/dualInvestment/home";

        @NotNull
        public static final String FINANCE_DUAL_MY_HOLDER = "/dualInvestment/myOrders";

        @NotNull
        public static final String FINANCE_DUAL_ORDER_PAGE = "/dualInvestment/orderDetail";

        @NotNull
        public static final String FINANCE_DUAL_PRICE_PAGE = "/dualInvestment/marketList";

        @NotNull
        public static final String FINANCE_LEND_EARN_HOME = "/lendEarn/lendEarnHome";

        @NotNull
        public static final String FINANCE_LEND_EARN_LEND_SUBMIT = "/lendEarn/lendSubmit";

        @NotNull
        public static final String FINANCE_LEND_EARN_MINE_LEND = "/lendEarn/mineLends";

        @NotNull
        public static final String FINANCE_LOCK_EARN_ASSET = "/wallet/lockEarnList";

        @NotNull
        public static final String FINANCE_LOCK_EARN_HOME = "/wallet/lockEarnHome";

        @NotNull
        public static final String FINANCE_LOCK_EARN_MINE_HOLD = "/lockEarn/myHoldings";

        @NotNull
        public static final String FLUTTER_LIVE_APPLY = "/moments/live_apply";

        @NotNull
        public static final String FLUTTER_SHARE_TO_NEWS = "/moments/post_creation";

        @NotNull
        public static final String FLUTTER_WEB3_DEX_PAGE = "/web3Dex/dexPage";

        @NotNull
        public static final String FLUTTER_WEB3_MARKET = "/cex/biz_web3_market/marketPage";

        @NotNull
        public static final String FLUTTER_WEB3_MARKET_FAV = "/cex/biz_web3_market/marketCollectPage";

        @NotNull
        public static final String FUTURES_CALCULATOR = "/exchange/futures/calculator";

        @NotNull
        public static final String FUTURES_POINTS_ACTIVITIES = "/exchange/futures/points_activities";

        @NotNull
        public static final String GATE_CARD_3DS = "/gate_card_router/3ds_info_page";

        @NotNull
        public static final String GATE_CARD_HOME = "/gate_card_router/entrance_page";

        @NotNull
        public static final String GATE_CARD_TRANSACTION_DETAIL = "/gate_card_router/general_transaction_detail_page";

        @NotNull
        public static final String GATE_IO_VERIFICATION_HOME_PAGE = "/setting/gate_io_verification_home_page";

        @NotNull
        public static final String HELP_CENTER_PAGE = "/newsly/help_center_page";

        @NotNull
        public static final String INFORMATION_CHAT_HOME = "/information/chatHomePage";

        @NotNull
        public static final String INFORMATION_COMMAND_SHARE = "/information/command_redpacket_share_page";

        @NotNull
        public static final String INFORMATION_LIVE_CHAT_ROOM = "/information/liveChatRoom";

        @NotNull
        public static final String INFORMATION_LIVE_CLOSENESS = "/information/closeness";

        @NotNull
        public static final String INFORMATION_LIVE_INFO = "/information/live_info";

        @NotNull
        public static final String INFORMATION_LIVE_MAIN_PAGE = "/information/live_tap_main_page";

        @NotNull
        public static final String INFORMATION_LIVE_MORE = "/information/live_more";

        @NotNull
        public static final String INFORMATION_LIVE_RECORD_CHAT_ROOM = "/information/liveHistoryChatRoom";

        @NotNull
        public static final String INFORMATION_LIVE_RECORD_PLAY_LIST = "/information/play_list";

        @NotNull
        public static final String INFORMATION_LIVE_SHARE = "/information/live_share";

        @NotNull
        public static final String INNOVATION_WINDOW_MAIN_PAGE = "/innovation/InnovationWindowMainPage";

        @NotNull
        public static final Flutter INSTANCE = new Flutter();

        @NotNull
        public static final String INSTITUTION_HOME_PAGE = "/business/institution_home_page";

        @NotNull
        public static final String LAUNCHPAD_DETAIL_PAGE = "/launchpad/detail_page";

        @NotNull
        public static final String LAUNCHPAD_HISTORY_PAGE = "/launchpad/history_page";

        @NotNull
        public static final String LOGIN_CONTAINER = "/account/login";

        @NotNull
        public static final String MARKET_AI_SELECT_PAGE = "/market/market_ai_select_page";

        @NotNull
        public static final String MARKET_SENTIMENT_PAGE = "/market/market_sentiment_page";

        @NotNull
        public static final String MINIAPP_C2C_TRANSFER = "/miniapp/transfer_page";

        @NotNull
        public static final String MINIAPP_NEW_HOME = "/miniapp/home_page";

        @NotNull
        public static final String MOMENTS_LIVE_COIN_SEARCH = "/moments/live_coin_search";

        @NotNull
        public static final String MOMENTS_PAGE = "/moments/moments_page";

        @NotNull
        public static final String MOMENTS_POST_CREATION = "/moments/post_creation";

        @NotNull
        public static final String MOMENTS_POST_DAILY = "/moments/post_daily";

        @NotNull
        public static final String MOMENTS_POST_DETAIL = "/moments/post_detail";

        @NotNull
        public static final String MOMENTS_POST_LIST = "/moments/post_list";

        @NotNull
        public static final String MOMENTS_POST_USER_POINT_HISTORY = "/moments/post_user_point_history_page";

        @NotNull
        public static final String MOMENTS_POST_USER_POINT_HOME = "/moments/post_user_point_home_page";

        @NotNull
        public static final String MOMENTS_POST_USER_POINT_RANKING_LIST = "/moments/post_user_point_ranking_list_page";

        @NotNull
        public static final String MOMENTS_POST_USER_POINT_RULES = "/moments/post_user_point_rules_page";

        @NotNull
        public static final String MOMENTS_SPACE = "/moments/space";

        @NotNull
        public static final String MOMENTS_SPACE_PAGE = "/moments/space_page";

        @NotNull
        public static final String MOMENTS_USER_HOMEPAGE = "/moments/user_homepage";

        @NotNull
        public static final String MY_BLOCK_LIST_PAGE = "/moments/my_block_list_page";

        @NotNull
        public static final String NAVIGATION_MORE_PAGE = "/setting/navigationToolsMorePage";

        @NotNull
        public static final String NAVIGATION_SETTINGS_PAGE = "/setting/navigation_settings_page";

        @NotNull
        public static final String OPTIONS_STRATEGY_HOME = "/optionsStrategis/home";

        @NotNull
        public static final String P2P_BLOCK_FOLLOW_LIST = "/bizP2P/block_follow_list";

        @NotNull
        public static final String PATTEN_CANDY_DROP_DETAIL = "/candyDrop/detail";

        @NotNull
        public static final String PATTEN_CHAIN_STAKING_EARN_REDEEM = "/staking/redeem";

        @NotNull
        public static final String PATTEN_CHAIN_STAKING_EARN_SUBSCRIBE = "/staking/subscribe";

        @NotNull
        public static final String PATTEN_PRIVATE_WEALTH_HOME = "/wealthVip/privateWealth/home";

        @NotNull
        public static final String PATTEN_SOFT_STAKING_HOME = "/softStaking/homePage";

        @NotNull
        public static final String PATTEN_WALLET_ASSET_EXCHANGE = "/wallet/exchangeGt";

        @NotNull
        public static final String PATTEN_WALLET_BILL = "/wallet/bill";

        @NotNull
        public static final String PATTEN_WALLET_GT_HOLDING = "/wallet/gtHolding";

        @NotNull
        public static final String PATTEN_WEALTH_VIP_HOME = "/wealthVip/wealthVipHome";

        @NotNull
        public static final String PAY_INTERNAL_MERCHANT_C2C = "/pay/pay_transfer_internal_c2c";

        @NotNull
        public static final String PAY_PRE_PAGE = "/pay/pay_transfer_confirm";

        @NotNull
        public static final String PAY_ROOT_PAGE = "/pay/pay_root_page";

        @NotNull
        public static final String POST_COLLECTION_LIST_PAGE = "/moments/post_collection_list_page";

        @NotNull
        public static final String PREMARKET_HOME = "/premarket/home";

        @NotNull
        public static final String PRE_MINT_CREATE_ENTER_DIALOG = "/premarket/preMintCreateEnterDialog";

        @NotNull
        public static final String PRE_MINT_DISCLAIMER_DIALOG = "/premint/disclaimer";

        @NotNull
        public static final String PROMOTION_VOUCHERPADE = "/promotion/voucherPage";

        @NotNull
        public static final String PROMOTION_VOUCHERPADE_MARGIN = "/promotion/voucher_margin";

        @NotNull
        public static final String PROMOTION_VOUCHERPADE_SPOT = "/promotion/voucherPage_spot";

        @NotNull
        public static final String PROVIDER_MEME_BOX_ALPHA_POSITION_SHARE = "/alpha/position/share";

        @NotNull
        public static final String REFERRAL_MAIN_PAGE = "/referral/referral_main_page";

        @NotNull
        public static final String REFERRAL_REFERRAL_AC_LIST_PAGE = "/referral/referral_ac_list_page";

        @NotNull
        public static final String REFERRAL_REFERRAL_MAIN_HOME = "/referral/referral_main_page";

        @NotNull
        public static final String REGISTER_CONTAINER = "/account/register";

        @NotNull
        public static final String RESET_PASSWORD = "/account/resetPassword";

        @NotNull
        public static final String RESET_SECURITY = "/reset_security_router/entrance_page";

        @NotNull
        public static final String ROUTER_ORDER_DETAIL = "/memeBox/trade/info";

        @NotNull
        public static final String ROUTER_TPSL_DETAIL = "/memeBox/tpsl/info";

        @NotNull
        public static final String SETTING_ANTI_PHISING_CODE_PAGE = "/setting/anti_phising_code_page";

        @NotNull
        public static final String SETTING_DEVICE_MANAGER_PAGE = "/setting/devices_manager_page";

        @NotNull
        public static final String SETTING_FUNDPW_MAIN_PAGE = "/setting/fund_main_set_page";

        @NotNull
        public static final String SETTING_FUNDPW_SET_PAGE = "/setting/fund_password_set_page";

        @NotNull
        public static final String SETTING_FUND_FREQUENCY_PAGE = "/setting/fund_frequency_set_page";

        @NotNull
        public static final String SETTING_GATE_IO_VERIFICATION_HOME_PAGE = "/setting/gate_io_verification_home_page";

        @NotNull
        public static final String SETTING_GATE_IO_VERIFICATION_PUSH_AUTH_PAGE = "/setting/gate_io_verification_push_auth_page";

        @NotNull
        public static final String SETTING_LOGIN_SETTING = "/account/loginSetting";

        @NotNull
        public static final String SETTING_NAVIGATION_TOOLS_PAGE = "/setting/navigationToolsPage";

        @NotNull
        public static final String SETTING_NO_PASSWORD_AMOUNT_PAGE = "/setting/no_password_amount_set_page";

        @NotNull
        public static final String SETTING_USER_CENTER_PAGE = "/setting/userCenterPage";

        @NotNull
        public static final String SETTING_USER_FEEDBACK_DETAIL_PAGE = "/setting/user_feedback_detail_page";

        @NotNull
        public static final String SETTING_USER_FEEDBACK_HOME_PAGE = "/setting/user_feedback_home_page";

        @NotNull
        public static final String SETTING_VIBRATION_SETTING_PAGE = "/setting/userCenter/vibration_settings";

        @NotNull
        public static final String SINGLE_CHAT = "/information/chatPage";

        @NotNull
        public static final String SITE_ALERT_SELECT_PAGE = "/site/alertSelectPage";

        @NotNull
        public static final String SITE_ALERT_SETTING_PAGE = "/site/alertSettingsPage";

        @NotNull
        public static final String SITE_ALL_ALERTS_PAGE = "/site/allAlertsPage";

        @NotNull
        public static final String SITE_PUSH_DIALOG = "/site/pushDialogPage";

        @NotNull
        public static final String STARTUP_DETAIL = "/startup/detail_page";

        @NotNull
        public static final String STARTUP_HOME = "/startup_home";

        @NotNull
        public static final String SWITCH_ACCOUNT = "/account/switchAccount";

        @NotNull
        public static final String TOPIC_DETAIL = "/moments/topic";

        @NotNull
        public static final String TRANS_ACTIVITY_EXCHANGE_BORROW_DETAIL = "/exchange/spotBorrowDetail";

        @NotNull
        public static final String TRANS_ACTIVITY_MARGIN_BORROW_REPAY_DETAIL_PAGE = "/exchange/marginBorrowDetailPage";

        @NotNull
        public static final String TRANS_ACTIVITY_MARGIN_BORROW_REPAY_ROOT = "/exchange/marginBorrowRepay";

        @NotNull
        public static final String TRANS_ACTIVITY_TRANS_BORROW_REPAY_ROOT = "/exchange/spotBorrowRepay";

        @NotNull
        public static final String TRANS_PAGE_DUAL_EXCHANGE_HOME = "/lendEarn/DualExchangeHomePage";

        @NotNull
        public static final String UNIFIED_ACCOUNT_MODE_SIMPLE_EARN_DIALOG = "/unified/account_mode/simple_earn_dialog";

        @NotNull
        public static final String USER_CENTER_PREFERENCE_SETTINGS = "/setting/userCenter/preference_settings";

        @NotNull
        public static final String VIP_RIGHT_PAGE = "/business/vip_right_page";

        @NotNull
        public static final String VOUCHER_FUTURES_DIALOG_PAGE = "/promotion/voucherPage";

        @NotNull
        public static final String VOUCHER_HOME_PAGE = "/promotion/voucher/homePage";

        @NotNull
        public static final String WALLET_FULL_DIALOG = "/wallet/fullDialog";

        @NotNull
        public static final String WALLET_LOAN_BIG_CUSTOMER = "/cryptoLoan/loanBigCustomer";

        @NotNull
        public static final String WALLET_STARTUP_MINING_AIRDROP_DETAIL = "/startupMining/airdropDetail";

        @NotNull
        public static final String WALLET_STARTUP_MINING_PROJECT_INFO = "/startupMining/projectInfo";

        @NotNull
        public static final String WEB3_BROWSER_SCAN_HANDLE = "/web3Wallet/dAppBrowserMultiEnginePage";

        private Flutter() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0012\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0016"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Futures;", "", "()V", "ACTIVITY_FUTURES_SETTINGV2", "", "ACTIVITY_FUTURE_POSITION_VOUCHER", "ACTIVITY_FUTURE_TEST", "ACTIVITY_POS_DETAILS", "FRAGMENT_FUTURES_HOME", "FUTURES_API_PROVIDER", "FUTURES_CALCULATOR_SERVICE", "FUTURES_CALCULATOR_SERVICE_V2", "FUTURES_POSITION_MORE_SERVICE", "FUTURES_SERVICE", "FUTURES_SUBJECT", "FUTURES_TICKER_ALL_SERVICE", "FUTURES_UTILS_SERVICE", "FUTURES_WALLET_POSITIONS_FRAGMENT", "PROVIDER_FUTURES_FAILT_DISPATCHER", "PROVIDER_FUTURE_CALLBACK", "WALLET_FUTURES_SUBJECT", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Futures {

        @NotNull
        public static final String ACTIVITY_FUTURES_SETTINGV2 = "/moduleFutures/activity/FuturesSettingV2";

        @NotNull
        public static final String ACTIVITY_FUTURE_POSITION_VOUCHER = "/moduleFutures/activity/positionVoucher";

        @NotNull
        public static final String ACTIVITY_FUTURE_TEST = "/moduleFutures/activity/FutureTest";

        @NotNull
        public static final String ACTIVITY_POS_DETAILS = "/moduleFutures/activity/PosDetails";

        @NotNull
        public static final String FRAGMENT_FUTURES_HOME = "/moduleFutures/fragment/futures_home";

        @NotNull
        public static final String FUTURES_API_PROVIDER = "/moduleFutures/provider/api";

        @NotNull
        public static final String FUTURES_CALCULATOR_SERVICE = "/moduleFutures/futuresCalculatorService";

        @NotNull
        public static final String FUTURES_CALCULATOR_SERVICE_V2 = "/moduleFutures/futuresCalculatorServiceV2";

        @NotNull
        public static final String FUTURES_POSITION_MORE_SERVICE = "/moduleFutures/futuresPositionMoreService";

        @NotNull
        public static final String FUTURES_SERVICE = "/moduleFutures/futures_service";

        @NotNull
        public static final String FUTURES_SUBJECT = "/moduleFutures/futures_subject";

        @NotNull
        public static final String FUTURES_TICKER_ALL_SERVICE = "/moduleFutures/futuresTickerAllSubjectService";

        @NotNull
        public static final String FUTURES_UTILS_SERVICE = "/moduleFutures/futuresUtilsService";

        @NotNull
        public static final String FUTURES_WALLET_POSITIONS_FRAGMENT = "/moduleFutures/fragment/futuresWalletPositionsFragment";

        @NotNull
        public static final Futures INSTANCE = new Futures();

        @NotNull
        public static final String PROVIDER_FUTURES_FAILT_DISPATCHER = "/moduleFutures/provider/futures_failt_dispatcher";

        @NotNull
        public static final String PROVIDER_FUTURE_CALLBACK = "/moduleFutures/provider/future_callback";

        @NotNull
        public static final String WALLET_FUTURES_SUBJECT = "/moduleFutures/wallet_futures_subject";

        @NotNull
        private static final String groupName = "moduleFutures";

        private Futures() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$HomePage;", "", "()V", "HOME_PROVIDER_IMPL", "", "HOME_SETTING_VIBRATION", "HOME_TRADING_SELECT", "HOME_USERINFO_ACTIVITY", "MARKET_TOP_UTILS_SERVICE", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class HomePage {

        @NotNull
        public static final String HOME_PROVIDER_IMPL = "/Homepage/provider_impl";

        @NotNull
        public static final String HOME_SETTING_VIBRATION = "/Homepage/activity/vibration_setting";

        @NotNull
        public static final String HOME_TRADING_SELECT = "/Homepage/fragment/tradingSelect";

        @NotNull
        public static final String HOME_USERINFO_ACTIVITY = "/old_homepage/activity/UserInfo";

        @NotNull
        public static final HomePage INSTANCE = new HomePage();

        @NotNull
        public static final String MARKET_TOP_UTILS_SERVICE = "/Homepage/fixed/market_top_utils_service";

        private HomePage() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0010\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0014"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$KYC;", "", "()V", "ADDRESS_PHOTO_VERIFICATION", "", "ADDRESS_VERIFICATION", "FACE_VERIFICATION", "FACE_VERIFICATION_GUIDE", "KYC1", "KYC1_SECOND", "KYC_HOME", "MT_KYC", "MT_KYC_HOME", "PENDING", "PROVIDER", "TURKEY_KYC_TYPE", "US_FACE_VERIFICATION_GUIDE", "US_KYC_HOME", "VIDEO_VERIFICATION", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class KYC {

        @NotNull
        public static final String ADDRESS_PHOTO_VERIFICATION = "/kyc/address_photo_verification";

        @NotNull
        public static final String ADDRESS_VERIFICATION = "/kyc/address_verification";

        @NotNull
        public static final String FACE_VERIFICATION = "/kyc/face_verification";

        @NotNull
        public static final String FACE_VERIFICATION_GUIDE = "/kyc/face_verification_guide";

        @NotNull
        public static final KYC INSTANCE = new KYC();

        @NotNull
        public static final String KYC1 = "/kyc/kyc1";

        @NotNull
        public static final String KYC1_SECOND = "/kyc/kyc1_second";

        @NotNull
        public static final String KYC_HOME = "/kyc/home";

        @NotNull
        public static final String MT_KYC = "/kyc/mt_kyc";

        @NotNull
        public static final String MT_KYC_HOME = "/kyc/mt_kyc_home";

        @NotNull
        public static final String PENDING = "/kyc/pending";

        @NotNull
        public static final String PROVIDER = "/kyc/provider";

        @NotNull
        public static final String TURKEY_KYC_TYPE = "/turkey/activity/KycTypeActivity";

        @NotNull
        public static final String US_FACE_VERIFICATION_GUIDE = "/kyc/us/face_verification_guide";

        @NotNull
        public static final String US_KYC_HOME = "/kyc/us/home";

        @NotNull
        public static final String VIDEO_VERIFICATION = "/kyc/video_verification";

        @NotNull
        private static final String groupName = "kyc";

        private KYC() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\r\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0011"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Kline;", "", "()V", "ACTIVITY_KLINE_TRADEVIEW", "", "APP_KLINE_SERVICE", "APP_KLINE_SUBJECT", "FRAGMENT_KLINE_BASE", "FRAGMENT_KLINE_HOME", "FRAGMENT_KLINE_TRADINGVIEW", "KLINE_FAST_CONTRACT_FRAGMENT", "KLINE_FAST_TRANS_FRAGMENT", "KLINE_GLOBAL_MARKETS_SPOT_PAGE", "KLINE_MORE_SETTINGS", "KLINE_PRE_MARKET_TRADING_FRAGMENT", "KLINE_PRE_MARKET_TRADING_OTC_DETAIL", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Kline {

        @NotNull
        public static final String ACTIVITY_KLINE_TRADEVIEW = "/moduleKline/kline/tradeview";

        @NotNull
        public static final String APP_KLINE_SERVICE = "/moduleKline/kline/service";

        @NotNull
        public static final String APP_KLINE_SUBJECT = "/moduleKline/klinesubject";

        @NotNull
        public static final String FRAGMENT_KLINE_BASE = "/moduleKline/kline/base";

        @NotNull
        public static final String FRAGMENT_KLINE_HOME = "/moduleKline/kline/home";

        @NotNull
        public static final String FRAGMENT_KLINE_TRADINGVIEW = "/moduleKline/kline/tradingview";

        @NotNull
        public static final Kline INSTANCE = new Kline();

        @NotNull
        public static final String KLINE_FAST_CONTRACT_FRAGMENT = "/moduleKline/kline/fast_contract_fragment";

        @NotNull
        public static final String KLINE_FAST_TRANS_FRAGMENT = "/moduleKline/kline/fast_trans_fragment";

        @NotNull
        public static final String KLINE_GLOBAL_MARKETS_SPOT_PAGE = "/bigData/RainGlobalMarketsSpotPage";

        @NotNull
        public static final String KLINE_MORE_SETTINGS = "/moduleKline/kline/more_settings";

        @NotNull
        public static final String KLINE_PRE_MARKET_TRADING_FRAGMENT = "/moduleKline/kline/pre_market_trading_fragment";

        @NotNull
        public static final String KLINE_PRE_MARKET_TRADING_OTC_DETAIL = "/moduleKline/kline/pre_market_trading_otc_detail";

        @NotNull
        private static final String groupName = "moduleKline";

        private Kline() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Live;", "", "()V", "PROVIDER_LIVE", "", "PROVIDER_LIVE_CALLBACK", "groupName", "oldGroupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Live {

        @NotNull
        public static final Live INSTANCE = new Live();

        @NotNull
        public static final String PROVIDER_LIVE = "/old_live/provider/live";

        @NotNull
        public static final String PROVIDER_LIVE_CALLBACK = "/live/provider/live_callback";

        @NotNull
        private static final String groupName = "live";

        @NotNull
        private static final String oldGroupName = "old_live";

        private Live() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0005"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Margin;", "", "()V", "MARGIN_MANAGER", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Margin {

        @NotNull
        public static final Margin INSTANCE = new Margin();

        @NotNull
        public static final String MARGIN_MANAGER = "/margin/activity/manager";

        private Margin() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0016\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u001a"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Market;", "", "()V", "APP_SEARCH_COINS", "", "CHOICE_PAGE", "FLOATING_BALL_SETTING", "MARKET_API_PROVIDER", "MARKET_API_V2_PROVIDER", "MARKET_EDITFAV", "MARKET_ETF_HOME_ACTIVITY", "MARKET_FAV_API_PROVIDER", "MARKET_HEATMAP_ACTIVITY", "MARKET_HOME_PAGE", "MARKET_MAIN_PAGE", "MARKET_OPPORTUNITY_EDIT_LAYOUT_ACTIVITY", "MARKET_PILOT_OPPORTUNITY_ACTIVITY", "MARKET_RANKING_ACTIVITY", "MARKET_RANKING_PAGE", "MARKET_SEARCH", "MARKET_SELECT_PAIR_SETS_ACTIVITY", "MARKET_WS_API_PROVIDER", "MARKET_ZONES_INFO_ACTIVITY", "PROVIDER_MARKET_CALLBACK", "PROVIDER_MARKET_SELECT", "oldGroupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Market {

        @NotNull
        public static final String APP_SEARCH_COINS = "/market/activity/market_search";

        @NotNull
        public static final String CHOICE_PAGE = "/market/activity/marketChoice";

        @NotNull
        public static final String FLOATING_BALL_SETTING = "/market_old/activity/marketBallSetting";

        @NotNull
        public static final Market INSTANCE = new Market();

        @NotNull
        public static final String MARKET_API_PROVIDER = "/market/provider/api";

        @NotNull
        public static final String MARKET_API_V2_PROVIDER = "/market/provider/api/v2";

        @NotNull
        public static final String MARKET_EDITFAV = "/market/activity/edit_fav";

        @NotNull
        public static final String MARKET_ETF_HOME_ACTIVITY = "/market/etf/home/activity";

        @NotNull
        public static final String MARKET_FAV_API_PROVIDER = "/market/provider/favApi";

        @NotNull
        public static final String MARKET_HEATMAP_ACTIVITY = "/market/heatmap/activity";

        @NotNull
        public static final String MARKET_HOME_PAGE = "/market/fragment/marketHome";

        @NotNull
        public static final String MARKET_MAIN_PAGE = "/market/fragment/marketMain";

        @NotNull
        public static final String MARKET_OPPORTUNITY_EDIT_LAYOUT_ACTIVITY = "/market/opportunity/edit_layout";

        @NotNull
        public static final String MARKET_PILOT_OPPORTUNITY_ACTIVITY = "/market/pilot/opportunity/activity";

        @NotNull
        public static final String MARKET_RANKING_ACTIVITY = "/market/ranking/activity";

        @NotNull
        public static final String MARKET_RANKING_PAGE = "/market/fragment/ranking";

        @NotNull
        public static final String MARKET_SEARCH = "/market/fragment/search";

        @NotNull
        public static final String MARKET_SELECT_PAIR_SETS_ACTIVITY = "/market/set/select/pair/sets";

        @NotNull
        public static final String MARKET_WS_API_PROVIDER = "/market/provider/wsApi";

        @NotNull
        public static final String MARKET_ZONES_INFO_ACTIVITY = "/market/zones/info/activity";

        @NotNull
        public static final String PROVIDER_MARKET_CALLBACK = "/market_old/provider/marketCallback";

        @NotNull
        public static final String PROVIDER_MARKET_SELECT = "/market/provider/select";

        @NotNull
        private static final String oldGroupName = "market_old";

        private Market() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$MemeBox;", "", "()V", "PROVIDER", "", "PROVIDER_MEME_BOX_HOME", "PROVIDER_MEME_BOX_POINT", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class MemeBox {

        @NotNull
        public static final MemeBox INSTANCE = new MemeBox();

        @NotNull
        public static final String PROVIDER = "/memebox/provider/memebox";

        @NotNull
        public static final String PROVIDER_MEME_BOX_HOME = "/memebox/fragment/memebox_home";

        @NotNull
        public static final String PROVIDER_MEME_BOX_POINT = "/memebox/fragment/memebox_point";

        @NotNull
        private static final String groupName = "memebox";

        private MemeBox() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u000b\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u000f"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$MiniApp;", "", "()V", "ACTIVITY_APPROVE_LIST", "", "ACTIVITY_APP_LIST", "ACTIVITY_BILL", "ACTIVITY_CENTER", "ACTIVITY_SCANPAYEE", "FRAGMENT_FLUTTER_HOME", "FRAGMENT_PRE_PAY", "GATE_PAY_APP_SPLASH", "MINIAPP_SUBJECT_UTILS", "PAY_APP_SUBJECT_UTILS", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class MiniApp {

        @NotNull
        public static final String ACTIVITY_APPROVE_LIST = "/moduleMiniApp/activity/approveList";

        @NotNull
        public static final String ACTIVITY_APP_LIST = "/moduleMiniApp/activity/appList";

        @NotNull
        public static final String ACTIVITY_BILL = "/moduleMiniApp/activity/miniAppBill";

        @NotNull
        public static final String ACTIVITY_CENTER = "/moduleMiniApp/activity/center";

        @NotNull
        public static final String ACTIVITY_SCANPAYEE = "/moduleMiniApp/activity/scanPayee";

        @NotNull
        public static final String FRAGMENT_FLUTTER_HOME = "/moduleMiniApp/fragmentFlutter/home";

        @NotNull
        public static final String FRAGMENT_PRE_PAY = "/moduleMiniApp/fragment/prePayFragment";

        @NotNull
        public static final String GATE_PAY_APP_SPLASH = "/moduleMiniApp/activity/gatepay_app";

        @NotNull
        public static final MiniApp INSTANCE = new MiniApp();

        @NotNull
        public static final String MINIAPP_SUBJECT_UTILS = "/moduleMiniApp/subject/utils";

        @NotNull
        public static final String PAY_APP_SUBJECT_UTILS = "/moduleMiniApp/subject/gatepay_app_utils";

        @NotNull
        private static final String groupName = "moduleMiniApp";

        private MiniApp() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0006"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Network;", "", "()V", "ACTIVITY_NETWORK_FAQ", "", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Network {

        @NotNull
        public static final String ACTIVITY_NETWORK_FAQ = "/network/activity/faq";

        @NotNull
        public static final Network INSTANCE = new Network();

        @NotNull
        private static final String groupName = "network";

        private Network() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0010\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0014"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$OTC;", "", "()V", "ADD_BANK_ACCOUNT", "", "BANK_ACCOUNT", "ELIGIBILITY_ADD_INFORMATION", "ELIGIBILITY_GUIDE_VERIFICATION", "ELIGIBILITY_VERIFICATION", "HOMEPAGE", "ORDER_LIST", "PROVIDER", "SIGNATURE", "SIGNATURE_POLICY", "TRADE", "TRADE_DOCS", "TRADE_INFO", "TRADE_STATUS", "WALLET_MANAGE", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class OTC {

        @NotNull
        public static final String ADD_BANK_ACCOUNT = "/gate_otc/add_bank_account";

        @NotNull
        public static final String BANK_ACCOUNT = "/gate_otc/bank_account";

        @NotNull
        public static final String ELIGIBILITY_ADD_INFORMATION = "/gate_otc/activity/eligibility_add_information";

        @NotNull
        public static final String ELIGIBILITY_GUIDE_VERIFICATION = "/gate_otc/activity/eligibility_guide_verification";

        @NotNull
        public static final String ELIGIBILITY_VERIFICATION = "/gate_otc/activity/eligibility_verification";

        @NotNull
        public static final String HOMEPAGE = "/gate_otc/activity/home_page";

        @NotNull
        public static final OTC INSTANCE = new OTC();

        @NotNull
        public static final String ORDER_LIST = "/gate_otc/activity/order_list";

        @NotNull
        public static final String PROVIDER = "/gate_otc/provider";

        @NotNull
        public static final String SIGNATURE = "/gate_otc/activity/signature";

        @NotNull
        public static final String SIGNATURE_POLICY = "/gate_otc/activity/signature_policy";

        @NotNull
        public static final String TRADE = "/gate_otc/activity/trade";

        @NotNull
        public static final String TRADE_DOCS = "/gate_otc/trade_docs";

        @NotNull
        public static final String TRADE_INFO = "/gate_otc/activity/trade_info";

        @NotNull
        public static final String TRADE_STATUS = "/gate_otc/activity/trade_status";

        @NotNull
        public static final String WALLET_MANAGE = "/gate_otc/activity/wallet_manage";

        @NotNull
        private static final String groupName = "gate_otc";

        private OTC() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0006\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\n"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Options;", "", "()V", "ACTIVITY_OPTIONS_SETTINGS", "", "OPTIONS_PLACE_ORDER", "OPTIONS_T_SHAPE_QUOTE", "PROVIDER", "PROVIDER_OPTIONS_DISPATCHER", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Options {

        @NotNull
        public static final String ACTIVITY_OPTIONS_SETTINGS = "/moduleOptions/activity/optionsSettings";

        @NotNull
        public static final Options INSTANCE = new Options();

        @NotNull
        public static final String OPTIONS_PLACE_ORDER = "/moduleOptions/activity/optionsTradeMain";

        @NotNull
        public static final String OPTIONS_T_SHAPE_QUOTE = "/moduleOptions/fragment/optionsTShapeQuote";

        @NotNull
        public static final String PROVIDER = "/moduleOptions/provider/optionsSubject";

        @NotNull
        public static final String PROVIDER_OPTIONS_DISPATCHER = "/moduleOptions/provider/optionsDispatcher";

        @NotNull
        private static final String groupName = "moduleOptions";

        private Options() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Pilot;", "", "()V", "FRAGMENT_PILOT_HOME", "", "FRAGMENT_PILOT_TRANSATION_SHARE", "PROVIDER_PILOT", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Pilot {

        @NotNull
        public static final String FRAGMENT_PILOT_HOME = "/pilot/fragment/pilot_home";

        @NotNull
        public static final String FRAGMENT_PILOT_TRANSATION_SHARE = "/pilot/transaction/share";

        @NotNull
        public static final Pilot INSTANCE = new Pilot();

        @NotNull
        public static final String PROVIDER_PILOT = "/pilot/provider/pilot";

        @NotNull
        private static final String groupName = "pilot";

        private Pilot() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u000f\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0013"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$RegisterLogin;", "", "()V", "ACTIVITY_LOGIN", "", "ACTIVITY_RESET_PASSWORD_HOME", "ACTIVITY_SIGN_UP", "ACTIVITY_SINGLE_VERIFY", "ACTIVITY_TELEGRAM", "FRAGMENT_AGREEMENT", "PROVIDER_ACCOUNT", "PROVIDER_ACCOUNT_LOGIN", "PROVIDER_ACCOUNT_TESTNET", "PROVIDER_APP_TYPE_EVENT", "PROVIDER_KYC", "PROVIDER_REFERRAL", "PROVIDER_USER_UTILS", "groupName", "oldGroupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class RegisterLogin {

        @NotNull
        public static final String ACTIVITY_LOGIN = "/moduleLogin/activity/login";

        @NotNull
        public static final String ACTIVITY_RESET_PASSWORD_HOME = "/moduleLogin/reset/ResetPasswordHomeActivity";

        @NotNull
        public static final String ACTIVITY_SIGN_UP = "/moduleLogin/activity/signup";

        @NotNull
        public static final String ACTIVITY_SINGLE_VERIFY = "/moduleLogin/activity/singleVerify";

        @NotNull
        public static final String ACTIVITY_TELEGRAM = "/moduleLogin/activity/telegram";

        @NotNull
        public static final String FRAGMENT_AGREEMENT = "/moduleLogin/gate/path/user_agreement";

        @NotNull
        public static final RegisterLogin INSTANCE = new RegisterLogin();

        @NotNull
        public static final String PROVIDER_ACCOUNT = "/moduleLogin/provider/account";

        @NotNull
        public static final String PROVIDER_ACCOUNT_LOGIN = "/old_moduleLogin/provider/account_login";

        @NotNull
        public static final String PROVIDER_ACCOUNT_TESTNET = "/moduleLogin/provider/testnet/account";

        @NotNull
        public static final String PROVIDER_APP_TYPE_EVENT = "/moduleLogin/provider/app_type_event";

        @NotNull
        public static final String PROVIDER_KYC = "/moduleLogin/provider/account_kyc";

        @NotNull
        public static final String PROVIDER_REFERRAL = "/moduleLogin/provider/account_referral";

        @NotNull
        public static final String PROVIDER_USER_UTILS = "/moduleLogin/provider/user_utils";

        @NotNull
        private static final String groupName = "moduleLogin";

        @NotNull
        private static final String oldGroupName = "old_moduleLogin";

        private RegisterLogin() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0007\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Safe;", "", "()V", "ACTIVITY_FORGET_FUND_PWD", "", "ACTIVITY_FUND_PASSWORD", "ACTIVITY_FUND_PASSWORD_AMOUNT", "ACTIVITY_FUND_PWD_FREQUENCY", "ACTIVITY_RESET_FUND_PWD", "PROVIDER_SAFE", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Safe {

        @NotNull
        public static final String ACTIVITY_FORGET_FUND_PWD = "/safe/forget/fund/password";

        @NotNull
        public static final String ACTIVITY_FUND_PASSWORD = "/safe/activity/FundPassword";

        @NotNull
        public static final String ACTIVITY_FUND_PASSWORD_AMOUNT = "/safe/activity/password_amount";

        @NotNull
        public static final String ACTIVITY_FUND_PWD_FREQUENCY = "/safe/activity/password_frequency";

        @NotNull
        public static final String ACTIVITY_RESET_FUND_PWD = "/safe/reset/fund/password";

        @NotNull
        public static final Safe INSTANCE = new Safe();

        @NotNull
        public static final String PROVIDER_SAFE = "/safe/provider/safe";

        @NotNull
        private static final String groupName = "safe";

        private Safe() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u000e\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0012"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Security;", "", "()V", "SECURITY_ACCOUNT_DELETE", "", "SECURITY_ANTI_PHISHING_CODE", "SECURITY_BIND_PHONE", "SECURITY_CALENDAR", "SECURITY_EMAIL_CERTIFY", "SECURITY_EMAIL_SETTING", "SECURITY_GOOGLE_CERTIFY", "SECURITY_LOGIN2_SETTING", "SECURITY_LOGIN_SETTING", "SECURITY_MY_DEVICES", "SECURITY_PASSWORD_RESET", "SECURITY_WEB_SCAN_LOGIN", "USER_CENTER_UKEY_BIND", "USER_CENTER_UKEY_LIST", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Security {

        @NotNull
        public static final Security INSTANCE = new Security();

        @NotNull
        public static final String SECURITY_ACCOUNT_DELETE = "/security/account_delete";

        @NotNull
        public static final String SECURITY_ANTI_PHISHING_CODE = "/security/anti_phishing_code";

        @NotNull
        public static final String SECURITY_BIND_PHONE = "/security/bindPhone";

        @NotNull
        public static final String SECURITY_CALENDAR = "/security/calendar";

        @NotNull
        public static final String SECURITY_EMAIL_CERTIFY = "/security/emailCertify";

        @NotNull
        public static final String SECURITY_EMAIL_SETTING = "/security/emailSetting";

        @NotNull
        public static final String SECURITY_GOOGLE_CERTIFY = "/security/googleCertify";

        @NotNull
        public static final String SECURITY_LOGIN2_SETTING = "/security/login2Setting";

        @NotNull
        public static final String SECURITY_LOGIN_SETTING = "/security/loginSetting";

        @NotNull
        public static final String SECURITY_MY_DEVICES = "/security/my_devices";

        @NotNull
        public static final String SECURITY_PASSWORD_RESET = "/security/password_reset";

        @NotNull
        public static final String SECURITY_WEB_SCAN_LOGIN = "/security/webscanlogin";

        @NotNull
        public static final String USER_CENTER_UKEY_BIND = "/user_center/ukey_bind";

        @NotNull
        public static final String USER_CENTER_UKEY_LIST = "/user_center/ukey_list";

        private Security() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0006"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$SubApps;", "", "()V", "PROVIDER_OAUTH_LOGIN", "", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class SubApps {

        @NotNull
        public static final SubApps INSTANCE = new SubApps();

        @NotNull
        public static final String PROVIDER_OAUTH_LOGIN = "/subapps/oauth/login";

        @NotNull
        private static final String groupName = "subapps";

        private SubApps() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0007\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Trans;", "", "()V", "FRAGMENT_TRANS_HOME", "", "FRAGMENT_TRANS_LAYOUT_SETTING", "FRAGMENT_TRANS_MARGIN_RISK", "FRAGMENT_TRANS_V1_SPOT_BORROWED_FRAGMENT", "PROVIDER_TRANS", "groupName", "groupNameNew", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Trans {

        @NotNull
        public static final String FRAGMENT_TRANS_HOME = "/trans/fragment/trans_home";

        @NotNull
        public static final String FRAGMENT_TRANS_LAYOUT_SETTING = "/trans/fragment/trans_layout_setting_fragment";

        @NotNull
        public static final String FRAGMENT_TRANS_MARGIN_RISK = "/trans/fragment/trans_margin_risk_fragment";

        @NotNull
        public static final String FRAGMENT_TRANS_V1_SPOT_BORROWED_FRAGMENT = "/trans/fragment/trans_v1_spot_borrowed_fragment";

        @NotNull
        public static final Trans INSTANCE = new Trans();

        @NotNull
        public static final String PROVIDER_TRANS = "/trans_new/provider/trans";

        @NotNull
        private static final String groupName = "trans";

        @NotNull
        private static final String groupNameNew = "trans_new";

        private Trans() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0007\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Unified;", "", "()V", "LEVERAGE_LIST", "", "LEVERAGE_SETTING", "MARGIN_DETAILS", "UNIFIED_ACCOUNT_MODE_HELP", "UNIFIED_UPGRADE", "UNIFIED_UPGRADE_DIALOG", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Unified {

        @NotNull
        public static final Unified INSTANCE = new Unified();

        @NotNull
        public static final String LEVERAGE_LIST = "/unified/leverage/list";

        @NotNull
        public static final String LEVERAGE_SETTING = "/unified/leverage/setting";

        @NotNull
        public static final String MARGIN_DETAILS = "/unified/margin/details";

        @NotNull
        public static final String UNIFIED_ACCOUNT_MODE_HELP = "/unified/account_mode/help";

        @NotNull
        public static final String UNIFIED_UPGRADE = "/unified/account_mode/upgrade";

        @NotNull
        public static final String UNIFIED_UPGRADE_DIALOG = "/unified/account_mode/upgrade_dialog";

        @NotNull
        private static final String groupName = "unified";

        private Unified() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\b\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\f"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Wallet;", "", "()V", "FRAGMENT_WALLET_HOME", "", "PROVIDER_COPY_TRADING_CALLBACK", "PROVIDER_REWARD_CENTER_CALLBACK", "PROVIDER_STRATEGY_CALLBACK", "WALLET_PAGE_MONITOR", "groupName", "oldGroupName", "oldGroupName_app", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Wallet {

        @NotNull
        public static final String FRAGMENT_WALLET_HOME = "/wallet/wallet_home";

        @NotNull
        public static final Wallet INSTANCE = new Wallet();

        @NotNull
        public static final String PROVIDER_COPY_TRADING_CALLBACK = "/old_wallet/provider/copytrading_callback";

        @NotNull
        public static final String PROVIDER_REWARD_CENTER_CALLBACK = "/old_wallet_app/provider/rewardcenter_callback";

        @NotNull
        public static final String PROVIDER_STRATEGY_CALLBACK = "/old_wallet_app/provider/strategy_callback";

        @NotNull
        public static final String WALLET_PAGE_MONITOR = "/wallet/provider/pageMonitor";

        @NotNull
        private static final String groupName = "wallet";

        @NotNull
        private static final String oldGroupName = "old_wallet";

        @NotNull
        private static final String oldGroupName_app = "old_wallet_app";

        private Wallet() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\n\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u000e"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Wallets;", "", "()V", "ADD_FUNDS", "", "DEPOSIT_ACCELERATION", "DEPOSIT_TOKEN_RECOVERY", "GATECODE_DEPOSIT", "GATECODE_WITHDRAWAL", "ONCHAIN_DEPOSIT", "ONCHAIN_DEPOSIT_RECORD", "ONCHAIN_WITHDRAWAL", "PROVIDER", "groupName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Wallets {

        @NotNull
        public static final String ADD_FUNDS = "/wallets/add_funds";

        @NotNull
        public static final String DEPOSIT_ACCELERATION = "/wallets/acceleration";

        @NotNull
        public static final String DEPOSIT_TOKEN_RECOVERY = "/wallets/token_recovery";

        @NotNull
        public static final String GATECODE_DEPOSIT = "/wallets/gatecode_deposit";

        @NotNull
        public static final String GATECODE_WITHDRAWAL = "/wallets/gatecode_withdrawal";

        @NotNull
        public static final Wallets INSTANCE = new Wallets();

        @NotNull
        public static final String ONCHAIN_DEPOSIT = "/wallets/onchain_deposit";

        @NotNull
        public static final String ONCHAIN_DEPOSIT_RECORD = "/wallets/deposit_withdraw_record";

        @NotNull
        public static final String ONCHAIN_WITHDRAWAL = "/wallets/onchain_withdrawal";

        @NotNull
        public static final String PROVIDER = "/wallets/provider";

        @NotNull
        private static final String groupName = "wallets";

        private Wallets() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0006"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Web3;", "", "()V", "WEB3_DEFI_PROVIDER", "", "WEB3_SPLASH", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Web3 {

        @NotNull
        public static final Web3 INSTANCE = new Web3();

        @NotNull
        public static final String WEB3_DEFI_PROVIDER = "/web3/defi/provider";

        @NotNull
        public static final String WEB3_SPLASH = "/web3/splash";

        private Web3() {
        }
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0005"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$WebPath;", "", "()V", "cryptoLoan", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class WebPath {

        @NotNull
        public static final WebPath INSTANCE = new WebPath();

        @NotNull
        public static final String cryptoLoan = "cryptoloan";

        private WebPath() {
        }
    }

    private RouterConst() {
    }

    /* compiled from: RouterConst.kt */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u000e\n\u0002\u0010\b\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0012\u0010\u0011\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0012\u001a\u00020\u0013H\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0014"}, d2 = {"Lcom/gateio/biz/base/router/RouterConst$Moments;", "", "()V", "TAB_FIRST_ANNOUNCEMENTS", "", "TAB_FIRST_DAILY", "TAB_FIRST_LIVE", "TAB_FIRST_NEWS", "TAB_FIRST_POST", "TAB_SECOND_NEWS_ANNOUNCEMENTS", "TAB_SECOND_NEWS_DEPTH", "TAB_SECOND_NEWS_FLASH", "TAB_SECOND_NEWS_LEARN", "TAB_SECOND_POST_CHAT", "TAB_SECOND_POST_FOLLOW", "TAB_SECOND_POST_LEADERBOARD", "TAB_SECOND_POST_SQUARE", "informationOldPosition2FlutterTab", MarketDataFinderConst.PAGE, "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Moments {

        @NotNull
        public static final Moments INSTANCE = new Moments();

        @NotNull
        public static final String TAB_FIRST_ANNOUNCEMENTS = "announcements";

        @NotNull
        public static final String TAB_FIRST_DAILY = "daily";

        @NotNull
        public static final String TAB_FIRST_LIVE = "live";

        @NotNull
        public static final String TAB_FIRST_NEWS = "news";

        @NotNull
        public static final String TAB_FIRST_POST = "post";

        @NotNull
        public static final String TAB_SECOND_NEWS_ANNOUNCEMENTS = "announcements";

        @NotNull
        public static final String TAB_SECOND_NEWS_DEPTH = "depth";

        @NotNull
        public static final String TAB_SECOND_NEWS_FLASH = "flash";

        @NotNull
        public static final String TAB_SECOND_NEWS_LEARN = "learn";

        @NotNull
        public static final String TAB_SECOND_POST_CHAT = "chat";

        @NotNull
        public static final String TAB_SECOND_POST_FOLLOW = "follow";

        @NotNull
        public static final String TAB_SECOND_POST_LEADERBOARD = "leaderboard";

        @NotNull
        public static final String TAB_SECOND_POST_SQUARE = "square";

        private Moments() {
        }

        @JvmStatic
        @Nullable
        public static final String informationOldPosition2FlutterTab(int page) {
            switch (page) {
                case 0:
                    return "daily";
                case 1:
                    return TAB_FIRST_POST;
                case 2:
                    return "live";
                case 3:
                    return "chat";
                case 4:
                    return "leaderboard";
                case 5:
                    return "announcements";
                case 6:
                    return TAB_SECOND_NEWS_FLASH;
                case 7:
                    return "learn";
                default:
                    return null;
            }
        }
    }
}