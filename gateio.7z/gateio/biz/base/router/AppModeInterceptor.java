package com.gateio.biz.base.router;

import android.content.Context;
import com.alibaba.android.arouter.facade.Postcard;
import com.alibaba.android.arouter.facade.annotation.Interceptor;
import com.alibaba.android.arouter.facade.callback.InterceptorCallback;
import com.alibaba.android.arouter.facade.template.IInterceptor;
import com.gateio.biz.base.router.RouterConst;
import java.util.HashSet;
import kotlin.Lazy;
import kotlin.LazyKt__LazyJVMKt;
import kotlin.Metadata;
import kotlin.collections.SetsKt__SetsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;

/* compiled from: AppModeInterceptor.kt */
@Interceptor(name = "AppMode拦截器", priority = 1)
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u0000 \f2\u00020\u0001:\u0001\fB\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u0004H\u0016J\u0018\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082.¢\u0006\u0002\n\u0000¨\u0006\r"}, d2 = {"Lcom/gateio/biz/base/router/AppModeInterceptor;", "Lcom/alibaba/android/arouter/facade/template/IInterceptor;", "()V", "context", "Landroid/content/Context;", "init", "", "process", "postcard", "Lcom/alibaba/android/arouter/facade/Postcard;", "callback", "Lcom/alibaba/android/arouter/facade/callback/InterceptorCallback;", "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public final class AppModeInterceptor implements IInterceptor {

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @NotNull
    private static final Lazy<HashSet<String>> paths$delegate = LazyKt__LazyJVMKt.lazy(new Function0<HashSet<String>>() { // from class: com.gateio.biz.base.router.AppModeInterceptor$Companion$paths$2
        @Override // kotlin.jvm.functions.Function0
        @NotNull
        public final HashSet<String> invoke() {
            return SetsKt__SetsKt.hashSetOf(RouterConst.MiniApp.ACTIVITY_APP_LIST, RouterConst.MiniApp.ACTIVITY_APPROVE_LIST, RouterConst.MiniApp.ACTIVITY_BILL, RouterConst.App.ACTIVITY_MARGIN_FUND);
        }
    });
    private Context context;

    /* compiled from: AppModeInterceptor.kt */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u0005H\u0007J\u0010\u0010\u000e\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u0005H\u0007R+\u0010\u0003\u001a\u0012\u0012\u0004\u0012\u00020\u00050\u0004j\b\u0012\u0004\u0012\u00020\u0005`\u00068BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\t\u0010\n\u001a\u0004\b\u0007\u0010\b¨\u0006\u000f"}, d2 = {"Lcom/gateio/biz/base/router/AppModeInterceptor$Companion;", "", "()V", "paths", "Ljava/util/HashSet;", "", "Lkotlin/collections/HashSet;", "getPaths", "()Ljava/util/HashSet;", "paths$delegate", "Lkotlin/Lazy;", "addPath", "", "path", "removePath", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final HashSet<String> getPaths() {
            return (HashSet) AppModeInterceptor.paths$delegate.getValue();
        }

        @JvmStatic
        public final void addPath(@NotNull String path) {
            getPaths().add(path);
        }

        @JvmStatic
        public final void removePath(@NotNull String path) {
            getPaths().remove(path);
        }
    }

    @JvmStatic
    public static final void addPath(@NotNull String str) {
        INSTANCE.addPath(str);
    }

    @JvmStatic
    public static final void removePath(@NotNull String str) {
        INSTANCE.removePath(str);
    }

    @Override // com.alibaba.android.arouter.facade.template.IProvider
    public void init(@NotNull Context context) {
        this.context = context;
    }

    @Override // com.alibaba.android.arouter.facade.template.IInterceptor
    public void process(@NotNull Postcard postcard, @NotNull InterceptorCallback callback) {
        if (INSTANCE.getPaths().contains(postcard.getPath())) {
            callback.onContinue(postcard);
        } else {
            callback.onContinue(postcard);
        }
    }
}