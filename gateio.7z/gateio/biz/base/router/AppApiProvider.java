package com.gateio.biz.base.router;

import com.gateio.biz.base.router.RouterConst;
import com.gateio.biz.base.router.provider.AppCallbackApi;
import com.gateio.biz.base.router.provider.GradleApi;
import com.gateio.lib.router.GTRouter;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: AppApiProvider.kt */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0012\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\u0004H\u0007J\b\u0010\u000b\u001a\u00020\tH\u0007J\b\u0010\f\u001a\u00020\u0006H\u0007J\u0012\u0010\r\u001a\u00020\u00062\b\b\u0002\u0010\n\u001a\u00020\u0004H\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u000e"}, d2 = {"Lcom/gateio/biz/base/router/AppApiProvider;", "", "()V", "defaultAppCallbackRoutePath", "", "defaultGradleApi", "Lcom/gateio/biz/base/router/provider/GradleApi;", "defaultGradleRoutePath", "getAppCallbackApi", "Lcom/gateio/biz/base/router/provider/AppCallbackApi;", "path", "getDefaultAppCallbackApi", "getDefaultGradleApi", "getGradleApi", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public final class AppApiProvider {

    @Nullable
    private static GradleApi defaultGradleApi;

    @NotNull
    public static final AppApiProvider INSTANCE = new AppApiProvider();

    @NotNull
    private static String defaultGradleRoutePath = RouterConst.App.PROVIDER_GRADLE;

    @NotNull
    private static String defaultAppCallbackRoutePath = RouterConst.App.PROVIDER_APP_CALLBACK;

    private AppApiProvider() {
    }

    @JvmStatic
    @NotNull
    public static final AppCallbackApi getDefaultAppCallbackApi() {
        return getAppCallbackApi$default(null, 1, null);
    }

    public static /* synthetic */ AppCallbackApi getAppCallbackApi$default(String str, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = defaultAppCallbackRoutePath;
        }
        return getAppCallbackApi(str);
    }

    @JvmStatic
    @NotNull
    public static final GradleApi getDefaultGradleApi() {
        if (defaultGradleApi == null) {
            defaultGradleApi = getGradleApi$default(null, 1, null);
        }
        return defaultGradleApi;
    }

    public static /* synthetic */ GradleApi getGradleApi$default(String str, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = defaultGradleRoutePath;
        }
        return getGradleApi(str);
    }

    @JvmStatic
    @NotNull
    public static final AppCallbackApi getAppCallbackApi(@NotNull String path) {
        return (AppCallbackApi) GTRouter.serviceAPI(path);
    }

    @JvmStatic
    @NotNull
    public static final GradleApi getGradleApi(@NotNull String path) {
        return (GradleApi) GTRouter.serviceAPI(path);
    }
}