package com.gateio.biz.base.router.page;

import androidx.viewbinding.ViewBinding;
import com.gateio.biz.base.listener.MiniAppOnClickListener;
import com.gateio.common.base.GTBaseMVPDialogFragment;
import com.gateio.rxjava.basemvp.IBasePresenter;
import com.gateio.rxjava.basemvp.IHostView;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* compiled from: IBaseMiniAppFragment.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b&\u0018\u0000*\b\b\u0000\u0010\u0001*\u00020\u0002*\b\b\u0001\u0010\u0003*\u00020\u0004*\b\b\u0002\u0010\u0005*\u00020\u00062\u0014\u0012\u0004\u0012\u0002H\u0001\u0012\u0004\u0012\u0002H\u0003\u0012\u0004\u0012\u0002H\u00050\u0007B\u0005¢\u0006\u0002\u0010\bJ\b\u0010\t\u001a\u00020\nH\u0016J\u0010\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\rH&¨\u0006\u000e"}, d2 = {"Lcom/gateio/biz/base/router/page/IBaseMiniAppFragment;", "P", "Lcom/gateio/rxjava/basemvp/IBasePresenter;", "H", "Lcom/gateio/rxjava/basemvp/IHostView;", "VB", "Landroidx/viewbinding/ViewBinding;", "Lcom/gateio/common/base/GTBaseMVPDialogFragment;", "()V", "onBackPressed", "", "onClickListener", "miniAppOnClickListener", "Lcom/gateio/biz/base/listener/MiniAppOnClickListener;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public abstract class IBaseMiniAppFragment<P extends IBasePresenter, H extends IHostView, VB extends ViewBinding> extends GTBaseMVPDialogFragment<P, H, VB> {
    public abstract void onClickListener(@NotNull MiniAppOnClickListener miniAppOnClickListener);

    public void onBackPressed() {
    }
}