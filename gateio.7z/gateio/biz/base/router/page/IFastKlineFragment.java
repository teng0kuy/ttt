package com.gateio.biz.base.router.page;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import androidx.viewbinding.ViewBinding;
import com.bytedance.apm.agent.v2.instrumentation.AppAgent;
import com.gateio.biz.base.model.enums.EnumMiniKLineType;
import com.gateio.biz.base.utils.GTThemUtils;
import com.gateio.common.base.GTBaseMVPDialogFragment;
import com.gateio.common.tool.GlobalUtils;
import com.gateio.rxjava.basemvp.IBasePresenter;
import com.gateio.rxjava.basemvp.IHostView;
import com.google.android.gms.common.internal.ServiceSpecificExtraArgs;
import java.util.List;
import kotlin.Metadata;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: IFastKlineFragment.kt */
@Metadata(d1 = {"\u0000p\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\b&\u0018\u0000 ;*\b\b\u0000\u0010\u0001*\u00020\u0002*\b\b\u0001\u0010\u0003*\u00020\u0004*\b\b\u0002\u0010\u0005*\u00020\u00062\u0014\u0012\u0004\u0012\u0002H\u0001\u0012\u0004\u0012\u0002H\u0003\u0012\u0004\u0012\u0002H\u00050\u0007:\u0001;B\u0005¢\u0006\u0002\u0010\bJ\u0018\u0010\u001a\u001a\u00020\u00112\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001eH&J\u0010\u0010\u001f\u001a\u00020\u00112\u0006\u0010 \u001a\u00020!H&J\u0010\u0010\"\u001a\u00020\u00112\u0006\u0010#\u001a\u00020!H&J\u0010\u0010$\u001a\u00020\u00112\u0006\u0010$\u001a\u00020!H&J\b\u0010%\u001a\u00020!H\u0004J\b\u0010&\u001a\u00020!H&J\u0010\u0010'\u001a\u00020\u00112\u0006\u0010(\u001a\u00020!H&J\u0010\u0010)\u001a\u00020\u00112\u0006\u0010*\u001a\u00020+H\u0016J\u0012\u0010,\u001a\u00020\u00112\b\u0010-\u001a\u0004\u0018\u00010.H\u0016J\b\u0010/\u001a\u00020\u0011H&J\u001a\u00100\u001a\u00020\u00112\u0006\u00101\u001a\u00020!2\b\b\u0002\u00102\u001a\u00020!H&J \u00103\u001a\u00020\u00112\u0006\u00104\u001a\u00020\u00172\u0006\u00105\u001a\u00020\u00172\u0006\u00106\u001a\u00020\u0017H&J(\u00107\u001a\u00020\u00112\u001e\u00108\u001a\u001a\u0012\u0016\u0012\u0014\u0012\u0004\u0012\u00020\u0017\u0012\u0004\u0012\u00020\u0017\u0012\u0004\u0012\u00020!0:09H&R\u001e\u0010\u000b\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\n@BX\u0084\u000e¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR(\u0010\u000e\u001a\u0010\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R(\u0010\u0016\u001a\u0010\u0012\u0004\u0012\u00020\u0017\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0013\"\u0004\b\u0019\u0010\u0015¨\u0006<"}, d2 = {"Lcom/gateio/biz/base/router/page/IFastKlineFragment;", "P", "Lcom/gateio/rxjava/basemvp/IBasePresenter;", "H", "Lcom/gateio/rxjava/basemvp/IHostView;", "VB", "Landroidx/viewbinding/ViewBinding;", "Lcom/gateio/common/base/GTBaseMVPDialogFragment;", "()V", "<set-?>", "Lcom/gateio/biz/base/model/enums/EnumMiniKLineType;", IFastKlineFragment.ARG_MINIKLINE_TYPE, "getMiniKLineType", "()Lcom/gateio/biz/base/model/enums/EnumMiniKLineType;", "onChartHeightGetListener", "Lkotlin/Function1;", "", "", "getOnChartHeightGetListener", "()Lkotlin/jvm/functions/Function1;", "setOnChartHeightGetListener", "(Lkotlin/jvm/functions/Function1;)V", "onChartValueClickedListener", "", "getOnChartValueClickedListener", "setOnChartValueClickedListener", "addCloseView", "close", "Landroid/view/View;", ServiceSpecificExtraArgs.CastExtraArgs.LISTENER, "Lcom/gateio/biz/base/router/page/CloseListener;", "changeNightMode", "nightMode", "", "isFullWidth", "fullWidth", "isGoneAllShowClickView", "isLastPriceUpdateFromTicker", "isShowKlineState", "isShowKlineView", "isShowKline", "onConfigurationChanged", "newConfig", "Landroid/content/res/Configuration;", AppAgent.ON_CREATE, "savedInstanceState", "Landroid/os/Bundle;", "removeCloseView", "showFastData", "isRefresh", "reInitUI", "updateLastPrice", "currency", "lastPrice", "lastMarkPrice", "updatePendingOrder", "pendingOrders", "", "Lkotlin/Triple;", "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public abstract class IFastKlineFragment<P extends IBasePresenter, H extends IHostView, VB extends ViewBinding> extends GTBaseMVPDialogFragment<P, H, VB> {

    @NotNull
    public static final String ARG_MINIKLINE_TYPE = "miniKLineType";

    @NotNull
    private EnumMiniKLineType miniKLineType = EnumMiniKLineType.OTHER;

    @Nullable
    private Function1<? super Integer, Unit> onChartHeightGetListener;

    @Nullable
    private Function1<? super String, Unit> onChartValueClickedListener;

    public abstract void addCloseView(@NotNull View close, @NotNull CloseListener listener);

    public abstract void changeNightMode(boolean nightMode);

    public abstract void isFullWidth(boolean fullWidth);

    public abstract void isGoneAllShowClickView(boolean isGoneAllShowClickView);

    public abstract boolean isShowKlineState();

    public abstract void isShowKlineView(boolean isShowKline);

    public abstract void removeCloseView();

    public abstract void showFastData(boolean isRefresh, boolean reInitUI);

    public abstract void updateLastPrice(@NotNull String currency, @NotNull String lastPrice, @NotNull String lastMarkPrice);

    public abstract void updatePendingOrder(@NotNull List<Triple<String, String, Boolean>> pendingOrders);

    public static /* synthetic */ void showFastData$default(IFastKlineFragment iFastKlineFragment, boolean z10, boolean z11, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: showFastData");
        }
        if ((i10 & 2) != 0) {
            z11 = true;
        }
        iFastKlineFragment.showFastData(z10, z11);
    }

    @NotNull
    protected final EnumMiniKLineType getMiniKLineType() {
        return this.miniKLineType;
    }

    @Nullable
    public final Function1<Integer, Unit> getOnChartHeightGetListener() {
        return this.onChartHeightGetListener;
    }

    @Nullable
    public final Function1<String, Unit> getOnChartValueClickedListener() {
        return this.onChartValueClickedListener;
    }

    protected final boolean isLastPriceUpdateFromTicker() {
        return this.miniKLineType == EnumMiniKLineType.OTHER;
    }

    public final void setOnChartHeightGetListener(@Nullable Function1<? super Integer, Unit> function1) {
        this.onChartHeightGetListener = function1;
    }

    public final void setOnChartValueClickedListener(@Nullable Function1<? super String, Unit> function1) {
        this.onChartValueClickedListener = function1;
    }

    @Override // androidx.fragment.app.Fragment, android.content.ComponentCallbacks
    public void onConfigurationChanged(@NotNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (this.miniKLineType == EnumMiniKLineType.OTHER) {
            int i10 = newConfig.uiMode & 48;
            if (i10 == 16 || i10 == 32) {
                GTThemUtils.updateThemeConfig$default(this.mHostView.getHost(), false, 2, null);
                changeNightMode(GlobalUtils.isNightMode());
            }
        }
    }

    @Override // com.gateio.common.base.GTBaseMVPDialogFragment, androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onCreate(@Nullable Bundle savedInstanceState) {
        Integer numValueOf;
        super.onCreate(savedInstanceState);
        EnumMiniKLineType.Companion companion = EnumMiniKLineType.INSTANCE;
        Bundle arguments = getArguments();
        if (arguments != null) {
            numValueOf = Integer.valueOf(arguments.getInt(ARG_MINIKLINE_TYPE));
        } else {
            numValueOf = null;
        }
        EnumMiniKLineType enumMiniKLineTypeFromValue = companion.fromValue(numValueOf);
        this.miniKLineType = enumMiniKLineTypeFromValue;
        if (enumMiniKLineTypeFromValue == EnumMiniKLineType.OTHER) {
            GTThemUtils.updateThemeConfig$default(this.mHostView.getHost(), false, 2, null);
        }
    }
}