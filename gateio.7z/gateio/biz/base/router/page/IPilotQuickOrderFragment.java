package com.gateio.biz.base.router.page;

import androidx.viewbinding.ViewBinding;
import com.gateio.fiatotclib.function.order.appeal.GetHelpActivity;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: IPilotQuickOrderFragment.kt */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b&\u0018\u0000*\b\b\u0000\u0010\u0001*\u00020\u00022\b\u0012\u0004\u0012\u0002H\u00010\u0003:\u0001\u0005B\u0005¢\u0006\u0002\u0010\u0004¨\u0006\u0006"}, d2 = {"Lcom/gateio/biz/base/router/page/IPilotQuickOrderFragment;", "VB", "Landroidx/viewbinding/ViewBinding;", "Lcom/gateio/biz/base/router/page/ITransQuickOrderFragment;", "()V", "PilotQuickOrderParams", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public abstract class IPilotQuickOrderFragment<VB extends ViewBinding> extends ITransQuickOrderFragment<VB> {

    /* compiled from: IPilotQuickOrderFragment.kt */
    @Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0015\u0018\u00002\u00020\u0001B½\u0001\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\t\u0012\u0006\u0010\u000b\u001a\u00020\t\u0012\u0006\u0010\f\u001a\u00020\t\u0012\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\t\u0012\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\t\u0012\n\b\u0002\u0010\u000f\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0010\u001a\u00020\u0011\u0012\u0006\u0010\u0012\u001a\u00020\u0011\u0012\u0006\u0010\u0013\u001a\u00020\t\u0012\b\b\u0002\u0010\u0014\u001a\u00020\t\u0012\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00170\u0016\u0012\u0010\b\u0002\u0010\u0018\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0016¢\u0006\u0002\u0010\u0019R\u0013\u0010\u000e\u001a\u0004\u0018\u00010\t¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001bR\u0011\u0010\u0012\u001a\u00020\u0011¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001eR\u0011\u0010\u0010\u001a\u00020\u0011¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u001eR\u0011\u0010\n\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u001bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010!R\u0015\u0010\u000f\u001a\u0004\u0018\u00010\u0003¢\u0006\n\n\u0002\u0010#\u001a\u0004\b\u000f\u0010\"R\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010!R\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010!R\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010!R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0004\u0010!R\u0011\u0010\u0014\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b$\u0010\u001bR\u0019\u0010\u0018\u001a\n\u0012\u0004\u0012\u00020\u0017\u0018\u00010\u0016¢\u0006\b\n\u0000\u001a\u0004\b%\u0010&R\u0011\u0010\u0013\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b'\u0010\u001bR\u0011\u0010\u000b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b(\u0010\u001bR\u0011\u0010\f\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b)\u0010\u001bR\u0017\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00170\u0016¢\u0006\b\n\u0000\u001a\u0004\b*\u0010&R\u0013\u0010\r\u001a\u0004\u0018\u00010\t¢\u0006\b\n\u0000\u001a\u0004\b+\u0010\u001b¨\u0006,"}, d2 = {"Lcom/gateio/biz/base/router/page/IPilotQuickOrderFragment$PilotQuickOrderParams;", "", GetHelpActivity.IS_BUY, "", "isShowTip", "isShowGoSpot", "isShowSetting", "isShowLastPrice", "currency", "", "exchange", "showCurrency", "showExchange", "wtPrice", "buyAvgPrice", "isNeedFormatPrice", "decimalPrice", "", "decimalCount", "originPrice", "moduleSource", "tipsClickListener", "Lkotlin/Function0;", "", "onBackListener", "(ZZZZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;IILjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V", "getBuyAvgPrice", "()Ljava/lang/String;", "getCurrency", "getDecimalCount", "()I", "getDecimalPrice", "getExchange", "()Z", "()Ljava/lang/Boolean;", "Ljava/lang/Boolean;", "getModuleSource", "getOnBackListener", "()Lkotlin/jvm/functions/Function0;", "getOriginPrice", "getShowCurrency", "getShowExchange", "getTipsClickListener", "getWtPrice", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class PilotQuickOrderParams {

        @Nullable
        private final String buyAvgPrice;

        @NotNull
        private final String currency;
        private final int decimalCount;
        private final int decimalPrice;

        @NotNull
        private final String exchange;
        private final boolean isBuy;

        @Nullable
        private final Boolean isNeedFormatPrice;
        private final boolean isShowGoSpot;
        private final boolean isShowLastPrice;
        private final boolean isShowSetting;
        private final boolean isShowTip;

        @NotNull
        private final String moduleSource;

        @Nullable
        private final Function0<Unit> onBackListener;

        @NotNull
        private final String originPrice;

        @NotNull
        private final String showCurrency;

        @NotNull
        private final String showExchange;

        @NotNull
        private final Function0<Unit> tipsClickListener;

        @Nullable
        private final String wtPrice;

        public PilotQuickOrderParams(boolean z10, boolean z11, boolean z12, boolean z13, boolean z14, @NotNull String str, @NotNull String str2, @NotNull String str3, @NotNull String str4, @Nullable String str5, @Nullable String str6, @Nullable Boolean bool, int i10, int i11, @NotNull String str7, @NotNull String str8, @NotNull Function0<Unit> function0, @Nullable Function0<Unit> function02) {
            this.isBuy = z10;
            this.isShowTip = z11;
            this.isShowGoSpot = z12;
            this.isShowSetting = z13;
            this.isShowLastPrice = z14;
            this.currency = str;
            this.exchange = str2;
            this.showCurrency = str3;
            this.showExchange = str4;
            this.wtPrice = str5;
            this.buyAvgPrice = str6;
            this.isNeedFormatPrice = bool;
            this.decimalPrice = i10;
            this.decimalCount = i11;
            this.originPrice = str7;
            this.moduleSource = str8;
            this.tipsClickListener = function0;
            this.onBackListener = function02;
        }

        @Nullable
        public final String getBuyAvgPrice() {
            return this.buyAvgPrice;
        }

        @NotNull
        public final String getCurrency() {
            return this.currency;
        }

        public final int getDecimalCount() {
            return this.decimalCount;
        }

        public final int getDecimalPrice() {
            return this.decimalPrice;
        }

        @NotNull
        public final String getExchange() {
            return this.exchange;
        }

        @NotNull
        public final String getModuleSource() {
            return this.moduleSource;
        }

        @Nullable
        public final Function0<Unit> getOnBackListener() {
            return this.onBackListener;
        }

        @NotNull
        public final String getOriginPrice() {
            return this.originPrice;
        }

        @NotNull
        public final String getShowCurrency() {
            return this.showCurrency;
        }

        @NotNull
        public final String getShowExchange() {
            return this.showExchange;
        }

        @NotNull
        public final Function0<Unit> getTipsClickListener() {
            return this.tipsClickListener;
        }

        @Nullable
        public final String getWtPrice() {
            return this.wtPrice;
        }

        /* renamed from: isBuy, reason: from getter */
        public final boolean getIsBuy() {
            return this.isBuy;
        }

        @Nullable
        /* renamed from: isNeedFormatPrice, reason: from getter */
        public final Boolean getIsNeedFormatPrice() {
            return this.isNeedFormatPrice;
        }

        /* renamed from: isShowGoSpot, reason: from getter */
        public final boolean getIsShowGoSpot() {
            return this.isShowGoSpot;
        }

        /* renamed from: isShowLastPrice, reason: from getter */
        public final boolean getIsShowLastPrice() {
            return this.isShowLastPrice;
        }

        /* renamed from: isShowSetting, reason: from getter */
        public final boolean getIsShowSetting() {
            return this.isShowSetting;
        }

        /* renamed from: isShowTip, reason: from getter */
        public final boolean getIsShowTip() {
            return this.isShowTip;
        }

        public /* synthetic */ PilotQuickOrderParams(boolean z10, boolean z11, boolean z12, boolean z13, boolean z14, String str, String str2, String str3, String str4, String str5, String str6, Boolean bool, int i10, int i11, String str7, String str8, Function0 function0, Function0 function02, int i12, DefaultConstructorMarker defaultConstructorMarker) {
            this((i12 & 1) != 0 ? true : z10, (i12 & 2) != 0 ? true : z11, (i12 & 4) != 0 ? true : z12, (i12 & 8) != 0 ? true : z13, (i12 & 16) != 0 ? false : z14, str, str2, str3, str4, (i12 & 512) != 0 ? null : str5, (i12 & 1024) != 0 ? null : str6, (i12 & 2048) != 0 ? Boolean.TRUE : bool, i10, i11, str7, (32768 & i12) != 0 ? "" : str8, function0, (i12 & 131072) != 0 ? null : function02);
        }
    }
}