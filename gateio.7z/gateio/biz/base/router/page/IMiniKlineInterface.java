package com.gateio.biz.base.router.page;

import android.view.View;
import com.google.android.gms.common.internal.ServiceSpecificExtraArgs;
import java.util.List;
import kotlin.Metadata;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: IMiniKlineInterface.kt */
@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u000e\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\bf\u0018\u00002\u00020\u0001J\u0018\u0010\u000e\u001a\u00020\u00052\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0012H&J\u0010\u0010\u0013\u001a\u00020\u00052\u0006\u0010\u0014\u001a\u00020\u0015H&J\u0010\u0010\u0016\u001a\u00020\u00052\u0006\u0010\u0016\u001a\u00020\u0015H&J\b\u0010\u0017\u001a\u00020\u0015H&J\u0010\u0010\u0018\u001a\u00020\u00052\u0006\u0010\u0019\u001a\u00020\u0015H&J\b\u0010\u001a\u001a\u00020\u0005H&J\u001a\u0010\u001b\u001a\u00020\u00052\u0006\u0010\u001c\u001a\u00020\u00152\b\b\u0002\u0010\u001d\u001a\u00020\u0015H&J \u0010\u001e\u001a\u00020\u00052\u0006\u0010\u001f\u001a\u00020\u000b2\u0006\u0010 \u001a\u00020\u000b2\u0006\u0010!\u001a\u00020\u000bH&J(\u0010\"\u001a\u00020\u00052\u001e\u0010#\u001a\u001a\u0012\u0016\u0012\u0014\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00150%0$H&R&\u0010\u0002\u001a\u0010\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u0003X¦\u000e¢\u0006\f\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR&\u0010\n\u001a\u0010\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u0003X¦\u000e¢\u0006\f\u001a\u0004\b\f\u0010\u0007\"\u0004\b\r\u0010\tø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006&À\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/router/page/IMiniKlineInterface;", "", "onChartHeightGetListener", "Lkotlin/Function1;", "", "", "getOnChartHeightGetListener", "()Lkotlin/jvm/functions/Function1;", "setOnChartHeightGetListener", "(Lkotlin/jvm/functions/Function1;)V", "onChartValueClickedListener", "", "getOnChartValueClickedListener", "setOnChartValueClickedListener", "addCloseView", "close", "Landroid/view/View;", ServiceSpecificExtraArgs.CastExtraArgs.LISTENER, "Lcom/gateio/biz/base/router/page/CloseListener;", "isFullWidth", "fullWidth", "", "isGoneAllShowClickView", "isShowKlineState", "isShowKlineView", "isShowKline", "removeCloseView", "showFastData", "isLoading", "reInitUI", "updateLastPrice", "currency", "lastPrice", "lastMarkPrice", "updatePendingOrder", "pendingOrders", "", "Lkotlin/Triple;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public interface IMiniKlineInterface {
    void addCloseView(@NotNull View close, @NotNull CloseListener listener);

    @Nullable
    Function1<Integer, Unit> getOnChartHeightGetListener();

    @Nullable
    Function1<String, Unit> getOnChartValueClickedListener();

    void isFullWidth(boolean fullWidth);

    void isGoneAllShowClickView(boolean isGoneAllShowClickView);

    boolean isShowKlineState();

    void isShowKlineView(boolean isShowKline);

    void removeCloseView();

    void setOnChartHeightGetListener(@Nullable Function1<? super Integer, Unit> function1);

    void setOnChartValueClickedListener(@Nullable Function1<? super String, Unit> function1);

    void showFastData(boolean isLoading, boolean reInitUI);

    void updateLastPrice(@NotNull String currency, @NotNull String lastPrice, @NotNull String lastMarkPrice);

    void updatePendingOrder(@NotNull List<Triple<String, String, Boolean>> pendingOrders);

    static /* synthetic */ void showFastData$default(IMiniKlineInterface iMiniKlineInterface, boolean z10, boolean z11, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: showFastData");
        }
        if ((i10 & 2) != 0) {
            z11 = true;
        }
        iMiniKlineInterface.showFastData(z10, z11);
    }
}