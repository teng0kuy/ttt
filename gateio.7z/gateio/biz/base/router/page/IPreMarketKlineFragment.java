package com.gateio.biz.base.router.page;

import androidx.viewbinding.ViewBinding;
import com.gateio.biz.base.listener.PreMarketMiniKLinePlatformViewEventListener;
import com.gateio.biz.base.model.PreMarketKlineData;
import com.gateio.biz.base.mvvm.GTBaseMVVMFragment;
import kotlin.Metadata;
import org.jetbrains.annotations.Nullable;

/* compiled from: IPreMarketKlineFragment.kt */
@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b&\u0018\u0000*\b\b\u0000\u0010\u0001*\u00020\u00022\b\u0012\u0004\u0012\u0002H\u00010\u0003B\u0005¢\u0006\u0002\u0010\u0004J\u0018\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000eH&J\u0010\u0010\u0010\u001a\u00020\f2\u0006\u0010\u0011\u001a\u00020\u0012H&J\"\u0010\u0013\u001a\u00020\f2\b\u0010\u0014\u001a\u0004\u0018\u00010\u00152\u0006\u0010\u0016\u001a\u00020\u00122\u0006\u0010\u0017\u001a\u00020\u0012H&R\u001c\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\n¨\u0006\u0018"}, d2 = {"Lcom/gateio/biz/base/router/page/IPreMarketKlineFragment;", "VB", "Landroidx/viewbinding/ViewBinding;", "Lcom/gateio/biz/base/mvvm/GTBaseMVVMFragment;", "()V", "onChartViewEventListener", "Lcom/gateio/biz/base/listener/PreMarketMiniKLinePlatformViewEventListener;", "getOnChartViewEventListener", "()Lcom/gateio/biz/base/listener/PreMarketMiniKLinePlatformViewEventListener;", "setOnChartViewEventListener", "(Lcom/gateio/biz/base/listener/PreMarketMiniKLinePlatformViewEventListener;)V", "setUpPreMarketKline", "", "decimalPrice", "", "decimalVolume", "showKline", "show", "", "updateKlineData", "data", "Lcom/gateio/biz/base/model/PreMarketKlineData;", "scrollToLatest", "isLoadMore", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public abstract class IPreMarketKlineFragment<VB extends ViewBinding> extends GTBaseMVVMFragment<VB> {

    @Nullable
    private PreMarketMiniKLinePlatformViewEventListener onChartViewEventListener;

    public abstract void setUpPreMarketKline(int decimalPrice, int decimalVolume);

    public abstract void showKline(boolean show);

    public abstract void updateKlineData(@Nullable PreMarketKlineData data, boolean scrollToLatest, boolean isLoadMore);

    @Nullable
    public final PreMarketMiniKLinePlatformViewEventListener getOnChartViewEventListener() {
        return this.onChartViewEventListener;
    }

    public final void setOnChartViewEventListener(@Nullable PreMarketMiniKLinePlatformViewEventListener preMarketMiniKLinePlatformViewEventListener) {
        this.onChartViewEventListener = preMarketMiniKLinePlatformViewEventListener;
    }
}