package com.gateio.biz.base.router.page;

import androidx.viewbinding.ViewBinding;
import com.gate_sdk.web3_wallet.DeFiConstants;
import com.gateio.biz.base.model.trans.TransTradeTypeEnum;
import com.gateio.biz.base.mvvm.compat.GTBaseMVVMFragmentCompatMVP;
import com.gateio.fiatotclib.function.order.appeal.GetHelpActivity;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: ITransQuickOrderFragment.kt */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0005\b&\u0018\u0000*\b\b\u0000\u0010\u0001*\u00020\u00022\b\u0012\u0004\u0012\u0002H\u00010\u0003:\u0001\u0017B\u0005¢\u0006\u0002\u0010\u0004J\u0010\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH&J\u0010\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\bH&J\u0018\u0010\u000b\u001a\u00020\u00062\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\rH&J)\u0010\u000f\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\r2\u0006\u0010\u0011\u001a\u00020\b2\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u00010\u0013H&¢\u0006\u0002\u0010\u0014J\u0010\u0010\u0015\u001a\u00020\u00062\u0006\u0010\u0016\u001a\u00020\rH&¨\u0006\u0018"}, d2 = {"Lcom/gateio/biz/base/router/page/ITransQuickOrderFragment;", "VB", "Landroidx/viewbinding/ViewBinding;", "Lcom/gateio/biz/base/mvvm/compat/GTBaseMVVMFragmentCompatMVP;", "()V", "setDecimalCount", "", "decimalCount", "", "setDecimalTotal", "decimalTotal", "setDepthFirstPrice", "buyPrice", "", "sellPrice", "setLimitWtPrice", "price", "decimalPrice", "isNeedFormat", "", "(Ljava/lang/String;ILjava/lang/Boolean;)V", "setOriginPrice", "originPrice", "TransQuickOrderParams", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public abstract class ITransQuickOrderFragment<VB extends ViewBinding> extends GTBaseMVVMFragmentCompatMVP<VB> {

    /* compiled from: ITransQuickOrderFragment.kt */
    @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0013\u0018\u00002\u00020\u0001Bq\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\u0006\u0010\f\u001a\u00020\u000b\u0012\u0006\u0010\r\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u0005\u0012\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00110\u0010¢\u0006\u0002\u0010\u0012R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\f\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0011\u0010\n\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0016R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0014R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0019R\u0015\u0010\t\u001a\u0004\u0018\u00010\u0003¢\u0006\n\n\u0002\u0010\u001b\u001a\u0004\b\t\u0010\u001aR\u0011\u0010\u000e\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0014R\u0011\u0010\r\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0014R\u0017\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00110\u0010¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001fR\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b \u0010\u0014\"\u0004\b!\u0010\"R\u0013\u0010\b\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b#\u0010\u0014¨\u0006$"}, d2 = {"Lcom/gateio/biz/base/router/page/ITransQuickOrderFragment$TransQuickOrderParams;", "", GetHelpActivity.IS_BUY, "", "type", "", "currency", "exchange", "wtPrice", "isNeedFormatPrice", "decimalPrice", "", "decimalCount", "originPrice", "moduleSource", "tipsClickListener", "Lkotlin/Function0;", "", "(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;IILjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V", "getCurrency", "()Ljava/lang/String;", "getDecimalCount", "()I", "getDecimalPrice", "getExchange", "()Z", "()Ljava/lang/Boolean;", "Ljava/lang/Boolean;", "getModuleSource", "getOriginPrice", "getTipsClickListener", "()Lkotlin/jvm/functions/Function0;", DeFiConstants.GetType, "setType", "(Ljava/lang/String;)V", "getWtPrice", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class TransQuickOrderParams {

        @NotNull
        private final String currency;
        private final int decimalCount;
        private final int decimalPrice;

        @NotNull
        private final String exchange;
        private final boolean isBuy;

        @Nullable
        private final Boolean isNeedFormatPrice;

        @NotNull
        private final String moduleSource;

        @NotNull
        private final String originPrice;

        @NotNull
        private final Function0<Unit> tipsClickListener;

        @NotNull
        private String type;

        @Nullable
        private final String wtPrice;

        public TransQuickOrderParams(boolean z10, @NotNull String str, @NotNull String str2, @NotNull String str3, @Nullable String str4, @Nullable Boolean bool, int i10, int i11, @NotNull String str5, @NotNull String str6, @NotNull Function0<Unit> function0) {
            this.isBuy = z10;
            this.type = str;
            this.currency = str2;
            this.exchange = str3;
            this.wtPrice = str4;
            this.isNeedFormatPrice = bool;
            this.decimalPrice = i10;
            this.decimalCount = i11;
            this.originPrice = str5;
            this.moduleSource = str6;
            this.tipsClickListener = function0;
        }

        @NotNull
        public final String getCurrency() {
            return this.currency;
        }

        public final int getDecimalCount() {
            return this.decimalCount;
        }

        public final int getDecimalPrice() {
            return this.decimalPrice;
        }

        @NotNull
        public final String getExchange() {
            return this.exchange;
        }

        @NotNull
        public final String getModuleSource() {
            return this.moduleSource;
        }

        @NotNull
        public final String getOriginPrice() {
            return this.originPrice;
        }

        @NotNull
        public final Function0<Unit> getTipsClickListener() {
            return this.tipsClickListener;
        }

        @NotNull
        public final String getType() {
            return this.type;
        }

        @Nullable
        public final String getWtPrice() {
            return this.wtPrice;
        }

        /* renamed from: isBuy, reason: from getter */
        public final boolean getIsBuy() {
            return this.isBuy;
        }

        @Nullable
        /* renamed from: isNeedFormatPrice, reason: from getter */
        public final Boolean getIsNeedFormatPrice() {
            return this.isNeedFormatPrice;
        }

        public final void setType(@NotNull String str) {
            this.type = str;
        }

        public /* synthetic */ TransQuickOrderParams(boolean z10, String str, String str2, String str3, String str4, Boolean bool, int i10, int i11, String str5, String str6, Function0 function0, int i12, DefaultConstructorMarker defaultConstructorMarker) {
            this((i12 & 1) != 0 ? true : z10, (i12 & 2) != 0 ? TransTradeTypeEnum.TRANS_SPOT.getType() : str, str2, str3, (i12 & 16) != 0 ? null : str4, (i12 & 32) != 0 ? Boolean.TRUE : bool, i10, i11, str5, (i12 & 512) != 0 ? "" : str6, function0);
        }
    }

    public abstract void setDecimalCount(int decimalCount);

    public abstract void setDecimalTotal(int decimalTotal);

    public abstract void setDepthFirstPrice(@NotNull String buyPrice, @NotNull String sellPrice);

    public abstract void setLimitWtPrice(@NotNull String price, int decimalPrice, @Nullable Boolean isNeedFormat);

    public abstract void setOriginPrice(@NotNull String originPrice);

    public static /* synthetic */ void setLimitWtPrice$default(ITransQuickOrderFragment iTransQuickOrderFragment, String str, int i10, Boolean bool, int i11, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: setLimitWtPrice");
        }
        if ((i11 & 4) != 0) {
            bool = Boolean.TRUE;
        }
        iTransQuickOrderFragment.setLimitWtPrice(str, i10, bool);
    }
}