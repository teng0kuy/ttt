package com.gateio.biz.base.router.page;

import android.view.View;
import android.widget.FrameLayout;
import androidx.viewbinding.ViewBinding;
import com.alipay.zoloz.toyger.ToygerService;
import com.gateio.biz.base.listener.IBaseKlineListener;
import com.gateio.common.base.GTBaseMVPFragment;
import com.gateio.rxjava.basemvp.IBasePresenter;
import com.gateio.rxjava.basemvp.IHostView;
import com.google.android.gms.common.internal.ServiceSpecificExtraArgs;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: IBaseKlineFragment.kt */
@Metadata(d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0000\b&\u0018\u0000*\b\b\u0000\u0010\u0001*\u00020\u0002*\b\b\u0001\u0010\u0003*\u00020\u0004*\b\b\u0002\u0010\u0005*\u00020\u00062\u0014\u0012\u0004\u0012\u0002H\u0001\u0012\u0004\u0012\u0002H\u0003\u0012\u0004\u0012\u0002H\u00050\u0007B\u0005¢\u0006\u0002\u0010\bJ\b\u0010\t\u001a\u00020\nH&J\u0010\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\rH&J\u0010\u0010\u000e\u001a\u00020\n2\u0006\u0010\u000f\u001a\u00020\rH&J\b\u0010\u0010\u001a\u00020\rH&J\b\u0010\u0011\u001a\u00020\nH&J\u0018\u0010\u0012\u001a\u00020\n2\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u0016H\u0016J\b\u0010\u0017\u001a\u00020\nH&J\b\u0010\u0018\u001a\u00020\nH&J\b\u0010\u0019\u001a\u00020\nH&J\b\u0010\u001a\u001a\u00020\nH\u0016J\b\u0010\u001b\u001a\u00020\nH&J\b\u0010\u001c\u001a\u00020\nH&J\u001a\u0010\u001d\u001a\u00020\n2\u0006\u0010\u001e\u001a\u00020\u001f2\b\u0010 \u001a\u0004\u0018\u00010!H&J\u0010\u0010\"\u001a\u00020\n2\u0006\u0010\u0015\u001a\u00020#H&J\u0010\u0010$\u001a\u00020\n2\u0006\u0010%\u001a\u00020\u0014H&J\u0010\u0010&\u001a\u00020\n2\u0006\u0010'\u001a\u00020\rH&J\u0010\u0010(\u001a\u00020\n2\u0006\u0010)\u001a\u00020*H&¨\u0006+"}, d2 = {"Lcom/gateio/biz/base/router/page/IBaseKlineFragment;", "P", "Lcom/gateio/rxjava/basemvp/IBasePresenter;", "H", "Lcom/gateio/rxjava/basemvp/IHostView;", "VB", "Landroidx/viewbinding/ViewBinding;", "Lcom/gateio/common/base/GTBaseMVPFragment;", "()V", "changeChartLandscape", "", "changeNightMode", "isNightMode", "", "chartEnableLoadMore", "enable", "isLandscapeCanShare", "landSpaceSetting", "moveKLineToPosition", "index", "", ServiceSpecificExtraArgs.CastExtraArgs.LISTENER, "", "onFullBackPressed", "refreshCountdown", "refreshSubIndexCheck", "resetCache", "resetData", "setInfoViewGone", "setKLineInfoView", "klineTopInfoView", "Landroid/view/View;", "klineFloatInfoParent", "Landroid/widget/FrameLayout;", "setKlineBaseListener", "Lcom/gateio/biz/base/listener/IBaseKlineListener;", "setKlineHeight", "height", "setShowLabel", "showLabel", "setTuyaPreferencesKey", ToygerService.KEY_RES_9_KEY, "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes37.dex */
public abstract class IBaseKlineFragment<P extends IBasePresenter, H extends IHostView, VB extends ViewBinding> extends GTBaseMVPFragment<P, H, VB> {
    public abstract void changeChartLandscape();

    public abstract void changeNightMode(boolean isNightMode);

    public abstract void chartEnableLoadMore(boolean enable);

    public abstract boolean isLandscapeCanShare();

    public abstract void landSpaceSetting();

    public abstract void onFullBackPressed();

    public abstract void refreshCountdown();

    public abstract void refreshSubIndexCheck();

    public abstract void resetData();

    public abstract void setInfoViewGone();

    public abstract void setKLineInfoView(@NotNull View klineTopInfoView, @Nullable FrameLayout klineFloatInfoParent);

    public abstract void setKlineBaseListener(@NotNull IBaseKlineListener listener);

    public abstract void setKlineHeight(int height);

    public abstract void setShowLabel(boolean showLabel);

    public abstract void setTuyaPreferencesKey(@NotNull String key);

    public void resetCache() {
    }

    public void moveKLineToPosition(int index, @NotNull Object listener) {
    }
}