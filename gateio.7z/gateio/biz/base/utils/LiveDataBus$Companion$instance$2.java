package com.gateio.biz.base.utils;

import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;
import org.jetbrains.annotations.NotNull;

/* compiled from: LiveDataBus.kt */
@Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u0001H\n¢\u0006\u0002\b\u0002"}, d2 = {"<anonymous>", "Lcom/gateio/biz/base/utils/LiveDataBus;", "invoke"}, k = 3, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes5.dex */
final class LiveDataBus$Companion$instance$2 extends Lambda implements Function0<LiveDataBus> {
    public static final LiveDataBus$Companion$instance$2 INSTANCE = ;

    LiveDataBus$Companion$instance$2() {
    }

    @Override // kotlin.jvm.functions.Function0
    @NotNull
    public final LiveDataBus invoke() {
        return new LiveDataBus();
    }
}