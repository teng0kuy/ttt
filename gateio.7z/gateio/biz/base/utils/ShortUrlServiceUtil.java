package com.gateio.biz.base.utils;

import com.gateio.biz.base.http.BizBaseHttpMethodV3;
import com.gateio.biz.base.model.ShortUrlServiceEntity;
import com.gateio.rxjava.CustomObserver;
import io.reactivex.rxjava3.core.s;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* compiled from: ShortUrlServiceUtil.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001\tB\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0016\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b¨\u0006\n"}, d2 = {"Lcom/gateio/biz/base/utils/ShortUrlServiceUtil;", "", "()V", "getShortUrl", "", "url", "", "callback", "Lcom/gateio/biz/base/utils/ShortUrlServiceUtil$ShortUrlServiceCallback;", "ShortUrlServiceCallback", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class ShortUrlServiceUtil {

    @NotNull
    public static final ShortUrlServiceUtil INSTANCE = new ShortUrlServiceUtil();

    /* compiled from: ShortUrlServiceUtil.kt */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\u0018\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u0005H&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\tÀ\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/utils/ShortUrlServiceUtil$ShortUrlServiceCallback;", "", "onFailed", "", "error", "", "onSuccess", "originUrl", "shortUrl", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public interface ShortUrlServiceCallback {
        void onFailed(@NotNull String error);

        void onSuccess(@NotNull String originUrl, @NotNull String shortUrl);
    }

    private ShortUrlServiceUtil() {
    }

    public final void getShortUrl(@NotNull final String url, @NotNull final ShortUrlServiceCallback callback) {
        s<ShortUrlServiceEntity> shortUrl;
        BizBaseHttpMethodV3 companion = BizBaseHttpMethodV3.INSTANCE.getInstance();
        if (companion == null || (shortUrl = companion.getShortUrl(url)) == null) {
            return;
        }
        shortUrl.subscribe(new CustomObserver<ShortUrlServiceEntity>() { // from class: com.gateio.biz.base.utils.ShortUrlServiceUtil.getShortUrl.1
            @Override // com.gateio.rxjava.CustomObserver, io.reactivex.rxjava3.core.z, org.reactivestreams.Subscriber
            public void onNext(@NotNull ShortUrlServiceEntity item) {
                callback.onSuccess(url, item.getTinyUrl());
            }

            @Override // com.gateio.rxjava.CustomObserver, io.reactivex.rxjava3.core.z, org.reactivestreams.Subscriber, io.reactivex.rxjava3.core.m, io.reactivex.rxjava3.core.c0
            public void onError(@NotNull Throwable e10) {
                super.onError(e10);
                ShortUrlServiceCallback shortUrlServiceCallback = callback;
                String message = e10.getMessage();
                if (message == null) {
                    message = "";
                }
                shortUrlServiceCallback.onFailed(message);
            }
        });
    }
}