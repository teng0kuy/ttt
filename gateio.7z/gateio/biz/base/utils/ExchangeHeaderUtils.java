package com.gateio.biz.base.utils;

import com.gateio.biz.base.BizBaseConstants;
import com.gateio.biz.market.ui_market.MarketFragmentList;
import com.gateio.lib.network.util.GTCustomHeaderHelper;
import java.util.LinkedHashMap;
import kotlin.Metadata;
import kotlin.collections.MapsKt__MapsKt;
import org.jetbrains.annotations.NotNull;

/* compiled from: ExchangeHeaderUtils.kt */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fJ\u000e\u0010\r\u001a\u00020\n2\u0006\u0010\u000e\u001a\u00020\fJ\u0006\u0010\u000f\u001a\u00020\nJ\u0006\u0010\u0010\u001a\u00020\nR\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0006X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0011"}, d2 = {"Lcom/gateio/biz/base/utils/ExchangeHeaderUtils;", "", "()V", "FUTURES_MODE_DEFAULT", "", "FUTURES_MODE_TESTNET", "", "FUTURES_MODE_VOUCHER", "FUTURES_TESTNET_DEFAULT", "addFuturesTestNetHeader", "", "isTestNet", "", "addMarketSelectHeader", MarketFragmentList.IS_MODE_VOUCHER, "clearMarketSelectHeaderValue", "clearTestNetHeaderValue", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class ExchangeHeaderUtils {
    public static final int FUTURES_MODE_DEFAULT = 0;

    @NotNull
    public static final String FUTURES_MODE_TESTNET = "1";
    public static final int FUTURES_MODE_VOUCHER = 1;

    @NotNull
    public static final String FUTURES_TESTNET_DEFAULT = "0";

    @NotNull
    public static final ExchangeHeaderUtils INSTANCE = new ExchangeHeaderUtils();

    private ExchangeHeaderUtils() {
    }

    public final void addFuturesTestNetHeader(boolean isTestNet) {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put("x-gate-testnet-unified", isTestNet ? "1" : "0");
        GTCustomHeaderHelper.addCustomHeaderString(BizBaseConstants.FuturesKey.FUTURES_TESTNET_HEADER, linkedHashMap);
    }

    public final void addMarketSelectHeader(boolean isModeVoucher) {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        linkedHashMap.put("x-gate-futures-voucher-mode", String.valueOf(isModeVoucher ? 1 : 0));
        GTCustomHeaderHelper.addCustomHeaderString(BizBaseConstants.FuturesKey.MARKET_SELECT_HEADER, linkedHashMap);
        StringBuilder sb = new StringBuilder();
        sb.append("addMarketSelectHeader isModeVoucher = ");
        sb.append(isModeVoucher ? 1 : 0);
    }

    public final void clearMarketSelectHeaderValue() {
        GTCustomHeaderHelper.addCustomHeaderString(BizBaseConstants.FuturesKey.MARKET_SELECT_HEADER, MapsKt__MapsKt.emptyMap());
    }

    public final void clearTestNetHeaderValue() {
        GTCustomHeaderHelper.addCustomHeaderString(BizBaseConstants.FuturesKey.MARKET_SELECT_HEADER, MapsKt__MapsKt.emptyMap());
    }
}