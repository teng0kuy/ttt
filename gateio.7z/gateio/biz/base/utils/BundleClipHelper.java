package com.gateio.biz.base.utils;

import android.os.Bundle;
import android.os.Parcel;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: BundleClipHelper.kt */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u0000 \u00112\u00020\u0001:\u0001\u0011B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0001H\u0002J\u0006\u0010\u000b\u001a\u00020\fJ\u0010\u0010\r\u001a\u00020\f2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fJ\u0010\u0010\u0010\u001a\u00020\f2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0012"}, d2 = {"Lcom/gateio/biz/base/utils/BundleClipHelper;", "", "()V", "fragmentLifecycleCallbacks", "Landroidx/fragment/app/FragmentManager$FragmentLifecycleCallbacks;", "pendingClearBundleList", "", "Landroid/os/Bundle;", "calculateObjectSize", "", "obj", "clipBundle", "", "register", "activity", "Landroidx/fragment/app/FragmentActivity;", "unRegister", "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nBundleClipHelper.kt\nKotlin\n*S Kotlin\n*F\n+ 1 BundleClipHelper.kt\ncom/gateio/biz/base/utils/BundleClipHelper\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,90:1\n1855#2,2:91\n*S KotlinDebug\n*F\n+ 1 BundleClipHelper.kt\ncom/gateio/biz/base/utils/BundleClipHelper\n*L\n82#1:91,2\n*E\n"})
/* loaded from: classes5.dex */
public final class BundleClipHelper {

    @NotNull
    private static final String BUNDLE_KEY_FRAGMENTS = "android:support:fragments";

    @NotNull
    private static final String BUNDLE_KEY_VIEWS = "android:view_state";

    @NotNull
    private static final String TAG = "BundleClipHelper";

    @NotNull
    private final List<Bundle> pendingClearBundleList = new ArrayList();

    @NotNull
    private final FragmentManager.FragmentLifecycleCallbacks fragmentLifecycleCallbacks = new FragmentManager.FragmentLifecycleCallbacks() { // from class: com.gateio.biz.base.utils.BundleClipHelper$fragmentLifecycleCallbacks$1
        @Override // androidx.fragment.app.FragmentManager.FragmentLifecycleCallbacks
        public void onFragmentSaveInstanceState(@NotNull FragmentManager fm, @NotNull Fragment f10, @NotNull Bundle outState) {
            super.onFragmentSaveInstanceState(fm, f10, outState);
            this.this$0.pendingClearBundleList.add(outState);
        }
    };

    public final void clipBundle() {
        if (calculateObjectSize(this.pendingClearBundleList) >= 512000 && (!this.pendingClearBundleList.isEmpty())) {
            for (Bundle bundle : this.pendingClearBundleList) {
                bundle.remove(BUNDLE_KEY_FRAGMENTS);
                bundle.remove(BUNDLE_KEY_VIEWS);
            }
            this.pendingClearBundleList.clear();
        }
    }

    public final void register(@Nullable FragmentActivity activity) {
        FragmentManager supportFragmentManager;
        if (activity == null || (supportFragmentManager = activity.getSupportFragmentManager()) == null) {
            return;
        }
        supportFragmentManager.registerFragmentLifecycleCallbacks(this.fragmentLifecycleCallbacks, true);
    }

    public final void unRegister(@Nullable FragmentActivity activity) {
        FragmentManager supportFragmentManager;
        if (activity == null || (supportFragmentManager = activity.getSupportFragmentManager()) == null) {
            return;
        }
        supportFragmentManager.unregisterFragmentLifecycleCallbacks(this.fragmentLifecycleCallbacks);
    }

    private final int calculateObjectSize(Object obj) {
        Parcel parcelObtain = Parcel.obtain();
        parcelObtain.writeValue(obj);
        int iDataSize = parcelObtain.dataSize();
        parcelObtain.recycle();
        return iDataSize;
    }
}