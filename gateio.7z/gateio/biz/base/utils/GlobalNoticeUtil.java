package com.gateio.biz.base.utils;

import android.content.Context;
import com.alipay.zoloz.toyger.ToygerService;
import com.gateio.biz.base.R;
import com.gateio.biz.base.http.BizBaseHttpMethod;
import com.gateio.biz.base.notice.GlobalNoticeType;
import com.gateio.biz.base.router.AppApiProvider;
import com.gateio.biz.base.router.RouterConst;
import com.gateio.common.entity.GlobalNoticeEntity;
import com.gateio.common.kotlin.ext.UtilsAnyKt;
import com.gateio.common.kotlin.ext.ViewKt;
import com.gateio.common.tool.BaseGlobalManager;
import com.gateio.lib.router.GTRouter;
import com.gateio.lib.storage.GTStorage;
import com.gateio.lib.storage.mmvk.GTStoreKVDomain;
import com.gateio.lib.uikit.alert.GTAlertV5;
import com.gateio.rxjava.CustomObserver;
import com.gateio.rxjava.SchedulerConfig;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GlobalNoticeUtil.kt */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\t\u001a\u00020\nJ$\u0010\u000b\u001a\u00020\n2\b\u0010\f\u001a\u0004\u0018\u00010\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011J$\u0010\u0012\u001a\u00020\n2\b\u0010\f\u001a\u0004\u0018\u00010\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011J\b\u0010\u0013\u001a\u00020\nH\u0002J$\u0010\u0013\u001a\u00020\n2\b\u0010\f\u001a\u0004\u0018\u00010\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u001c\u0010\u0005\u001a\u0010\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0014"}, d2 = {"Lcom/gateio/biz/base/utils/GlobalNoticeUtil;", "", "()V", "allKey", "", "caches", "", "Lcom/gateio/common/entity/GlobalNoticeEntity;", ToygerService.KEY_RES_9_KEY, "getGlobalNotice", "", "showGlobalNotice", "context", "Landroid/content/Context;", "gtAlert", "Lcom/gateio/lib/uikit/alert/GTAlertV5;", "type", "Lcom/gateio/biz/base/notice/GlobalNoticeType;", "showGlobalNoticeV5", "updateGlobalNotice", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nGlobalNoticeUtil.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GlobalNoticeUtil.kt\ncom/gateio/biz/base/utils/GlobalNoticeUtil\n+ 2 GTStorage.kt\ncom/gateio/lib/storage/GTStorage\n*L\n1#1,194:1\n384#2,10:195\n384#2,10:205\n384#2,10:215\n*S KotlinDebug\n*F\n+ 1 GlobalNoticeUtil.kt\ncom/gateio/biz/base/utils/GlobalNoticeUtil\n*L\n59#1:195,10\n115#1:205,10\n155#1:215,10\n*E\n"})
/* loaded from: classes5.dex */
public final class GlobalNoticeUtil {

    @NotNull
    public static final GlobalNoticeUtil INSTANCE = new GlobalNoticeUtil();

    @NotNull
    private static final String allKey = "global_notice_view_all_";

    @Nullable
    private static Map<String, ? extends GlobalNoticeEntity> caches = null;

    @NotNull
    private static final String key = "global_notice_view_";

    private GlobalNoticeUtil() {
    }

    private final void updateGlobalNotice() {
        if (Intrinsics.areEqual(AppApiProvider.getDefaultGradleApi().getAppType(), "11")) {
            return;
        }
        BizBaseHttpMethod.getInstance().getFullsiteBulletin().subscribe(new CustomObserver<Map<String, ? extends GlobalNoticeEntity>>() { // from class: com.gateio.biz.base.utils.GlobalNoticeUtil.updateGlobalNotice.1
            @Override // com.gateio.rxjava.CustomObserver, io.reactivex.rxjava3.core.z, org.reactivestreams.Subscriber
            public void onNext(@Nullable Map<String, ? extends GlobalNoticeEntity> item) {
                if (item != null) {
                    String languageInPost = BaseGlobalManager.getLocale().getLanguageInPost();
                    GlobalNoticeUtil.caches = item;
                    GTStorage.saveKV$default(GlobalNoticeUtil.allKey + languageInPost, item, null, 4, null);
                }
            }
        });
    }

    public final void getGlobalNotice() {
        try {
            Result.Companion companion = Result.INSTANCE;
            if (UtilsAnyKt.isNull(caches)) {
                String languageInPost = BaseGlobalManager.getLocale().getLanguageInPost();
                GTStorage gTStorage = GTStorage.INSTANCE;
                String str = allKey + languageInPost;
                GTStoreKVDomain gTStoreKVDomain = GTStoreKVDomain.Default;
                String str2 = (String) (gTStorage.isPrimitiveOrWrapper(String.class) ? GTStorage.queryKV(str, (Class<String>) String.class, "", gTStoreKVDomain) : GTStorage.queryKV(str, new TypeToken<String>() { // from class: com.gateio.biz.base.utils.GlobalNoticeUtil$getGlobalNotice$lambda$11$$inlined$queryKV$default$1
                }.getType(), "", gTStoreKVDomain));
                if (str2 != null) {
                    caches = (Map) new Gson().fromJson(str2, new TypeToken<Map<String, ? extends String>>() { // from class: com.gateio.biz.base.utils.GlobalNoticeUtil$getGlobalNotice$1$1$1
                    }.getType());
                }
            }
            Result.m4830constructorimpl(Unit.INSTANCE);
        } catch (Throwable th) {
            Result.Companion companion2 = Result.INSTANCE;
            Result.m4830constructorimpl(ResultKt.createFailure(th));
        }
        updateGlobalNotice();
    }

    public final void showGlobalNotice(@Nullable final Context context, @Nullable final GTAlertV5 gtAlert, @Nullable final GlobalNoticeType type) {
        final GlobalNoticeEntity globalNoticeEntity;
        Object objQueryKV;
        String noticeType;
        if (UtilsAnyKt.isNull(type)) {
            if (gtAlert != null) {
                ViewKt.setVisibleOrGone(gtAlert, false);
                return;
            }
            return;
        }
        Map<String, ? extends GlobalNoticeEntity> map = caches;
        if (map != null) {
            if (type != null) {
                noticeType = type.getNoticeType();
            } else {
                noticeType = null;
            }
            globalNoticeEntity = map.get(noticeType);
        } else {
            globalNoticeEntity = null;
        }
        if (gtAlert != null) {
            if (UtilsAnyKt.isNull(globalNoticeEntity)) {
                ViewKt.setVisibleOrGone(gtAlert, false);
                return;
            }
            if (globalNoticeEntity != null) {
                if (globalNoticeEntity.isNoticeExpired()) {
                    ViewKt.setVisibleOrGone(gtAlert, false);
                    return;
                }
                GTStorage gTStorage = GTStorage.INSTANCE;
                String str = key + type;
                GlobalNoticeEntity globalNoticeEntity2 = new GlobalNoticeEntity();
                GTStoreKVDomain gTStoreKVDomain = GTStoreKVDomain.Default;
                if (gTStorage.isPrimitiveOrWrapper(GlobalNoticeEntity.class)) {
                    objQueryKV = GTStorage.queryKV(str, (Class<GlobalNoticeEntity>) GlobalNoticeEntity.class, globalNoticeEntity2, gTStoreKVDomain);
                } else {
                    objQueryKV = GTStorage.queryKV(str, new TypeToken<GlobalNoticeEntity>() { // from class: com.gateio.biz.base.utils.GlobalNoticeUtil$showGlobalNotice$lambda$4$lambda$3$$inlined$queryKV$default$1
                    }.getType(), globalNoticeEntity2, gTStoreKVDomain);
                }
                GlobalNoticeEntity globalNoticeEntity3 = (GlobalNoticeEntity) objQueryKV;
                if (globalNoticeEntity3 != null && Intrinsics.areEqual(globalNoticeEntity3.getContent_id(), globalNoticeEntity.getContent_id()) && globalNoticeEntity3.isIs_delete()) {
                    ViewKt.setVisibleOrGone(gtAlert, false);
                    return;
                } else {
                    String content = globalNoticeEntity.getContent();
                    if (content != null) {
                        GTAlertV5.setAlertText$default(gtAlert, content, false, 2, null);
                    }
                }
            }
            ViewKt.setVisibleOrGone(gtAlert, true);
            gtAlert.setAutoScroll();
            gtAlert.setOnAlertClickListener(new GTAlertV5.OnAlertClickListener() { // from class: com.gateio.biz.base.utils.GlobalNoticeUtil$showGlobalNotice$1$2
                @Override // com.gateio.lib.uikit.alert.GTAlertV5.OnAlertClickListener
                public void onIconClick() {
                    ViewKt.setVisibleOrGone(gtAlert, false);
                    GlobalNoticeEntity globalNoticeEntity4 = globalNoticeEntity;
                    if (globalNoticeEntity4 != null) {
                        GlobalNoticeType globalNoticeType = type;
                        globalNoticeEntity4.setIs_delete(true);
                        GTStorage.saveKV$default("global_notice_view_" + globalNoticeType, globalNoticeEntity4, null, 4, null);
                    }
                }

                @Override // com.gateio.lib.uikit.alert.GTAlertV5.OnAlertClickListener
                public void onTextClick() {
                    Context context2;
                    GlobalNoticeEntity globalNoticeEntity4 = globalNoticeEntity;
                    if (globalNoticeEntity4 == null || (context2 = context) == null) {
                        return;
                    }
                    BizBaseHttpMethod bizBaseHttpMethod = BizBaseHttpMethod.getInstance();
                    String link = globalNoticeEntity4.getLink();
                    if (link == null) {
                        link = "";
                    }
                    String wholeUrl = bizBaseHttpMethod.getWholeUrl(link);
                    String title = globalNoticeEntity4.getTitle();
                    if (title == null) {
                        title = context2.getString(R.string.information_news);
                    }
                    GTRouter.navigation$default(context2, RouterConst.App.APP_WEB, MapsKt__MapsKt.mapOf(TuplesKt.to("title", title), TuplesKt.to("url", wholeUrl)), null, null, 24, null);
                }
            });
        }
    }

    public final void showGlobalNoticeV5(@Nullable final Context context, @Nullable final GTAlertV5 gtAlert, @Nullable final GlobalNoticeType type) {
        final GlobalNoticeEntity globalNoticeEntity;
        Object objQueryKV;
        String noticeType;
        if (UtilsAnyKt.isNull(type)) {
            if (gtAlert != null) {
                ViewKt.setVisibleOrGone(gtAlert, false);
                return;
            }
            return;
        }
        Map<String, ? extends GlobalNoticeEntity> map = caches;
        if (map != null) {
            if (type != null) {
                noticeType = type.getNoticeType();
            } else {
                noticeType = null;
            }
            globalNoticeEntity = map.get(noticeType);
        } else {
            globalNoticeEntity = null;
        }
        if (gtAlert != null) {
            if (UtilsAnyKt.isNull(globalNoticeEntity)) {
                ViewKt.setVisibleOrGone(gtAlert, false);
                return;
            }
            if (globalNoticeEntity != null) {
                if (globalNoticeEntity.isNoticeExpired()) {
                    ViewKt.setVisibleOrGone(gtAlert, false);
                    return;
                }
                GTStorage gTStorage = GTStorage.INSTANCE;
                String str = key + type;
                GlobalNoticeEntity globalNoticeEntity2 = new GlobalNoticeEntity();
                GTStoreKVDomain gTStoreKVDomain = GTStoreKVDomain.Default;
                if (gTStorage.isPrimitiveOrWrapper(GlobalNoticeEntity.class)) {
                    objQueryKV = GTStorage.queryKV(str, (Class<GlobalNoticeEntity>) GlobalNoticeEntity.class, globalNoticeEntity2, gTStoreKVDomain);
                } else {
                    objQueryKV = GTStorage.queryKV(str, new TypeToken<GlobalNoticeEntity>() { // from class: com.gateio.biz.base.utils.GlobalNoticeUtil$showGlobalNoticeV5$lambda$9$lambda$8$$inlined$queryKV$default$1
                    }.getType(), globalNoticeEntity2, gTStoreKVDomain);
                }
                GlobalNoticeEntity globalNoticeEntity3 = (GlobalNoticeEntity) objQueryKV;
                if (globalNoticeEntity3 != null && Intrinsics.areEqual(globalNoticeEntity3.getContent_id(), globalNoticeEntity.getContent_id()) && globalNoticeEntity3.isIs_delete()) {
                    ViewKt.setVisibleOrGone(gtAlert, false);
                    return;
                } else {
                    String content = globalNoticeEntity.getContent();
                    if (content != null) {
                        GTAlertV5.setAlertText$default(gtAlert, content, false, 2, null);
                    }
                }
            }
            ViewKt.setVisibleOrGone(gtAlert, true);
            gtAlert.setAutoScroll();
            gtAlert.setOnAlertClickListener(new GTAlertV5.OnAlertClickListener() { // from class: com.gateio.biz.base.utils.GlobalNoticeUtil$showGlobalNoticeV5$1$2
                @Override // com.gateio.lib.uikit.alert.GTAlertV5.OnAlertClickListener
                public void onIconClick() {
                    ViewKt.setVisibleOrGone(gtAlert, false);
                    GlobalNoticeEntity globalNoticeEntity4 = globalNoticeEntity;
                    if (globalNoticeEntity4 != null) {
                        GlobalNoticeType globalNoticeType = type;
                        globalNoticeEntity4.setIs_delete(true);
                        GTStorage.saveKV$default("global_notice_view_" + globalNoticeType, globalNoticeEntity4, null, 4, null);
                    }
                }

                @Override // com.gateio.lib.uikit.alert.GTAlertV5.OnAlertClickListener
                public void onTextClick() {
                    Context context2;
                    GlobalNoticeEntity globalNoticeEntity4 = globalNoticeEntity;
                    if (globalNoticeEntity4 == null || (context2 = context) == null) {
                        return;
                    }
                    BizBaseHttpMethod bizBaseHttpMethod = BizBaseHttpMethod.getInstance();
                    String link = globalNoticeEntity4.getLink();
                    if (link == null) {
                        link = "";
                    }
                    String wholeUrl = bizBaseHttpMethod.getWholeUrl(link);
                    String title = globalNoticeEntity4.getTitle();
                    if (title == null) {
                        title = context2.getString(R.string.information_news);
                    }
                    GTRouter.navigation$default(context2, RouterConst.App.APP_WEB, MapsKt__MapsKt.mapOf(TuplesKt.to("title", title), TuplesKt.to("url", wholeUrl)), null, null, 24, null);
                }
            });
        }
    }

    public final void updateGlobalNotice(@Nullable final Context context, @Nullable final GTAlertV5 gtAlert, @Nullable final GlobalNoticeType type) {
        if (Intrinsics.areEqual(AppApiProvider.getDefaultGradleApi().getAppType(), "11")) {
            return;
        }
        BizBaseHttpMethod.getInstance().getFullsiteBulletin().compose(SchedulerConfig.io_main()).subscribe(new CustomObserver<Map<String, ? extends GlobalNoticeEntity>>() { // from class: com.gateio.biz.base.utils.GlobalNoticeUtil.updateGlobalNotice.2
            @Override // com.gateio.rxjava.CustomObserver, io.reactivex.rxjava3.core.z, org.reactivestreams.Subscriber
            public void onNext(@Nullable Map<String, ? extends GlobalNoticeEntity> item) {
                if (item != null) {
                    String languageInPost = BaseGlobalManager.getLocale().getLanguageInPost();
                    GlobalNoticeUtil.caches = item;
                    GTStorage.saveKV$default(GlobalNoticeUtil.allKey + languageInPost, item, null, 4, null);
                }
                GlobalNoticeUtil.INSTANCE.showGlobalNotice(context, gtAlert, type);
            }
        });
    }
}