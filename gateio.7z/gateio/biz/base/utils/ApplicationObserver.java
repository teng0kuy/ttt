package com.gateio.biz.base.utils;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import com.gateio.lib.logger.GTLog;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* compiled from: ApplicationObserver.kt */
@Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0016¨\u0006\t"}, d2 = {"Lcom/gateio/biz/base/utils/ApplicationObserver;", "Landroidx/lifecycle/LifecycleEventObserver;", "()V", "onStateChanged", "", "source", "Landroidx/lifecycle/LifecycleOwner;", "event", "Landroidx/lifecycle/Lifecycle$Event;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class ApplicationObserver implements LifecycleEventObserver {

    /* compiled from: ApplicationObserver.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[Lifecycle.Event.values().length];
            try {
                iArr[Lifecycle.Event.ON_START.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[Lifecycle.Event.ON_RESUME.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[Lifecycle.Event.ON_PAUSE.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[Lifecycle.Event.ON_STOP.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    @Override // androidx.lifecycle.LifecycleEventObserver
    public void onStateChanged(@NotNull LifecycleOwner source, @NotNull Lifecycle.Event event) {
        int i10 = WhenMappings.$EnumSwitchMapping$0[event.ordinal()];
        if (i10 == 1) {
            GTLog.i$default("前后台切换状态监听 ON_START", null, null, null, 14, null);
            return;
        }
        if (i10 == 2) {
            LiveDataBus.INSTANCE.getInstance().getAppFontAndBackSwitch().postValue(Boolean.TRUE);
            GTLog.i$default("前后台切换状态监听 ON_RESUME", null, null, null, 14, null);
        } else if (i10 == 3) {
            GTLog.i$default("前后台切换状态监听 ON_PAUSE", null, null, null, 14, null);
        } else if (i10 != 4) {
            GTLog.i$default(String.valueOf(event), null, null, null, 14, null);
        } else {
            LiveDataBus.INSTANCE.getInstance().getAppFontAndBackSwitch().postValue(Boolean.FALSE);
            GTLog.i$default("前后台切换状态监听 ON_STOP", null, null, null, 14, null);
        }
    }
}