package com.gateio.biz.base.utils;

import com.gateio.biz.home.utils.HomeConst;
import com.gateio.biz.market.util.MarketConst;
import com.gateio.gateio.activity.HomeTabHelper;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: HomeFunctionEntry.kt */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\t\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004J\u0010\u0010\u0006\u001a\u00020\u00042\b\u0010\u0007\u001a\u0004\u0018\u00010\u0004J\u0010\u0010\b\u001a\u00020\u00042\b\u0010\t\u001a\u0004\u0018\u00010\u0004J\u0010\u0010\n\u001a\u00020\u00042\b\u0010\u000b\u001a\u0004\u0018\u00010\u0004J\u0010\u0010\f\u001a\u00020\u00042\b\u0010\t\u001a\u0004\u0018\u00010\u0004¨\u0006\r"}, d2 = {"Lcom/gateio/biz/base/utils/HomeFunctionEntry;", "", "()V", "getHomeBottomTabEntry", "", "tag", "getHomeExchangeEntry", "buttonName", "getHomeMainFunctionEntry", "code", "getHomePorcelainEntry", "categoryCode", "getHomeSidebarEntry", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class HomeFunctionEntry {

    @NotNull
    public static final HomeFunctionEntry INSTANCE = new HomeFunctionEntry();

    private HomeFunctionEntry() {
    }

    @NotNull
    public final String getHomeBottomTabEntry(@Nullable String tag) {
        return (tag != null && Intrinsics.areEqual(tag, HomeTabHelper.TAG_BOTS)) ? "homepage_bottom_tab_menu_bots" : "";
    }

    @NotNull
    public final String getHomeExchangeEntry(@Nullable String buttonName) {
        return (buttonName != null && Intrinsics.areEqual(buttonName, MarketConst.searchBotsType)) ? "homepage_bottom_tab_trade_bots" : "";
    }

    @NotNull
    public final String getHomeMainFunctionEntry(@Nullable String code) {
        return (code != null && Intrinsics.areEqual(code, "strategy")) ? "homepage_mainfunction_bots" : "";
    }

    @NotNull
    public final String getHomePorcelainEntry(@Nullable String categoryCode) {
        return (categoryCode != null && Intrinsics.areEqual(categoryCode, HomeConst.HOME_PORCELAIN_CATEGORY_STRATEGY_DETAIL)) ? "homepage_banner_bots" : "";
    }

    @NotNull
    public final String getHomeSidebarEntry(@Nullable String code) {
        return (code != null && Intrinsics.areEqual(code, "strategy")) ? "homepage_sidebar_bots" : "";
    }
}