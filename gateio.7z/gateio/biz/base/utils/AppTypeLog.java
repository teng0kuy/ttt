package com.gateio.biz.base.utils;

import com.alipay.alipaysecuritysdk.common.legacy.model.DynamicModel;
import com.ap.zoloz.hummer.h5.ZolozEkycH5Handler;
import com.gate.subconfig.data.GTDynamicConfig;
import com.gateio.lib.datafinder.GTDataFinder;
import com.gateio.lib.logger.GTLog;
import com.gateio.lib.thread.coroutine.GTGlobalIOCoroutine;
import com.gateio.lib.utils.json.GTJSONUtils;
import java.util.Map;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.MapsKt__MapsJVMKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: AppTypeLog.kt */
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J*\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00062\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\tJ*\u0010\u000b\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00062\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\tJ*\u0010\f\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00062\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\tJ\u0010\u0010\r\u001a\u00020\u00042\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fJ\u000e\u0010\r\u001a\u00020\u00042\u0006\u0010\u000e\u001a\u00020\u0006J\u0016\u0010\u0010\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u0006J\u0010\u0010\u0012\u001a\u00020\u00042\u0006\u0010\u0013\u001a\u00020\u0006H\u0002J*\u0010\u0014\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00062\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\t¨\u0006\u0015"}, d2 = {"Lcom/gateio/biz/base/utils/AppTypeLog;", "", "()V", "d", "", "tag", "", "msg", "isRecovery", "", "isEvent", DynamicModel.KEY_ABBR_DYNAMIC_EXPIRE, "i", "logConfig", "config", "Lcom/gate/subconfig/data/GTDynamicConfig;", ZolozEkycH5Handler.HUMMER_FOUNDATION_LOG_MESS, "message", "postConfigLog", "configStr", "w", "biz_account_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class AppTypeLog {

    @NotNull
    public static final AppTypeLog INSTANCE = new AppTypeLog();

    /* compiled from: AppTypeLog.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.base.utils.AppTypeLog$logConfig$1", f = "AppTypeLog.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.base.utils.AppTypeLog$logConfig$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ GTDynamicConfig $config;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(GTDynamicConfig gTDynamicConfig, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$config = gTDynamicConfig;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            return new AnonymousClass1(this.$config, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull CoroutineScope coroutineScope, @Nullable Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label == 0) {
                ResultKt.throwOnFailure(obj);
                String jsonString = GTJSONUtils.toJsonString(this.$config);
                if (jsonString == null) {
                    jsonString = "null";
                }
                AppTypeLog.INSTANCE.postConfigLog(jsonString);
                return Unit.INSTANCE;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }

    /* compiled from: AppTypeLog.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.base.utils.AppTypeLog$logConfig$2", f = "AppTypeLog.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.base.utils.AppTypeLog$logConfig$2, reason: invalid class name */
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $config;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass2(String str, Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
            this.$config = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            return new AnonymousClass2(this.$config, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull CoroutineScope coroutineScope, @Nullable Continuation<? super Unit> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label == 0) {
                ResultKt.throwOnFailure(obj);
                AppTypeLog.INSTANCE.postConfigLog(this.$config);
                return Unit.INSTANCE;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }

    /* compiled from: AppTypeLog.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.base.utils.AppTypeLog$logMessage$1", f = "AppTypeLog.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.base.utils.AppTypeLog$logMessage$1, reason: invalid class name and case insensitive filesystem */
    static final class C18681 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $message;
        final /* synthetic */ String $tag;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C18681(String str, String str2, Continuation<? super C18681> continuation) {
            super(2, continuation);
            this.$tag = str;
            this.$message = str2;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            return new C18681(this.$tag, this.$message, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull CoroutineScope coroutineScope, @Nullable Continuation<? super Unit> continuation) {
            return ((C18681) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label == 0) {
                ResultKt.throwOnFailure(obj);
                GTDataFinder.postBizAnalyseEvent("gt_compliance_event", (Map<String, ? extends Object>) MapsKt__MapsKt.mapOf(TuplesKt.to("tag", this.$tag), TuplesKt.to("message", this.$message)));
                return Unit.INSTANCE;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }

    private AppTypeLog() {
    }

    public final void i(@NotNull String tag, @NotNull String msg, boolean isRecovery, boolean isEvent) {
        GTLog.i$default(tag, msg, null, null, 12, null);
        if (isEvent) {
            logMessage(tag, msg);
        }
    }

    public final void logConfig(@Nullable GTDynamicConfig config) {
        BuildersKt__Builders_commonKt.launch$default(GTGlobalIOCoroutine.INSTANCE, null, null, new AnonymousClass1(config, null), 3, null);
    }

    public static /* synthetic */ void d$default(AppTypeLog appTypeLog, String str, String str2, boolean z10, boolean z11, int i10, Object obj) {
        if ((i10 & 4) != 0) {
            z10 = true;
        }
        if ((i10 & 8) != 0) {
            z11 = false;
        }
        appTypeLog.d(str, str2, z10, z11);
    }

    public static /* synthetic */ void e$default(AppTypeLog appTypeLog, String str, String str2, boolean z10, boolean z11, int i10, Object obj) {
        if ((i10 & 4) != 0) {
            z10 = true;
        }
        if ((i10 & 8) != 0) {
            z11 = false;
        }
        appTypeLog.e(str, str2, z10, z11);
    }

    public static /* synthetic */ void i$default(AppTypeLog appTypeLog, String str, String str2, boolean z10, boolean z11, int i10, Object obj) {
        if ((i10 & 4) != 0) {
            z10 = true;
        }
        if ((i10 & 8) != 0) {
            z11 = false;
        }
        appTypeLog.i(str, str2, z10, z11);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void postConfigLog(String configStr) {
        GTDataFinder.postBizAnalyseEvent("gt_compliance_event", (Map<String, ? extends Object>) MapsKt__MapsJVMKt.mapOf(TuplesKt.to("config", configStr)));
    }

    public static /* synthetic */ void w$default(AppTypeLog appTypeLog, String str, String str2, boolean z10, boolean z11, int i10, Object obj) {
        if ((i10 & 4) != 0) {
            z10 = true;
        }
        if ((i10 & 8) != 0) {
            z11 = false;
        }
        appTypeLog.w(str, str2, z10, z11);
    }

    public final void d(@NotNull String tag, @NotNull String msg, boolean isRecovery, boolean isEvent) {
        if (isEvent) {
            logMessage(tag, msg);
        }
    }

    public final void logConfig(@NotNull String config) {
        BuildersKt__Builders_commonKt.launch$default(GTGlobalIOCoroutine.INSTANCE, null, null, new AnonymousClass2(config, null), 3, null);
    }

    public final void logMessage(@NotNull String tag, @NotNull String message) {
        BuildersKt__Builders_commonKt.launch$default(GTGlobalIOCoroutine.INSTANCE, null, null, new C18681(tag, message, null), 3, null);
    }

    public final void e(@NotNull String tag, @NotNull String msg, boolean isRecovery, boolean isEvent) {
        GTLog.e(tag, msg, isRecovery);
        if (isEvent) {
            logMessage(tag, msg);
        }
    }

    public final void w(@NotNull String tag, @NotNull String msg, boolean isRecovery, boolean isEvent) {
        GTLog.w(tag, msg, isRecovery);
        if (isEvent) {
            logMessage(tag, msg);
        }
    }
}