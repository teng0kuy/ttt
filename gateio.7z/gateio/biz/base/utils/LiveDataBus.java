package com.gateio.biz.base.utils;

import com.gateio.biz.base.model.memebox.MemeBoxJumpParams;
import com.gateio.lib.uikit.tabbar.GTTabBarBottomNavigatorV5;
import com.kunminx.architecture.ui.callback.UnPeekLiveData;
import kotlin.Lazy;
import kotlin.LazyKt__LazyJVMKt;
import kotlin.LazyThreadSafetyMode;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;

/* compiled from: LiveDataBus.kt */
@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\u0018\u0000 \u00182\u00020\u0001:\u0001\u0018B\u0005¢\u0006\u0002\u0010\u0002R\u0017\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u001b\u0010\b\u001a\f\u0012\b\u0012\u00060\nR\u00020\u000b0\t¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0017\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00050\t¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\rR\u0019\u0010\u0010\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00110\t¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\rR\u0017\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00140\t¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\rR\u0017\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00140\t¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\r¨\u0006\u0019"}, d2 = {"Lcom/gateio/biz/base/utils/LiveDataBus;", "", "()V", "appFontAndBackSwitch", "Lcom/gateio/biz/base/utils/UnPeekDistinctLiveData;", "", "getAppFontAndBackSwitch", "()Lcom/gateio/biz/base/utils/UnPeekDistinctLiveData;", "homeTradeGuided", "Lcom/kunminx/architecture/ui/callback/UnPeekLiveData;", "Lcom/gateio/lib/uikit/tabbar/GTTabBarBottomNavigatorV5$Item;", "Lcom/gateio/lib/uikit/tabbar/GTTabBarBottomNavigatorV5;", "getHomeTradeGuided", "()Lcom/kunminx/architecture/ui/callback/UnPeekLiveData;", "klineUpdatePositionMode", "getKlineUpdatePositionMode", "memeBoxMarketChanged", "Lcom/gateio/biz/base/model/memebox/MemeBoxJumpParams;", "getMemeBoxMarketChanged", "pilotMarketChanged", "", "getPilotMarketChanged", "quickOrderPriceChanged", "getQuickOrderPriceChanged", "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class LiveDataBus {

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @NotNull
    private static final Lazy<LiveDataBus> instance$delegate = LazyKt__LazyJVMKt.lazy(LazyThreadSafetyMode.SYNCHRONIZED, (Function0) new Function0<LiveDataBus>() { // from class: com.gateio.biz.base.utils.LiveDataBus$Companion$instance$2
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // kotlin.jvm.functions.Function0
        @NotNull
        public final LiveDataBus invoke() {
            return new LiveDataBus();
        }
    });

    @NotNull
    private final UnPeekDistinctLiveData<Boolean> appFontAndBackSwitch = new UnPeekDistinctLiveData<>();

    @NotNull
    private final UnPeekLiveData<GTTabBarBottomNavigatorV5.Item> homeTradeGuided = new UnPeekLiveData<>();

    @NotNull
    private final UnPeekLiveData<String> quickOrderPriceChanged = new UnPeekLiveData<>();

    @NotNull
    private final UnPeekLiveData<Boolean> klineUpdatePositionMode = new UnPeekLiveData<>();

    @NotNull
    private final UnPeekLiveData<String> pilotMarketChanged = new UnPeekLiveData<>();

    @NotNull
    private final UnPeekLiveData<MemeBoxJumpParams> memeBoxMarketChanged = new UnPeekLiveData<>();

    /* compiled from: LiveDataBus.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u001b\u0010\u0003\u001a\u00020\u00048FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\u0007\u0010\b\u001a\u0004\b\u0005\u0010\u0006¨\u0006\t"}, d2 = {"Lcom/gateio/biz/base/utils/LiveDataBus$Companion;", "", "()V", "instance", "Lcom/gateio/biz/base/utils/LiveDataBus;", "getInstance", "()Lcom/gateio/biz/base/utils/LiveDataBus;", "instance$delegate", "Lkotlin/Lazy;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final LiveDataBus getInstance() {
            return (LiveDataBus) LiveDataBus.instance$delegate.getValue();
        }
    }

    @NotNull
    public final UnPeekDistinctLiveData<Boolean> getAppFontAndBackSwitch() {
        return this.appFontAndBackSwitch;
    }

    @NotNull
    public final UnPeekLiveData<GTTabBarBottomNavigatorV5.Item> getHomeTradeGuided() {
        return this.homeTradeGuided;
    }

    @NotNull
    public final UnPeekLiveData<Boolean> getKlineUpdatePositionMode() {
        return this.klineUpdatePositionMode;
    }

    @NotNull
    public final UnPeekLiveData<MemeBoxJumpParams> getMemeBoxMarketChanged() {
        return this.memeBoxMarketChanged;
    }

    @NotNull
    public final UnPeekLiveData<String> getPilotMarketChanged() {
        return this.pilotMarketChanged;
    }

    @NotNull
    public final UnPeekLiveData<String> getQuickOrderPriceChanged() {
        return this.quickOrderPriceChanged;
    }
}