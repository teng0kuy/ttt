package com.gateio.biz.base.utils;

import com.alipay.zoloz.toyger.ToygerService;
import com.gateio.common.Constants;
import com.gateio.common.tool.GlobalUtils;
import com.gateio.lib.storage.GTStorage;
import com.gateio.lib.storage.mmvk.GTStoreKVDomain;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.CollectionsKt___CollectionsKt;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.StringsKt__StringsKt;
import org.apache.commons.lang3.time.DateUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: ConstUtil.kt */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\r\n\u0002\u0010\b\n\u0002\b\"\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0010 \n\u0000\n\u0002\u0010\t\n\u0002\b\b\n\u0002\u0010\u0002\n\u0002\b\u0006\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0018\u00109\u001a\u00020\u00042\u0006\u0010:\u001a\u00020\u00042\b\u0010;\u001a\u0004\u0018\u00010\u0004J\u000e\u0010<\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010=J\b\u0010>\u001a\u00020?H\u0002J\u0006\u0010@\u001a\u000205J\u0006\u0010A\u001a\u000205J\u0006\u0010B\u001a\u000205J\u0006\u0010C\u001a\u000205J \u0010D\u001a\u00020\u00042\f\u0010E\u001a\b\u0012\u0004\u0012\u00020\u00040=2\b\b\u0002\u0010F\u001a\u00020\u0004H\u0002J\u0006\u0010G\u001a\u00020HJ\u0014\u0010I\u001a\u00020H2\f\u0010E\u001a\b\u0012\u0004\u0012\u00020\u00040=J\u000e\u0010J\u001a\u00020H2\u0006\u0010K\u001a\u000205J \u0010L\u001a\b\u0012\u0004\u0012\u00020\u00040=2\u0006\u0010M\u001a\u00020\u00042\b\b\u0002\u0010F\u001a\u00020\u0004H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00100\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00101\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00102\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00103\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u001a\u00104\u001a\u000205X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b4\u00106\"\u0004\b7\u00108¨\u0006N"}, d2 = {"Lcom/gateio/biz/base/utils/ConstUtil;", "", "()V", "AB_VIP_HOME_LINK_BLOCK_SWITCH_ANDROID", "", "ACTION_PAGE", ConstUtil.APP_LAST_OPEN_DATE_KEY, "APP_MODE_EXCHANGE", "APP_MODE_PAY", "APP_MODE_WEB3", "APP_TENCENT_PUSH_LOG_KEY", "ENABLE_FLUTTER_REFERRAL_MAIN_PAGE", "FUNS_GROUP_GUIDE_LIVE", "FUNS_GROUP_GUIDE_USERINFO", ConstUtil.FUTURES_NOVICE_GUIDE, "GATE_PAY_IS_DISABLE_ANIMATION", "GATE_PAY_IS_PAY_MODE", "GET_REAL_IP_INTERVAL_TIME", "", "HOME_CUSTOM_TAB_DATA", ConstUtil.HOME_TRADE_TAB_GUIDE, "LATEST_NEWS_AB_SHOW", "LATEST_NEWS_POSITION", "LATEST_NEWS_POSITION_NOT_MIN", "LAYOUT_MARKET", "LAYOUT_MOMENTS", "LAYOUT_STYLE", "LOGIN_PAGE", "MAIN_EARN_STARTUP_KEY", "MOMENTS_ANNOUNCE_DETAIL_FLUTTER", "MOMENTS_BLOG_DETAIL_FLUTTER", "MOMENTS_BLOG_FLUTTER", "MOMENTS_DRAWER_MIN_STYLE", "MOMENTS_DRAWER_SHOW", "MONITOR_SYSTEM_SCREENSHOT", "NEW_LIVE_PUSH_HINT", "REAL_IP_DATA", "REAL_IP_SAVE_TIME", "REGISTER_PAGE", "SOCIAL_COIN_DRAWER_GUIDE", "STARTUP_AD_CLICK_TO_SKIP", "STARTUP_AD_DISPLAY_DURATION_KEY", "STARTUP_AD_IMAGE_CUSTOMIZE_KEY", "STARTUP_AD_IMAGE_KEY", "STARTUP_AD_LANG_CUSTOMIZE_KEY", "STARTUP_AD_SKIP_DISPLAY_DURATION_KEY", "VIBRATION_FEEDBACK", "WALLET_FUTURES_TAB_MAIN", "WALLET_FUTURES_TAB_MAIN_FLUTTER", "WALLET_FUTURES_TAB_SUB", "WEB3_IS_DISABLE_ANIMATION", "WEB3_IS_WEB3_MODE", "isNightMode", "", "()Z", "setNightMode", "(Z)V", "appendAppTypeKey", ToygerService.KEY_RES_9_KEY, "suffix", "getRealIpData", "", "getRealIpSaveTime", "", "isChangeTheme", "isHomeTradeGuided", "isMainEarnStartup", "isNeedGetRealIp", "listToString", "list", "separator", "putMainEarnStartup", "", "saveGetRealIpTimeAndData", "setHomeTradeGuided", "guided", "stringToList", "string", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nConstUtil.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ConstUtil.kt\ncom/gateio/biz/base/utils/ConstUtil\n+ 2 GTStorage.kt\ncom/gateio/lib/storage/GTStorage\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,203:1\n384#2,10:204\n1#3:214\n1549#4:215\n1620#4,3:216\n*S KotlinDebug\n*F\n+ 1 ConstUtil.kt\ncom/gateio/biz/base/utils/ConstUtil\n*L\n179#1:204,10\n200#1:215\n200#1:216,3\n*E\n"})
/* loaded from: classes5.dex */
public final class ConstUtil {

    @NotNull
    public static final String AB_VIP_HOME_LINK_BLOCK_SWITCH_ANDROID = "vip_home_link_block_switch_android";

    @NotNull
    public static final String ACTION_PAGE = "action_page";

    @NotNull
    public static final String APP_LAST_OPEN_DATE_KEY = "APP_LAST_OPEN_DATE_KEY";

    @NotNull
    public static final String APP_MODE_EXCHANGE = "exchange";

    @NotNull
    public static final String APP_MODE_PAY = "pay";

    @NotNull
    public static final String APP_MODE_WEB3 = "web3";

    @NotNull
    public static final String APP_TENCENT_PUSH_LOG_KEY = "app_tencent_push_log::";

    @NotNull
    public static final String ENABLE_FLUTTER_REFERRAL_MAIN_PAGE = "enable_flutter_referral_main_page";

    @NotNull
    public static final String FUNS_GROUP_GUIDE_LIVE = "funs_group_guide_live";

    @NotNull
    public static final String FUNS_GROUP_GUIDE_USERINFO = "funs_group_guide_userinfo";

    @NotNull
    public static final String FUTURES_NOVICE_GUIDE = "FUTURES_NOVICE_GUIDE";

    @NotNull
    public static final String GATE_PAY_IS_DISABLE_ANIMATION = "is_disable_animation";

    @NotNull
    public static final String GATE_PAY_IS_PAY_MODE = "is_gate_pay_mode";
    private static final int GET_REAL_IP_INTERVAL_TIME = 86400000;

    @NotNull
    public static final String HOME_CUSTOM_TAB_DATA = "home_custom_tab_data";

    @NotNull
    public static final String HOME_TRADE_TAB_GUIDE = "HOME_TRADE_TAB_GUIDE";

    @NotNull
    public static final String LATEST_NEWS_AB_SHOW = "moments_trends_enabled_android";

    @NotNull
    public static final String LATEST_NEWS_POSITION = "social_latest_position";

    @NotNull
    public static final String LATEST_NEWS_POSITION_NOT_MIN = "latest_news_position_not_min";

    @NotNull
    public static final String LAYOUT_MARKET = "layout_old";

    @NotNull
    public static final String LAYOUT_MOMENTS = "layout_new";

    @NotNull
    public static final String LAYOUT_STYLE = "layout_style";

    @NotNull
    public static final String LOGIN_PAGE = "login_page";

    @NotNull
    public static final String MAIN_EARN_STARTUP_KEY = "main_earn_startup_key";

    @NotNull
    public static final String MOMENTS_ANNOUNCE_DETAIL_FLUTTER = "moments_announce_detail_flutter";

    @NotNull
    public static final String MOMENTS_BLOG_DETAIL_FLUTTER = "moments_blog_detail_flutter";

    @NotNull
    public static final String MOMENTS_BLOG_FLUTTER = "moments_blog_flutter";

    @NotNull
    public static final String MOMENTS_DRAWER_MIN_STYLE = "gateio.moments.drawer.minStyle";

    @NotNull
    public static final String MOMENTS_DRAWER_SHOW = "moments_drawer_show";

    @NotNull
    public static final String MONITOR_SYSTEM_SCREENSHOT = "base_share_kit_system_screenshot_android";

    @NotNull
    public static final String NEW_LIVE_PUSH_HINT = "new_live_push_hint";

    @NotNull
    private static final String REAL_IP_DATA = "real_ip_data";

    @NotNull
    private static final String REAL_IP_SAVE_TIME = "real_ip_save_time";

    @NotNull
    public static final String REGISTER_PAGE = "register_page";

    @NotNull
    public static final String SOCIAL_COIN_DRAWER_GUIDE = "social_latest_position";

    @NotNull
    public static final String STARTUP_AD_CLICK_TO_SKIP = "startup_ad_click_to_skip";

    @NotNull
    public static final String STARTUP_AD_DISPLAY_DURATION_KEY = "startup_ad_display_duration_key";

    @NotNull
    public static final String STARTUP_AD_IMAGE_CUSTOMIZE_KEY = "startup_ad_image_customize_key";

    @NotNull
    public static final String STARTUP_AD_IMAGE_KEY = "startup_ad_image_key";

    @NotNull
    public static final String STARTUP_AD_LANG_CUSTOMIZE_KEY = "startup_ad_lang_customize_key";

    @NotNull
    public static final String STARTUP_AD_SKIP_DISPLAY_DURATION_KEY = "startup_ad_skip_display_duration_key";

    @NotNull
    public static final String VIBRATION_FEEDBACK = "side_settings_vibration_feedback";

    @NotNull
    public static final String WALLET_FUTURES_TAB_MAIN = "wallet_futures_tab_main";

    @NotNull
    public static final String WALLET_FUTURES_TAB_MAIN_FLUTTER = "gateio.wallet.futuresTabSelected";

    @NotNull
    public static final String WALLET_FUTURES_TAB_SUB = "wallet_futures_tab_sub";

    @NotNull
    public static final String WEB3_IS_DISABLE_ANIMATION = "is_disable_animation";

    @NotNull
    public static final String WEB3_IS_WEB3_MODE = "is_web3_mode";

    @NotNull
    public static final ConstUtil INSTANCE = new ConstUtil();
    private static boolean isNightMode = GlobalUtils.isNightModeEnabled();

    private ConstUtil() {
    }

    private final String listToString(List<String> list, String separator) {
        return CollectionsKt___CollectionsKt.joinToString$default(list, separator, null, null, 0, null, null, 62, null);
    }

    public final boolean isChangeTheme() {
        if (GTStorage.queryIntKV$default(Constants.PreferKey.PREFER_THEME_MODE, 1, null, 4, null) == 0) {
            z = GlobalUtils.isNightModeEnabled() != isNightMode;
            StringBuilder sb = new StringBuilder();
            sb.append("theme change = ");
            sb.append(z);
            if (z) {
                isNightMode = !isNightMode;
            }
        }
        return z;
    }

    public final boolean isHomeTradeGuided() {
        return GTStorage.queryBooleanKV$default(HOME_TRADE_TAB_GUIDE, false, null, 4, null);
    }

    public final boolean isMainEarnStartup() {
        return GTStorage.queryBooleanKV$default(MAIN_EARN_STARTUP_KEY, false, null, 4, null);
    }

    private final long getRealIpSaveTime() {
        return GTStorage.queryLongKV$default(REAL_IP_SAVE_TIME, 0L, null, 4, null);
    }

    static /* synthetic */ String listToString$default(ConstUtil constUtil, List list, String str, int i10, Object obj) {
        if ((i10 & 2) != 0) {
            str = "|";
        }
        return constUtil.listToString(list, str);
    }

    static /* synthetic */ List stringToList$default(ConstUtil constUtil, String str, String str2, int i10, Object obj) {
        if ((i10 & 2) != 0) {
            str2 = "|";
        }
        return constUtil.stringToList(str, str2);
    }

    @NotNull
    public final String appendAppTypeKey(@NotNull String key, @Nullable String suffix) {
        StringBuilder sb = new StringBuilder();
        sb.append(key);
        sb.append('_');
        if (suffix == null) {
            suffix = "";
        }
        sb.append(suffix);
        return sb.toString();
    }

    @Nullable
    public final List<String> getRealIpData() {
        GTStorage gTStorage = GTStorage.INSTANCE;
        GTStoreKVDomain gTStoreKVDomain = GTStoreKVDomain.Default;
        String str = (String) (gTStorage.isPrimitiveOrWrapper(String.class) ? GTStorage.queryKV(REAL_IP_DATA, (Class<String>) String.class, "", gTStoreKVDomain) : GTStorage.queryKV(REAL_IP_DATA, new TypeToken<String>() { // from class: com.gateio.biz.base.utils.ConstUtil$getRealIpData$$inlined$queryKV$default$1
        }.getType(), "", gTStoreKVDomain));
        if (str != null) {
            return stringToList$default(INSTANCE, str, null, 2, null);
        }
        return null;
    }

    public final boolean isNightMode() {
        return isNightMode;
    }

    public final void putMainEarnStartup() {
        GTStorage.saveKV$default(MAIN_EARN_STARTUP_KEY, Boolean.TRUE, null, 4, null);
    }

    public final void setNightMode(boolean z10) {
        isNightMode = z10;
    }

    private final List<String> stringToList(String string, String separator) {
        List listSplit$default = StringsKt__StringsKt.split$default((CharSequence) string, new String[]{separator}, false, 0, 6, (Object) null);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(listSplit$default, 10));
        Iterator it = listSplit$default.iterator();
        while (it.hasNext()) {
            arrayList.add(StringsKt__StringsKt.trim((CharSequence) it.next()).toString());
        }
        return arrayList;
    }

    public final boolean isNeedGetRealIp() {
        if (System.currentTimeMillis() - getRealIpSaveTime() > DateUtils.MILLIS_PER_DAY) {
            return true;
        }
        return false;
    }

    public final void saveGetRealIpTimeAndData(@NotNull List<String> list) {
        GTStorage.saveKV$default(REAL_IP_SAVE_TIME, Long.valueOf(System.currentTimeMillis()), null, 4, null);
        GTStorage.saveKV$default(REAL_IP_DATA, listToString$default(this, list, null, 2, null), null, 4, null);
    }

    public final void setHomeTradeGuided(boolean guided) {
        GTStorage.saveKV$default(HOME_TRADE_TAB_GUIDE, Boolean.valueOf(guided), null, 4, null);
    }
}