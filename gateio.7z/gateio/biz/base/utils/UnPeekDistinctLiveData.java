package com.gateio.biz.base.utils;

import androidx.exifinterface.media.ExifInterface;
import com.kunminx.architecture.ui.callback.UnPeekLiveData;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: UnPeekDistinctLiveData.kt */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u0002H\u00010\u0002B\u0007\b\u0016¢\u0006\u0002\u0010\u0003B\u000f\b\u0016\u0012\u0006\u0010\u0004\u001a\u00028\u0000¢\u0006\u0002\u0010\u0005J\u0015\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0004\u001a\u00028\u0000H\u0016¢\u0006\u0002\u0010\u0005J\u0015\u0010\b\u001a\u00020\u00072\u0006\u0010\u0004\u001a\u00028\u0000H\u0016¢\u0006\u0002\u0010\u0005¨\u0006\t"}, d2 = {"Lcom/gateio/biz/base/utils/UnPeekDistinctLiveData;", ExifInterface.GPS_DIRECTION_TRUE, "Lcom/kunminx/architecture/ui/callback/UnPeekLiveData;", "()V", "value", "(Ljava/lang/Object;)V", "postValue", "", "setValue", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class UnPeekDistinctLiveData<T> extends UnPeekLiveData<T> {
    public UnPeekDistinctLiveData() {
    }

    public UnPeekDistinctLiveData(T t10) {
        super(t10);
    }

    @Override // com.kunminx.architecture.ui.callback.UnPeekLiveData, androidx.lifecycle.LiveData
    public void postValue(T value) {
        if (!Intrinsics.areEqual(value, getValue())) {
            super.postValue(value);
        }
    }

    @Override // com.kunminx.architecture.ui.callback.UnPeekLiveData, com.kunminx.architecture.ui.callback.ProtectedUnPeekLiveData, androidx.lifecycle.LiveData
    public void setValue(T value) {
        if (!Intrinsics.areEqual(value, getValue())) {
            super.setValue(value);
        }
    }
}