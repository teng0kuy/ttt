package com.gateio.biz.base.utils;

import android.content.Context;
import com.gateio.biz.base.R;
import com.gateio.biz.base.http.BizBaseHttpMethod;
import com.gateio.biz.base.notice.GlobalNoticeType;
import com.gateio.biz.base.router.RouterConst;
import com.gateio.common.entity.GlobalNoticeEntity;
import com.gateio.common.kotlin.ext.ViewKt;
import com.gateio.lib.router.GTRouter;
import com.gateio.lib.storage.GTStorage;
import com.gateio.lib.uikit.alert.GTAlertV5;
import kotlin.Metadata;
import kotlin.TuplesKt;
import kotlin.collections.MapsKt__MapsKt;

/* compiled from: GlobalNoticeUtil.kt */
@Metadata(d1 = {"\u0000\u0013\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016J\b\u0010\u0004\u001a\u00020\u0003H\u0016¨\u0006\u0005"}, d2 = {"com/gateio/biz/base/utils/GlobalNoticeUtil$showGlobalNotice$1$2", "Lcom/gateio/lib/uikit/alert/GTAlertV5$OnAlertClickListener;", "onIconClick", "", "onTextClick", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class GlobalNoticeUtil$showGlobalNotice$1$2 implements GTAlertV5.OnAlertClickListener {
    final /* synthetic */ Context $context;
    final /* synthetic */ GTAlertV5 $this_run;
    final /* synthetic */ GlobalNoticeType $type;

    GlobalNoticeUtil$showGlobalNotice$1$2(Context context, GTAlertV5 gTAlertV5, GlobalNoticeType globalNoticeType) {
        context = context;
        gtAlert = gTAlertV5;
        type = globalNoticeType;
    }

    @Override // com.gateio.lib.uikit.alert.GTAlertV5.OnAlertClickListener
    public void onIconClick() {
        ViewKt.setVisibleOrGone(gtAlert, false);
        GlobalNoticeEntity globalNoticeEntity = globalNoticeEntity;
        if (globalNoticeEntity != null) {
            GlobalNoticeType globalNoticeType = type;
            globalNoticeEntity.setIs_delete(true);
            GTStorage.saveKV$default("global_notice_view_" + globalNoticeType, globalNoticeEntity, null, 4, null);
        }
    }

    @Override // com.gateio.lib.uikit.alert.GTAlertV5.OnAlertClickListener
    public void onTextClick() {
        Context context;
        GlobalNoticeEntity globalNoticeEntity = globalNoticeEntity;
        if (globalNoticeEntity == null || (context = context) == null) {
            return;
        }
        BizBaseHttpMethod bizBaseHttpMethod = BizBaseHttpMethod.getInstance();
        String link = globalNoticeEntity.getLink();
        if (link == null) {
            link = "";
        }
        String wholeUrl = bizBaseHttpMethod.getWholeUrl(link);
        String title = globalNoticeEntity.getTitle();
        if (title == null) {
            title = context.getString(R.string.information_news);
        }
        GTRouter.navigation$default(context, RouterConst.App.APP_WEB, MapsKt__MapsKt.mapOf(TuplesKt.to("title", title), TuplesKt.to("url", wholeUrl)), null, null, 24, null);
    }
}