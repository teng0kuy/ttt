package com.gateio.biz.base.utils;

import androidx.lifecycle.MutableLiveData;
import com.gateio.biz.account.service.model.AppTypeChangeEvent;
import com.gateio.biz.account.service.model.ConfigUpdateEvent;
import com.gateio.biz.account.service.router.AccountApiProvider;
import com.gateio.biz.base.router.AppApiProvider;
import com.gateio.lib.datafinder.GTABTest;
import com.gateio.lib.encrypt.SystemUtils;
import com.gateio.lib.network.GTNetworkInitializer;
import com.gateio.lib.storage.GTStorage;
import com.gateio.lib.storage.mmvk.GTStoreKVDomain;
import com.gateio.lib.thread.coroutine.GTGlobalMainCoroutine;
import com.google.gson.reflect.TypeToken;
import com.tencent.qcloud.tuicore.TUIConstants;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.channels.BufferOverflow;
import kotlinx.coroutines.flow.MutableSharedFlow;
import kotlinx.coroutines.flow.SharedFlow;
import kotlinx.coroutines.flow.SharedFlowKt;
import org.greenrobot.eventbus.EventBus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: AppTypeUtils.kt */
@Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\u000b\n\u0002\u0010\u0002\n\u0002\b\n\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0017\u001a\u00020\u0004J\u0010\u0010\u0017\u001a\u00020\u00042\b\u0010\u0018\u001a\u0004\u0018\u00010\u0004J\u0014\u0010\u0019\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u0010\u0018\u001a\u0004\u0018\u00010\u0004J\u0012\u0010\u001a\u001a\u00020\u00042\b\u0010\u0018\u001a\u0004\u0018\u00010\u0004H\u0002J\u0006\u0010\u001b\u001a\u00020\u0004J\u001c\u0010\u001c\u001a\u00020\u001d2\b\u0010\u001e\u001a\u0004\u0018\u00010\u00042\b\u0010\u001f\u001a\u0004\u0018\u00010\u0004H\u0002J\u0006\u0010 \u001a\u00020\u001dJ\u0006\u0010!\u001a\u00020\u001dJ\u0006\u0010\"\u001a\u00020\u001dJ\u0006\u0010#\u001a\u00020\u001dJ\u000e\u0010#\u001a\u00020\u001d2\u0006\u0010$\u001a\u00020\u0004J\u0006\u0010%\u001a\u00020\u001dJ\u0006\u0010&\u001a\u00020\u001dJ\u0006\u0010'\u001a\u00020\u001dJ\u0006\u0010(\u001a\u00020)J\u0010\u0010*\u001a\u00020)2\u0006\u0010+\u001a\u00020\u0001H\u0007J@\u0010,\u001a\u00020)2\n\b\u0002\u0010-\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u0010.\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u0010/\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u00100\u001a\u0004\u0018\u00010\u00042\b\b\u0002\u00101\u001a\u00020\u001dJ\u0010\u00102\u001a\u00020)2\u0006\u0010+\u001a\u00020\u0001H\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\n0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\b0\f¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\"\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\b0\u00108\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\u0011\u0010\u0002\u001a\u0004\b\u0012\u0010\u0013R\"\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\n0\u00108\u0006X\u0087\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\u0015\u0010\u0002\u001a\u0004\b\u0016\u0010\u0013¨\u00063"}, d2 = {"Lcom/gateio/biz/base/utils/AppTypeUtils;", "", "()V", "KEY_APP_TYPE_WITH_USER_ID", "", "TAG", "_appTypeFlow", "Lkotlinx/coroutines/flow/MutableSharedFlow;", "Lcom/gateio/biz/account/service/model/AppTypeChangeEvent;", "_configUpdateFlow", "Lcom/gateio/biz/account/service/model/ConfigUpdateEvent;", "appTypeBus", "Landroidx/lifecycle/MutableLiveData;", "getAppTypeBus", "()Landroidx/lifecycle/MutableLiveData;", "appTypeFlow", "Lkotlinx/coroutines/flow/SharedFlow;", "getAppTypeFlow$annotations", "getAppTypeFlow", "()Lkotlinx/coroutines/flow/SharedFlow;", "configUpdateFlow", "getConfigUpdateFlow$annotations", "getConfigUpdateFlow", "getAppType", "userId", "getAppTypeFromKV", "getAppTypeKey", "getBuildAppType", "isAppTypeEqual", "", "type1", "type2", "isAppTypeFeatureEnable", "isCanadaSite", "isHongKongSite", "isMainSite", "appType", "isMaltaSite", "isTurkeySite", "isUsSite", "postConfigUpdateEvent", "", "registerAppTypeChangeListener", "subscriber", "setAppType", "fromUid", "fromType", "toUid", "toType", TUIConstants.TUIGroupNotePlugin.PLUGIN_GROUP_NOTE_ENABLE_NOTIFICATION, "unregisterAppTypeChangeListener", "biz_account_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nAppTypeUtils.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AppTypeUtils.kt\ncom/gateio/biz/base/utils/AppTypeUtils\n+ 2 GTStorage.kt\ncom/gateio/lib/storage/GTStorage\n*L\n1#1,199:1\n384#2,10:200\n384#2,10:210\n*S KotlinDebug\n*F\n+ 1 AppTypeUtils.kt\ncom/gateio/biz/base/utils/AppTypeUtils\n*L\n84#1:200,10\n153#1:210,10\n*E\n"})
/* loaded from: classes5.dex */
public final class AppTypeUtils {

    @NotNull
    private static final String KEY_APP_TYPE_WITH_USER_ID = "app_type_with_user_id_";

    @NotNull
    public static final String TAG = "AppTypeUtils: ";

    @NotNull
    private static final MutableSharedFlow<AppTypeChangeEvent> _appTypeFlow;

    @NotNull
    private static final MutableSharedFlow<ConfigUpdateEvent> _configUpdateFlow;

    @NotNull
    private static final SharedFlow<AppTypeChangeEvent> appTypeFlow;

    @NotNull
    private static final SharedFlow<ConfigUpdateEvent> configUpdateFlow;

    @NotNull
    public static final AppTypeUtils INSTANCE = new AppTypeUtils();

    @NotNull
    private static final MutableLiveData<AppTypeChangeEvent> appTypeBus = new MutableLiveData<>();

    /* compiled from: AppTypeUtils.kt */
    @Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.base.utils.AppTypeUtils$setAppType$1", f = "AppTypeUtils.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.base.utils.AppTypeUtils$setAppType$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ AppTypeChangeEvent $changeData;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(AppTypeChangeEvent appTypeChangeEvent, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$changeData = appTypeChangeEvent;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            return new AnonymousClass1(this.$changeData, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull CoroutineScope coroutineScope, @Nullable Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label == 0) {
                ResultKt.throwOnFailure(obj);
                AppTypeUtils.INSTANCE.getAppTypeBus().setValue(this.$changeData);
                return Unit.INSTANCE;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }

    private AppTypeUtils() {
    }

    @NotNull
    public final String getAppType() {
        return getAppType(AccountApiProvider.getDefaultUserUtilsApi().getUserId());
    }

    public final boolean isMainSite() {
        return isMainSite(getAppType());
    }

    static {
        BufferOverflow bufferOverflow = BufferOverflow.DROP_OLDEST;
        MutableSharedFlow<AppTypeChangeEvent> MutableSharedFlow = SharedFlowKt.MutableSharedFlow(1, 16, bufferOverflow);
        _appTypeFlow = MutableSharedFlow;
        appTypeFlow = MutableSharedFlow;
        MutableSharedFlow<ConfigUpdateEvent> MutableSharedFlow2 = SharedFlowKt.MutableSharedFlow(0, 16, bufferOverflow);
        _configUpdateFlow = MutableSharedFlow2;
        configUpdateFlow = MutableSharedFlow2;
    }

    @NotNull
    public static final SharedFlow<AppTypeChangeEvent> getAppTypeFlow() {
        return appTypeFlow;
    }

    public static /* synthetic */ String getAppTypeFromKV$default(AppTypeUtils appTypeUtils, String str, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = AccountApiProvider.getDefaultUserUtilsApi().getUserId();
        }
        return appTypeUtils.getAppTypeFromKV(str);
    }

    private final String getAppTypeKey(String userId) {
        if (userId == null || userId.length() == 0) {
            return KEY_APP_TYPE_WITH_USER_ID;
        }
        return KEY_APP_TYPE_WITH_USER_ID + SystemUtils.md5(userId);
    }

    @NotNull
    public static final SharedFlow<ConfigUpdateEvent> getConfigUpdateFlow() {
        return configUpdateFlow;
    }

    public static /* synthetic */ void setAppType$default(AppTypeUtils appTypeUtils, String str, String str2, String str3, String str4, boolean z10, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = null;
        }
        if ((i10 & 2) != 0) {
            str2 = null;
        }
        if ((i10 & 4) != 0) {
            str3 = null;
        }
        if ((i10 & 8) != 0) {
            str4 = null;
        }
        if ((i10 & 16) != 0) {
            z10 = true;
        }
        appTypeUtils.setAppType(str, str2, str3, str4, z10);
    }

    @NotNull
    public final String getAppType(@Nullable String userId) {
        if (!isAppTypeFeatureEnable()) {
            return getBuildAppType();
        }
        GTStorage gTStorage = GTStorage.INSTANCE;
        String appTypeKey = getAppTypeKey(userId);
        GTStoreKVDomain gTStoreKVDomain = GTStoreKVDomain.Default;
        String str = (String) (gTStorage.isPrimitiveOrWrapper(String.class) ? GTStorage.queryKV(appTypeKey, (Class<Object>) String.class, (Object) null, gTStoreKVDomain) : GTStorage.queryKV(appTypeKey, new TypeToken<String>() { // from class: com.gateio.biz.base.utils.AppTypeUtils$getAppType$$inlined$queryKV$default$1
        }.getType(), (Object) null, gTStoreKVDomain));
        return str == null ? getBuildAppType() : str;
    }

    @NotNull
    public final MutableLiveData<AppTypeChangeEvent> getAppTypeBus() {
        return appTypeBus;
    }

    @Nullable
    public final String getAppTypeFromKV(@Nullable String userId) {
        GTStorage gTStorage = GTStorage.INSTANCE;
        String appTypeKey = getAppTypeKey(userId);
        GTStoreKVDomain gTStoreKVDomain = GTStoreKVDomain.Default;
        return (String) (gTStorage.isPrimitiveOrWrapper(String.class) ? GTStorage.queryKV(appTypeKey, (Class<Object>) String.class, (Object) null, gTStoreKVDomain) : GTStorage.queryKV(appTypeKey, new TypeToken<String>() { // from class: com.gateio.biz.base.utils.AppTypeUtils$getAppTypeFromKV$$inlined$queryKV$default$1
        }.getType(), (Object) null, gTStoreKVDomain));
    }

    public final boolean isAppTypeFeatureEnable() {
        return ((Boolean) GTABTest.getTestCase("gt_mg_apptype_switch", Boolean.TRUE)).booleanValue();
    }

    public final boolean isCanadaSite() {
        return Intrinsics.areEqual("7", getAppType());
    }

    public final boolean isHongKongSite() {
        return Intrinsics.areEqual("5", getAppType());
    }

    public final boolean isMainSite(@NotNull String appType) {
        return Intrinsics.areEqual("0", appType) || Intrinsics.areEqual("1", appType) || Intrinsics.areEqual("4", appType);
    }

    public final boolean isMaltaSite() {
        return Intrinsics.areEqual("3", getAppType());
    }

    public final boolean isTurkeySite() {
        return Intrinsics.areEqual("2", getAppType());
    }

    public final boolean isUsSite() {
        return Intrinsics.areEqual("11", getAppType());
    }

    public final void postConfigUpdateEvent() {
        _configUpdateFlow.tryEmit(new ConfigUpdateEvent());
    }

    public final void setAppType(@Nullable String fromUid, @Nullable String fromType, @Nullable String toUid, @Nullable String toType, boolean notify) {
        String appTypeFromKV = fromType;
        if (!isAppTypeFeatureEnable()) {
            AppTypeLog.i$default(AppTypeLog.INSTANCE, TAG, " isAppTypeFeatureEnable = false", false, true, 4, null);
            return;
        }
        AppTypeLog appTypeLog = AppTypeLog.INSTANCE;
        StringBuilder sb = new StringBuilder();
        sb.append("setAppType fromUid: ");
        sb.append(fromUid == null || fromUid.length() == 0 ? "" : SystemUtils.md5(fromUid));
        sb.append(", toUid: ");
        sb.append(toUid == null || toUid.length() == 0 ? "" : SystemUtils.md5(toUid));
        AppTypeLog.w$default(appTypeLog, TAG, sb.toString(), false, true, 4, null);
        AppTypeLog.w$default(appTypeLog, TAG, "setAppType fromType: " + appTypeFromKV + ", toType: " + toType + " notify: " + notify, false, false, 12, null);
        if (appTypeFromKV == null) {
            appTypeFromKV = getAppTypeFromKV(fromUid);
        }
        int appType = GTNetworkInitializer.getConfig().getAppType();
        GTNetworkInitializer.setAppType(toType == null || toType.length() == 0 ? Integer.parseInt(getBuildAppType()) : Integer.parseInt(toType));
        int appType2 = GTNetworkInitializer.getConfig().getAppType();
        GTStorage.saveKV$default(getAppTypeKey(toUid), toType, null, 4, null);
        AppTypeLog.w$default(appTypeLog, TAG, " 设置成功 appType: from " + appTypeFromKV + " to " + toType + ", fromNetAppType: " + appType + ", toNetAppType: " + appType2, false, true, 4, null);
        if (isAppTypeEqual(appTypeFromKV, toType)) {
            AppTypeLog.w$default(appTypeLog, TAG, " current appType is the same: " + appTypeFromKV + " -> " + toType, false, true, 4, null);
            return;
        }
        if (notify) {
            AppTypeChangeEvent appTypeChangeEvent = new AppTypeChangeEvent(appTypeFromKV, toType);
            BuildersKt__Builders_commonKt.launch$default(GTGlobalMainCoroutine.INSTANCE, null, null, new AnonymousClass1(appTypeChangeEvent, null), 3, null);
            _appTypeFlow.tryEmit(appTypeChangeEvent);
            EventBus.getDefault().post(appTypeChangeEvent);
            AppTypeLog.w$default(appTypeLog, "AppTypeUtils", "finish notify", false, true, 4, null);
        }
    }

    private final boolean isAppTypeEqual(String type1, String type2) {
        if (Intrinsics.areEqual(type1, type2)) {
            return true;
        }
        if (Intrinsics.areEqual(type1, getBuildAppType()) && type2 == null) {
            return true;
        }
        if (type1 == null && Intrinsics.areEqual(type2, getBuildAppType())) {
            return true;
        }
        return false;
    }

    @JvmStatic
    public static final void registerAppTypeChangeListener(@NotNull Object subscriber) {
        if (!EventBus.getDefault().isRegistered(subscriber)) {
            EventBus.getDefault().register(subscriber);
        }
    }

    @JvmStatic
    public static final void unregisterAppTypeChangeListener(@NotNull Object subscriber) {
        if (EventBus.getDefault().isRegistered(subscriber)) {
            EventBus.getDefault().unregister(subscriber);
        }
    }

    @NotNull
    public final String getBuildAppType() {
        return AppApiProvider.getDefaultGradleApi().getBuildAppType();
    }

    @JvmStatic
    public static /* synthetic */ void getAppTypeFlow$annotations() {
    }

    @JvmStatic
    public static /* synthetic */ void getConfigUpdateFlow$annotations() {
    }
}