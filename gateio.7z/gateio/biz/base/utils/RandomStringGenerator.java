package com.gateio.biz.base.utils;

import java.security.SecureRandom;

/* loaded from: classes5.dex */
public class RandomStringGenerator {
    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private static final int LENGTH = 32;

    public static String generateRandomString() {
        SecureRandom secureRandom = new SecureRandom();
        StringBuilder sb = new StringBuilder(32);
        for (int i10 = 0; i10 < 32; i10++) {
            sb.append(CHARACTERS.charAt(secureRandom.nextInt(62)));
        }
        return sb.toString();
    }
}