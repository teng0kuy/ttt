package com.gateio.biz.base.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import com.coremedia.iso.boxes.UserBox;
import com.fingerprintjs.android.fingerprint.signal_providers.device_id.DeviceIdConstantsKt;
import com.gateio.common.tool.StringUtils;
import com.gateio.lib.logger.GTLog;
import com.gateio.lib.storage.GTStorage;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt___CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt__IndentKt;
import org.jetbrains.annotations.NotNull;

/* compiled from: DeviceInfoDetector.kt */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0007\u001a\u00020\bJ\u0010\u0010\t\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u000bH\u0007J\u0006\u0010\f\u001a\u00020\u0004J\u0006\u0010\r\u001a\u00020\u0004J\u0010\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\n\u001a\u00020\u000bH\u0002J\u001c\u0010\u0010\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\u000b2\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\b0\u0012J \u0010\u0013\u001a\u00020\b2\u0006\u0010\u0014\u001a\u00020\u00042\u0006\u0010\u0015\u001a\u00020\u00042\u0006\u0010\u0016\u001a\u00020\u0004H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0017"}, d2 = {"Lcom/gateio/biz/base/utils/DeviceInfoDetector;", "", "()V", "PREFS_NAME_ANDROID_ID", "", "PREFS_NAME_DEVICE_UUID", "PREFS_NAME_HARDWARE_INFO", "clearStoredInfo", "", "getAndroidId", "context", "Landroid/content/Context;", "getHardwareInfo", "getOrCreateDeviceUuid", "isMigratedDevice", "", "safeCheckAndHandleMigration", "onMigrated", "Lkotlin/Function0;", "saveCurrentInfo", DeviceIdConstantsKt.ANDROID_ID_NAME, UserBox.TYPE, "hardwareInfo", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class DeviceInfoDetector {

    @NotNull
    public static final DeviceInfoDetector INSTANCE = new DeviceInfoDetector();

    @NotNull
    public static final String PREFS_NAME_ANDROID_ID = "device_info_android_id";

    @NotNull
    public static final String PREFS_NAME_DEVICE_UUID = "device_info_device_uuid";

    @NotNull
    public static final String PREFS_NAME_HARDWARE_INFO = "device_info_hardware_info";

    private DeviceInfoDetector() {
    }

    @NotNull
    public final String getHardwareInfo() {
        String[] strArr = new String[7];
        String str = Build.BOARD;
        if (str == null) {
            str = "";
        }
        strArr[0] = str;
        String str2 = Build.BRAND;
        if (str2 == null) {
            str2 = "";
        }
        strArr[1] = str2;
        String str3 = Build.DEVICE;
        if (str3 == null) {
            str3 = "";
        }
        strArr[2] = str3;
        String str4 = Build.HARDWARE;
        if (str4 == null) {
            str4 = "";
        }
        strArr[3] = str4;
        String str5 = Build.MANUFACTURER;
        if (str5 == null) {
            str5 = "";
        }
        strArr[4] = str5;
        String str6 = Build.MODEL;
        if (str6 == null) {
            str6 = "";
        }
        strArr[5] = str6;
        String str7 = Build.PRODUCT;
        strArr[6] = str7 != null ? str7 : "";
        return CollectionsKt___CollectionsKt.joinToString$default(CollectionsKt__CollectionsKt.listOf((Object[]) strArr), "|", null, null, 0, null, null, 62, null);
    }

    private final boolean isMigratedDevice(Context context) {
        String strQueryStringKV$default = GTStorage.queryStringKV$default(PREFS_NAME_ANDROID_ID, "", null, 4, null);
        String strQueryStringKV$default2 = GTStorage.queryStringKV$default(PREFS_NAME_DEVICE_UUID, "", null, 4, null);
        String strQueryStringKV$default3 = GTStorage.queryStringKV$default(PREFS_NAME_HARDWARE_INFO, "", null, 4, null);
        String androidId = getAndroidId(context);
        String orCreateDeviceUuid = getOrCreateDeviceUuid();
        String hardwareInfo = getHardwareInfo();
        if (StringUtils.isEmpty(strQueryStringKV$default) || StringUtils.isEmpty(strQueryStringKV$default2) || StringUtils.isEmpty(strQueryStringKV$default3)) {
            GTLog.i$default("[DeviceInfoDetector] First launch detected, saving device info.", null, null, null, 14, null);
            saveCurrentInfo(androidId, orCreateDeviceUuid, hardwareInfo);
            return false;
        }
        boolean z10 = !Intrinsics.areEqual(strQueryStringKV$default, androidId);
        boolean z11 = !Intrinsics.areEqual(strQueryStringKV$default2, orCreateDeviceUuid);
        boolean z12 = !Intrinsics.areEqual(strQueryStringKV$default3, hardwareInfo);
        GTLog.i$default(StringsKt__IndentKt.trimMargin$default("[DeviceInfoDetector] Migration check result:\n                    |- AndroidId: " + z10 + "::storedAndroidId::" + strQueryStringKV$default + "::::currentAndroidId:" + androidId + "\"\n                    |- UUID: " + z11 + "::storedDeviceUuid::" + strQueryStringKV$default2 + "::::currentDeviceUuid:" + orCreateDeviceUuid + "\"\n                    |- Hardware: " + z12 + "::storedHardwareInfo::" + strQueryStringKV$default3 + "::::currentHardwareInfo:" + hardwareInfo + "\"\n                ", null, 1, null), null, null, null, 14, null);
        return (z10 || z11) && z12;
    }

    private final void saveCurrentInfo(String androidId, String uuid, String hardwareInfo) {
        GTStorage.saveKV$default(PREFS_NAME_ANDROID_ID, androidId, null, 4, null);
        GTStorage.saveKV$default(PREFS_NAME_DEVICE_UUID, uuid, null, 4, null);
        GTStorage.saveKV$default(PREFS_NAME_HARDWARE_INFO, hardwareInfo, null, 4, null);
        GTLog.i$default("[DeviceInfoDetector] saveCurrentInfo::AndroidId:" + androidId + ":::saveCurrentInfo::DeviceUuid:" + uuid + "::::saveCurrentInfo::HardwareInfo:" + hardwareInfo, null, null, null, 14, null);
    }

    public final void clearStoredInfo() {
        GTStorage.saveKV$default(PREFS_NAME_ANDROID_ID, "", null, 4, null);
        GTStorage.saveKV$default(PREFS_NAME_DEVICE_UUID, "", null, 4, null);
        GTStorage.saveKV$default(PREFS_NAME_HARDWARE_INFO, "", null, 4, null);
    }

    @NotNull
    public final String getOrCreateDeviceUuid() {
        String strQueryStringKV$default = GTStorage.queryStringKV$default(PREFS_NAME_DEVICE_UUID, "", null, 4, null);
        if (!StringUtils.isEmpty(strQueryStringKV$default)) {
            return strQueryStringKV$default;
        }
        String string = UUID.randomUUID().toString();
        GTStorage.saveKV$default(PREFS_NAME_DEVICE_UUID, string, null, 4, null);
        return string;
    }

    @SuppressLint({"HardwareIds"})
    @NotNull
    public final String getAndroidId(@NotNull Context context) {
        String string = Settings.Secure.getString(context.getContentResolver(), "android_id");
        if (string == null) {
            return "";
        }
        return string;
    }

    public final void safeCheckAndHandleMigration(@NotNull Context context, @NotNull Function0<Unit> onMigrated) {
        try {
            if (isMigratedDevice(context)) {
                GTLog.i$default("[DeviceInfoDetector] Device migration detected, forcing logout.", null, null, null, 14, null);
                onMigrated.invoke();
            }
        } catch (Exception e10) {
            GTLog.i$default("[DeviceInfoDetector] An error occurred during migration check: " + e10.getMessage(), null, null, null, 14, null);
        }
    }
}