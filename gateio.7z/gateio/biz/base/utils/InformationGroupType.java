package com.gateio.biz.base.utils;

import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import org.jetbrains.annotations.NotNull;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: InformationGroupType.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/base/utils/InformationGroupType;", "", "(Ljava/lang/String;I)V", "FUTURE", "COPY_TRADING", "WEB3", "STRATEGY", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class InformationGroupType {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ InformationGroupType[] $VALUES;
    public static final InformationGroupType FUTURE = new InformationGroupType("FUTURE", 0);
    public static final InformationGroupType COPY_TRADING = new InformationGroupType("COPY_TRADING", 1);
    public static final InformationGroupType WEB3 = new InformationGroupType("WEB3", 2);
    public static final InformationGroupType STRATEGY = new InformationGroupType("STRATEGY", 3);

    private static final /* synthetic */ InformationGroupType[] $values() {
        return new InformationGroupType[]{FUTURE, COPY_TRADING, WEB3, STRATEGY};
    }

    static {
        InformationGroupType[] informationGroupTypeArr$values = $values();
        $VALUES = informationGroupTypeArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(informationGroupTypeArr$values);
    }

    @NotNull
    public static EnumEntries<InformationGroupType> getEntries() {
        return $ENTRIES;
    }

    public static InformationGroupType valueOf(String str) {
        return (InformationGroupType) Enum.valueOf(InformationGroupType.class, str);
    }

    public static InformationGroupType[] values() {
        return (InformationGroupType[]) $VALUES.clone();
    }

    private InformationGroupType(String str, int i10) {
    }
}