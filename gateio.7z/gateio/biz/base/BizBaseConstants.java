package com.gateio.biz.base;

import com.gateio.biz_options.common.OptionsConstants;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* compiled from: BizBaseConstants.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\n\bÆ\u0002\u0018\u00002\u00020\u0001:\b\u0003\u0004\u0005\u0006\u0007\b\t\nB\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u000b"}, d2 = {"Lcom/gateio/biz/base/BizBaseConstants;", "", "()V", "Exchange", "FuturesKey", "FuturesParams", "OptionsKey", "Pilot", "Trans", "Unified", "UserCenter", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class BizBaseConstants {

    @NotNull
    public static final BizBaseConstants INSTANCE = new BizBaseConstants();

    /* compiled from: BizBaseConstants.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/base/BizBaseConstants$Exchange;", "", "()V", "EXCHANGE_KEY_APP_TAB_BAR_CUSTOM_ENABLE", "", "EXCHANGE_KEY_BADGE_VIEW", "EXCHANGE_ROOT_SELECT_TYPE_MEMORY", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Exchange {

        @NotNull
        public static final String EXCHANGE_KEY_APP_TAB_BAR_CUSTOM_ENABLE = "app_tab_bar_custom_enable";

        @NotNull
        public static final String EXCHANGE_KEY_BADGE_VIEW = "exchange_key_badge_view";

        @NotNull
        public static final String EXCHANGE_ROOT_SELECT_TYPE_MEMORY = "exchange_root_select_type_memory";

        @NotNull
        public static final Exchange INSTANCE = new Exchange();

        private Exchange() {
        }
    }

    /* compiled from: BizBaseConstants.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u001a\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u001e"}, d2 = {"Lcom/gateio/biz/base/BizBaseConstants$FuturesKey;", "", "()V", "BASE_DEPTH_AMOUNT", "", "BASE_DEPTH_AMOUNT_NOTICE", "BASE_VIBRATION", "BUY_OR_SELL_TYPE", "FUTURES_CENTER_IS_OPEN", "FUTURES_CENTER_IS_OPEN_ENABLE", "FUTURES_COIN2ZHANG2U", "FUTURES_DEFAULT_HEADER", "FUTURES_DEFAULT_SELECT_SMART_MARKET", FuturesKey.FUTURES_DEPTH_FREQUENCY, "FUTURES_DETAIL_HEADER", "FUTURES_HEADER", "FUTURES_KLINE_HEADER", "FUTURES_NOTIFY_HEADER", "FUTURES_OPEN_HTTP_BLOCKING_QUEUE", "FUTURES_SMART_MARKET", "FUTURES_TESTNET_HEADER", "FUTURES_WS_TYPE", FuturesKey.KEY_EXCHANGE_DEPTH_TYPE, FuturesKey.KEY_EXCHANGE_DEPTH_TYPE_V1, "KEY_PILOT_DEPTH_FREQUENCY", "KEY_TRANS_DEPTH_FREQUENCY", "MARKET_SELECT_HEADER", "MARKET_SELECT_HEADER_X_GATE_MODE", "PILOT_KEY_DEPTH_FREQUENCY", "RIGHT_OR_LEFT", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class FuturesKey {

        @NotNull
        public static final String BASE_DEPTH_AMOUNT = "base_depth_amount";

        @NotNull
        public static final String BASE_DEPTH_AMOUNT_NOTICE = "base_depth_amount_notice_v1";

        @NotNull
        public static final String BASE_VIBRATION = "base_vibration";

        @NotNull
        public static final String BUY_OR_SELL_TYPE = "futures_buy_or_sell_type";

        @NotNull
        public static final String FUTURES_CENTER_IS_OPEN = "futures_center_is_open";

        @NotNull
        public static final String FUTURES_CENTER_IS_OPEN_ENABLE = "futures_center_is_open_enable";

        @NotNull
        public static final String FUTURES_COIN2ZHANG2U = "futures_coin2zhang2u";

        @NotNull
        public static final String FUTURES_DEFAULT_HEADER = "futures_default_header";

        @NotNull
        public static final String FUTURES_DEFAULT_SELECT_SMART_MARKET = "futures_default_select_smart_market";

        @NotNull
        public static final String FUTURES_DEPTH_FREQUENCY = "FUTURES_DEPTH_FREQUENCY";

        @NotNull
        public static final String FUTURES_DETAIL_HEADER = "futures_detail_header";

        @NotNull
        public static final String FUTURES_HEADER = "futures_header";

        @NotNull
        public static final String FUTURES_KLINE_HEADER = "futures_kline_header";

        @NotNull
        public static final String FUTURES_NOTIFY_HEADER = "futures_notify_header";

        @NotNull
        public static final String FUTURES_OPEN_HTTP_BLOCKING_QUEUE = "futures_open_http_blocking_queue";

        @NotNull
        public static final String FUTURES_SMART_MARKET = "futures_smart_market";

        @NotNull
        public static final String FUTURES_TESTNET_HEADER = "futures_testnet_header";

        @NotNull
        public static final String FUTURES_WS_TYPE = "futures_ws_type";

        @NotNull
        public static final FuturesKey INSTANCE = new FuturesKey();

        @NotNull
        public static final String KEY_EXCHANGE_DEPTH_TYPE = "KEY_EXCHANGE_DEPTH_TYPE";

        @NotNull
        public static final String KEY_EXCHANGE_DEPTH_TYPE_V1 = "KEY_EXCHANGE_DEPTH_TYPE_V1";

        @NotNull
        public static final String KEY_PILOT_DEPTH_FREQUENCY = "key_pilot_depth_frequency";

        @NotNull
        public static final String KEY_TRANS_DEPTH_FREQUENCY = "key_trans_depth_frequency";

        @NotNull
        public static final String MARKET_SELECT_HEADER = "market_select_header";

        @NotNull
        public static final String MARKET_SELECT_HEADER_X_GATE_MODE = "market_select_header_x_gate_mode";

        @NotNull
        public static final String PILOT_KEY_DEPTH_FREQUENCY = "pilot_key_depth_frequency";

        @NotNull
        public static final String RIGHT_OR_LEFT = "futures_right_or_left";

        private FuturesKey() {
        }
    }

    /* compiled from: BizBaseConstants.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\n\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u000e"}, d2 = {"Lcom/gateio/biz/base/BizBaseConstants$FuturesParams;", "", "()V", "FUTURES_CHILD_TAB", "", "FUTURES_COUNT", "FUTURES_COUNT_UNIT", FuturesParams.FUTURES_DUAL_TYPE, "FUTURES_LOSE", "FUTURES_MODE_VOUCHER", "FUTURES_PRICE", "FUTURES_PRICE_TYPE", "FUTURES_PROFIT", "FUTURES_SINGLE_GROUP_TYPE", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class FuturesParams {

        @NotNull
        public static final String FUTURES_CHILD_TAB = "futures_child_tab";

        @NotNull
        public static final String FUTURES_COUNT = "futures_count";

        @NotNull
        public static final String FUTURES_COUNT_UNIT = "futures_count_unit";

        @NotNull
        public static final String FUTURES_DUAL_TYPE = "FUTURES_DUAL_TYPE";

        @NotNull
        public static final String FUTURES_LOSE = "futures_lose";

        @NotNull
        public static final String FUTURES_MODE_VOUCHER = "futures_mode_voucher";

        @NotNull
        public static final String FUTURES_PRICE = "futures_price";

        @NotNull
        public static final String FUTURES_PRICE_TYPE = "futures_price_type";

        @NotNull
        public static final String FUTURES_PROFIT = "futures_profit";

        @NotNull
        public static final String FUTURES_SINGLE_GROUP_TYPE = "futures_single_group_type";

        @NotNull
        public static final FuturesParams INSTANCE = new FuturesParams();

        private FuturesParams() {
        }
    }

    /* compiled from: BizBaseConstants.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0006"}, d2 = {"Lcom/gateio/biz/base/BizBaseConstants$OptionsKey;", "", "()V", "KEY_OPTIONS_COIN2ZHANG", "", OptionsConstants.KEY_OPTIONS_DEPTH_TYPE_V1, "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class OptionsKey {

        @NotNull
        public static final OptionsKey INSTANCE = new OptionsKey();

        @NotNull
        public static final String KEY_OPTIONS_COIN2ZHANG = "key_options_coin2zhang";

        @NotNull
        public static final String KEY_OPTIONS_DEPTH_TYPE_V1 = "key_options_depth_type_v1";

        private OptionsKey() {
        }
    }

    /* compiled from: BizBaseConstants.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0005"}, d2 = {"Lcom/gateio/biz/base/BizBaseConstants$Pilot;", "", "()V", Pilot.KEY_PILOT_EXCHANGE_DEPTH_TYPE, "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Pilot {

        @NotNull
        public static final Pilot INSTANCE = new Pilot();

        @NotNull
        public static final String KEY_PILOT_EXCHANGE_DEPTH_TYPE = "KEY_PILOT_EXCHANGE_DEPTH_TYPE";

        private Pilot() {
        }
    }

    /* compiled from: BizBaseConstants.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0005"}, d2 = {"Lcom/gateio/biz/base/BizBaseConstants$Trans;", "", "()V", Trans.KEY_TRANS_EXCHANGE_DEPTH_TYPE, "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Trans {

        @NotNull
        public static final Trans INSTANCE = new Trans();

        @NotNull
        public static final String KEY_TRANS_EXCHANGE_DEPTH_TYPE = "KEY_TRANS_EXCHANGE_DEPTH_TYPE";

        private Trans() {
        }
    }

    /* compiled from: BizBaseConstants.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0005"}, d2 = {"Lcom/gateio/biz/base/BizBaseConstants$Unified;", "", "()V", "UNIFIED_ACCOUNT_MODE", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Unified {

        @NotNull
        public static final Unified INSTANCE = new Unified();

        @NotNull
        public static final String UNIFIED_ACCOUNT_MODE = "unified_account_mode";

        private Unified() {
        }
    }

    /* compiled from: BizBaseConstants.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0005"}, d2 = {"Lcom/gateio/biz/base/BizBaseConstants$UserCenter;", "", "()V", "KEY_UKEY_BIND_ENABLE", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class UserCenter {

        @NotNull
        public static final UserCenter INSTANCE = new UserCenter();

        @NotNull
        public static final String KEY_UKEY_BIND_ENABLE = "ukey_bind_enable";

        private UserCenter() {
        }
    }

    private BizBaseConstants() {
    }
}