package com.gateio.biz.base.dispatcher;

import androidx.annotation.Keep;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import org.jetbrains.annotations.NotNull;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: CopyParamsMessage.kt */
@Keep
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0003\b\u0087\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003¨\u0006\u0004"}, d2 = {"Lcom/gateio/biz/base/dispatcher/CopyParamsMessage;", "", "(Ljava/lang/String;I)V", "copyUpdateParams", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class CopyParamsMessage {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ CopyParamsMessage[] $VALUES;
    public static final CopyParamsMessage copyUpdateParams = new CopyParamsMessage("copyUpdateParams", 0);

    private static final /* synthetic */ CopyParamsMessage[] $values() {
        return new CopyParamsMessage[]{copyUpdateParams};
    }

    static {
        CopyParamsMessage[] copyParamsMessageArr$values = $values();
        $VALUES = copyParamsMessageArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(copyParamsMessageArr$values);
    }

    @NotNull
    public static EnumEntries<CopyParamsMessage> getEntries() {
        return $ENTRIES;
    }

    public static CopyParamsMessage valueOf(String str) {
        return (CopyParamsMessage) Enum.valueOf(CopyParamsMessage.class, str);
    }

    public static CopyParamsMessage[] values() {
        return (CopyParamsMessage[]) $VALUES.clone();
    }

    private CopyParamsMessage(String str, int i10) {
    }
}