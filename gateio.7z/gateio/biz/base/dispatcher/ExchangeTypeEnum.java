package com.gateio.biz.base.dispatcher;

import androidx.annotation.Keep;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import org.jetbrains.annotations.NotNull;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: ExchangeTypeEnum.kt */
@Keep
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010\u0000\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u001a\b\u0087\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u000b\u001a\u00020\fJ\u0006\u0010\r\u001a\u00020\fJ\u0006\u0010\u000e\u001a\u00020\fJ\u0006\u0010\u000f\u001a\u00020\fJ\u0006\u0010\u0010\u001a\u00020\fJ\u0006\u0010\u0011\u001a\u00020\fJ\u0006\u0010\u0012\u001a\u00020\fJ\u0006\u0010\u0013\u001a\u00020\fJ\u0006\u0010\u0014\u001a\u00020\fJ\u0006\u0010\u0015\u001a\u00020\fJ\u0006\u0010\u0016\u001a\u00020\fJ\u0006\u0010\u0017\u001a\u00020\fJ\u0006\u0010\u0018\u001a\u00020\fR&\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\nj\u0002\b\u0019j\u0002\b\u001aj\u0002\b\u001bj\u0002\b\u001cj\u0002\b\u001dj\u0002\b\u001ej\u0002\b\u001fj\u0002\b j\u0002\b!j\u0002\b\"j\u0002\b#j\u0002\b$j\u0002\b%¨\u0006&"}, d2 = {"Lcom/gateio/biz/base/dispatcher/ExchangeTypeEnum;", "", "(Ljava/lang/String;I)V", "params", "", "", "", "getParams", "()Ljava/util/Map;", "setParams", "(Ljava/util/Map;)V", "isBotPool", "", "isBots", "isConvert", "isCopy", "isEarn", "isFutures", "isMargin", "isMemeBox", "isOptions", "isOptionsStrategy", "isPilot", "isPreMarket", "isSpot", "SPOT", "MARGIN", "FUTURES", "OPTIONS", "EARN", "COPY", "BOTS", "BOT_POOL", "PRE_MARKET", "CONVERT", "PILOT", "OPTIONS_STRATEGY", "MEME_BOX", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class ExchangeTypeEnum {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ ExchangeTypeEnum[] $VALUES;

    @NotNull
    private Map<String, ? extends Object> params = MapsKt__MapsKt.emptyMap();
    public static final ExchangeTypeEnum SPOT = new ExchangeTypeEnum("SPOT", 0);
    public static final ExchangeTypeEnum MARGIN = new ExchangeTypeEnum("MARGIN", 1);
    public static final ExchangeTypeEnum FUTURES = new ExchangeTypeEnum("FUTURES", 2);
    public static final ExchangeTypeEnum OPTIONS = new ExchangeTypeEnum("OPTIONS", 3);
    public static final ExchangeTypeEnum EARN = new ExchangeTypeEnum("EARN", 4);
    public static final ExchangeTypeEnum COPY = new ExchangeTypeEnum("COPY", 5);
    public static final ExchangeTypeEnum BOTS = new ExchangeTypeEnum("BOTS", 6);
    public static final ExchangeTypeEnum BOT_POOL = new ExchangeTypeEnum("BOT_POOL", 7);
    public static final ExchangeTypeEnum PRE_MARKET = new ExchangeTypeEnum("PRE_MARKET", 8);
    public static final ExchangeTypeEnum CONVERT = new ExchangeTypeEnum("CONVERT", 9);
    public static final ExchangeTypeEnum PILOT = new ExchangeTypeEnum("PILOT", 10);
    public static final ExchangeTypeEnum OPTIONS_STRATEGY = new ExchangeTypeEnum("OPTIONS_STRATEGY", 11);
    public static final ExchangeTypeEnum MEME_BOX = new ExchangeTypeEnum("MEME_BOX", 12);

    private static final /* synthetic */ ExchangeTypeEnum[] $values() {
        return new ExchangeTypeEnum[]{SPOT, MARGIN, FUTURES, OPTIONS, EARN, COPY, BOTS, BOT_POOL, PRE_MARKET, CONVERT, PILOT, OPTIONS_STRATEGY, MEME_BOX};
    }

    static {
        ExchangeTypeEnum[] exchangeTypeEnumArr$values = $values();
        $VALUES = exchangeTypeEnumArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(exchangeTypeEnumArr$values);
    }

    @NotNull
    public static EnumEntries<ExchangeTypeEnum> getEntries() {
        return $ENTRIES;
    }

    public static ExchangeTypeEnum valueOf(String str) {
        return (ExchangeTypeEnum) Enum.valueOf(ExchangeTypeEnum.class, str);
    }

    public static ExchangeTypeEnum[] values() {
        return (ExchangeTypeEnum[]) $VALUES.clone();
    }

    @NotNull
    public final Map<String, Object> getParams() {
        return this.params;
    }

    public final boolean isBotPool() {
        return this == BOT_POOL;
    }

    public final boolean isBots() {
        return this == BOTS;
    }

    public final boolean isConvert() {
        return this == CONVERT;
    }

    public final boolean isCopy() {
        return this == COPY;
    }

    public final boolean isEarn() {
        return this == EARN;
    }

    public final boolean isFutures() {
        return this == FUTURES;
    }

    public final boolean isMargin() {
        return this == MARGIN;
    }

    public final boolean isMemeBox() {
        return this == MEME_BOX;
    }

    public final boolean isOptions() {
        return this == OPTIONS;
    }

    public final boolean isOptionsStrategy() {
        return this == OPTIONS_STRATEGY;
    }

    public final boolean isPilot() {
        return this == PILOT;
    }

    public final boolean isPreMarket() {
        return this == PRE_MARKET;
    }

    public final boolean isSpot() {
        return this == SPOT;
    }

    public final void setParams(@NotNull Map<String, ? extends Object> map) {
        this.params = map;
    }

    private ExchangeTypeEnum(String str, int i10) {
    }
}