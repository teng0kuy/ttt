package com.gateio.biz.base.dispatcher;

import androidx.lifecycle.LiveData;
import com.kunminx.architecture.ui.callback.UnPeekLiveData;
import kotlin.Lazy;
import kotlin.LazyKt__LazyJVMKt;
import kotlin.LazyThreadSafetyMode;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: MainRootLiveDataBus.kt */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0004\u0018\u0000 \u00132\u00020\u0001:\u0001\u0013B\u0005¢\u0006\u0002\u0010\u0002J\u0006\u0010\u000f\u001a\u00020\u0010J\u0010\u0010\u0011\u001a\u00020\u00102\b\u0010\u0012\u001a\u0004\u0018\u00010\u0005R\u0016\u0010\u0003\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010\u0006\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0019\u0010\t\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\n¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0019\u0010\r\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\b¨\u0006\u0014"}, d2 = {"Lcom/gateio/biz/base/dispatcher/MainRootLiveDataBus;", "", "()V", "_exchangeTypeBus", "Lcom/kunminx/architecture/ui/callback/UnPeekLiveData;", "Lcom/gateio/biz/base/dispatcher/ExchangeTypeEnum;", "exchangeSpotTypeBus", "getExchangeSpotTypeBus", "()Lcom/kunminx/architecture/ui/callback/UnPeekLiveData;", "exchangeTypeBus", "Landroidx/lifecycle/LiveData;", "getExchangeTypeBus", "()Landroidx/lifecycle/LiveData;", "rootTypeBus", "getRootTypeBus", "destory", "", "setExchangeTypeBus", "exchangeTypeEnum", "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class MainRootLiveDataBus {

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @NotNull
    private static final Lazy<MainRootLiveDataBus> instance$delegate = LazyKt__LazyJVMKt.lazy(LazyThreadSafetyMode.SYNCHRONIZED, (Function0) new Function0<MainRootLiveDataBus>() { // from class: com.gateio.biz.base.dispatcher.MainRootLiveDataBus$Companion$instance$2
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // kotlin.jvm.functions.Function0
        @NotNull
        public final MainRootLiveDataBus invoke() {
            return new MainRootLiveDataBus();
        }
    });

    @NotNull
    private final UnPeekLiveData<ExchangeTypeEnum> _exchangeTypeBus;

    @NotNull
    private final UnPeekLiveData<ExchangeTypeEnum> exchangeSpotTypeBus;

    @NotNull
    private final LiveData<ExchangeTypeEnum> exchangeTypeBus;

    @NotNull
    private final UnPeekLiveData<ExchangeTypeEnum> rootTypeBus = new UnPeekLiveData<>();

    /* compiled from: MainRootLiveDataBus.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u001b\u0010\u0003\u001a\u00020\u00048FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\u0007\u0010\b\u001a\u0004\b\u0005\u0010\u0006¨\u0006\t"}, d2 = {"Lcom/gateio/biz/base/dispatcher/MainRootLiveDataBus$Companion;", "", "()V", "instance", "Lcom/gateio/biz/base/dispatcher/MainRootLiveDataBus;", "getInstance", "()Lcom/gateio/biz/base/dispatcher/MainRootLiveDataBus;", "instance$delegate", "Lkotlin/Lazy;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final MainRootLiveDataBus getInstance() {
            return (MainRootLiveDataBus) MainRootLiveDataBus.instance$delegate.getValue();
        }
    }

    public final void destory() {
        this.rootTypeBus.setValue(null);
        this._exchangeTypeBus.setValue(null);
        this.exchangeSpotTypeBus.setValue(null);
    }

    @NotNull
    public final UnPeekLiveData<ExchangeTypeEnum> getExchangeSpotTypeBus() {
        return this.exchangeSpotTypeBus;
    }

    @NotNull
    public final LiveData<ExchangeTypeEnum> getExchangeTypeBus() {
        return this.exchangeTypeBus;
    }

    @NotNull
    public final UnPeekLiveData<ExchangeTypeEnum> getRootTypeBus() {
        return this.rootTypeBus;
    }

    public final void setExchangeTypeBus(@Nullable ExchangeTypeEnum exchangeTypeEnum) {
        this._exchangeTypeBus.setValue(exchangeTypeEnum);
    }

    public MainRootLiveDataBus() {
        UnPeekLiveData<ExchangeTypeEnum> unPeekLiveData = new UnPeekLiveData<>();
        this._exchangeTypeBus = unPeekLiveData;
        this.exchangeTypeBus = unPeekLiveData;
        this.exchangeSpotTypeBus = new UnPeekLiveData<>();
    }
}