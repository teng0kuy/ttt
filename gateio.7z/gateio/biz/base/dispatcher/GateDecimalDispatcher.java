package com.gateio.biz.base.dispatcher;

import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import com.gateio.biz.base.dispatcher.listener.DecimalListener;
import com.gateio.biz.base.dispatcher.listener.DecimalTransListener;
import com.gateio.biz.base.model.futures.entity.DepthAccuracy;
import com.gateio.common.tool.StringUtils;
import com.gateio.common.tool.TextUtils;
import com.gateio.lib.storage.GTStorage;
import com.google.android.gms.common.internal.ServiceSpecificExtraArgs;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.StringsKt__StringsJVMKt;
import kotlin.text.StringsKt__StringsKt;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GateDecimalDispatcher.kt */
@Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u000e\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\b\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J \u0010\u0014\u001a\u0004\u0018\u00010\u00102\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u0004J\u0018\u0010\u0019\u001a\u0004\u0018\u00010\u00102\u0006\u0010\u001a\u001a\u00020\u00042\u0006\u0010\u001b\u001a\u00020\u0004J\u0012\u0010\u001c\u001a\u0004\u0018\u00010\u00102\u0006\u0010\u001d\u001a\u00020\u0004H\u0002J\u0012\u0010\u001e\u001a\u0004\u0018\u00010\u00102\u0006\u0010\u001f\u001a\u00020\u0004H\u0002J\u0012\u0010 \u001a\u0004\u0018\u00010\u00102\u0006\u0010!\u001a\u00020\u0004H\u0002J\u0010\u0010\"\u001a\u00020\u00042\u0006\u0010\u0017\u001a\u00020\u0004H\u0002J\u0018\u0010#\u001a\u0004\u0018\u00010\u00102\u0006\u0010\u001a\u001a\u00020\u00042\u0006\u0010\u001b\u001a\u00020\u0004J&\u0010$\u001a\u00020%2\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u00042\u0006\u0010&\u001a\u00020\u0010J\u001e\u0010'\u001a\u00020%2\u0006\u0010\u001a\u001a\u00020\u00042\u0006\u0010\u001b\u001a\u00020\u00042\u0006\u0010&\u001a\u00020\u0010J\u001e\u0010(\u001a\u00020%2\u0006\u0010\u001a\u001a\u00020\u00042\u0006\u0010\u001b\u001a\u00020\u00042\u0006\u0010&\u001a\u00020\u0010J\u0016\u0010)\u001a\u00020%2\u0006\u0010*\u001a\u00020\r2\u0006\u0010+\u001a\u00020,J\u0016\u0010-\u001a\u00020%2\u0006\u0010*\u001a\u00020\u00122\u0006\u0010+\u001a\u00020,J\u0018\u0010.\u001a\u00020%2\u0006\u0010\u001d\u001a\u00020\u00042\u0006\u0010/\u001a\u00020\u0010H\u0002J\u0018\u00100\u001a\u00020%2\u0006\u0010!\u001a\u00020\u00042\u0006\u0010/\u001a\u00020\u0010H\u0002J\u0018\u00101\u001a\u00020%2\u0006\u0010!\u001a\u00020\u00042\u0006\u0010/\u001a\u00020\u0010H\u0002J\u000e\u00102\u001a\u00020%2\u0006\u0010*\u001a\u00020\rJ\u000e\u00103\u001a\u00020%2\u0006\u0010*\u001a\u00020\u0012R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00100\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00120\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0013\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00100\u000fX\u0082\u0004¢\u0006\u0002\n\u0000¨\u00064"}, d2 = {"Lcom/gateio/biz/base/dispatcher/GateDecimalDispatcher;", "", "()V", "FUTURES_TEST", "", "FUTURES_TYPE", "PILOT_TYPE", "SPLIT", "SPOT_TYPE", "gson", "Lcom/google/gson/Gson;", "mDecimalListeners", "", "Lcom/gateio/biz/base/dispatcher/listener/DecimalListener;", "mDecimalMap", "", "Lcom/gateio/biz/base/model/futures/entity/DepthAccuracy;", "mTransDecimalListeners", "Lcom/gateio/biz/base/dispatcher/listener/DecimalTransListener;", "mTransDecimalMap", "getFuturesDecimal", "isTest", "", "contract", "closeUnit", "getPilotDecimal", "currencyType", "exchangeType", "getSPFuturesDecimal", "futuresKey", "getSPPilotDecimal", "pilotKey", "getSPSpotDecimal", "spotKey", "getShowContract", "getTransDecimal", "notifyFuturesDecimal", "", "decimal", "notifyPilotDecimal", "notifyTransDecimal", "registerDecimal", ServiceSpecificExtraArgs.CastExtraArgs.LISTENER, "lifecycle", "Landroidx/lifecycle/Lifecycle;", "registerTransDecimal", "setSPFuturesDecimal", "depthAccuracy", "setSPPilotDecimal", "setSPSpotDecimal", "unRegisterDecimal", "unRegisterTransDecimal", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nGateDecimalDispatcher.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GateDecimalDispatcher.kt\ncom/gateio/biz/base/dispatcher/GateDecimalDispatcher\n+ 2 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n*L\n1#1,217:1\n37#2,2:218\n*S KotlinDebug\n*F\n+ 1 GateDecimalDispatcher.kt\ncom/gateio/biz/base/dispatcher/GateDecimalDispatcher\n*L\n212#1:218,2\n*E\n"})
/* loaded from: classes4.dex */
public final class GateDecimalDispatcher {

    @NotNull
    private static final String FUTURES_TEST = "test";

    @NotNull
    private static final String FUTURES_TYPE = "futures_";

    @NotNull
    private static final String PILOT_TYPE = "pilot_";

    @NotNull
    private static final String SPLIT = ":";

    @NotNull
    private static final String SPOT_TYPE = "spot_";

    @NotNull
    public static final GateDecimalDispatcher INSTANCE = new GateDecimalDispatcher();

    @NotNull
    private static final Gson gson = new Gson();

    @NotNull
    private static final List<DecimalListener> mDecimalListeners = new ArrayList();

    @NotNull
    private static final List<DecimalTransListener> mTransDecimalListeners = new ArrayList();

    @NotNull
    private static final Map<String, DepthAccuracy> mDecimalMap = new LinkedHashMap();

    @NotNull
    private static final Map<String, DepthAccuracy> mTransDecimalMap = new LinkedHashMap();

    private GateDecimalDispatcher() {
    }

    private final DepthAccuracy getSPFuturesDecimal(String futuresKey) {
        Map<String, DepthAccuracy> map = mDecimalMap;
        DepthAccuracy depthAccuracy = map.get(futuresKey);
        if (depthAccuracy != null) {
            return depthAccuracy;
        }
        String strQueryStringOrNullKV$default = GTStorage.queryStringOrNullKV$default(FUTURES_TYPE + futuresKey, null, null, 4, null);
        if (strQueryStringOrNullKV$default == null) {
            return null;
        }
        DepthAccuracy depthAccuracy2 = (DepthAccuracy) gson.fromJson(strQueryStringOrNullKV$default, DepthAccuracy.class);
        if (depthAccuracy2 != null) {
            map.put(futuresKey, depthAccuracy2);
        }
        return depthAccuracy2;
    }

    private final DepthAccuracy getSPPilotDecimal(String pilotKey) {
        Map<String, DepthAccuracy> map = mTransDecimalMap;
        DepthAccuracy depthAccuracy = map.get(pilotKey);
        if (depthAccuracy != null) {
            return depthAccuracy;
        }
        String strQueryStringOrNullKV$default = GTStorage.queryStringOrNullKV$default(PILOT_TYPE + pilotKey, null, null, 4, null);
        if (strQueryStringOrNullKV$default == null) {
            return null;
        }
        DepthAccuracy depthAccuracy2 = (DepthAccuracy) gson.fromJson(strQueryStringOrNullKV$default, DepthAccuracy.class);
        if (depthAccuracy2 != null) {
            map.put(pilotKey, depthAccuracy2);
        }
        return depthAccuracy2;
    }

    private final DepthAccuracy getSPSpotDecimal(String spotKey) {
        Map<String, DepthAccuracy> map = mTransDecimalMap;
        DepthAccuracy depthAccuracy = map.get(spotKey);
        if (depthAccuracy != null) {
            return depthAccuracy;
        }
        String strQueryStringOrNullKV$default = GTStorage.queryStringOrNullKV$default(SPOT_TYPE + spotKey, null, null, 4, null);
        if (strQueryStringOrNullKV$default == null) {
            return null;
        }
        DepthAccuracy depthAccuracy2 = (DepthAccuracy) gson.fromJson(strQueryStringOrNullKV$default, DepthAccuracy.class);
        if (depthAccuracy2 != null) {
            map.put(spotKey, depthAccuracy2);
        }
        return depthAccuracy2;
    }

    private final void setSPFuturesDecimal(String futuresKey, DepthAccuracy depthAccuracy) {
        mDecimalMap.put(futuresKey, depthAccuracy);
        GTStorage.saveKV$default(FUTURES_TYPE + futuresKey, gson.toJson(depthAccuracy), null, 4, null);
    }

    private final void setSPPilotDecimal(String spotKey, DepthAccuracy depthAccuracy) {
        mTransDecimalMap.put(spotKey, depthAccuracy);
        GTStorage.saveKV$default(PILOT_TYPE + spotKey, gson.toJson(depthAccuracy), null, 4, null);
    }

    private final void setSPSpotDecimal(String spotKey, DepthAccuracy depthAccuracy) {
        mTransDecimalMap.put(spotKey, depthAccuracy);
        GTStorage.saveKV$default(SPOT_TYPE + spotKey, gson.toJson(depthAccuracy), null, 4, null);
    }

    @Nullable
    public final DepthAccuracy getFuturesDecimal(boolean isTest, @NotNull String contract, @NotNull String closeUnit) {
        String str;
        if (isTest) {
            str = "test:" + getShowContract(contract) + AbstractJsonLexerKt.COLON + closeUnit;
        } else {
            str = getShowContract(contract) + AbstractJsonLexerKt.COLON + closeUnit;
        }
        return getSPFuturesDecimal(str);
    }

    @Nullable
    public final DepthAccuracy getPilotDecimal(@NotNull String currencyType, @NotNull String exchangeType) {
        return getSPPilotDecimal(currencyType + AbstractJsonLexerKt.COLON + exchangeType);
    }

    @Nullable
    public final DepthAccuracy getTransDecimal(@NotNull String currencyType, @NotNull String exchangeType) {
        return getSPSpotDecimal(currencyType + AbstractJsonLexerKt.COLON + exchangeType);
    }

    public final void notifyFuturesDecimal(boolean isTest, @NotNull String contract, @NotNull String closeUnit, @NotNull DepthAccuracy decimal) {
        String str;
        if (isTest) {
            str = "test:" + getShowContract(contract) + AbstractJsonLexerKt.COLON + closeUnit;
        } else {
            str = getShowContract(contract) + AbstractJsonLexerKt.COLON + closeUnit;
        }
        setSPFuturesDecimal(str, decimal);
        Iterator<DecimalListener> it = mDecimalListeners.iterator();
        while (it.hasNext()) {
            it.next().updateDecimal(isTest, contract, closeUnit, decimal);
        }
    }

    public final void notifyPilotDecimal(@NotNull String currencyType, @NotNull String exchangeType, @NotNull DepthAccuracy decimal) {
        setSPPilotDecimal(currencyType + AbstractJsonLexerKt.COLON + exchangeType, decimal);
        Iterator<DecimalTransListener> it = mTransDecimalListeners.iterator();
        while (it.hasNext()) {
            it.next().updateDecimal(currencyType, exchangeType, decimal);
        }
    }

    public final void notifyTransDecimal(@NotNull String currencyType, @NotNull String exchangeType, @NotNull DepthAccuracy decimal) {
        setSPSpotDecimal(currencyType + AbstractJsonLexerKt.COLON + exchangeType, decimal);
        Iterator<DecimalTransListener> it = mTransDecimalListeners.iterator();
        while (it.hasNext()) {
            it.next().updateDecimal(currencyType, exchangeType, decimal);
        }
    }

    public final void registerDecimal(@NotNull final DecimalListener listener, @NotNull final Lifecycle lifecycle) {
        List<DecimalListener> list = mDecimalListeners;
        if (list.contains(listener)) {
            return;
        }
        list.add(listener);
        lifecycle.addObserver(new DefaultLifecycleObserver() { // from class: com.gateio.biz.base.dispatcher.GateDecimalDispatcher.registerDecimal.1
            @Override // androidx.lifecycle.DefaultLifecycleObserver
            public void onDestroy(@NotNull LifecycleOwner owner) {
                GateDecimalDispatcher.INSTANCE.unRegisterDecimal(listener);
                lifecycle.removeObserver(this);
            }
        });
    }

    public final void registerTransDecimal(@NotNull final DecimalTransListener listener, @NotNull final Lifecycle lifecycle) {
        List<DecimalTransListener> list = mTransDecimalListeners;
        if (list.contains(listener)) {
            return;
        }
        list.add(listener);
        lifecycle.addObserver(new DefaultLifecycleObserver() { // from class: com.gateio.biz.base.dispatcher.GateDecimalDispatcher.registerTransDecimal.1
            @Override // androidx.lifecycle.DefaultLifecycleObserver
            public void onDestroy(@NotNull LifecycleOwner owner) {
                GateDecimalDispatcher.INSTANCE.unRegisterTransDecimal(listener);
                lifecycle.removeObserver(this);
            }
        });
    }

    public final void unRegisterDecimal(@NotNull DecimalListener listener) {
        mDecimalListeners.remove(listener);
    }

    public final void unRegisterTransDecimal(@NotNull DecimalTransListener listener) {
        mTransDecimalListeners.remove(listener);
    }

    private final String getShowContract(String contract) {
        if (!TextUtils.isEmpty(contract)) {
            return StringsKt__StringsJVMKt.replace$default(((String[]) StringsKt__StringsKt.split$default((CharSequence) StringUtils.trimToEmpty(contract), new String[]{":"}, false, 0, 6, (Object) null).toArray(new String[0]))[0], "_", "/", false, 4, (Object) null);
        }
        return StringUtils.trimToEmpty(contract);
    }
}