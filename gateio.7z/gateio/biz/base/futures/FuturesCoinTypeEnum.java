package com.gateio.biz.base.futures;

/* loaded from: classes4.dex */
public enum FuturesCoinTypeEnum {
    COIN,
    ZHANG,
    U,
    U_C;

    public boolean isCoin() {
        return equals(COIN);
    }

    public boolean isUNew() {
        return equals(U) || equals(U_C);
    }

    public boolean isU_C() {
        return equals(U_C);
    }

    public boolean isU_V() {
        return equals(U);
    }

    public boolean isZhang() {
        return equals(ZHANG);
    }
}