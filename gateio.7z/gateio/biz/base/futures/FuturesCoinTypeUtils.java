package com.gateio.biz.base.futures;

import com.gateio.biz.base.BizBaseConstants;
import com.gateio.biz.base.router.RouterConst;
import com.gateio.biz.base.router.provider.FuturesSubjectService;
import com.gateio.lib.router.GTRouter;
import com.gateio.lib.storage.GTStorage;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: FuturesCoinTypeUtils.kt */
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0005\u001a\u00020\u00042\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007J\u0006\u0010\b\u001a\u00020\u0004J\u0006\u0010\t\u001a\u00020\u0004J\u0006\u0010\n\u001a\u00020\u000bJ\u0006\u0010\f\u001a\u00020\u000bJ\u0006\u0010\r\u001a\u00020\u000bJ\u0006\u0010\u000e\u001a\u00020\u000bJ\u0006\u0010\u000f\u001a\u00020\u000bJ\u000e\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0006\u001a\u00020\u0004R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0012"}, d2 = {"Lcom/gateio/biz/base/futures/FuturesCoinTypeUtils;", "", "()V", "coinTypeEnum", "Lcom/gateio/biz/base/futures/FuturesCoinTypeEnum;", "defaultValueOf", "enum", "", "getFuturesTypeEnum", "getFuturesTypeFlutterEnum", "isCoinUnit", "", "isUCostUnit", "isUNewUnit", "isUValueUnit", "isZhangUnit", "putFuturesEnum", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class FuturesCoinTypeUtils {

    @NotNull
    public static final FuturesCoinTypeUtils INSTANCE = new FuturesCoinTypeUtils();

    @Nullable
    private static FuturesCoinTypeEnum coinTypeEnum;

    private FuturesCoinTypeUtils() {
    }

    @NotNull
    public final FuturesCoinTypeEnum defaultValueOf(@Nullable String str) {
        if (str == null) {
            try {
                str = FuturesCoinTypeEnum.ZHANG.toString();
            } catch (Exception unused) {
                return FuturesCoinTypeEnum.ZHANG;
            }
        }
        return FuturesCoinTypeEnum.valueOf(str);
    }

    @NotNull
    public final FuturesCoinTypeEnum getFuturesTypeEnum() {
        FuturesCoinTypeEnum futuresCoinTypeEnum = coinTypeEnum;
        if (futuresCoinTypeEnum != null) {
            return futuresCoinTypeEnum;
        }
        FuturesCoinTypeEnum futuresCoinTypeEnumDefaultValueOf = defaultValueOf(GTStorage.queryStringKV$default(BizBaseConstants.FuturesKey.FUTURES_COIN2ZHANG2U, FuturesCoinTypeEnum.COIN.toString(), null, 4, null));
        coinTypeEnum = futuresCoinTypeEnumDefaultValueOf;
        return futuresCoinTypeEnumDefaultValueOf;
    }

    public final void putFuturesEnum(@NotNull FuturesCoinTypeEnum futuresCoinTypeEnum) {
        coinTypeEnum = futuresCoinTypeEnum;
        GTStorage.saveKV$default(BizBaseConstants.FuturesKey.FUTURES_COIN2ZHANG2U, futuresCoinTypeEnum.toString(), null, 4, null);
        FuturesSubjectService futuresSubjectService = (FuturesSubjectService) GTRouter.serviceAPI(RouterConst.Futures.FUTURES_SUBJECT);
        if (futuresSubjectService != null) {
            futuresSubjectService.setAmountType(futuresCoinTypeEnum);
        }
    }

    @NotNull
    public final FuturesCoinTypeEnum getFuturesTypeFlutterEnum() {
        FuturesCoinTypeEnum futuresTypeEnum = getFuturesTypeEnum();
        if (futuresTypeEnum.isUNew()) {
            return FuturesCoinTypeEnum.U;
        }
        return futuresTypeEnum;
    }

    public final boolean isCoinUnit() {
        return getFuturesTypeEnum().isCoin();
    }

    public final boolean isUCostUnit() {
        return getFuturesTypeEnum().isU_C();
    }

    public final boolean isUNewUnit() {
        return getFuturesTypeEnum().isUNew();
    }

    public final boolean isUValueUnit() {
        return getFuturesTypeEnum().isU_V();
    }

    public final boolean isZhangUnit() {
        return getFuturesTypeEnum().isZhang();
    }
}