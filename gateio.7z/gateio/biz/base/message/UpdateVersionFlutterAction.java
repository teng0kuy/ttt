package com.gateio.biz.base.message;

import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import org.jetbrains.annotations.NotNull;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: UpdateVersionFlutterAction.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0003\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003¨\u0006\u0004"}, d2 = {"Lcom/gateio/biz/base/message/UpdateVersionFlutterAction;", "", "(Ljava/lang/String;I)V", "onUpdateStatusChange", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class UpdateVersionFlutterAction {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ UpdateVersionFlutterAction[] $VALUES;
    public static final UpdateVersionFlutterAction onUpdateStatusChange = new UpdateVersionFlutterAction("onUpdateStatusChange", 0);

    private static final /* synthetic */ UpdateVersionFlutterAction[] $values() {
        return new UpdateVersionFlutterAction[]{onUpdateStatusChange};
    }

    static {
        UpdateVersionFlutterAction[] updateVersionFlutterActionArr$values = $values();
        $VALUES = updateVersionFlutterActionArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(updateVersionFlutterActionArr$values);
    }

    @NotNull
    public static EnumEntries<UpdateVersionFlutterAction> getEntries() {
        return $ENTRIES;
    }

    public static UpdateVersionFlutterAction valueOf(String str) {
        return (UpdateVersionFlutterAction) Enum.valueOf(UpdateVersionFlutterAction.class, str);
    }

    public static UpdateVersionFlutterAction[] values() {
        return (UpdateVersionFlutterAction[]) $VALUES.clone();
    }

    private UpdateVersionFlutterAction(String str, int i10) {
    }
}