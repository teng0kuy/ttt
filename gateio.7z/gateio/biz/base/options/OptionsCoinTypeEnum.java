package com.gateio.biz.base.options;

import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import org.jetbrains.annotations.NotNull;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: OptionsCoinTypeEnum.kt */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u00048F¢\u0006\u0006\u001a\u0004\b\u0003\u0010\u0005R\u0011\u0010\u0006\u001a\u00020\u00048F¢\u0006\u0006\u001a\u0004\b\u0006\u0010\u0005j\u0002\b\u0007j\u0002\b\b¨\u0006\t"}, d2 = {"Lcom/gateio/biz/base/options/OptionsCoinTypeEnum;", "", "(Ljava/lang/String;I)V", "isCoin", "", "()Z", "isZhang", "COIN", "ZHANG", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class OptionsCoinTypeEnum {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ OptionsCoinTypeEnum[] $VALUES;
    public static final OptionsCoinTypeEnum COIN = new OptionsCoinTypeEnum("COIN", 0);
    public static final OptionsCoinTypeEnum ZHANG = new OptionsCoinTypeEnum("ZHANG", 1);

    private static final /* synthetic */ OptionsCoinTypeEnum[] $values() {
        return new OptionsCoinTypeEnum[]{COIN, ZHANG};
    }

    static {
        OptionsCoinTypeEnum[] optionsCoinTypeEnumArr$values = $values();
        $VALUES = optionsCoinTypeEnumArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(optionsCoinTypeEnumArr$values);
    }

    @NotNull
    public static EnumEntries<OptionsCoinTypeEnum> getEntries() {
        return $ENTRIES;
    }

    public static OptionsCoinTypeEnum valueOf(String str) {
        return (OptionsCoinTypeEnum) Enum.valueOf(OptionsCoinTypeEnum.class, str);
    }

    public static OptionsCoinTypeEnum[] values() {
        return (OptionsCoinTypeEnum[]) $VALUES.clone();
    }

    public final boolean isCoin() {
        return this == COIN;
    }

    public final boolean isZhang() {
        return this == ZHANG;
    }

    private OptionsCoinTypeEnum(String str, int i10) {
    }
}