package com.gateio.biz.base;

import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import androidx.databinding.DataBinderMapper;
import androidx.databinding.DataBindingComponent;
import androidx.databinding.ViewDataBinding;
import com.gateio.biz.base.databinding.DialogSelectTypeFragmentBindingImpl;
import com.gateio.biz.base.databinding.LayoutHeaderSimpleBindingImpl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/* loaded from: classes4.dex */
public class DataBinderMapperImpl extends DataBinderMapper {
    private static final SparseIntArray INTERNAL_LAYOUT_ID_LOOKUP;
    private static final int LAYOUT_DIALOGSELECTTYPEFRAGMENT = 1;
    private static final int LAYOUT_LAYOUTHEADERSIMPLE = 2;

    private static class InnerBrLookup {
        static final SparseArray<String> sKeys;

        private InnerBrLookup() {
        }

        static {
            SparseArray<String> sparseArray = new SparseArray<>(1);
            sKeys = sparseArray;
            sparseArray.put(0, "_all");
        }
    }

    private static class InnerLayoutIdLookup {
        static final HashMap<String, Integer> sKeys;

        private InnerLayoutIdLookup() {
        }

        static {
            HashMap<String, Integer> map = new HashMap<>(2);
            sKeys = map;
            map.put("layout/dialog_select_type_fragment_0", Integer.valueOf(R.layout.dialog_select_type_fragment));
            map.put("layout/layout_header_simple_0", Integer.valueOf(R.layout.layout_header_simple));
        }
    }

    @Override // androidx.databinding.DataBinderMapper
    public ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View view, int i10) {
        int i11 = INTERNAL_LAYOUT_ID_LOOKUP.get(i10);
        if (i11 <= 0) {
            return null;
        }
        Object tag = view.getTag();
        if (tag == null) {
            throw new RuntimeException("view must have a tag");
        }
        if (i11 == 1) {
            if ("layout/dialog_select_type_fragment_0".equals(tag)) {
                return new DialogSelectTypeFragmentBindingImpl(dataBindingComponent, view);
            }
            throw new IllegalArgumentException("The tag for dialog_select_type_fragment is invalid. Received: " + tag);
        }
        if (i11 != 2) {
            return null;
        }
        if ("layout/layout_header_simple_0".equals(tag)) {
            return new LayoutHeaderSimpleBindingImpl(dataBindingComponent, view);
        }
        throw new IllegalArgumentException("The tag for layout_header_simple is invalid. Received: " + tag);
    }

    @Override // androidx.databinding.DataBinderMapper
    public int getLayoutId(String str) {
        Integer num;
        if (str == null || (num = InnerLayoutIdLookup.sKeys.get(str)) == null) {
            return 0;
        }
        return num.intValue();
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray(2);
        INTERNAL_LAYOUT_ID_LOOKUP = sparseIntArray;
        sparseIntArray.put(R.layout.dialog_select_type_fragment, 1);
        sparseIntArray.put(R.layout.layout_header_simple, 2);
    }

    @Override // androidx.databinding.DataBinderMapper
    public List<DataBinderMapper> collectDependencies() {
        ArrayList arrayList = new ArrayList(4);
        arrayList.add(new androidx.databinding.library.baseAdapters.DataBinderMapperImpl());
        arrayList.add(new com.chad.library.DataBinderMapperImpl());
        arrayList.add(new com.gateio.lib.core.DataBinderMapperImpl());
        arrayList.add(new com.gateio.lib.uikit.DataBinderMapperImpl());
        return arrayList;
    }

    @Override // androidx.databinding.DataBinderMapper
    public String convertBrIdToString(int i10) {
        return InnerBrLookup.sKeys.get(i10);
    }

    @Override // androidx.databinding.DataBinderMapper
    public ViewDataBinding getDataBinder(DataBindingComponent dataBindingComponent, View[] viewArr, int i10) {
        if (viewArr == null || viewArr.length == 0 || INTERNAL_LAYOUT_ID_LOOKUP.get(i10) <= 0 || viewArr[0].getTag() != null) {
            return null;
        }
        throw new RuntimeException("view must have a tag");
    }
}