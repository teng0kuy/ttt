package com.gateio.biz.base.dao;

import com.gateio.biz.base.model.CurrencyData;
import com.gateio.common.tool.StringUtils;
import com.gateio.lib.storage.GTStorage;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes4.dex */
public class CurrencyUtils {
    private static Map<String, String> symbols;

    public static String getSymbol(String str) {
        Map<String, String> map = symbols;
        if (map == null) {
            symbols = new HashMap();
            return initSymbol(str);
        }
        String str2 = map.get(str);
        return !StringUtils.isEmpty(str2) ? str2 : initSymbol(str);
    }

    private static String initSymbol(String str) {
        CurrencyData currencyData = (CurrencyData) GTStorage.query(CurrencyData.class).equalTo("currencyType", str).findFirst();
        String strSubstring = (currencyData == null || StringUtils.isEmpty(currencyData.getSymbol())) ? str.substring(0, 1) : currencyData.getSymbol();
        symbols.put(str, strSubstring);
        return strSubstring;
    }
}