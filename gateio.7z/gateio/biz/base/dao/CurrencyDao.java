package com.gateio.biz.base.dao;

import com.gateio.biz.base.model.CurrencyData;
import com.gateio.biz.base.model.CurrencyDataVersion;
import com.gateio.biz_options.datafinder.GTOptionsEvent;
import com.gateio.common.tool.StringUtils;
import com.gateio.lib.storage.GTStorage;
import io.realm.Sort;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: CurrencyDao.kt */
@Metadata(d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010%\u001a\u00020&H\u0007J\u0016\u0010'\u001a\b\u0012\u0004\u0012\u00020\u00050\u00042\u0006\u0010(\u001a\u00020\u001aH\u0007J\u0014\u0010)\u001a\u0004\u0018\u00010\u00052\b\u0010*\u001a\u0004\u0018\u00010\u001aH\u0007J\u0012\u0010+\u001a\u0004\u0018\u00010\u00052\u0006\u0010*\u001a\u00020\u001aH\u0007J\u001a\u0010,\u001a\u0004\u0018\u00010\u00052\b\u0010*\u001a\u0004\u0018\u00010\u001aH\u0087@¢\u0006\u0002\u0010-J\u0018\u0010.\u001a\u00020&2\u000e\u0010/\u001a\n\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u0004H\u0002J\u001a\u00100\u001a\u00020\u00162\u0006\u00101\u001a\u0002022\b\b\u0002\u00103\u001a\u00020\u0016H\u0007R \u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u00048FX\u0087\u0004¢\u0006\f\u0012\u0004\b\u0006\u0010\u0002\u001a\u0004\b\u0007\u0010\bR\"\u0010\t\u001a\n\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u00048FX\u0087\u0004¢\u0006\f\u0012\u0004\b\n\u0010\u0002\u001a\u0004\b\u000b\u0010\bR \u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00050\u00048FX\u0087\u0004¢\u0006\f\u0012\u0004\b\r\u0010\u0002\u001a\u0004\b\u000e\u0010\bR\"\u0010\u000f\u001a\n\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u00048FX\u0087\u0004¢\u0006\f\u0012\u0004\b\u0010\u0010\u0002\u001a\u0004\b\u0011\u0010\bR \u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00050\u00048FX\u0087\u0004¢\u0006\f\u0012\u0004\b\u0013\u0010\u0002\u001a\u0004\b\u0014\u0010\bR\u0014\u0010\u0015\u001a\u00020\u00168BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0015\u0010\u0017R\u001c\u0010\u0018\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u001a\u0012\u0004\u0012\u00020\u00050\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u001b\u001a\u00020\u001c8FX\u0087\u0004¢\u0006\f\u0012\u0004\b\u001d\u0010\u0002\u001a\u0004\b\u001e\u0010\u001fR\u001a\u0010 \u001a\u00020!8FX\u0087\u0004¢\u0006\f\u0012\u0004\b\"\u0010\u0002\u001a\u0004\b#\u0010$¨\u00064"}, d2 = {"Lcom/gateio/biz/base/dao/CurrencyDao;", "", "()V", "all", "", "Lcom/gateio/biz/base/model/CurrencyData;", "getAll$annotations", "getAll", "()Ljava/util/List;", "allDeposit", "getAllDeposit$annotations", "getAllDeposit", "allFilterFiat", "getAllFilterFiat$annotations", "getAllFilterFiat", "allWithdraw", "getAllWithdraw$annotations", "getAllWithdraw", "assets", "getAssets$annotations", "getAssets", "isCacheValid", "", "()Z", "mMap", "Ljava/util/concurrent/ConcurrentHashMap;", "", GTOptionsEvent.value_size, "", "getSize$annotations", "getSize", "()I", "size2", "", "getSize2$annotations", "getSize2", "()J", "clear", "", "getAssetsExcept", "currency", "getIfon", "currencyType", "getIfonVisibility", "getIfonWithSuspend", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "setCache", "currencyDatas", "update", "currencyDataVersion", "Lcom/gateio/biz/base/model/CurrencyDataVersion;", "isAssetsJson", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class CurrencyDao {

    @NotNull
    public static final CurrencyDao INSTANCE = new CurrencyDao();

    @NotNull
    private static final ConcurrentHashMap<String, CurrencyData> mMap = new ConcurrentHashMap<>();

    /* compiled from: CurrencyDao.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    @DebugMetadata(c = "com.gateio.biz.base.dao.CurrencyDao", f = "CurrencyDao.kt", i = {0}, l = {54}, m = "getIfonWithSuspend", n = {"currencyType"}, s = {"L$0"})
    /* renamed from: com.gateio.biz.base.dao.CurrencyDao$getIfonWithSuspend$1, reason: invalid class name */
    static final class AnonymousClass1 extends ContinuationImpl {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return CurrencyDao.getIfonWithSuspend(null, this);
        }

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(continuation);
        }
    }

    private CurrencyDao() {
    }

    private final void setCache(List<? extends CurrencyData> currencyDatas) {
        List<? extends CurrencyData> list = currencyDatas;
        if (list == null || list.isEmpty()) {
            return;
        }
        for (CurrencyData currencyData : currencyDatas) {
            mMap.put(currencyData.getCurrencyType(), currencyData);
        }
    }

    @JvmStatic
    public static final void clear() {
        GTStorage.delete(CurrencyData.class).removeAll();
        mMap.clear();
    }

    @NotNull
    public static final List<CurrencyData> getAll() {
        CurrencyDao currencyDao = INSTANCE;
        if (currencyDao.isCacheValid()) {
            return new ArrayList(mMap.values());
        }
        List<CurrencyData> listFindAll = GTStorage.query(CurrencyData.class).findAll();
        currencyDao.setCache(listFindAll);
        return listFindAll == null ? CollectionsKt__CollectionsKt.emptyList() : listFindAll;
    }

    @Nullable
    public static final List<CurrencyData> getAllDeposit() {
        return GTStorage.query(CurrencyData.class).notEqualTo("isFiat", "1").findAll();
    }

    @NotNull
    public static final List<CurrencyData> getAllFilterFiat() {
        List<CurrencyData> listFindAll = GTStorage.query(CurrencyData.class).notEqualTo("isFiat", "1").findAll();
        return listFindAll == null ? CollectionsKt__CollectionsKt.emptyList() : listFindAll;
    }

    @Nullable
    public static final List<CurrencyData> getAllWithdraw() {
        return GTStorage.query(CurrencyData.class).notEqualTo("isFiat", "1").findAll();
    }

    @NotNull
    public static final List<CurrencyData> getAssets() {
        List<CurrencyData> listFindAll = GTStorage.query(CurrencyData.class).equalTo("is_visibility", "1").notEqualTo("isFiat", "1").sort("seq", Sort.ASCENDING).findAll();
        return listFindAll == null ? CollectionsKt__CollectionsKt.emptyList() : listFindAll;
    }

    @JvmStatic
    @NotNull
    public static final List<CurrencyData> getAssetsExcept(@NotNull String currency) {
        List<CurrencyData> listFindAll = GTStorage.query(CurrencyData.class).equalTo("is_visibility", "1").notEqualTo("isFiat", "1").notEqualTo("currencyType", currency).sort("seq", Sort.ASCENDING).findAll();
        return listFindAll == null ? CollectionsKt__CollectionsKt.emptyList() : listFindAll;
    }

    @JvmStatic
    @Nullable
    public static final CurrencyData getIfon(@Nullable String currencyType) {
        CurrencyData currencyData;
        if (currencyType == null) {
            return null;
        }
        ConcurrentHashMap<String, CurrencyData> concurrentHashMap = mMap;
        if (concurrentHashMap.containsKey(currencyType) && (currencyData = concurrentHashMap.get(currencyType)) != null) {
            return currencyData;
        }
        CurrencyData currencyData2 = (CurrencyData) GTStorage.query(CurrencyData.class).equalTo("currencyType", currencyType).findFirst();
        if (currencyData2 != null) {
            concurrentHashMap.put(currencyType, currencyData2);
        }
        return currencyData2;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    @kotlin.jvm.JvmStatic
    @org.jetbrains.annotations.Nullable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final java.lang.Object getIfonWithSuspend(@org.jetbrains.annotations.Nullable java.lang.String r5, @org.jetbrains.annotations.NotNull kotlin.coroutines.Continuation<? super com.gateio.biz.base.model.CurrencyData> r6) throws java.lang.Throwable {
        /*
            boolean r0 = r6 instanceof com.gateio.biz.base.dao.CurrencyDao.AnonymousClass1
            if (r0 == 0) goto L13
            r0 = r6
            com.gateio.biz.base.dao.CurrencyDao$getIfonWithSuspend$1 r0 = (com.gateio.biz.base.dao.CurrencyDao.AnonymousClass1) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.label = r1
            goto L18
        L13:
            com.gateio.biz.base.dao.CurrencyDao$getIfonWithSuspend$1 r0 = new com.gateio.biz.base.dao.CurrencyDao$getIfonWithSuspend$1
            r0.<init>(r6)
        L18:
            java.lang.Object r6 = r0.result
            java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L36
            if (r2 != r3) goto L2d
            java.lang.Object r5 = r0.L$0
            java.lang.String r5 = (java.lang.String) r5
            kotlin.ResultKt.throwOnFailure(r6)
            goto L62
        L2d:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r6)
            throw r5
        L36:
            kotlin.ResultKt.throwOnFailure(r6)
            r6 = 0
            if (r5 != 0) goto L3d
            return r6
        L3d:
            java.util.concurrent.ConcurrentHashMap<java.lang.String, com.gateio.biz.base.model.CurrencyData> r2 = com.gateio.biz.base.dao.CurrencyDao.mMap
            boolean r4 = r2.containsKey(r5)
            if (r4 == 0) goto L4e
            java.lang.Object r2 = r2.get(r5)
            com.gateio.biz.base.model.CurrencyData r2 = (com.gateio.biz.base.model.CurrencyData) r2
            if (r2 == 0) goto L4e
            return r2
        L4e:
            kotlinx.coroutines.CoroutineDispatcher r2 = kotlinx.coroutines.Dispatchers.getIO()
            com.gateio.biz.base.dao.CurrencyDao$getIfonWithSuspend$currencyData$1 r4 = new com.gateio.biz.base.dao.CurrencyDao$getIfonWithSuspend$currencyData$1
            r4.<init>(r5, r6)
            r0.L$0 = r5
            r0.label = r3
            java.lang.Object r6 = kotlinx.coroutines.BuildersKt.withContext(r2, r4, r0)
            if (r6 != r1) goto L62
            return r1
        L62:
            com.gateio.biz.base.model.CurrencyData r6 = (com.gateio.biz.base.model.CurrencyData) r6
            if (r6 == 0) goto L6b
            java.util.concurrent.ConcurrentHashMap<java.lang.String, com.gateio.biz.base.model.CurrencyData> r0 = com.gateio.biz.base.dao.CurrencyDao.mMap
            r0.put(r5, r6)
        L6b:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.gateio.biz.base.dao.CurrencyDao.getIfonWithSuspend(java.lang.String, kotlin.coroutines.Continuation):java.lang.Object");
    }

    public static final int getSize() {
        if (INSTANCE.isCacheValid()) {
            return mMap.size();
        }
        List listFindAll = GTStorage.query(CurrencyData.class).findAll();
        Integer numValueOf = listFindAll != null ? Integer.valueOf(listFindAll.size()) : null;
        if (numValueOf != null) {
            return numValueOf.intValue();
        }
        return 0;
    }

    public static final long getSize2() {
        return GTStorage.query(CurrencyData.class).count();
    }

    private final boolean isCacheValid() {
        ConcurrentHashMap<String, CurrencyData> concurrentHashMap = mMap;
        return !concurrentHashMap.isEmpty() && concurrentHashMap.size() > 100;
    }

    public static /* synthetic */ boolean update$default(CurrencyDataVersion currencyDataVersion, boolean z10, int i10, Object obj) {
        if ((i10 & 2) != 0) {
            z10 = false;
        }
        return update(currencyDataVersion, z10);
    }

    @JvmStatic
    @Nullable
    public static final CurrencyData getIfonVisibility(@NotNull String currencyType) {
        CurrencyData ifon = getIfon(currencyType);
        if (ifon == null || !StringUtils.equals(ifon.is_visibility(), "1")) {
            return null;
        }
        return ifon;
    }

    @JvmStatic
    public static final boolean update(@NotNull CurrencyDataVersion currencyDataVersion, boolean isAssetsJson) {
        List<CurrencyData> currencyDatas = currencyDataVersion.getCurrencyDatas();
        if (!isAssetsJson && currencyDatas != null && (!currencyDatas.isEmpty() || getSize() != 0)) {
            String strQueryStringOrNullKV$default = GTStorage.queryStringOrNullKV$default(CurrencyDaoKt.getCURRENCY_DATA_VERSION_V3(), "0", null, 4, null);
            if (strQueryStringOrNullKV$default == null) {
                strQueryStringOrNullKV$default = "0";
            }
            if (currencyDataVersion.isFirstVersion() || Intrinsics.areEqual(strQueryStringOrNullKV$default, "0")) {
                clear();
            }
            try {
                INSTANCE.setCache(currencyDatas);
                GTStorage.save(currencyDatas);
                GTStorage.saveKV$default(CurrencyDaoKt.getCURRENCY_DATA_VERSION_V3(), currencyDataVersion.getVersion(), null, 4, null);
                return true;
            } catch (Exception unused) {
            }
        }
        return false;
    }

    @JvmStatic
    public static /* synthetic */ void getAll$annotations() {
    }

    @JvmStatic
    public static /* synthetic */ void getAllDeposit$annotations() {
    }

    @JvmStatic
    public static /* synthetic */ void getAllFilterFiat$annotations() {
    }

    @JvmStatic
    public static /* synthetic */ void getAllWithdraw$annotations() {
    }

    @JvmStatic
    public static /* synthetic */ void getAssets$annotations() {
    }

    @JvmStatic
    public static /* synthetic */ void getSize$annotations() {
    }

    @JvmStatic
    public static /* synthetic */ void getSize2$annotations() {
    }
}