package com.gateio.biz.base.dao;

import com.gateio.biz.base.model.AreaData;
import com.gateio.lib.storage.GTStorage;
import java.util.List;

/* loaded from: classes4.dex */
public class AreaDao {
    private static volatile AreaDao areaDao;

    public static AreaDao getInstance() {
        if (areaDao == null) {
            synchronized (AreaDao.class) {
                if (areaDao == null) {
                    areaDao = new AreaDao();
                }
            }
        }
        return areaDao;
    }

    public List<AreaData> getIfon(String str) {
        return GTStorage.query(AreaData.class).equalTo("parentId", str).findAll();
    }

    public int getSize() {
        return GTStorage.query(AreaData.class).findAll().size();
    }

    public void add(List<AreaData> list) {
        GTStorage.save(list);
    }
}