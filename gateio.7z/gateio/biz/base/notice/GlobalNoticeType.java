package com.gateio.biz.base.notice;

import com.gateio.biz.kline.utlis.KlinePriceSwitchUtil;
import com.gateio.common.tool.AccessUtil;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import org.jetbrains.annotations.NotNull;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: GlobalNoticeType.kt */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\b\f\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u000f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000e¨\u0006\u000f"}, d2 = {"Lcom/gateio/biz/base/notice/GlobalNoticeType;", "", "noticeType", "", "(Ljava/lang/String;ILjava/lang/String;)V", "getNoticeType", "()Ljava/lang/String;", KlinePriceSwitchUtil.KLINE_INDEX_PRICE, "SPOT", "FUTURES", "DELIVERY", "MARGIN", "WALLET", "COPYTRADING", "STRATEGY", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class GlobalNoticeType {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ GlobalNoticeType[] $VALUES;

    @NotNull
    private final String noticeType;
    public static final GlobalNoticeType INDEX = new GlobalNoticeType(KlinePriceSwitchUtil.KLINE_INDEX_PRICE, 0, "index");
    public static final GlobalNoticeType SPOT = new GlobalNoticeType("SPOT", 1, "spot");
    public static final GlobalNoticeType FUTURES = new GlobalNoticeType("FUTURES", 2, "futures");
    public static final GlobalNoticeType DELIVERY = new GlobalNoticeType("DELIVERY", 3, "delivery");
    public static final GlobalNoticeType MARGIN = new GlobalNoticeType("MARGIN", 4, "margin");
    public static final GlobalNoticeType WALLET = new GlobalNoticeType("WALLET", 5, "wallet");
    public static final GlobalNoticeType COPYTRADING = new GlobalNoticeType("COPYTRADING", 6, AccessUtil.WALLET.COPYTRADING);
    public static final GlobalNoticeType STRATEGY = new GlobalNoticeType("STRATEGY", 7, "strategy");

    private static final /* synthetic */ GlobalNoticeType[] $values() {
        return new GlobalNoticeType[]{INDEX, SPOT, FUTURES, DELIVERY, MARGIN, WALLET, COPYTRADING, STRATEGY};
    }

    static {
        GlobalNoticeType[] globalNoticeTypeArr$values = $values();
        $VALUES = globalNoticeTypeArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(globalNoticeTypeArr$values);
    }

    @NotNull
    public static EnumEntries<GlobalNoticeType> getEntries() {
        return $ENTRIES;
    }

    public static GlobalNoticeType valueOf(String str) {
        return (GlobalNoticeType) Enum.valueOf(GlobalNoticeType.class, str);
    }

    public static GlobalNoticeType[] values() {
        return (GlobalNoticeType[]) $VALUES.clone();
    }

    @NotNull
    public final String getNoticeType() {
        return this.noticeType;
    }

    private GlobalNoticeType(String str, int i10, String str2) {
        this.noticeType = str2;
    }
}