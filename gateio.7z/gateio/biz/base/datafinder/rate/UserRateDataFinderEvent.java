package com.gateio.biz.base.datafinder.rate;

import androidx.media3.extractor.text.ttml.TtmlNode;
import com.gate_sdk.web3_wallet.DeFiConstants;
import com.gateio.lib.datafinder.protocol.GTBaseFinderEvent;
import java.util.HashMap;
import java.util.Map;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: UserRateEvent.kt */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010\u0000\n\u0002\b\u0010\u0018\u0000 \u00122\u0016\u0012\u0012\u0012\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u00040\u00020\u0001:\u0003\u0011\u0012\u0013B%\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0016\u0010\u0006\u001a\u0012\u0012\u0004\u0012\u00020\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u0004\u0018\u00010\u0002¢\u0006\u0002\u0010\u0007J\u0016\u0010\u0010\u001a\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u00040\u0002H\u0016J\b\u0010\u0005\u001a\u00020\u0003H\u0016R\u001a\u0010\u0005\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\b\u0010\t\"\u0004\b\n\u0010\u000bR*\u0010\u0006\u001a\u0012\u0012\u0004\u0012\u00020\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u0004\u0018\u00010\u0002X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000f¨\u0006\u0014"}, d2 = {"Lcom/gateio/biz/base/datafinder/rate/UserRateDataFinderEvent;", "Lcom/gateio/lib/datafinder/protocol/GTBaseFinderEvent;", "", "", "", DeFiConstants.EventName, "logBody", "(Ljava/lang/String;Ljava/util/Map;)V", "getEventName", "()Ljava/lang/String;", "setEventName", "(Ljava/lang/String;)V", "getLogBody", "()Ljava/util/Map;", "setLogBody", "(Ljava/util/Map;)V", TtmlNode.TAG_BODY, "Attribute", "Companion", "Event", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class UserRateDataFinderEvent implements GTBaseFinderEvent<Map<String, ? extends Object>> {

    @NotNull
    public static final String ABOUT_US = "about us";

    @NotNull
    public static final String AMM = "amm";

    @NotNull
    public static final String BEARISH_SHARKFIN = "bearishsharkfin";

    @NotNull
    public static final String BULLISH_SHARKFIN = "bullishsharkfin";

    @NotNull
    public static final String DUAL_STAKING = "dualstaking";

    @NotNull
    public static final String ETH2_STAKING = "eth2staking";

    @NotNull
    public static final String GT_STAKING = "gtstaking";

    @NotNull
    public static final String LEND_EARN = "lendearn";

    @NotNull
    public static final String RATE_POPUP = "home_market_viewing";

    @NotNull
    public static final String SOL_STAKING = "solstaking";

    @NotNull
    public static final String SPOT_ORDER_ILLUSTRATE_SHEET = "spot_orderIllustrateSheet";

    @NotNull
    public static final String STARTUP = "startup";

    @NotNull
    public static final String TRX_STAKING = "trxstaking";

    @NotNull
    public static final String WITHDRAWAL = "withdrawal";

    @NotNull
    private String eventName;

    @Nullable
    private Map<String, ? extends Object> logBody;

    /* compiled from: UserRateEvent.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0006"}, d2 = {"Lcom/gateio/biz/base/datafinder/rate/UserRateDataFinderEvent$Attribute;", "", "()V", "BUTTON_NAME", "", "SOURCE", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Attribute {

        @NotNull
        public static final String BUTTON_NAME = "button_name";

        @NotNull
        public static final Attribute INSTANCE = new Attribute();

        @NotNull
        public static final String SOURCE = "source";

        private Attribute() {
        }
    }

    /* compiled from: UserRateEvent.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/base/datafinder/rate/UserRateDataFinderEvent$Event;", "", "()V", "CLICK_ON_THE_FEEDBACK_CARD", "", "CLICK_ON_THE_RATING_SCORE", "RATING_SCORE_VIEW", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Event {

        @NotNull
        public static final String CLICK_ON_THE_FEEDBACK_CARD = "click_on_the_feedback_card";

        @NotNull
        public static final String CLICK_ON_THE_RATING_SCORE = "click_on_the_rating_score";

        @NotNull
        public static final Event INSTANCE = new Event();

        @NotNull
        public static final String RATING_SCORE_VIEW = "rating_score_view";

        private Event() {
        }
    }

    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    @NotNull
    /* renamed from: body, reason: avoid collision after fix types in other method */
    public Map<String, ? extends Object> get$jsonObject() {
        Map<String, ? extends Object> map = this.logBody;
        return map == null ? new HashMap() : map;
    }

    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    @NotNull
    /* renamed from: eventName, reason: from getter */
    public String getEventName() {
        return this.eventName;
    }

    @NotNull
    public final String getEventName() {
        return this.eventName;
    }

    @Nullable
    public final Map<String, Object> getLogBody() {
        return this.logBody;
    }

    public final void setEventName(@NotNull String str) {
        this.eventName = str;
    }

    public final void setLogBody(@Nullable Map<String, ? extends Object> map) {
        this.logBody = map;
    }

    public UserRateDataFinderEvent(@NotNull String str, @Nullable Map<String, ? extends Object> map) {
        this.eventName = str;
        this.logBody = map;
    }
}