package com.gateio.biz.base.datafinder;

import com.gate_sdk.web3_wallet.DeFiConstants;
import com.gateio.common.kotlin.ext.UtilsAnyKt;
import com.gateio.lib.utils.ext.FormatExtensionsKt;
import java.util.Map;
import kotlin.Metadata;
import kotlin.TuplesKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.JvmStatic;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GTPageDataFinder.kt */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\b\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010$\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0018\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\u0004H\u0007J0\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\u00042\u0006\u0010\u0010\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\u00042\u0006\u0010\u0012\u001a\u00020\u0004H\u0002J \u0010\u0013\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\u0004H\u0002J\u0016\u0010\u0014\u001a\u00020\r2\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u000f\u001a\u00020\u0004J&\u0010\u0017\u001a\u00020\r2\u0006\u0010\u0018\u001a\u00020\u00042\u0014\u0010\u0019\u001a\u0010\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0001\u0018\u00010\u001aH\u0007J\u0012\u0010\u001b\u001a\u00020\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u0004H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001c"}, d2 = {"Lcom/gateio/biz/base/datafinder/GTPageDataFinder;", "", "()V", "EVENT_NAME", "", "EVENT_NAME_KEY_CURRENCY_NAME", "EVENT_NAME_KEY_LAST_PAGE_NAME", "EVENT_NAME_KEY_MODULE_SOURCE", "EVENT_NAME_KEY_PAGE_KEY", "EVENT_NAME_KEY_PAGE_NAME", "EVENT_NAME_KEY_STATUS", "lastPageName", "postPageNameCommonEvent", "", "pageName", "pageKey", "currencyName", "moduleSource", "status", "postPageNameCommonSourceEvent", "postPageNameEvent", "eventMeta", "Lcom/gateio/biz/base/datafinder/IGTPageEventMeta;", "postPageNameMapEvent", DeFiConstants.EventName, "params", "", "recordLastPageName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class GTPageDataFinder {

    @NotNull
    public static final String EVENT_NAME = "app_page_view";

    @NotNull
    private static final String EVENT_NAME_KEY_CURRENCY_NAME = "currency_name";

    @NotNull
    private static final String EVENT_NAME_KEY_LAST_PAGE_NAME = "refer_page_name";

    @NotNull
    private static final String EVENT_NAME_KEY_MODULE_SOURCE = "module_source";

    @NotNull
    private static final String EVENT_NAME_KEY_PAGE_KEY = "page_key";

    @NotNull
    private static final String EVENT_NAME_KEY_PAGE_NAME = "page_name";

    @NotNull
    private static final String EVENT_NAME_KEY_STATUS = "status";

    @NotNull
    public static final GTPageDataFinder INSTANCE = new GTPageDataFinder();

    @NotNull
    private static String lastPageName = "";

    private GTPageDataFinder() {
    }

    private final void postPageNameCommonEvent(String pageName, String pageKey, String currencyName, String moduleSource, String status) {
        if (pageName.length() == 0) {
            return;
        }
        GTBaseFuturesDataFinder.postEvent("app_page_view", MapsKt__MapsKt.mapOf(TuplesKt.to(EVENT_NAME_KEY_PAGE_KEY, pageKey), TuplesKt.to("page_name", pageName), TuplesKt.to("module_source", moduleSource), TuplesKt.to("currency_name", currencyName), TuplesKt.to(EVENT_NAME_KEY_LAST_PAGE_NAME, lastPageName), TuplesKt.to("status", status)));
        recordLastPageName(pageName);
    }

    @JvmStatic
    public static final void postPageNameMapEvent(@NotNull String eventName, @Nullable Map<String, ? extends Object> params) {
        if (params == null) {
            return;
        }
        GTBaseFuturesDataFinder.postEvent(eventName, MapsKt__MapsKt.plus(params, TuplesKt.to(EVENT_NAME_KEY_LAST_PAGE_NAME, lastPageName)));
        GTPageDataFinder gTPageDataFinder = INSTANCE;
        Object obj = params.get("page_name");
        gTPageDataFinder.recordLastPageName(obj instanceof String ? (String) obj : null);
    }

    private final void recordLastPageName(String pageName) {
        if (pageName == null) {
            return;
        }
        lastPageName = pageName;
    }

    private final void postPageNameCommonSourceEvent(String pageName, String pageKey, String moduleSource) {
        boolean z10;
        if (pageName.length() == 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (z10) {
            return;
        }
        GTBaseFuturesDataFinder.postEvent("app_page_view", MapsKt__MapsKt.mapOf(TuplesKt.to(EVENT_NAME_KEY_PAGE_KEY, pageKey), TuplesKt.to("page_name", pageName), TuplesKt.to("module_source", moduleSource), TuplesKt.to(EVENT_NAME_KEY_LAST_PAGE_NAME, lastPageName)));
        recordLastPageName(pageName);
    }

    public final void postPageNameEvent(@NotNull IGTPageEventMeta eventMeta, @NotNull String pageKey) {
        boolean z10;
        if (eventMeta.pageName().length() == 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (z10) {
            return;
        }
        String moduleSource = eventMeta.getModuleSource();
        String strCurrencyName = eventMeta.currencyName();
        String strStatus = eventMeta.status();
        if (UtilsAnyKt.isNotNull(moduleSource) && UtilsAnyKt.isNotNull(strCurrencyName) && UtilsAnyKt.isNotNull(strStatus)) {
            postPageNameCommonEvent(eventMeta.pageName(), pageKey, FormatExtensionsKt.value(strCurrencyName), FormatExtensionsKt.value(moduleSource), FormatExtensionsKt.value(strStatus));
        } else if (UtilsAnyKt.isNotNull(moduleSource)) {
            postPageNameCommonSourceEvent(eventMeta.pageName(), pageKey, FormatExtensionsKt.value(moduleSource));
        } else {
            postPageNameCommonEvent(eventMeta.pageName(), pageKey);
        }
    }

    @JvmStatic
    public static final void postPageNameCommonEvent(@NotNull String pageName, @NotNull String pageKey) {
        if (pageName.length() == 0) {
            return;
        }
        GTBaseFuturesDataFinder.postEvent("app_page_view", MapsKt__MapsKt.mapOf(TuplesKt.to(EVENT_NAME_KEY_PAGE_KEY, pageKey), TuplesKt.to("page_name", pageName), TuplesKt.to(EVENT_NAME_KEY_LAST_PAGE_NAME, lastPageName)));
        INSTANCE.recordLastPageName(pageName);
    }
}