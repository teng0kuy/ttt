package com.gateio.biz.base.datafinder;

import androidx.media3.extractor.text.ttml.TtmlNode;
import com.gateio.lib.datafinder.protocol.IGTBizAnalyseEvent;
import java.util.HashMap;
import java.util.Map;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GTAssetEvent.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0007\u0018\u0000 \r2\u0016\u0012\u0012\u0012\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u00040\u00020\u0001:\u0001\rB\u0017\b\u0016\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bB+\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0014\u0010\t\u001a\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0002¢\u0006\u0002\u0010\nJ\u0016\u0010\u000b\u001a\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u00040\u0002H\u0016J\b\u0010\f\u001a\u00020\u0003H\u0016R\u001c\u0010\t\u001a\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0002X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000e"}, d2 = {"Lcom/gateio/biz/base/datafinder/GTAssetEvent;", "Lcom/gateio/lib/datafinder/protocol/IGTBizAnalyseEvent;", "", "", "", "moduleName", "isError", "", "(Ljava/lang/String;Z)V", "info", "(Ljava/lang/String;ZLjava/util/Map;)V", TtmlNode.TAG_BODY, "subEventName", "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class GTAssetEvent implements IGTBizAnalyseEvent<Map<String, ? extends Object>> {

    @NotNull
    public static final String asset = "asset";

    @NotNull
    public static final String home = "home";

    @NotNull
    public static final String transfer_future = "transfer_future";

    @NotNull
    public static final String transfer_spot = "transfer_spot";

    @NotNull
    public static final String wallet_spot = "wallet_spot";

    @Nullable
    private final Map<String, Object> info;
    private final boolean isError;

    @NotNull
    private final String moduleName;

    public GTAssetEvent(@NotNull String str, boolean z10, @Nullable Map<String, ? extends Object> map) {
        this.moduleName = str;
        this.isError = z10;
        this.info = map;
    }

    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    @NotNull
    /* renamed from: body */
    public Map<String, Object> get$jsonObject() {
        HashMap map = new HashMap();
        Map<String, Object> map2 = this.info;
        if (map2 != null) {
            map.putAll(map2);
        }
        map.put(this.moduleName, Boolean.valueOf(this.isError));
        return map;
    }

    @Override // com.gateio.lib.datafinder.protocol.IGTInternalFinderEvent
    @NotNull
    /* renamed from: subEventName */
    public String get$subEventName() {
        return "asset";
    }

    public GTAssetEvent(@NotNull String str, boolean z10) {
        this(str, z10, null);
    }
}