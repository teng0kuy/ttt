package com.gateio.biz.base.datafinder;

import androidx.exifinterface.media.ExifInterface;
import com.gate_sdk.web3_wallet.DeFiConstants;
import com.gateio.lib.datafinder.GTDataFinder;
import com.gateio.lib.datafinder.protocol.GTBaseFinderEvent;
import com.gateio.lib.datafinder.protocol.GTFinderEvent;
import com.gateio.lib.datafinder.protocol.IGTInternalFinderEvent;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import org.jetbrains.annotations.NotNull;

/* compiled from: GTBaseFuturesDataFinder.kt */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010$\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0007J\u001c\u0010\u0005\u001a\u00020\u0006\"\u0004\b\u0000\u0010\u00072\f\u0010\b\u001a\b\u0012\u0004\u0012\u0002H\u00070\tH\u0007J\u0010\u0010\u0005\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\nH\u0007J\u001c\u0010\u0005\u001a\u00020\u0006\"\u0004\b\u0000\u0010\u00072\f\u0010\b\u001a\b\u0012\u0004\u0012\u0002H\u00070\u000bH\u0007J\u0010\u0010\u0005\u001a\u00020\u00062\u0006\u0010\f\u001a\u00020\rH\u0007J$\u0010\u0005\u001a\u00020\u00062\u0006\u0010\f\u001a\u00020\r2\u0012\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00010\u000fH\u0007¨\u0006\u0010"}, d2 = {"Lcom/gateio/biz/base/datafinder/GTBaseFuturesDataFinder;", "", "()V", "isFuture", "", "postEvent", "", ExifInterface.GPS_DIRECTION_TRUE, "event", "Lcom/gateio/lib/datafinder/protocol/GTBaseFinderEvent;", "Lcom/gateio/lib/datafinder/protocol/GTFinderEvent;", "Lcom/gateio/lib/datafinder/protocol/IGTInternalFinderEvent;", DeFiConstants.EventName, "", "bodyMap", "", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class GTBaseFuturesDataFinder {

    @NotNull
    public static final GTBaseFuturesDataFinder INSTANCE = new GTBaseFuturesDataFinder();

    private GTBaseFuturesDataFinder() {
    }

    @JvmStatic
    public static final boolean isFuture() {
        return true;
    }

    @JvmStatic
    public static final <T> void postEvent(@NotNull GTBaseFinderEvent<T> event) {
        if (isFuture()) {
            GTDataFinder.postEvent(event);
        }
    }

    @JvmStatic
    public static final void postEvent(@NotNull GTFinderEvent event) {
        if (isFuture()) {
            GTDataFinder.postEvent(event);
        }
    }

    @JvmStatic
    public static final void postEvent(@NotNull String eventName) {
        if (isFuture()) {
            GTDataFinder.postEvent(eventName);
        }
    }

    @JvmStatic
    public static final void postEvent(@NotNull String eventName, @NotNull Map<String, ? extends Object> bodyMap) {
        if (isFuture()) {
            GTDataFinder.postEvent(eventName, bodyMap);
        }
    }

    @JvmStatic
    public static final <T> void postEvent(@NotNull IGTInternalFinderEvent<T> event) {
        if (isFuture()) {
            GTDataFinder.postEvent((IGTInternalFinderEvent) event);
        }
    }
}