package com.gateio.biz.base.datafinder.futures.event;

import com.gateio.biz.base.datafinder.futures.BaseFuturesPointConstants;
import com.gateio.common.tool.TextUtils;
import com.gateio.lib.datafinder.protocol.GTBaseFinderEvent;

/* loaded from: classes4.dex */
public class BaseContractPopupWindowClickEvent implements GTBaseFinderEvent<ContractNavigation> {
    public static final String ICEBERG_STRATEGY = "ICEBERG_STRATEGY";
    public static final String TWAP = "TWAP";
    public static final String base = "base";
    public static final String bbo_more = "bbo_more";
    public static final String bbo_window = "bbo_window";
    public static final String conditional_limit = "conditional_limit";
    public static final String conditional_market = "conditional_market";
    public static final String deposit = "deposit";
    public static final String fun_rate_history = "fun_rate_history";
    public static final String fund_password_cancel = "fund_password_cancel";
    public static final String fund_password_change = "fund_password_change";
    public static final String fund_password_confirm = "fund_password_confirm";
    public static final String fund_password_faceid = "fund_password_faceid";
    public static final String fund_rate_more = "fund_rate_more";
    public static final String fund_rate_time = "fund_rate_time";
    public static final String iceberg_more = "iceberg_more";
    public static final String iceberg_window = "iceberg_window";
    public static final String limit_order = "limit_order";
    public static final String liquidation_price_more = "liquidation_price_more";
    public static final String liquidation_price_window = "liquidation_price_window";
    public static final String margin_rate_more = "margin_rate_more";
    public static final String margin_rate_window = "margin_rate_window";
    public static final String market_order = "market_order";
    public static final String reduceonly_more = "reduceonly_more";
    public static final String reduceonly_window = "reduceonly_window";
    public static final String tpsl_more = "tpsl_more";
    public static final String tpsl_window = "tpsl_window";
    public static final String trailing_stop = "trailing_stop";
    public static final String transfer = "transfer";
    public static final String unit = "unit";
    public static final String usdt = "usdt";
    public static final String usdt_cost = "usdt_cost";
    String button_name;
    String input_amount;
    String last_price;
    String leverage_change;
    String order_price;
    String order_type;
    String unit_switch;

    static class ContractNavigation {
        String button_name;
        String input_amount;
        String last_price;
        String leverage_change;
        String order_price;
        String order_type;
        String unit_switch;

        ContractNavigation() {
        }

        public void setButton_name(String str) {
            this.button_name = str;
        }

        public void setInput_amount(String str) {
            this.input_amount = str;
        }

        public void setLast_price(String str) {
            this.last_price = str;
        }

        public void setLeverage_change(String str) {
            this.leverage_change = str;
        }

        public void setOrder_price(String str) {
            this.order_price = str;
        }

        public void setOrder_type(String str) {
            this.order_type = str;
        }

        public void setUnit_switch(String str) {
            this.unit_switch = str;
        }
    }

    public BaseContractPopupWindowClickEvent(String str) {
        this.button_name = str;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    public ContractNavigation body() {
        ContractNavigation contractNavigation = new ContractNavigation();
        if (!TextUtils.isEmpty(this.order_type)) {
            contractNavigation.setOrder_type(this.order_type);
        }
        if (!TextUtils.isEmpty(this.button_name)) {
            contractNavigation.setButton_name(this.button_name);
        }
        if (!TextUtils.isEmpty(this.leverage_change)) {
            contractNavigation.setLeverage_change(this.leverage_change);
        }
        if (!TextUtils.isEmpty(this.input_amount)) {
            contractNavigation.setInput_amount(this.input_amount);
        }
        if (!TextUtils.isEmpty(this.unit_switch)) {
            contractNavigation.setUnit_switch(this.unit_switch);
        }
        if (!TextUtils.isEmpty(this.order_price)) {
            contractNavigation.setOrder_price(this.order_price);
        }
        if (!TextUtils.isEmpty(this.last_price)) {
            contractNavigation.setLast_price(this.last_price);
        }
        return contractNavigation;
    }

    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    public String eventName() {
        return BaseFuturesPointConstants.FuturesKey.contract_popup_window_click;
    }

    public BaseContractPopupWindowClickEvent(String str, String str2) {
        this.order_type = str;
        this.button_name = str2;
    }

    public BaseContractPopupWindowClickEvent(String str, String str2, String str3) {
        this.button_name = str;
        this.leverage_change = str2;
    }

    public BaseContractPopupWindowClickEvent(String str, String str2, String str3, String str4, String str5) {
        this.button_name = str;
        this.input_amount = str2;
        this.unit_switch = str3;
        this.order_price = str4;
        this.last_price = str5;
    }
}