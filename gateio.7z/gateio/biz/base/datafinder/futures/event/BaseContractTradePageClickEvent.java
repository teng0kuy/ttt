package com.gateio.biz.base.datafinder.futures.event;

import com.gateio.biz.base.datafinder.futures.BaseFuturesPointConstants;
import com.gateio.common.tool.TextUtils;
import com.gateio.lib.datafinder.protocol.GTBaseFinderEvent;

/* loaded from: classes4.dex */
public class BaseContractTradePageClickEvent implements GTBaseFinderEvent<ContractTopNavigation> {
    public static final String activity_trade = "activity_trade";
    public static final String adjust_margin_cross = "adjust_margin_cross";
    public static final String adjust_margin_isolate = "adjust_margin_isolate";
    public static final String closed_positions_navigator_share = "closed_positions_navigator_share";
    public static final String closed_positions_post_share = "closed_positions_post_share";
    public static final String closed_positions_share = "order_history_post_share";
    public static final String contract_events_click = "contract_events_click";
    public static final String hedgemode_close = "hedgemode_close";
    public static final String hedgemode_open = "hedgemode_open";
    public static final String list_market_add = "list_market_add";
    public static final String list_market_btc_margined = "list_market_btc_margined";
    public static final String list_market_delete = "list_market_delete";
    public static final String list_market_favorites = "list_market_favorites";
    public static final String list_market_quick_add = "list_market_quick_add";
    public static final String list_market_search = "list_market_search";
    public static final String list_market_usdt_margined = "list_market_usdt_margined";
    public static final String list_market_zones = "list_market_zones";
    public static final String open_orders_ChaseLimitOrder = "open_orders_ChaseLimitOrder";
    public static final String open_orders_TS = "open_orders_TS";
    public static final String open_orders_TWAP = "open_orders_TWAP";
    public static final String order_history_navigator_share = "order_history_navigator_share";
    public static final String order_history_post_share = "order_history_post_share";
    public static final String order_history_share = "order_history_share";
    String button_name;
    String trade_type;

    static class ContractTopNavigation {
        String button_name;
        String trade_type;

        ContractTopNavigation() {
        }

        public void setButton_name(String str) {
            this.button_name = str;
        }

        public void setTrade_type(String str) {
            this.trade_type = str;
        }
    }

    public BaseContractTradePageClickEvent(String str) {
        this.button_name = str;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    public ContractTopNavigation body() {
        ContractTopNavigation contractTopNavigation = new ContractTopNavigation();
        contractTopNavigation.setButton_name(this.button_name);
        if (!TextUtils.isEmpty(this.trade_type)) {
            contractTopNavigation.setTrade_type(this.trade_type);
        }
        return contractTopNavigation;
    }

    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    public String eventName() {
        return BaseFuturesPointConstants.FuturesKey.contract_trade_page_click;
    }

    public BaseContractTradePageClickEvent(String str, String str2) {
        this.button_name = str;
        this.trade_type = str2;
    }
}