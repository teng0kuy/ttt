package com.gateio.biz.base.datafinder.futures.event;

import com.gateio.biz.base.datafinder.futures.BaseFuturesPointConstants;
import com.gateio.lib.datafinder.protocol.GTBaseFinderEvent;

/* loaded from: classes4.dex */
public class BaseUtaDemoTradingAppClickEvent implements GTBaseFinderEvent<ContractTopNavigation> {
    public static final String app_more_trading = "app_more_trading";
    public static final String futures_setting = "futures_setting";
    public static final String margin_setting = "margin_setting";
    public static final String spot_setting = "spot_setting";
    String entrance_type = this.entrance_type;
    String entrance_type = this.entrance_type;

    static class ContractTopNavigation {
        String entrance_type;

        ContractTopNavigation() {
        }

        public String getEntrance_type() {
            return this.entrance_type;
        }

        public void setEntrance_type(String str) {
            this.entrance_type = str;
        }
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    /* renamed from: body */
    public ContractTopNavigation get$jsonObject() {
        ContractTopNavigation contractTopNavigation = new ContractTopNavigation();
        contractTopNavigation.setEntrance_type(this.entrance_type);
        return contractTopNavigation;
    }

    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    public String eventName() {
        return BaseFuturesPointConstants.FuturesKey.uta_demo_trading_app;
    }

    public BaseUtaDemoTradingAppClickEvent(String str) {
    }
}