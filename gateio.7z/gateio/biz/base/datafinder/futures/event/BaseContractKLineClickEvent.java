package com.gateio.biz.base.datafinder.futures.event;

import com.gateio.biz.base.datafinder.futures.BaseFuturesPointConstants;
import com.gateio.lib.datafinder.protocol.GTBaseFinderEvent;

/* loaded from: classes4.dex */
public class BaseContractKLineClickEvent implements GTBaseFinderEvent<ContractTopNavigation> {
    public static final String add = "add";
    public static final String alert = "alert";
    public static final String amount = "amount";
    public static final String andication_turn = "andication_turn";
    public static final String boll = "boll";
    public static final String buy = "buy";
    public static final String chart = "chart";
    public static final String chart_press = "chart_press";
    public static final String choose = "choose";
    public static final String delete = "delete";
    public static final String depth = "depth";
    public static final String draw = "draw";
    public static final String ema = "ema";
    public static final String full_screen = "full_screen";
    public static final String full_screen_close = "full_screen_close";
    public static final String full_screen_draw = "full_screen_draw";
    public static final String full_screen_indicator_setting = "full_screen_indicator_setting";
    public static final String full_screen_more = "full_screen_more";
    public static final String full_screen_setting = "full_screen_setting";
    public static final String indicator = "indicator";
    public static final String indicator_setting = "indicator_setting";
    public static final String kdj = "kdj";
    public static final String list_market = "list_market";

    /* renamed from: ma, reason: collision with root package name */
    public static final String f10980ma = "ma";
    public static final String macd = "macd";
    public static final String margin = "margin";
    public static final String more = "more";
    public static final String rsi = "rsi";
    public static final String sell = "sell";
    public static final String setting = "setting";
    public static final String share = "share";
    public static final String spec = "spec";
    public static final String spot = "spot";
    public static final String trades = "trades";
    public static final String vol = "vol";
    public static final String wr = "wr";
    String button_name;

    static class ContractTopNavigation {
        String button_name;

        ContractTopNavigation() {
        }

        public void setButton_name(String str) {
            this.button_name = str;
        }
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    /* renamed from: body */
    public ContractTopNavigation get$jsonObject() {
        ContractTopNavigation contractTopNavigation = new ContractTopNavigation();
        contractTopNavigation.setButton_name(this.button_name);
        return contractTopNavigation;
    }

    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    public String eventName() {
        return BaseFuturesPointConstants.FuturesKey.contract_k_line_click;
    }

    public BaseContractKLineClickEvent(String str) {
        this.button_name = str;
    }
}