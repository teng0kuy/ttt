package com.gateio.biz.base.datafinder.futures.event;

import com.gateio.biz.base.datafinder.futures.BaseFuturesPointConstants;
import com.gateio.lib.datafinder.protocol.GTBaseFinderEvent;

/* loaded from: classes4.dex */
public class BaseContractPopupWindowViewEvent implements GTBaseFinderEvent<ContractTopNavigation> {
    public static final String adl = "adl";
    public static final String cancel_all = "cancel_all";
    public static final String close_all = "close_all";
    public static final String close_second_confirmation = "close_second_confirmation";
    public static final String fund_password = "fund_password";
    public static final String fund_rate_time = "fund_rate_time";
    public static final String margin = "margin";
    public static final String open_second_confirmation = "open_second_confirmation";
    public static final String order_type = "order_type";
    public static final String reverse_second_confirmation = "reverse_second_confirmation";
    public static final String tutorial = "tutorial";
    String popup_name;

    static class ContractTopNavigation {
        String popup_name;

        ContractTopNavigation() {
        }

        public void setPopup_name(String str) {
            this.popup_name = str;
        }
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    /* renamed from: body */
    public ContractTopNavigation get$jsonObject() {
        ContractTopNavigation contractTopNavigation = new ContractTopNavigation();
        contractTopNavigation.setPopup_name(this.popup_name);
        return contractTopNavigation;
    }

    @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
    public String eventName() {
        return BaseFuturesPointConstants.FuturesKey.contract_popup_window_view;
    }

    public BaseContractPopupWindowViewEvent(String str) {
        this.popup_name = str;
    }
}