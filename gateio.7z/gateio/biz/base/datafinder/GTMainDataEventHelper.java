package com.gateio.biz.base.datafinder;

import com.gateio.biz.base.router.RouterConst;
import com.gateio.biz.base.utils.ConstUtil;
import com.gateio.biz.base.utils.HomeFunctionEntry;
import com.gateio.biz.market.util.MarketConst;
import com.gateio.common.tool.StringUtils;
import com.gateio.gateio.datafinder.DataFinderConstant;
import com.gateio.lib.datafinder.GTDataFinder;
import com.gateio.lib.datafinder.protocol.GTBaseFinderEvent;
import com.gateio.lib.storage.GTStorage;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GTMainDataEventHelper.kt */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0002JH\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00042\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u00042\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u00042\b\b\u0002\u0010\u000b\u001a\u00020\f2\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u0004J\u000e\u0010\u000e\u001a\u00020\u00062\u0006\u0010\u000f\u001a\u00020\u0004¨\u0006\u0010"}, d2 = {"Lcom/gateio/biz/base/datafinder/GTMainDataEventHelper;", "", "()V", "getLayoutTypeName", "", "reportTabClick", "", "tag", "reddot", RouterConst.BuyCrypto.KEY_TRADE_TYPE, "trade_list_type", "fromUser", "", "entry", "reportTradeButtonClick", "buttonName", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class GTMainDataEventHelper {

    @NotNull
    public static final GTMainDataEventHelper INSTANCE = new GTMainDataEventHelper();

    private GTMainDataEventHelper() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String getLayoutTypeName() {
        return Intrinsics.areEqual(GTStorage.queryStringKV$default(ConstUtil.LAYOUT_STYLE, ConstUtil.LAYOUT_MARKET, null, 4, null), ConstUtil.LAYOUT_MARKET) ? DataFinderConstant.DataFinderParamsValue.home_bottom_tab_click_market : MarketConst.searchMomentsType;
    }

    public static /* synthetic */ void reportTabClick$default(GTMainDataEventHelper gTMainDataEventHelper, String str, String str2, String str3, String str4, boolean z10, String str5, int i10, Object obj) {
        gTMainDataEventHelper.reportTabClick(str, (i10 & 2) != 0 ? null : str2, (i10 & 4) != 0 ? null : str3, (i10 & 8) != 0 ? null : str4, (i10 & 16) != 0 ? true : z10, (i10 & 32) == 0 ? str5 : null);
    }

    public final void reportTabClick(@NotNull final String tag, @Nullable final String reddot, @Nullable final String trade_type, @Nullable final String trade_list_type, final boolean fromUser, @Nullable final String entry) {
        GTDataFinder.postEvent(new GTBaseFinderEvent<Map<String, String>>() { // from class: com.gateio.biz.base.datafinder.GTMainDataEventHelper.reportTabClick.1
            @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
            @NotNull
            /* renamed from: body, reason: avoid collision after fix types in other method */
            public Map<String, String> get$jsonObject() {
                Pair[] pairArr = new Pair[3];
                pairArr[0] = TuplesKt.to("layout_type", GTMainDataEventHelper.INSTANCE.getLayoutTypeName());
                pairArr[1] = TuplesKt.to("button_name", tag);
                pairArr[2] = TuplesKt.to("source", fromUser ? "user_click" : "redirect");
                Map<String, String> mapMutableMapOf = MapsKt__MapsKt.mutableMapOf(pairArr);
                String str = reddot;
                String str2 = trade_type;
                String str3 = trade_list_type;
                String str4 = entry;
                if (str != null) {
                    mapMutableMapOf.put("reddot", str);
                }
                if (str2 != null) {
                    mapMutableMapOf.put(RouterConst.BuyCrypto.KEY_TRADE_TYPE, str2);
                }
                if (str3 != null) {
                    mapMutableMapOf.put("trade_list_type", str3);
                }
                if (!StringUtils.isEmpty(str4)) {
                    if (str4 == null) {
                        str4 = "";
                    }
                    mapMutableMapOf.put("entry", str4);
                }
                return mapMutableMapOf;
            }

            @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
            @NotNull
            /* renamed from: eventName */
            public String getEventName() {
                return "home_bottom_tab_click";
            }
        });
    }

    public final void reportTradeButtonClick(@NotNull String buttonName) {
        reportTabClick$default(this, "trade", null, null, buttonName, false, HomeFunctionEntry.INSTANCE.getHomeExchangeEntry(buttonName), 16, null);
    }
}