package com.gateio.biz.base.datafinder.kline;

import com.alipay.zoloz.toyger.ToygerService;
import com.gateio.biz.exchange.ui.ExchangeRootLiveDataBus;
import com.gateio.biz.safe.fido2.event.DataKey;
import com.gateio.common.tool.AccessUtil;
import com.gateio.common.tool.BuildMap;
import com.gateio.lib.datafinder.GTDataFinder;
import com.gateio.lib.datafinder.protocol.GTFinderEvent;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt__StringsJVMKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONObject;

/* compiled from: KlineFinder.kt */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\r\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u0004H\u0007J\u000e\u0010\u000e\u001a\u00020\f2\u0006\u0010\u000f\u001a\u00020\u0010J\u0010\u0010\u0011\u001a\u00020\f2\b\u0010\u0012\u001a\u0004\u0018\u00010\u0004J\u0010\u0010\u0013\u001a\u00020\f2\u0006\u0010\u0014\u001a\u00020\u0010H\u0007J\u000e\u0010\u0015\u001a\u00020\f2\u0006\u0010\u0014\u001a\u00020\u0010J\u0018\u0010\u0016\u001a\u00020\f2\u0006\u0010\u0017\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u0004H\u0007J\u0010\u0010\u0019\u001a\u00020\f2\u0006\u0010\u0014\u001a\u00020\u0010H\u0007J\u0006\u0010\u001a\u001a\u00020\fJ\u0010\u0010\u001b\u001a\u00020\f2\u0006\u0010\u001c\u001a\u00020\u0010H\u0007R0\u0010\u0005\u001a\u0004\u0018\u00010\u00042\b\u0010\u0003\u001a\u0004\u0018\u00010\u00048\u0006@FX\u0087\u000e¢\u0006\u0014\n\u0000\u0012\u0004\b\u0006\u0010\u0002\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\n¨\u0006\u001d"}, d2 = {"Lcom/gateio/biz/base/datafinder/kline/KlineFinder;", "", "()V", "value", "", "module_source", "getModule_source$annotations", "getModule_source", "()Ljava/lang/String;", "setModule_source", "(Ljava/lang/String;)V", "appPageView", "", "pageName", "exchangeSetModelSource", "spot", "", "exchangeTabSelect", ToygerService.KEY_RES_9_KEY, "futuresAppPage", "delivery", "futuresSetModuleSource", "miniKlineEvent", "buttonName", "source", "onBottomClickContractMiniKline", "onBottomClickPilotMiniKline", "onBottomClickTransMiniKline", "isSpot", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class KlineFinder {

    @NotNull
    public static final KlineFinder INSTANCE = new KlineFinder();

    @Nullable
    private static String module_source = "";

    private KlineFinder() {
    }

    @JvmStatic
    public static final void appPageView(@NotNull final String pageName) {
        GTDataFinder.postEvent(new GTFinderEvent() { // from class: com.gateio.biz.base.datafinder.kline.KlineFinder.appPageView.1
            @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
            @NotNull
            /* renamed from: body, reason: avoid collision after fix types in other method */
            public JSONObject get$jsonObject() {
                return new JSONObject().put(DataKey.PAGE_NAME, pageName);
            }

            @Override // com.gateio.lib.datafinder.protocol.GTFinderEvent, com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
            @NotNull
            /* renamed from: eventName */
            public String getEventName() {
                return "app_page_view";
            }
        });
    }

    @JvmStatic
    public static final void futuresAppPage(boolean delivery) {
        if (delivery) {
            appPageView("trade_delivery");
        }
    }

    @Nullable
    public static final String getModule_source() {
        return module_source;
    }

    @JvmStatic
    public static final void miniKlineEvent(@NotNull final String buttonName, @NotNull final String source) {
        GTDataFinder.postEvent(new GTFinderEvent() { // from class: com.gateio.biz.base.datafinder.kline.KlineFinder.miniKlineEvent.1
            @Override // com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
            @NotNull
            /* renamed from: body, reason: avoid collision after fix types in other method */
            public JSONObject get$jsonObject() {
                return new JSONObject().put("button_name", buttonName).put("module_source", source);
            }

            @Override // com.gateio.lib.datafinder.protocol.GTFinderEvent, com.gateio.lib.datafinder.protocol.GTBaseFinderEvent
            @NotNull
            /* renamed from: eventName */
            public String getEventName() {
                return "mini_kline";
            }
        });
    }

    @JvmStatic
    public static final void onBottomClickContractMiniKline(boolean delivery) {
        GTDataFinder.postEvent("mini_kline", BuildMap.initStr().put((BuildMap<String, String>) "module_source", delivery ? "trade_delivery" : "trade_futures").put((BuildMap<String, String>) "button_name", "mini_kline_bottom").build());
    }

    @JvmStatic
    public static final void onBottomClickTransMiniKline(boolean isSpot) {
        GTDataFinder.postEvent("mini_kline", BuildMap.initStr().put((BuildMap<String, String>) "module_source", isSpot ? AccessUtil.TRADE.SPOT : AccessUtil.TRADE.MARGIN).put((BuildMap<String, String>) "button_name", "mini_kline_bottom").build());
    }

    public static final void setModule_source(@Nullable String str) {
        String strReplace$default;
        if (str == null || (strReplace$default = StringsKt__StringsJVMKt.replace$default(str, "contract", "futures", false, 4, (Object) null)) == null) {
            strReplace$default = "";
        }
        module_source = strReplace$default;
    }

    public final void exchangeSetModelSource(boolean spot) {
        setModule_source(spot ? "trade_spot_top_go_to_kline" : "trade_margin_top_go_to_kline");
    }

    public final void exchangeTabSelect(@Nullable String key) {
        String str = Intrinsics.areEqual(key, ExchangeRootLiveDataBus.EXCHANGE_KEY_PRE_MARKET) ? "trade_premarket" : Intrinsics.areEqual(key, ExchangeRootLiveDataBus.EXCHANGE_KEY_MEME_BOX) ? "trade_memebox" : "";
        if (str.length() > 0) {
            appPageView(str);
        }
    }

    public final void futuresSetModuleSource(boolean delivery) {
        setModule_source(delivery ? "trade_delivery_top_go_to_kline" : "trade_futures_positions_go_to_kline");
    }

    public final void onBottomClickPilotMiniKline() {
        GTDataFinder.postEvent("mini_kline", BuildMap.initStr().put((BuildMap<String, String>) "module_source", "trade_pilot").put((BuildMap<String, String>) "button_name", "mini_kline_bottom").build());
    }

    @JvmStatic
    public static /* synthetic */ void getModule_source$annotations() {
    }
}