package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.R;
import com.gateio.biz.base.router.flutter_box.KlineFlutterNativeFrame;

/* loaded from: classes4.dex */
public final class FlutterInNativeScrollFragmentBinding implements ViewBinding {

    @NonNull
    public final KlineFlutterNativeFrame interceptScrollview;

    @NonNull
    public final FrameLayout relativeFlutter;

    @NonNull
    private final FrameLayout rootView;

    @NonNull
    public static FlutterInNativeScrollFragmentBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FlutterInNativeScrollFragmentBinding bind(@NonNull View view) {
        int i10 = R.id.intercept_scrollview;
        KlineFlutterNativeFrame klineFlutterNativeFrame = (KlineFlutterNativeFrame) ViewBindings.findChildViewById(view, i10);
        if (klineFlutterNativeFrame != null) {
            i10 = R.id.relative_flutter;
            FrameLayout frameLayout = (FrameLayout) ViewBindings.findChildViewById(view, i10);
            if (frameLayout != null) {
                return new FlutterInNativeScrollFragmentBinding((FrameLayout) view, klineFlutterNativeFrame, frameLayout);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FlutterInNativeScrollFragmentBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.flutter_in_native_scroll_fragment, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public FrameLayout getRoot() {
        return this.rootView;
    }

    private FlutterInNativeScrollFragmentBinding(@NonNull FrameLayout frameLayout, @NonNull KlineFlutterNativeFrame klineFlutterNativeFrame, @NonNull FrameLayout frameLayout2) {
        this.rootView = frameLayout;
        this.interceptScrollview = klineFlutterNativeFrame;
        this.relativeFlutter = frameLayout2;
    }
}