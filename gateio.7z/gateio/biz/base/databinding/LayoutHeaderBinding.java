package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.R;

/* loaded from: classes4.dex */
public final class LayoutHeaderBinding implements ViewBinding {

    @NonNull
    public final ImageView btnHeadBack;

    @NonNull
    public final ImageView btnHeadFront;

    @NonNull
    public final ImageView btnHeadFrontForC2c;

    @NonNull
    public final RelativeLayout layoutHeader;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final ImageView share;

    @NonNull
    public final TextView tvClickLxgly;

    @NonNull
    public final TextView tvHeadTitle;

    @NonNull
    public static LayoutHeaderBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static LayoutHeaderBinding bind(@NonNull View view) {
        int i10 = R.id.btn_head_back;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
        if (imageView != null) {
            i10 = R.id.btn_head_front;
            ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i10);
            if (imageView2 != null) {
                i10 = R.id.btn_head_front_for_c2c;
                ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(view, i10);
                if (imageView3 != null) {
                    RelativeLayout relativeLayout = (RelativeLayout) view;
                    i10 = R.id.share;
                    ImageView imageView4 = (ImageView) ViewBindings.findChildViewById(view, i10);
                    if (imageView4 != null) {
                        i10 = R.id.tv_click_lxgly;
                        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView != null) {
                            i10 = R.id.tv_head_title;
                            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView2 != null) {
                                return new LayoutHeaderBinding(relativeLayout, imageView, imageView2, imageView3, relativeLayout, imageView4, textView, textView2);
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static LayoutHeaderBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.layout_header, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private LayoutHeaderBinding(@NonNull RelativeLayout relativeLayout, @NonNull ImageView imageView, @NonNull ImageView imageView2, @NonNull ImageView imageView3, @NonNull RelativeLayout relativeLayout2, @NonNull ImageView imageView4, @NonNull TextView textView, @NonNull TextView textView2) {
        this.rootView = relativeLayout;
        this.btnHeadBack = imageView;
        this.btnHeadFront = imageView2;
        this.btnHeadFrontForC2c = imageView3;
        this.layoutHeader = relativeLayout2;
        this.share = imageView4;
        this.tvClickLxgly = textView;
        this.tvHeadTitle = textView2;
    }
}