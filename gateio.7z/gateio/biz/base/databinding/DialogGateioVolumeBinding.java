package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.R;
import com.gateio.lib.uikit.input.GTInputV5;

/* loaded from: classes4.dex */
public final class DialogGateioVolumeBinding implements ViewBinding {

    @NonNull
    public final GTInputV5 dialogGateioVolume;

    @NonNull
    private final LinearLayoutCompat rootView;

    @NonNull
    public static DialogGateioVolumeBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static DialogGateioVolumeBinding bind(@NonNull View view) {
        int i10 = R.id.dialog_gateio_volume;
        GTInputV5 gTInputV5 = (GTInputV5) ViewBindings.findChildViewById(view, i10);
        if (gTInputV5 != null) {
            return new DialogGateioVolumeBinding((LinearLayoutCompat) view, gTInputV5);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static DialogGateioVolumeBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.dialog_gateio_volume, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayoutCompat getRoot() {
        return this.rootView;
    }

    private DialogGateioVolumeBinding(@NonNull LinearLayoutCompat linearLayoutCompat, @NonNull GTInputV5 gTInputV5) {
        this.rootView = linearLayoutCompat;
        this.dialogGateioVolume = gTInputV5;
    }
}