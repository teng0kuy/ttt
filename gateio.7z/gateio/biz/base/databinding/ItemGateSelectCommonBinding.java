package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.R;

/* loaded from: classes4.dex */
public final class ItemGateSelectCommonBinding implements ViewBinding {

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final TextView tvName;

    @NonNull
    public final View vLine;

    @NonNull
    public static ItemGateSelectCommonBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ItemGateSelectCommonBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.tv_name;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
        if (textView == null || (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.v_line))) == null) {
            throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
        }
        return new ItemGateSelectCommonBinding((LinearLayout) view, textView, viewFindChildViewById);
    }

    @NonNull
    public static ItemGateSelectCommonBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.item_gate_select_common, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private ItemGateSelectCommonBinding(@NonNull LinearLayout linearLayout, @NonNull TextView textView, @NonNull View view) {
        this.rootView = linearLayout;
        this.tvName = textView;
        this.vLine = view;
    }
}