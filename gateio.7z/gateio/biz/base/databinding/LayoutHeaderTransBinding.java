package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.R;
import net.lucode.hackware.magicindicator.MagicIndicator;

/* loaded from: classes4.dex */
public final class LayoutHeaderTransBinding implements ViewBinding {

    @NonNull
    public final LinearLayout layoutHeaderSelect;

    @NonNull
    public final MagicIndicator magicIndicatorTrans;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public static LayoutHeaderTransBinding bind(@NonNull View view) {
        LinearLayout linearLayout = (LinearLayout) view;
        int i10 = R.id.magic_indicator_trans;
        MagicIndicator magicIndicator = (MagicIndicator) ViewBindings.findChildViewById(view, i10);
        if (magicIndicator != null) {
            return new LayoutHeaderTransBinding(linearLayout, linearLayout, magicIndicator);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static LayoutHeaderTransBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static LayoutHeaderTransBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.layout_header_trans, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private LayoutHeaderTransBinding(@NonNull LinearLayout linearLayout, @NonNull LinearLayout linearLayout2, @NonNull MagicIndicator magicIndicator) {
        this.rootView = linearLayout;
        this.layoutHeaderSelect = linearLayout2;
        this.magicIndicatorTrans = magicIndicator;
    }
}