package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.R;
import com.gateio.common.view.CornerLinearLayout;

/* loaded from: classes4.dex */
public final class MarketSelectFavPopBinding implements ViewBinding {

    @NonNull
    public final CornerLinearLayout layout;

    @NonNull
    private final ConstraintLayout rootView;

    @NonNull
    public final TextView tvFav;

    @NonNull
    public static MarketSelectFavPopBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static MarketSelectFavPopBinding bind(@NonNull View view) {
        int i10 = R.id.layout;
        CornerLinearLayout cornerLinearLayout = (CornerLinearLayout) ViewBindings.findChildViewById(view, i10);
        if (cornerLinearLayout != null) {
            i10 = R.id.tv_fav;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                return new MarketSelectFavPopBinding((ConstraintLayout) view, cornerLinearLayout, textView);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static MarketSelectFavPopBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.market_select_fav_pop, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    private MarketSelectFavPopBinding(@NonNull ConstraintLayout constraintLayout, @NonNull CornerLinearLayout cornerLinearLayout, @NonNull TextView textView) {
        this.rootView = constraintLayout;
        this.layout = cornerLinearLayout;
        this.tvFav = textView;
    }
}