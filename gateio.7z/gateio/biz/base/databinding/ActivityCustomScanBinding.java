package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.R;
import com.gateio.lib.uikit.title.GTTitleViewV3;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;

/* loaded from: classes4.dex */
public final class ActivityCustomScanBinding implements ViewBinding {

    @NonNull
    public final DecoratedBarcodeView dbvCustom;

    @NonNull
    public final GTTitleViewV3 layoutMain;

    @NonNull
    public final LinearLayout llTakePhoto;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final View statusBg;

    @NonNull
    public static ActivityCustomScanBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ActivityCustomScanBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.dbv_custom;
        DecoratedBarcodeView decoratedBarcodeView = (DecoratedBarcodeView) ViewBindings.findChildViewById(view, i10);
        if (decoratedBarcodeView != null) {
            i10 = R.id.layout_main;
            GTTitleViewV3 gTTitleViewV3 = (GTTitleViewV3) ViewBindings.findChildViewById(view, i10);
            if (gTTitleViewV3 != null) {
                i10 = R.id.ll_take_photo;
                LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                if (linearLayout != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.status_bg))) != null) {
                    return new ActivityCustomScanBinding((RelativeLayout) view, decoratedBarcodeView, gTTitleViewV3, linearLayout, viewFindChildViewById);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ActivityCustomScanBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_custom_scan, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private ActivityCustomScanBinding(@NonNull RelativeLayout relativeLayout, @NonNull DecoratedBarcodeView decoratedBarcodeView, @NonNull GTTitleViewV3 gTTitleViewV3, @NonNull LinearLayout linearLayout, @NonNull View view) {
        this.rootView = relativeLayout;
        this.dbvCustom = decoratedBarcodeView;
        this.layoutMain = gTTitleViewV3;
        this.llTakePhoto = linearLayout;
        this.statusBg = view;
    }
}