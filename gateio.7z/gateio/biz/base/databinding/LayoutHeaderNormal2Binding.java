package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.R;
import com.gateio.common.view.CornerTextView;

/* loaded from: classes4.dex */
public final class LayoutHeaderNormal2Binding implements ViewBinding {

    @NonNull
    public final ImageView btnHeadBack;

    @NonNull
    public final ImageView btnRightFront;

    @NonNull
    public final ImageView btnRightSencondFront;

    @NonNull
    public final ConstraintLayout layoutHeader;

    @NonNull
    public final LinearLayout llRightTv;

    @NonNull
    private final ConstraintLayout rootView;

    @NonNull
    public final CornerTextView tvRightFront;

    @NonNull
    public final TextView tvTitle;

    @NonNull
    public static LayoutHeaderNormal2Binding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static LayoutHeaderNormal2Binding bind(@NonNull View view) {
        int i10 = R.id.btn_head_back;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
        if (imageView != null) {
            i10 = R.id.btn_right_front;
            ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i10);
            if (imageView2 != null) {
                i10 = R.id.btn_right_sencond_front;
                ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(view, i10);
                if (imageView3 != null) {
                    ConstraintLayout constraintLayout = (ConstraintLayout) view;
                    i10 = R.id.ll_right_tv;
                    LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                    if (linearLayout != null) {
                        i10 = R.id.tv_right_front;
                        CornerTextView cornerTextView = (CornerTextView) ViewBindings.findChildViewById(view, i10);
                        if (cornerTextView != null) {
                            i10 = R.id.tv_title;
                            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView != null) {
                                return new LayoutHeaderNormal2Binding(constraintLayout, imageView, imageView2, imageView3, constraintLayout, linearLayout, cornerTextView, textView);
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static LayoutHeaderNormal2Binding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.layout_header_normal2, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    private LayoutHeaderNormal2Binding(@NonNull ConstraintLayout constraintLayout, @NonNull ImageView imageView, @NonNull ImageView imageView2, @NonNull ImageView imageView3, @NonNull ConstraintLayout constraintLayout2, @NonNull LinearLayout linearLayout, @NonNull CornerTextView cornerTextView, @NonNull TextView textView) {
        this.rootView = constraintLayout;
        this.btnHeadBack = imageView;
        this.btnRightFront = imageView2;
        this.btnRightSencondFront = imageView3;
        this.layoutHeader = constraintLayout2;
        this.llRightTv = linearLayout;
        this.tvRightFront = cornerTextView;
        this.tvTitle = textView;
    }
}