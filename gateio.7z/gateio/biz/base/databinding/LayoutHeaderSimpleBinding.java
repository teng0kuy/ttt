package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import com.gateio.biz.base.R;

/* loaded from: classes4.dex */
public abstract class LayoutHeaderSimpleBinding extends ViewDataBinding {

    @NonNull
    public final ImageView btnHeadBack;

    @NonNull
    public final LinearLayout layoutHeader;

    @NonNull
    public final TextView tvTitle;

    public static LayoutHeaderSimpleBinding bind(@NonNull View view) {
        return bind(view, DataBindingUtil.getDefaultComponent());
    }

    @NonNull
    public static LayoutHeaderSimpleBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        return inflate(layoutInflater, viewGroup, z10, DataBindingUtil.getDefaultComponent());
    }

    @Deprecated
    public static LayoutHeaderSimpleBinding bind(@NonNull View view, @Nullable Object obj) {
        return (LayoutHeaderSimpleBinding) ViewDataBinding.bind(obj, view, R.layout.layout_header_simple);
    }

    @NonNull
    @Deprecated
    public static LayoutHeaderSimpleBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10, @Nullable Object obj) {
        return (LayoutHeaderSimpleBinding) ViewDataBinding.inflateInternal(layoutInflater, R.layout.layout_header_simple, viewGroup, z10, obj);
    }

    protected LayoutHeaderSimpleBinding(Object obj, View view, int i10, ImageView imageView, LinearLayout linearLayout, TextView textView) {
        super(obj, view, i10);
        this.btnHeadBack = imageView;
        this.layoutHeader = linearLayout;
        this.tvTitle = textView;
    }

    @NonNull
    public static LayoutHeaderSimpleBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, DataBindingUtil.getDefaultComponent());
    }

    @NonNull
    @Deprecated
    public static LayoutHeaderSimpleBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable Object obj) {
        return (LayoutHeaderSimpleBinding) ViewDataBinding.inflateInternal(layoutInflater, R.layout.layout_header_simple, null, false, obj);
    }
}