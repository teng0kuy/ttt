package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.R;
import com.gateio.lib.uikit.button.GTButtonV5;
import com.gateio.lib.uikit.rate.GTRatingV5;
import com.gateio.uiComponent.GateIconFont;

/* loaded from: classes4.dex */
public final class UserRateComponentBinding implements ViewBinding {

    @NonNull
    public final GTButtonV5 btClaimNow;

    @NonNull
    public final GTButtonV5 btSubmitFeedback;

    @NonNull
    public final GateIconFont icClaimReward;

    @NonNull
    public final GateIconFont icRewardClose;

    @NonNull
    public final LinearLayout llRateReward;

    @NonNull
    public final GTRatingV5 ratingRate;

    @NonNull
    public final RelativeLayout rlRateShow;

    @NonNull
    private final View rootView;

    @NonNull
    public final TextView tvRateTitle;

    @NonNull
    public static UserRateComponentBinding bind(@NonNull View view) {
        int i10 = R.id.bt_claim_now;
        GTButtonV5 gTButtonV5 = (GTButtonV5) ViewBindings.findChildViewById(view, i10);
        if (gTButtonV5 != null) {
            i10 = R.id.bt_submit_feedback;
            GTButtonV5 gTButtonV52 = (GTButtonV5) ViewBindings.findChildViewById(view, i10);
            if (gTButtonV52 != null) {
                i10 = R.id.ic_claim_reward;
                GateIconFont gateIconFont = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                if (gateIconFont != null) {
                    i10 = R.id.ic_reward_close;
                    GateIconFont gateIconFont2 = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                    if (gateIconFont2 != null) {
                        i10 = R.id.ll_rate_reward;
                        LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                        if (linearLayout != null) {
                            i10 = R.id.rating_rate;
                            GTRatingV5 gTRatingV5 = (GTRatingV5) ViewBindings.findChildViewById(view, i10);
                            if (gTRatingV5 != null) {
                                i10 = R.id.rl_rate_show;
                                RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                if (relativeLayout != null) {
                                    i10 = R.id.tv_rate_title;
                                    TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView != null) {
                                        return new UserRateComponentBinding(view, gTButtonV5, gTButtonV52, gateIconFont, gateIconFont2, linearLayout, gTRatingV5, relativeLayout, textView);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static UserRateComponentBinding inflate(@NonNull LayoutInflater layoutInflater, @NonNull ViewGroup viewGroup) {
        if (viewGroup == null) {
            throw new NullPointerException("parent");
        }
        layoutInflater.inflate(R.layout.user_rate_component, viewGroup);
        return bind(viewGroup);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public View getRoot() {
        return this.rootView;
    }

    private UserRateComponentBinding(@NonNull View view, @NonNull GTButtonV5 gTButtonV5, @NonNull GTButtonV5 gTButtonV52, @NonNull GateIconFont gateIconFont, @NonNull GateIconFont gateIconFont2, @NonNull LinearLayout linearLayout, @NonNull GTRatingV5 gTRatingV5, @NonNull RelativeLayout relativeLayout, @NonNull TextView textView) {
        this.rootView = view;
        this.btClaimNow = gTButtonV5;
        this.btSubmitFeedback = gTButtonV52;
        this.icClaimReward = gateIconFont;
        this.icRewardClose = gateIconFont2;
        this.llRateReward = linearLayout;
        this.ratingRate = gTRatingV5;
        this.rlRateShow = relativeLayout;
        this.tvRateTitle = textView;
    }
}