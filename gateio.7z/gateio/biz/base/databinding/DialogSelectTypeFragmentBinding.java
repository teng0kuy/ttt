package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
import com.gateio.biz.base.R;

/* loaded from: classes4.dex */
public abstract class DialogSelectTypeFragmentBinding extends ViewDataBinding {

    @NonNull
    public final ConstraintLayout clRoot;

    @NonNull
    public final RecyclerView recycler;

    @NonNull
    public final TextView tvCancel;

    @NonNull
    public final TextView tvTips;

    @NonNull
    public final TextView tvTitle;

    public static DialogSelectTypeFragmentBinding bind(@NonNull View view) {
        return bind(view, DataBindingUtil.getDefaultComponent());
    }

    @NonNull
    public static DialogSelectTypeFragmentBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        return inflate(layoutInflater, viewGroup, z10, DataBindingUtil.getDefaultComponent());
    }

    @Deprecated
    public static DialogSelectTypeFragmentBinding bind(@NonNull View view, @Nullable Object obj) {
        return (DialogSelectTypeFragmentBinding) ViewDataBinding.bind(obj, view, R.layout.dialog_select_type_fragment);
    }

    @NonNull
    @Deprecated
    public static DialogSelectTypeFragmentBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10, @Nullable Object obj) {
        return (DialogSelectTypeFragmentBinding) ViewDataBinding.inflateInternal(layoutInflater, R.layout.dialog_select_type_fragment, viewGroup, z10, obj);
    }

    protected DialogSelectTypeFragmentBinding(Object obj, View view, int i10, ConstraintLayout constraintLayout, RecyclerView recyclerView, TextView textView, TextView textView2, TextView textView3) {
        super(obj, view, i10);
        this.clRoot = constraintLayout;
        this.recycler = recyclerView;
        this.tvCancel = textView;
        this.tvTips = textView2;
        this.tvTitle = textView3;
    }

    @NonNull
    public static DialogSelectTypeFragmentBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, DataBindingUtil.getDefaultComponent());
    }

    @NonNull
    @Deprecated
    public static DialogSelectTypeFragmentBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable Object obj) {
        return (DialogSelectTypeFragmentBinding) ViewDataBinding.inflateInternal(layoutInflater, R.layout.dialog_select_type_fragment, null, false, obj);
    }
}