package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import com.gateio.biz.base.R;

/* loaded from: classes4.dex */
public final class ViewGateSearch2Binding implements ViewBinding {

    @NonNull
    public final RelativeLayout rlGateSearch;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public static ViewGateSearch2Binding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ViewGateSearch2Binding bind(@NonNull View view) {
        if (view == null) {
            throw new NullPointerException("rootView");
        }
        RelativeLayout relativeLayout = (RelativeLayout) view;
        return new ViewGateSearch2Binding(relativeLayout, relativeLayout);
    }

    @NonNull
    public static ViewGateSearch2Binding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.view_gate_search2, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private ViewGateSearch2Binding(@NonNull RelativeLayout relativeLayout, @NonNull RelativeLayout relativeLayout2) {
        this.rootView = relativeLayout;
        this.rlGateSearch = relativeLayout2;
    }
}