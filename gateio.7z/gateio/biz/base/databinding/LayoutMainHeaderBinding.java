package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.R;
import com.gateio.common.view.LinearLayoutInterceptTouch;

/* loaded from: classes4.dex */
public final class LayoutMainHeaderBinding implements ViewBinding {

    @NonNull
    public final ImageView btnHeadBack;

    @NonNull
    public final ImageView btnHeadFront;

    @NonNull
    public final ImageView btnHeadFrontForC2c;

    @NonNull
    public final RelativeLayout clearSearchRl;

    @NonNull
    public final ImageView imgHeadIco;

    @NonNull
    public final ImageView imgHeadIcoR;

    @NonNull
    public final ImageView ivHelp;

    @NonNull
    public final RelativeLayout layoutHeader;

    @NonNull
    public final LinearLayoutInterceptTouch llHeadTitle;

    @NonNull
    public final LinearLayout llMiddle;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final EditText searchBarEt;

    @NonNull
    public final LinearLayout searchBarLl;

    @NonNull
    public final ImageView searchIcon;

    @NonNull
    public final ImageView share;

    @NonNull
    public final TextView tvC2c;

    @NonNull
    public final TextView tvClickLxgly;

    @NonNull
    public final TextView tvHeadTitle;

    private LayoutMainHeaderBinding(@NonNull RelativeLayout relativeLayout, @NonNull ImageView imageView, @NonNull ImageView imageView2, @NonNull ImageView imageView3, @NonNull RelativeLayout relativeLayout2, @NonNull ImageView imageView4, @NonNull ImageView imageView5, @NonNull ImageView imageView6, @NonNull RelativeLayout relativeLayout3, @NonNull LinearLayoutInterceptTouch linearLayoutInterceptTouch, @NonNull LinearLayout linearLayout, @NonNull EditText editText, @NonNull LinearLayout linearLayout2, @NonNull ImageView imageView7, @NonNull ImageView imageView8, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3) {
        this.rootView = relativeLayout;
        this.btnHeadBack = imageView;
        this.btnHeadFront = imageView2;
        this.btnHeadFrontForC2c = imageView3;
        this.clearSearchRl = relativeLayout2;
        this.imgHeadIco = imageView4;
        this.imgHeadIcoR = imageView5;
        this.ivHelp = imageView6;
        this.layoutHeader = relativeLayout3;
        this.llHeadTitle = linearLayoutInterceptTouch;
        this.llMiddle = linearLayout;
        this.searchBarEt = editText;
        this.searchBarLl = linearLayout2;
        this.searchIcon = imageView7;
        this.share = imageView8;
        this.tvC2c = textView;
        this.tvClickLxgly = textView2;
        this.tvHeadTitle = textView3;
    }

    @NonNull
    public static LayoutMainHeaderBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static LayoutMainHeaderBinding bind(@NonNull View view) {
        int i10 = R.id.btn_head_back;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
        if (imageView != null) {
            i10 = R.id.btn_head_front;
            ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i10);
            if (imageView2 != null) {
                i10 = R.id.btn_head_front_for_c2c;
                ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(view, i10);
                if (imageView3 != null) {
                    i10 = R.id.clear_search_rl;
                    RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                    if (relativeLayout != null) {
                        i10 = R.id.img_head_ico;
                        ImageView imageView4 = (ImageView) ViewBindings.findChildViewById(view, i10);
                        if (imageView4 != null) {
                            i10 = R.id.img_head_ico_r;
                            ImageView imageView5 = (ImageView) ViewBindings.findChildViewById(view, i10);
                            if (imageView5 != null) {
                                i10 = R.id.iv_help;
                                ImageView imageView6 = (ImageView) ViewBindings.findChildViewById(view, i10);
                                if (imageView6 != null) {
                                    RelativeLayout relativeLayout2 = (RelativeLayout) view;
                                    i10 = R.id.ll_head_title;
                                    LinearLayoutInterceptTouch linearLayoutInterceptTouch = (LinearLayoutInterceptTouch) ViewBindings.findChildViewById(view, i10);
                                    if (linearLayoutInterceptTouch != null) {
                                        i10 = R.id.ll_middle;
                                        LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                        if (linearLayout != null) {
                                            i10 = R.id.search_bar_et;
                                            EditText editText = (EditText) ViewBindings.findChildViewById(view, i10);
                                            if (editText != null) {
                                                i10 = R.id.search_bar_ll;
                                                LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                if (linearLayout2 != null) {
                                                    i10 = R.id.search_icon;
                                                    ImageView imageView7 = (ImageView) ViewBindings.findChildViewById(view, i10);
                                                    if (imageView7 != null) {
                                                        i10 = R.id.share;
                                                        ImageView imageView8 = (ImageView) ViewBindings.findChildViewById(view, i10);
                                                        if (imageView8 != null) {
                                                            i10 = R.id.tv_c2c;
                                                            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                                                            if (textView != null) {
                                                                i10 = R.id.tv_click_lxgly;
                                                                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                if (textView2 != null) {
                                                                    i10 = R.id.tv_head_title;
                                                                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                    if (textView3 != null) {
                                                                        return new LayoutMainHeaderBinding(relativeLayout2, imageView, imageView2, imageView3, relativeLayout, imageView4, imageView5, imageView6, relativeLayout2, linearLayoutInterceptTouch, linearLayout, editText, linearLayout2, imageView7, imageView8, textView, textView2, textView3);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static LayoutMainHeaderBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.layout_main_header, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }
}