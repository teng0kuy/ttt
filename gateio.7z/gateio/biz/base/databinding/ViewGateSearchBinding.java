package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.R;
import com.gateio.common.view.CornerRelativeLayout;

/* loaded from: classes4.dex */
public final class ViewGateSearchBinding implements ViewBinding {

    @NonNull
    public final EditText etSearch;

    @NonNull
    public final ImageView ivDelete;

    @NonNull
    public final ImageView ivSearch;

    @NonNull
    public final CornerRelativeLayout rlInput;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final TextView tvFinish;

    @NonNull
    public static ViewGateSearchBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ViewGateSearchBinding bind(@NonNull View view) {
        int i10 = R.id.et_search;
        EditText editText = (EditText) ViewBindings.findChildViewById(view, i10);
        if (editText != null) {
            i10 = R.id.iv_delete;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
            if (imageView != null) {
                i10 = R.id.iv_search;
                ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i10);
                if (imageView2 != null) {
                    i10 = R.id.rl_input;
                    CornerRelativeLayout cornerRelativeLayout = (CornerRelativeLayout) ViewBindings.findChildViewById(view, i10);
                    if (cornerRelativeLayout != null) {
                        i10 = R.id.tv_finish;
                        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView != null) {
                            return new ViewGateSearchBinding((RelativeLayout) view, editText, imageView, imageView2, cornerRelativeLayout, textView);
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ViewGateSearchBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.view_gate_search, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private ViewGateSearchBinding(@NonNull RelativeLayout relativeLayout, @NonNull EditText editText, @NonNull ImageView imageView, @NonNull ImageView imageView2, @NonNull CornerRelativeLayout cornerRelativeLayout, @NonNull TextView textView) {
        this.rootView = relativeLayout;
        this.etSearch = editText;
        this.ivDelete = imageView;
        this.ivSearch = imageView2;
        this.rlInput = cornerRelativeLayout;
        this.tvFinish = textView;
    }
}