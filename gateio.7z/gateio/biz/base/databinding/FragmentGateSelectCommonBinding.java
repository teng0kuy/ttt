package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.R;

/* loaded from: classes4.dex */
public final class FragmentGateSelectCommonBinding implements ViewBinding {

    @NonNull
    public final RecyclerView recyclerView;

    @NonNull
    public final RelativeLayout rlRoot;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final TextView tvCancel;

    @NonNull
    public static FragmentGateSelectCommonBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FragmentGateSelectCommonBinding bind(@NonNull View view) {
        int i10 = R.id.recycler_view;
        RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
        if (recyclerView != null) {
            RelativeLayout relativeLayout = (RelativeLayout) view;
            int i11 = R.id.tv_cancel;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i11);
            if (textView != null) {
                return new FragmentGateSelectCommonBinding(relativeLayout, recyclerView, relativeLayout, textView);
            }
            i10 = i11;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FragmentGateSelectCommonBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_gate_select_common, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private FragmentGateSelectCommonBinding(@NonNull RelativeLayout relativeLayout, @NonNull RecyclerView recyclerView, @NonNull RelativeLayout relativeLayout2, @NonNull TextView textView) {
        this.rootView = relativeLayout;
        this.recyclerView = recyclerView;
        this.rlRoot = relativeLayout2;
        this.tvCancel = textView;
    }
}