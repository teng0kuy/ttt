package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.R;
import com.gateio.common.view.CornerLinearLayout;

/* loaded from: classes4.dex */
public final class ViewGateSearchSwitchBinding implements ViewBinding {

    @NonNull
    public final EditText etSearch;

    @NonNull
    public final ImageView ivDelete;

    @NonNull
    public final ImageView ivSearch;

    @NonNull
    public final ImageView ivType;

    @NonNull
    public final CornerLinearLayout llInput;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final TextView tvFinish;

    @NonNull
    public final TextView tvType;

    @NonNull
    public static ViewGateSearchSwitchBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ViewGateSearchSwitchBinding bind(@NonNull View view) {
        int i10 = R.id.et_search;
        EditText editText = (EditText) ViewBindings.findChildViewById(view, i10);
        if (editText != null) {
            i10 = R.id.iv_delete;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
            if (imageView != null) {
                i10 = R.id.iv_search;
                ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i10);
                if (imageView2 != null) {
                    i10 = R.id.iv_type;
                    ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(view, i10);
                    if (imageView3 != null) {
                        i10 = R.id.ll_input;
                        CornerLinearLayout cornerLinearLayout = (CornerLinearLayout) ViewBindings.findChildViewById(view, i10);
                        if (cornerLinearLayout != null) {
                            i10 = R.id.tv_finish;
                            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView != null) {
                                i10 = R.id.tv_type;
                                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView2 != null) {
                                    return new ViewGateSearchSwitchBinding((RelativeLayout) view, editText, imageView, imageView2, imageView3, cornerLinearLayout, textView, textView2);
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ViewGateSearchSwitchBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.view_gate_search_switch, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private ViewGateSearchSwitchBinding(@NonNull RelativeLayout relativeLayout, @NonNull EditText editText, @NonNull ImageView imageView, @NonNull ImageView imageView2, @NonNull ImageView imageView3, @NonNull CornerLinearLayout cornerLinearLayout, @NonNull TextView textView, @NonNull TextView textView2) {
        this.rootView = relativeLayout;
        this.etSearch = editText;
        this.ivDelete = imageView;
        this.ivSearch = imageView2;
        this.ivType = imageView3;
        this.llInput = cornerLinearLayout;
        this.tvFinish = textView;
        this.tvType = textView2;
    }
}