package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.R;

/* loaded from: classes4.dex */
public final class ItemSelectTypeBinding implements ViewBinding {

    @NonNull
    public final CheckBox cbName;

    @NonNull
    private final FrameLayout rootView;

    @NonNull
    public static ItemSelectTypeBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ItemSelectTypeBinding bind(@NonNull View view) {
        int i10 = R.id.cb_name;
        CheckBox checkBox = (CheckBox) ViewBindings.findChildViewById(view, i10);
        if (checkBox != null) {
            return new ItemSelectTypeBinding((FrameLayout) view, checkBox);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ItemSelectTypeBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.item_select_type, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public FrameLayout getRoot() {
        return this.rootView;
    }

    private ItemSelectTypeBinding(@NonNull FrameLayout frameLayout, @NonNull CheckBox checkBox) {
        this.rootView = frameLayout;
        this.cbName = checkBox;
    }
}