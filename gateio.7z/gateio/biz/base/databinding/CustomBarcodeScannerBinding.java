package com.gateio.biz.base.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.R;
import com.gateio.common.view.scan.CustomBarcodeView;
import com.gateio.common.view.scan.CustomQRViewfinderView;

/* loaded from: classes4.dex */
public final class CustomBarcodeScannerBinding implements ViewBinding {

    @NonNull
    private final FrameLayout rootView;

    @NonNull
    public final CustomBarcodeView zxingBarcodeSurface;

    @NonNull
    public final TextView zxingStatusView;

    @NonNull
    public final CustomQRViewfinderView zxingViewfinderView;

    @NonNull
    public static CustomBarcodeScannerBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static CustomBarcodeScannerBinding bind(@NonNull View view) {
        int i10 = R.id.zxing_barcode_surface;
        CustomBarcodeView customBarcodeView = (CustomBarcodeView) ViewBindings.findChildViewById(view, i10);
        if (customBarcodeView != null) {
            i10 = R.id.zxing_status_view;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                i10 = R.id.zxing_viewfinder_view;
                CustomQRViewfinderView customQRViewfinderView = (CustomQRViewfinderView) ViewBindings.findChildViewById(view, i10);
                if (customQRViewfinderView != null) {
                    return new CustomBarcodeScannerBinding((FrameLayout) view, customBarcodeView, textView, customQRViewfinderView);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static CustomBarcodeScannerBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.custom_barcode_scanner, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public FrameLayout getRoot() {
        return this.rootView;
    }

    private CustomBarcodeScannerBinding(@NonNull FrameLayout frameLayout, @NonNull CustomBarcodeView customBarcodeView, @NonNull TextView textView, @NonNull CustomQRViewfinderView customQRViewfinderView) {
        this.rootView = frameLayout;
        this.zxingBarcodeSurface = customBarcodeView;
        this.zxingStatusView = textView;
        this.zxingViewfinderView = customQRViewfinderView;
    }
}