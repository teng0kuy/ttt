package com.gateio.biz.base.delegate;

import io.reactivex.rxjava3.core.s;
import io.reactivex.rxjava3.core.x;
import io.reactivex.rxjava3.core.y;

/* compiled from: R8$$SyntheticClass */
/* loaded from: classes4.dex */
public final /* synthetic */ class d implements y {
    @Override // io.reactivex.rxjava3.core.y
    public final x apply(s sVar) {
        return GTRxFragmentDelegate.bindToActiveChanged$lambda$1(this.f10984a, sVar);
    }

    public /* synthetic */ d() {
    }
}