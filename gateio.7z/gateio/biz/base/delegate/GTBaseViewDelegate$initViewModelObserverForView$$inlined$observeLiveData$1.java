package com.gateio.biz.base.delegate;

import androidx.exifinterface.media.ExifInterface;
import com.gateio.biz.base.mvvm.GTPageState;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.SourceDebugExtension;

/* compiled from: LifecycleOwnerExt.kt */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u00022\u000e\u0010\u0003\u001a\n \u0004*\u0004\u0018\u0001H\u0002H\u0002H\n¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"<anonymous>", "", ExifInterface.GPS_DIRECTION_TRUE, "it", "kotlin.jvm.PlatformType", "invoke", "(Ljava/lang/Object;)V", "com/gateio/lib/core/ext/LifecycleOwnerExtKt$observeLiveData$1"}, k = 3, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nLifecycleOwnerExt.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LifecycleOwnerExt.kt\ncom/gateio/lib/core/ext/LifecycleOwnerExtKt$observeLiveData$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 GTBaseViewDelegate.kt\ncom/gateio/biz/base/delegate/GTBaseViewDelegate\n*L\n1#1,28:1\n1#2:29\n205#3,8:30\n*E\n"})
/* loaded from: classes4.dex */
public final class GTBaseViewDelegate$initViewModelObserverForView$$inlined$observeLiveData$1 extends Lambda implements Function1<GTPageState, Unit> {
    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ Unit invoke(GTPageState gTPageState) {
        m1712invoke(gTPageState);
        return Unit.INSTANCE;
    }

    public GTBaseViewDelegate$initViewModelObserverForView$$inlined$observeLiveData$1() {
        super(1);
    }

    /* renamed from: invoke */
    public final void m1712invoke(GTPageState gTPageState) {
        if (gTPageState != null) {
            GTPageState gTPageState2 = gTPageState;
            if (gTPageState2 instanceof GTPageState.Loading) {
                this.this$0.showPageStateForLoading((GTPageState.Loading) gTPageState2);
                return;
            }
            if (gTPageState2 instanceof GTPageState.Empty) {
                this.this$0.showPageStateForEmpty((GTPageState.Empty) gTPageState2);
            } else if (gTPageState2 instanceof GTPageState.Failure) {
                this.this$0.showPageStateForFailure((GTPageState.Failure) gTPageState2);
            } else if (gTPageState2 instanceof GTPageState.Content) {
                this.this$0.showPageStateForContent((GTPageState.Content) gTPageState2);
            }
        }
    }
}