package com.gateio.biz.base.delegate;

import android.app.Dialog;
import android.content.Context;
import androidx.annotation.MainThread;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.Observer;
import com.gateio.biz.base.mvvm.GTBaseViewModel;
import com.gateio.biz.base.mvvm.GTGlobalUI;
import com.gateio.biz.base.mvvm.GTPageState;
import com.gateio.common.tool.Utils;
import com.gateio.common.view.LoadingProgressV5;
import com.gateio.common.view.MessageInfo;
import com.gateio.common.view.MyToast;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GTBaseViewDelegate.kt */
@Metadata(d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bf\u0018\u00002\u00020\u0001J\b\u0010\u000e\u001a\u00020\u000fH\u0016J\u0010\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0011\u001a\u00020\u0012H\u0016J\u0010\u0010\u0013\u001a\u00020\u000f2\u0006\u0010\u0011\u001a\u00020\u0014H\u0016J\u0010\u0010\u0015\u001a\u00020\u000f2\u0006\u0010\u0011\u001a\u00020\u0016H\u0016J\b\u0010\u0017\u001a\u00020\u0018H\u0016J\u0010\u0010\u0019\u001a\u00020\u000f2\u0006\u0010\u0011\u001a\u00020\u001aH\u0016J\u0010\u0010\u001b\u001a\u00020\u000f2\u0006\u0010\u0011\u001a\u00020\u0012H\u0016J\u0010\u0010\u001c\u001a\u00020\u000f2\u0006\u0010\u0011\u001a\u00020\u0014H\u0016J\u0010\u0010\u001d\u001a\u00020\u000f2\u0006\u0010\u0011\u001a\u00020\u0016H\u0016J\b\u0010\u001e\u001a\u00020\u000fH\u0016J\b\u0010\u001f\u001a\u00020\u000fH\u0016J\u0010\u0010 \u001a\u00020\u000f2\u0006\u0010!\u001a\u00020\"H\u0017J\u0014\u0010#\u001a\u00020\u000f*\u00020$2\u0006\u0010%\u001a\u00020&H\u0016R\u0018\u0010\u0002\u001a\u00020\u0003X¦\u000e¢\u0006\f\u001a\u0004\b\u0004\u0010\u0005\"\u0004\b\u0006\u0010\u0007R\u001a\u0010\b\u001a\u0004\u0018\u00010\tX¦\u000e¢\u0006\f\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006'À\u0006\u0003"}, d2 = {"Lcom/gateio/biz/base/delegate/GTBaseViewDelegate;", "", "mContext", "Landroid/content/Context;", "getMContext", "()Landroid/content/Context;", "setMContext", "(Landroid/content/Context;)V", "mLoadingProgress", "Lcom/gateio/common/view/LoadingProgressV5;", "getMLoadingProgress", "()Lcom/gateio/common/view/LoadingProgressV5;", "setMLoadingProgress", "(Lcom/gateio/common/view/LoadingProgressV5;)V", "hidePageStateForContent", "", "hidePageStateForEmpty", "pageState", "Lcom/gateio/biz/base/mvvm/GTPageState$Empty;", "hidePageStateForFailure", "Lcom/gateio/biz/base/mvvm/GTPageState$Failure;", "hidePageStateForLoading", "Lcom/gateio/biz/base/mvvm/GTPageState$Loading;", "isNetWorkConnected", "", "showPageStateForContent", "Lcom/gateio/biz/base/mvvm/GTPageState$Content;", "showPageStateForEmpty", "showPageStateForFailure", "showPageStateForLoading", "showUIForSubmitLoadingDismiss", "showUIForSubmitLoadingShow", "showUIForToast", "messageInfo", "Lcom/gateio/common/view/MessageInfo;", "initViewModelObserverForView", "Landroidx/lifecycle/LifecycleOwner;", "viewModel", "Lcom/gateio/biz/base/mvvm/GTBaseViewModel;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nGTBaseViewDelegate.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GTBaseViewDelegate.kt\ncom/gateio/biz/base/delegate/GTBaseViewDelegate\n+ 2 LifecycleOwnerExt.kt\ncom/gateio/lib/core/ext/LifecycleOwnerExtKt\n*L\n1#1,229:1\n27#2,2:230\n*S KotlinDebug\n*F\n+ 1 GTBaseViewDelegate.kt\ncom/gateio/biz/base/delegate/GTBaseViewDelegate\n*L\n204#1:230,2\n*E\n"})
/* loaded from: classes4.dex */
public interface GTBaseViewDelegate {
    @NotNull
    Context getMContext();

    @Nullable
    LoadingProgressV5 getMLoadingProgress();

    void setMContext(@NotNull Context context);

    void setMLoadingProgress(@Nullable LoadingProgressV5 loadingProgressV5);

    /* compiled from: GTBaseViewDelegate.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class DefaultImpls {
        @Deprecated
        public static void hidePageStateForContent(@NotNull GTBaseViewDelegate gTBaseViewDelegate) {
            GTBaseViewDelegate.super.hidePageStateForContent();
        }

        @Deprecated
        public static void hidePageStateForEmpty(@NotNull GTBaseViewDelegate gTBaseViewDelegate, @NotNull GTPageState.Empty empty) {
            GTBaseViewDelegate.super.hidePageStateForEmpty(empty);
        }

        @Deprecated
        public static void hidePageStateForFailure(@NotNull GTBaseViewDelegate gTBaseViewDelegate, @NotNull GTPageState.Failure failure) {
            GTBaseViewDelegate.super.hidePageStateForFailure(failure);
        }

        @Deprecated
        public static void hidePageStateForLoading(@NotNull GTBaseViewDelegate gTBaseViewDelegate, @NotNull GTPageState.Loading loading) {
            GTBaseViewDelegate.super.hidePageStateForLoading(loading);
        }

        @Deprecated
        public static void initViewModelObserverForView(@NotNull GTBaseViewDelegate gTBaseViewDelegate, @NotNull LifecycleOwner lifecycleOwner, @NotNull GTBaseViewModel gTBaseViewModel) {
            GTBaseViewDelegate.super.initViewModelObserverForView(lifecycleOwner, gTBaseViewModel);
        }

        @Deprecated
        public static boolean isNetWorkConnected(@NotNull GTBaseViewDelegate gTBaseViewDelegate) {
            return GTBaseViewDelegate.super.isNetWorkConnected();
        }

        @Deprecated
        public static void showPageStateForContent(@NotNull GTBaseViewDelegate gTBaseViewDelegate, @NotNull GTPageState.Content content) {
            GTBaseViewDelegate.super.showPageStateForContent(content);
        }

        @Deprecated
        public static void showPageStateForEmpty(@NotNull GTBaseViewDelegate gTBaseViewDelegate, @NotNull GTPageState.Empty empty) {
            GTBaseViewDelegate.super.showPageStateForEmpty(empty);
        }

        @Deprecated
        public static void showPageStateForFailure(@NotNull GTBaseViewDelegate gTBaseViewDelegate, @NotNull GTPageState.Failure failure) {
            GTBaseViewDelegate.super.showPageStateForFailure(failure);
        }

        @Deprecated
        public static void showPageStateForLoading(@NotNull GTBaseViewDelegate gTBaseViewDelegate, @NotNull GTPageState.Loading loading) {
            GTBaseViewDelegate.super.showPageStateForLoading(loading);
        }

        @Deprecated
        public static void showUIForSubmitLoadingDismiss(@NotNull GTBaseViewDelegate gTBaseViewDelegate) {
            GTBaseViewDelegate.super.showUIForSubmitLoadingDismiss();
        }

        @Deprecated
        public static void showUIForSubmitLoadingShow(@NotNull GTBaseViewDelegate gTBaseViewDelegate) {
            GTBaseViewDelegate.super.showUIForSubmitLoadingShow();
        }

        @MainThread
        @Deprecated
        public static void showUIForToast(@NotNull GTBaseViewDelegate gTBaseViewDelegate, @NotNull MessageInfo messageInfo) {
            GTBaseViewDelegate.super.showUIForToast(messageInfo);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    static void initViewModelObserverForView$lambda$0(GTBaseViewDelegate gTBaseViewDelegate, GTGlobalUI gTGlobalUI) {
        if (gTGlobalUI instanceof GTGlobalUI.Toast) {
            gTBaseViewDelegate.showUIForToast(((GTGlobalUI.Toast) gTGlobalUI).getMessageInfo());
        } else if (gTGlobalUI instanceof GTGlobalUI.SubmitLoading.Show) {
            gTBaseViewDelegate.showUIForSubmitLoadingShow();
        } else if (gTGlobalUI instanceof GTGlobalUI.SubmitLoading.Dismiss) {
            gTBaseViewDelegate.showUIForSubmitLoadingDismiss();
        }
    }

    default void hidePageStateForEmpty(@NotNull GTPageState.Empty pageState) {
        Intrinsics.areEqual(pageState, GTPageState.Empty.Default.INSTANCE);
    }

    default void hidePageStateForFailure(@NotNull GTPageState.Failure pageState) {
        Intrinsics.areEqual(pageState, GTPageState.Failure.Default.INSTANCE);
    }

    default void hidePageStateForLoading(@NotNull GTPageState.Loading pageState) {
        if (Intrinsics.areEqual(pageState, GTPageState.Loading.Default.INSTANCE)) {
            showUIForSubmitLoadingDismiss();
        }
    }

    default void initViewModelObserverForView(@NotNull final LifecycleOwner lifecycleOwner, @NotNull final GTBaseViewModel gTBaseViewModel) {
        final Observer<? super GTGlobalUI> observer = new Observer() { // from class: com.gateio.biz.base.delegate.b
            @Override // androidx.lifecycle.Observer
            public final void onChanged(Object obj) {
                GTBaseViewDelegate.initViewModelObserverForView$lambda$0(this.f10982a, (GTGlobalUI) obj);
            }
        };
        gTBaseViewModel.getUi$biz_base_core_release().observeForever(observer);
        gTBaseViewModel.getPageState$biz_base_core_release().observe(lifecycleOwner, new GTBaseViewDelegate$inlined$sam$i$androidx_lifecycle_Observer$0(new Function1<GTPageState, Unit>() { // from class: com.gateio.biz.base.delegate.GTBaseViewDelegate$initViewModelObserverForView$$inlined$observeLiveData$1
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(GTPageState gTPageState) {
                m1712invoke(gTPageState);
                return Unit.INSTANCE;
            }

            {
                super(1);
            }

            /* renamed from: invoke, reason: collision with other method in class */
            public final void m1712invoke(GTPageState gTPageState) {
                if (gTPageState != null) {
                    GTPageState gTPageState2 = gTPageState;
                    if (gTPageState2 instanceof GTPageState.Loading) {
                        this.this$0.showPageStateForLoading((GTPageState.Loading) gTPageState2);
                        return;
                    }
                    if (gTPageState2 instanceof GTPageState.Empty) {
                        this.this$0.showPageStateForEmpty((GTPageState.Empty) gTPageState2);
                    } else if (gTPageState2 instanceof GTPageState.Failure) {
                        this.this$0.showPageStateForFailure((GTPageState.Failure) gTPageState2);
                    } else if (gTPageState2 instanceof GTPageState.Content) {
                        this.this$0.showPageStateForContent((GTPageState.Content) gTPageState2);
                    }
                }
            }
        }));
        lifecycleOwner.getLifecycle().addObserver(new LifecycleEventObserver() { // from class: com.gateio.biz.base.delegate.GTBaseViewDelegate$initViewModelObserverForView$lifecycleObserver$1
            @Override // androidx.lifecycle.LifecycleEventObserver
            public void onStateChanged(@NotNull LifecycleOwner source, @NotNull Lifecycle.Event event) {
                if (event.getTargetState() == Lifecycle.State.DESTROYED) {
                    gTBaseViewModel.showUIForSubmitDismiss();
                    gTBaseViewModel.getUi$biz_base_core_release().removeObserver(observer);
                    lifecycleOwner.getLifecycle().removeObserver(this);
                }
            }
        });
    }

    default void showPageStateForContent(@NotNull GTPageState.Content pageState) {
        hidePageStateForLoading(GTPageState.Loading.Default.INSTANCE);
        hidePageStateForEmpty(GTPageState.Empty.Default.INSTANCE);
        hidePageStateForFailure(GTPageState.Failure.Default.INSTANCE);
    }

    default void showPageStateForEmpty(@NotNull GTPageState.Empty pageState) {
        hidePageStateForLoading(GTPageState.Loading.Default.INSTANCE);
        hidePageStateForFailure(GTPageState.Failure.Default.INSTANCE);
        hidePageStateForContent();
        Intrinsics.areEqual(pageState, GTPageState.Empty.Default.INSTANCE);
    }

    default void showPageStateForFailure(@NotNull GTPageState.Failure pageState) {
        hidePageStateForLoading(GTPageState.Loading.Default.INSTANCE);
        hidePageStateForEmpty(GTPageState.Empty.Default.INSTANCE);
        hidePageStateForContent();
        Intrinsics.areEqual(pageState, GTPageState.Failure.Default.INSTANCE);
    }

    default void showPageStateForLoading(@NotNull GTPageState.Loading pageState) {
        hidePageStateForEmpty(GTPageState.Empty.Default.INSTANCE);
        hidePageStateForFailure(GTPageState.Failure.Default.INSTANCE);
        hidePageStateForContent();
        if (Intrinsics.areEqual(pageState, GTPageState.Loading.Default.INSTANCE)) {
            showUIForSubmitLoadingShow();
        }
    }

    default boolean isNetWorkConnected() {
        return Utils.isNetWorkConnected();
    }

    default void showUIForSubmitLoadingDismiss() {
        LoadingProgressV5 mLoadingProgress = getMLoadingProgress();
        if (mLoadingProgress != null) {
            mLoadingProgress.dismiss();
        }
    }

    default void showUIForSubmitLoadingShow() {
        LoadingProgressV5 mLoadingProgress;
        Dialog mDialog;
        Dialog mDialog2;
        boolean z10 = false;
        if (getMLoadingProgress() == null) {
            setMLoadingProgress(new LoadingProgressV5(getMContext(), null, null, null, 14, null));
            LoadingProgressV5 mLoadingProgress2 = getMLoadingProgress();
            if (mLoadingProgress2 != null && (mDialog2 = mLoadingProgress2.getMDialog()) != null) {
                mDialog2.setCanceledOnTouchOutside(false);
            }
        }
        LoadingProgressV5 mLoadingProgress3 = getMLoadingProgress();
        if (mLoadingProgress3 != null && (mDialog = mLoadingProgress3.getMDialog()) != null && !mDialog.isShowing()) {
            z10 = true;
        }
        if (z10 && (mLoadingProgress = getMLoadingProgress()) != null) {
            mLoadingProgress.show();
        }
    }

    @MainThread
    default void showUIForToast(@NotNull MessageInfo messageInfo) {
        MyToast.show(getMContext(), messageInfo);
    }

    default void hidePageStateForContent() {
    }
}