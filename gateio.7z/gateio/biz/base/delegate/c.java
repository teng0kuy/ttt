package com.gateio.biz.base.delegate;

import ca.q;

/* compiled from: R8$$SyntheticClass */
/* loaded from: classes4.dex */
public final /* synthetic */ class c implements q {
    @Override // ca.q
    public final boolean test(Object obj) {
        return GTRxFragmentDelegate.bindToActiveChanged$lambda$1$lambda$0(this.f10983a, obj);
    }

    public /* synthetic */ c() {
    }
}