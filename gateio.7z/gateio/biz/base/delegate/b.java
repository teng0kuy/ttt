package com.gateio.biz.base.delegate;

import androidx.lifecycle.Observer;
import com.gateio.biz.base.mvvm.GTGlobalUI;

/* compiled from: R8$$SyntheticClass */
/* loaded from: classes4.dex */
public final /* synthetic */ class b implements Observer {
    @Override // androidx.lifecycle.Observer
    public final void onChanged(Object obj) {
        GTBaseViewDelegate.initViewModelObserverForView$lambda$0(this.f10982a, (GTGlobalUI) obj);
    }

    public /* synthetic */ b() {
    }
}