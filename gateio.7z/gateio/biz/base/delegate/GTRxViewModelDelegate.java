package com.gateio.biz.base.delegate;

import androidx.annotation.CheckResult;
import androidx.exifinterface.media.ExifInterface;
import com.trello.rxlifecycle4.LifecycleProvider;
import com.trello.rxlifecycle4.LifecycleTransformer;
import com.trello.rxlifecycle4.RxLifecycle;
import io.reactivex.rxjava3.core.s;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlinx.coroutines.debug.internal.DebugCoroutineInfoImplKt;
import org.jetbrains.annotations.NotNull;

/* compiled from: GTRxViewModelDelegate.kt */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\bf\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0010J\u001c\u0010\u0006\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005\"\u0004\b\u0000\u0010\u00032\u0006\u0010\u0004\u001a\u00020\u0002H\u0017J\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\u0005\"\u0004\b\u0000\u0010\u0003H\u0017J\u000e\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00020\bH\u0017R\"\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00020\n8&@&X¦\u000e¢\u0006\f\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0011À\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/delegate/GTRxViewModelDelegate;", "Lcom/trello/rxlifecycle4/LifecycleProvider;", "Lcom/gateio/biz/base/delegate/GTRxViewModelDelegate$LifecycleEvent;", ExifInterface.GPS_DIRECTION_TRUE, "event", "Lcom/trello/rxlifecycle4/LifecycleTransformer;", "bindUntilEvent", "bindToLifecycle", "Lio/reactivex/rxjava3/core/s;", "lifecycle", "Lio/reactivex/rxjava3/subjects/a;", "getRxLifecycleSubject", "()Lio/reactivex/rxjava3/subjects/a;", "setRxLifecycleSubject", "(Lio/reactivex/rxjava3/subjects/a;)V", "rxLifecycleSubject", "LifecycleEvent", "biz_base_core_release"}, k = 1, mv = {1, 9, 0})
/* loaded from: classes4.dex */
public interface GTRxViewModelDelegate extends LifecycleProvider<LifecycleEvent> {

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: GTRxViewModelDelegate.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, d2 = {"Lcom/gateio/biz/base/delegate/GTRxViewModelDelegate$LifecycleEvent;", "", "(Ljava/lang/String;I)V", DebugCoroutineInfoImplKt.CREATED, "DESTROYED", "PAUSE", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class LifecycleEvent {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ LifecycleEvent[] $VALUES;
        public static final LifecycleEvent CREATED = new LifecycleEvent(DebugCoroutineInfoImplKt.CREATED, 0);
        public static final LifecycleEvent DESTROYED = new LifecycleEvent("DESTROYED", 1);
        public static final LifecycleEvent PAUSE = new LifecycleEvent("PAUSE", 2);

        private static final /* synthetic */ LifecycleEvent[] $values() {
            return new LifecycleEvent[]{CREATED, DESTROYED, PAUSE};
        }

        static {
            LifecycleEvent[] lifecycleEventArr$values = $values();
            $VALUES = lifecycleEventArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(lifecycleEventArr$values);
        }

        @NotNull
        public static EnumEntries<LifecycleEvent> getEntries() {
            return $ENTRIES;
        }

        public static LifecycleEvent valueOf(String str) {
            return (LifecycleEvent) Enum.valueOf(LifecycleEvent.class, str);
        }

        public static LifecycleEvent[] values() {
            return (LifecycleEvent[]) $VALUES.clone();
        }

        private LifecycleEvent(String str, int i10) {
        }
    }

    @NotNull
    io.reactivex.rxjava3.subjects.a<LifecycleEvent> getRxLifecycleSubject();

    void setRxLifecycleSubject(@NotNull io.reactivex.rxjava3.subjects.a<LifecycleEvent> aVar);

    @Override // com.trello.rxlifecycle4.LifecycleProvider
    @CheckResult
    @NotNull
    default <T> LifecycleTransformer<T> bindUntilEvent(@NotNull LifecycleEvent event) {
        return RxLifecycle.bindUntilEvent(getRxLifecycleSubject(), event);
    }

    @Override // com.trello.rxlifecycle4.LifecycleProvider
    @CheckResult
    @NotNull
    default <T> LifecycleTransformer<T> bindToLifecycle() {
        return RxLifecycle.bindUntilEvent(getRxLifecycleSubject(), LifecycleEvent.DESTROYED);
    }

    @Override // com.trello.rxlifecycle4.LifecycleProvider
    @CheckResult
    @NotNull
    default s<LifecycleEvent> lifecycle() {
        return getRxLifecycleSubject().hide();
    }
}