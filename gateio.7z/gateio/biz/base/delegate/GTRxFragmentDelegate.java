package com.gateio.biz.base.delegate;

import androidx.annotation.CheckResult;
import androidx.exifinterface.media.ExifInterface;
import ca.q;
import com.gateio.rxjava.ActiveProvider;
import com.trello.rxlifecycle4.LifecycleProvider;
import com.trello.rxlifecycle4.LifecycleTransformer;
import com.trello.rxlifecycle4.RxLifecycle;
import com.trello.rxlifecycle4.android.FragmentEvent;
import io.reactivex.rxjava3.core.s;
import io.reactivex.rxjava3.core.x;
import io.reactivex.rxjava3.core.y;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* compiled from: GTRxFragmentDelegate.kt */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\bf\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u00012\u00020\u0003J\u000e\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00020\u0004H\u0017J\u001c\u0010\t\u001a\b\u0012\u0004\u0012\u00028\u00000\b\"\u0004\b\u0000\u0010\u00062\u0006\u0010\u0007\u001a\u00020\u0002H\u0017J\u0014\u0010\n\u001a\b\u0012\u0004\u0012\u00028\u00000\b\"\u0004\b\u0000\u0010\u0006H\u0017J\u001e\u0010\r\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00000\f\"\b\b\u0000\u0010\u0006*\u00020\u000bH\u0016R\"\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00020\u000e8&@&X¦\u000e¢\u0006\f\u001a\u0004\b\u000f\u0010\u0010\"\u0004\b\u0011\u0010\u0012ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0014À\u0006\u0003"}, d2 = {"Lcom/gateio/biz/base/delegate/GTRxFragmentDelegate;", "Lcom/trello/rxlifecycle4/LifecycleProvider;", "Lcom/trello/rxlifecycle4/android/FragmentEvent;", "Lcom/gateio/rxjava/ActiveProvider;", "Lio/reactivex/rxjava3/core/s;", "lifecycle", ExifInterface.GPS_DIRECTION_TRUE, "event", "Lcom/trello/rxlifecycle4/LifecycleTransformer;", "bindUntilEvent", "bindToLifecycle", "", "Lio/reactivex/rxjava3/core/y;", "bindToActiveChanged", "Lio/reactivex/rxjava3/subjects/a;", "getRxLifecycleSubject", "()Lio/reactivex/rxjava3/subjects/a;", "setRxLifecycleSubject", "(Lio/reactivex/rxjava3/subjects/a;)V", "rxLifecycleSubject", "biz_base_core_release"}, k = 1, mv = {1, 9, 0})
/* loaded from: classes4.dex */
public interface GTRxFragmentDelegate extends LifecycleProvider<FragmentEvent>, ActiveProvider {
    @NotNull
    io.reactivex.rxjava3.subjects.a<FragmentEvent> getRxLifecycleSubject();

    void setRxLifecycleSubject(@NotNull io.reactivex.rxjava3.subjects.a<FragmentEvent> aVar);

    /* compiled from: GTRxFragmentDelegate.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class DefaultImpls {
        @Deprecated
        @NotNull
        public static <T> y<T, T> bindToActiveChanged(@NotNull GTRxFragmentDelegate gTRxFragmentDelegate) {
            return GTRxFragmentDelegate.super.bindToActiveChanged();
        }

        @CheckResult
        @Deprecated
        @NotNull
        public static <T> LifecycleTransformer<T> bindToLifecycle(@NotNull GTRxFragmentDelegate gTRxFragmentDelegate) {
            return GTRxFragmentDelegate.super.bindToLifecycle();
        }

        @CheckResult
        @Deprecated
        @NotNull
        public static <T> LifecycleTransformer<T> bindUntilEvent(@NotNull GTRxFragmentDelegate gTRxFragmentDelegate, @NotNull FragmentEvent fragmentEvent) {
            return GTRxFragmentDelegate.super.bindUntilEvent(fragmentEvent);
        }

        @CheckResult
        @Deprecated
        @NotNull
        public static s<FragmentEvent> lifecycle(@NotNull GTRxFragmentDelegate gTRxFragmentDelegate) {
            return GTRxFragmentDelegate.super.lifecycle();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    static x bindToActiveChanged$lambda$1(final GTRxFragmentDelegate gTRxFragmentDelegate, s sVar) {
        return sVar.filter(new q() { // from class: com.gateio.biz.base.delegate.c
            @Override // ca.q
            public final boolean test(Object obj) {
                return GTRxFragmentDelegate.bindToActiveChanged$lambda$1$lambda$0(this.f10983a, obj);
            }
        });
    }

    @Override // com.gateio.rxjava.ActiveProvider
    @NotNull
    default <T> y<T, T> bindToActiveChanged() {
        return new y() { // from class: com.gateio.biz.base.delegate.d
            @Override // io.reactivex.rxjava3.core.y
            public final x apply(s sVar) {
                return GTRxFragmentDelegate.bindToActiveChanged$lambda$1(this.f10984a, sVar);
            }
        };
    }

    @Override // com.trello.rxlifecycle4.LifecycleProvider
    @CheckResult
    @NotNull
    default <T> LifecycleTransformer<T> bindUntilEvent(@NotNull FragmentEvent event) {
        return RxLifecycle.bindUntilEvent(getRxLifecycleSubject(), event);
    }

    /* JADX INFO: Access modifiers changed from: private */
    static boolean bindToActiveChanged$lambda$1$lambda$0(GTRxFragmentDelegate gTRxFragmentDelegate, Object obj) {
        return gTRxFragmentDelegate.isActive();
    }

    @Override // com.trello.rxlifecycle4.LifecycleProvider
    @CheckResult
    @NotNull
    default <T> LifecycleTransformer<T> bindToLifecycle() {
        return RxLifecycle.bindUntilEvent(getRxLifecycleSubject(), FragmentEvent.DESTROY_VIEW);
    }

    @Override // com.trello.rxlifecycle4.LifecycleProvider
    @CheckResult
    @NotNull
    default s<FragmentEvent> lifecycle() {
        return getRxLifecycleSubject().hide();
    }
}