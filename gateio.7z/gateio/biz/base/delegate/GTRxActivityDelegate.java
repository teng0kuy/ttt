package com.gateio.biz.base.delegate;

import androidx.annotation.CheckResult;
import androidx.exifinterface.media.ExifInterface;
import com.trello.rxlifecycle4.LifecycleProvider;
import com.trello.rxlifecycle4.LifecycleTransformer;
import com.trello.rxlifecycle4.RxLifecycle;
import com.trello.rxlifecycle4.android.ActivityEvent;
import io.reactivex.rxjava3.core.s;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* compiled from: GTRxActivityDelegate.kt */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\bf\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001J\u000e\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00020\u0003H\u0017J\u001c\u0010\b\u001a\b\u0012\u0004\u0012\u00028\u00000\u0007\"\u0004\b\u0000\u0010\u00052\u0006\u0010\u0006\u001a\u00020\u0002H\u0017J\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00028\u00000\u0007\"\u0004\b\u0000\u0010\u0005H\u0017R\"\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00020\n8&@&X¦\u000e¢\u0006\f\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0010À\u0006\u0003"}, d2 = {"Lcom/gateio/biz/base/delegate/GTRxActivityDelegate;", "Lcom/trello/rxlifecycle4/LifecycleProvider;", "Lcom/trello/rxlifecycle4/android/ActivityEvent;", "Lio/reactivex/rxjava3/core/s;", "lifecycle", ExifInterface.GPS_DIRECTION_TRUE, "event", "Lcom/trello/rxlifecycle4/LifecycleTransformer;", "bindUntilEvent", "bindToLifecycle", "Lio/reactivex/rxjava3/subjects/a;", "getRxLifecycleSubject", "()Lio/reactivex/rxjava3/subjects/a;", "setRxLifecycleSubject", "(Lio/reactivex/rxjava3/subjects/a;)V", "rxLifecycleSubject", "biz_base_core_release"}, k = 1, mv = {1, 9, 0})
/* loaded from: classes4.dex */
public interface GTRxActivityDelegate extends LifecycleProvider<ActivityEvent> {
    @NotNull
    io.reactivex.rxjava3.subjects.a<ActivityEvent> getRxLifecycleSubject();

    void setRxLifecycleSubject(@NotNull io.reactivex.rxjava3.subjects.a<ActivityEvent> aVar);

    /* compiled from: GTRxActivityDelegate.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class DefaultImpls {
        @CheckResult
        @Deprecated
        @NotNull
        public static <T> LifecycleTransformer<T> bindToLifecycle(@NotNull GTRxActivityDelegate gTRxActivityDelegate) {
            return GTRxActivityDelegate.super.bindToLifecycle();
        }

        @CheckResult
        @Deprecated
        @NotNull
        public static <T> LifecycleTransformer<T> bindUntilEvent(@NotNull GTRxActivityDelegate gTRxActivityDelegate, @NotNull ActivityEvent activityEvent) {
            return GTRxActivityDelegate.super.bindUntilEvent(activityEvent);
        }

        @CheckResult
        @Deprecated
        @NotNull
        public static s<ActivityEvent> lifecycle(@NotNull GTRxActivityDelegate gTRxActivityDelegate) {
            return GTRxActivityDelegate.super.lifecycle();
        }
    }

    @Override // com.trello.rxlifecycle4.LifecycleProvider
    @CheckResult
    @NotNull
    default <T> LifecycleTransformer<T> bindUntilEvent(@NotNull ActivityEvent event) {
        return RxLifecycle.bindUntilEvent(getRxLifecycleSubject(), event);
    }

    @Override // com.trello.rxlifecycle4.LifecycleProvider
    @CheckResult
    @NotNull
    default <T> LifecycleTransformer<T> bindToLifecycle() {
        return RxLifecycle.bindUntilEvent(getRxLifecycleSubject(), ActivityEvent.DESTROY);
    }

    @Override // com.trello.rxlifecycle4.LifecycleProvider
    @CheckResult
    @NotNull
    default s<ActivityEvent> lifecycle() {
        return getRxLifecycleSubject().hide();
    }
}