package com.gateio.biz.base.delegate;

import kotlin.Metadata;
import kotlin.text.StringsKt__StringsJVMKt;
import org.jetbrains.annotations.NotNull;

/* compiled from: GTBaseLogDelegate.kt */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\bf\u0018\u00002\u00020\u0001R\u0014\u0010\u0002\u001a\u00020\u00038VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0004\u0010\u0005R\u0014\u0010\u0006\u001a\u00020\u00038VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\u0005ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\bÀ\u0006\u0003"}, d2 = {"Lcom/gateio/biz/base/delegate/GTBaseLogDelegate;", "", "lifecycleLogMessage", "", "getLifecycleLogMessage", "()Ljava/lang/String;", "logTag", "getLogTag", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public interface GTBaseLogDelegate {

    /* compiled from: GTBaseLogDelegate.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class DefaultImpls {
        @Deprecated
        @NotNull
        public static String getLifecycleLogMessage(@NotNull GTBaseLogDelegate gTBaseLogDelegate) {
            return GTBaseLogDelegate.super.getLifecycleLogMessage();
        }

        @Deprecated
        @NotNull
        public static String getLogTag(@NotNull GTBaseLogDelegate gTBaseLogDelegate) {
            return GTBaseLogDelegate.super.getLogTag();
        }
    }

    @NotNull
    default String getLifecycleLogMessage() {
        String strValueOf = String.valueOf(this);
        if (!StringsKt__StringsJVMKt.startsWith(strValueOf, getLogTag(), false)) {
            return getClass().getSimpleName() + " - " + strValueOf;
        }
        return strValueOf;
    }

    @NotNull
    default String getLogTag() {
        return getClass().getSimpleName();
    }
}