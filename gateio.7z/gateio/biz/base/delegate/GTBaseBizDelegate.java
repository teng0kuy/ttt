package com.gateio.biz.base.delegate;

import android.app.Dialog;
import android.content.Context;
import android.text.TextUtils;
import androidx.annotation.StringRes;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.Observer;
import com.alipay.alipaysecuritysdk.common.legacy.model.DynamicModel;
import com.gateio.biz.base.BizBaseInitializer;
import com.gateio.biz.base.R;
import com.gateio.biz.base.mvvm.GTBaseViewModel;
import com.gateio.biz.base.mvvm.GTGlobalBiz;
import com.gateio.biz.safe.fido2.event.EventValue;
import com.gateio.common.kotlin.ext.AnyKt;
import com.gateio.common.view.LoadingProgressV5;
import com.gateio.common.view.MessageInfo;
import com.gateio.http.tool.HttpUtilsExt;
import com.gateio.lib.storage.GTStorage;
import com.gateio.lib.storage.utils.ThreadUtils;
import com.gateio.lib.uikit.dialog.GTDialogV3;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GTBaseBizDelegate.kt */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\b\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u0003\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bf\u0018\u00002\u00020\u0001J\u0012\u0010\b\u001a\u00020\t2\b\u0010\n\u001a\u0004\u0018\u00010\u000bH\u0016J\b\u0010\f\u001a\u00020\tH\u0016J\u0018\u0010\r\u001a\u00020\t2\u0006\u0010\u000e\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u000bH\u0016J\b\u0010\u0010\u001a\u00020\tH\u0016J\u0010\u0010\u0011\u001a\u00020\t2\u0006\u0010\u000f\u001a\u00020\u000bH\u0016J\u0012\u0010\u0012\u001a\u00020\t2\b\b\u0001\u0010\u0013\u001a\u00020\u0014H\u0016J\u001a\u0010\u0012\u001a\u00020\t2\u0006\u0010\u0015\u001a\u00020\u00142\b\u0010\u000f\u001a\u0004\u0018\u00010\u000bH\u0016J\u0012\u0010\u0016\u001a\u00020\t2\b\u0010\u000f\u001a\u0004\u0018\u00010\u000bH\u0016J\u0012\u0010\u0017\u001a\u00020\t2\b\u0010\u000f\u001a\u0004\u0018\u00010\u000bH\u0016J\u0010\u0010\u0018\u001a\u00020\t2\u0006\u0010\u0019\u001a\u00020\u001aH\u0016J\u0014\u0010\u001b\u001a\u00020\t*\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001eH\u0016R\u0018\u0010\u0002\u001a\u00020\u0003X¦\u000e¢\u0006\f\u001a\u0004\b\u0004\u0010\u0005\"\u0004\b\u0006\u0010\u0007ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u001fÀ\u0006\u0003"}, d2 = {"Lcom/gateio/biz/base/delegate/GTBaseBizDelegate;", "", "mContext", "Landroid/content/Context;", "getMContext", "()Landroid/content/Context;", "setMContext", "(Landroid/content/Context;)V", "handleBizForFingerPrintNeed", "", EventValue.STRATEGY_QRID, "", "handleBizForGoLogin", "handleBizForHttpApiError", "code", "msg", "handleBizForMomentTokenExpired", "handleBizForNoNet", "handleBizForPassNeed", "resId", "", "passType", "handleBizForPassNoSet", "handleBizForPassSecondNeed", "handleBizForUnknownError", DynamicModel.KEY_ABBR_DYNAMIC_EXPIRE, "", "initViewModelObserverForBiz", "Landroidx/lifecycle/LifecycleOwner;", "viewModel", "Lcom/gateio/biz/base/mvvm/GTBaseViewModel;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public interface GTBaseBizDelegate {

    /* compiled from: GTBaseBizDelegate.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class DefaultImpls {
        @Deprecated
        public static void handleBizForPassNeed(@NotNull GTBaseBizDelegate gTBaseBizDelegate, int i10, @Nullable String str) {
            GTBaseBizDelegate.super.handleBizForPassNeed(i10, str);
        }

        @Deprecated
        public static void handleBizForPassNeed(@NotNull GTBaseBizDelegate gTBaseBizDelegate, @StringRes int i10) {
            GTBaseBizDelegate.super.handleBizForPassNeed(i10);
        }

        @Deprecated
        public static void handleBizForFingerPrintNeed(@NotNull GTBaseBizDelegate gTBaseBizDelegate, @Nullable String str) {
            GTBaseBizDelegate.super.handleBizForFingerPrintNeed(str);
        }

        @Deprecated
        public static void handleBizForGoLogin(@NotNull GTBaseBizDelegate gTBaseBizDelegate) {
            GTBaseBizDelegate.super.handleBizForGoLogin();
        }

        @Deprecated
        public static void handleBizForHttpApiError(@NotNull GTBaseBizDelegate gTBaseBizDelegate, @NotNull String str, @NotNull String str2) {
            GTBaseBizDelegate.super.handleBizForHttpApiError(str, str2);
        }

        @Deprecated
        public static void handleBizForMomentTokenExpired(@NotNull GTBaseBizDelegate gTBaseBizDelegate) {
            GTBaseBizDelegate.super.handleBizForMomentTokenExpired();
        }

        @Deprecated
        public static void handleBizForNoNet(@NotNull GTBaseBizDelegate gTBaseBizDelegate, @NotNull String str) {
            GTBaseBizDelegate.super.handleBizForNoNet(str);
        }

        @Deprecated
        public static void handleBizForPassNoSet(@NotNull GTBaseBizDelegate gTBaseBizDelegate, @Nullable String str) {
            GTBaseBizDelegate.super.handleBizForPassNoSet(str);
        }

        @Deprecated
        public static void handleBizForPassSecondNeed(@NotNull GTBaseBizDelegate gTBaseBizDelegate, @Nullable String str) {
            GTBaseBizDelegate.super.handleBizForPassSecondNeed(str);
        }

        @Deprecated
        public static void handleBizForUnknownError(@NotNull GTBaseBizDelegate gTBaseBizDelegate, @NotNull Throwable th) {
            GTBaseBizDelegate.super.handleBizForUnknownError(th);
        }

        @Deprecated
        public static void initViewModelObserverForBiz(@NotNull GTBaseBizDelegate gTBaseBizDelegate, @NotNull LifecycleOwner lifecycleOwner, @NotNull GTBaseViewModel gTBaseViewModel) {
            GTBaseBizDelegate.super.initViewModelObserverForBiz(lifecycleOwner, gTBaseViewModel);
        }
    }

    @NotNull
    Context getMContext();

    default void handleBizForPassNeed(int passType, @Nullable String msg) {
        if (this instanceof GTBaseViewDelegate) {
            ((GTBaseViewDelegate) this).showUIForToast(MessageInfo.INSTANCE.string(msg, MessageInfo.Level.INFO));
        }
    }

    void setMContext(@NotNull Context context);

    /* JADX INFO: Access modifiers changed from: private */
    static void initViewModelObserverForBiz$lambda$1(GTBaseBizDelegate gTBaseBizDelegate, GTGlobalBiz gTGlobalBiz) {
        if (Intrinsics.areEqual(gTGlobalBiz, GTGlobalBiz.GoLogin.INSTANCE)) {
            gTBaseBizDelegate.handleBizForGoLogin();
            return;
        }
        if (gTGlobalBiz instanceof GTGlobalBiz.HttpApiError) {
            GTGlobalBiz.HttpApiError httpApiError = (GTGlobalBiz.HttpApiError) gTGlobalBiz;
            gTBaseBizDelegate.handleBizForHttpApiError(httpApiError.getCode(), httpApiError.getMessage());
            return;
        }
        if (Intrinsics.areEqual(gTGlobalBiz, GTGlobalBiz.MomentTokenExpired.INSTANCE)) {
            gTBaseBizDelegate.handleBizForMomentTokenExpired();
            return;
        }
        if (gTGlobalBiz instanceof GTGlobalBiz.PassNoSet) {
            gTBaseBizDelegate.handleBizForPassNoSet(((GTGlobalBiz.PassNoSet) gTGlobalBiz).getMessage());
            return;
        }
        if (gTGlobalBiz instanceof GTGlobalBiz.PassNeed) {
            GTGlobalBiz.PassNeed passNeed = (GTGlobalBiz.PassNeed) gTGlobalBiz;
            gTBaseBizDelegate.handleBizForPassNeed(passNeed.getPassType(), passNeed.getMessage());
            return;
        }
        if (gTGlobalBiz instanceof GTGlobalBiz.PassSecondNeed) {
            gTBaseBizDelegate.handleBizForPassSecondNeed(((GTGlobalBiz.PassSecondNeed) gTGlobalBiz).getMessage());
            return;
        }
        if (gTGlobalBiz instanceof GTGlobalBiz.FingerPrintNeed) {
            gTBaseBizDelegate.handleBizForFingerPrintNeed(((GTGlobalBiz.FingerPrintNeed) gTGlobalBiz).getQrid());
        } else if (gTGlobalBiz instanceof GTGlobalBiz.NoNet) {
            gTBaseBizDelegate.handleBizForNoNet(((GTGlobalBiz.NoNet) gTGlobalBiz).getMessage());
        } else if (gTGlobalBiz instanceof GTGlobalBiz.Unknown) {
            gTBaseBizDelegate.handleBizForUnknownError(((GTGlobalBiz.Unknown) gTGlobalBiz).getE());
        }
    }

    default void handleBizForGoLogin() {
        if (!ThreadUtils.INSTANCE.isMainThread()) {
            AnyKt.runOnMainThread(new Function0<Unit>() { // from class: com.gateio.biz.base.delegate.GTBaseBizDelegate.handleBizForGoLogin.1
                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                {
                    super(0);
                }

                /* renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    GTBaseBizDelegate.this.handleBizForGoLogin();
                }
            });
            return;
        }
        GTStorage.saveKV$default("isGoLogin", Boolean.TRUE, null, 4, null);
        BizBaseInitializer bizBaseInitializer = BizBaseInitializer.INSTANCE;
        bizBaseInitializer.getDataBridge().showLogin(getMContext());
        bizBaseInitializer.getDataBridge().logOut();
    }

    default void handleBizForHttpApiError(@NotNull String code, @NotNull String msg) {
        if (this instanceof GTBaseViewDelegate) {
            ((GTBaseViewDelegate) this).showUIForToast(MessageInfo.INSTANCE.string(msg, MessageInfo.Level.ERROR));
        }
    }

    default void handleBizForPassNeed(@StringRes int resId) {
        if (this instanceof GTBaseViewDelegate) {
            ((GTBaseViewDelegate) this).showUIForToast(MessageInfo.INSTANCE.stringId(resId, MessageInfo.Level.INFO));
        }
    }

    default void handleBizForPassNoSet(@Nullable String msg) {
        if (BizBaseInitializer.INSTANCE.getDataBridge().isValid()) {
            GTDialogV3.Builder.setConfirmButtonText$default(GTDialogV3.Builder.setCancelButtonText$default(GTDialogV3.Builder.setContentText$default(GTDialogV3.INSTANCE.builder(getMContext()).setTitle(getMContext().getString(R.string.fund_pass_no_hint)), TextUtils.isEmpty(msg) ? getMContext().getString(R.string.fund_pass_need_set_hint) : msg, false, 2, null), getMContext().getString(R.string.user_qx), null, null, null, 14, null), getMContext().getString(R.string.fund_pass_go_to_setting), null, null, new Function2<Boolean, Dialog, Unit>() { // from class: com.gateio.biz.base.delegate.GTBaseBizDelegate.handleBizForPassNoSet.1
                @Override // kotlin.jvm.functions.Function2
                /* renamed from: invoke */
                public /* bridge */ /* synthetic */ Unit mo2invoke(Boolean bool, Dialog dialog) {
                    invoke(bool.booleanValue(), dialog);
                    return Unit.INSTANCE;
                }

                {
                    super(2);
                }

                public final void invoke(boolean z10, @Nullable Dialog dialog) {
                    if (ThreadUtils.INSTANCE.isMainThread()) {
                        BizBaseInitializer.INSTANCE.getDataBridge().fundPasswordReset(GTBaseBizDelegate.this.getMContext());
                    } else {
                        final GTBaseBizDelegate gTBaseBizDelegate = GTBaseBizDelegate.this;
                        AnyKt.runOnMainThread(new Function0<Unit>() { // from class: com.gateio.biz.base.delegate.GTBaseBizDelegate.handleBizForPassNoSet.1.1
                            @Override // kotlin.jvm.functions.Function0
                            public /* bridge */ /* synthetic */ Unit invoke() {
                                invoke2();
                                return Unit.INSTANCE;
                            }

                            {
                                super(0);
                            }

                            /* renamed from: invoke, reason: avoid collision after fix types in other method */
                            public final void invoke2() {
                                BizBaseInitializer.INSTANCE.getDataBridge().fundPasswordReset(gTBaseBizDelegate.getMContext());
                            }
                        });
                    }
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                }
            }, 6, null).show();
        } else if (this instanceof GTBaseViewDelegate) {
            ((GTBaseViewDelegate) this).showUIForToast(MessageInfo.INSTANCE.stringId(R.string.user_manage_sqsx, MessageInfo.Level.INFO));
        }
    }

    default void handleBizForPassSecondNeed(@Nullable String msg) {
        if (this instanceof GTBaseViewDelegate) {
            ((GTBaseViewDelegate) this).showUIForToast(MessageInfo.INSTANCE.string(msg, MessageInfo.Level.INFO));
        }
    }

    default void handleBizForUnknownError(@NotNull Throwable e10) {
        int unknownErrorTip;
        if (this instanceof GTBaseViewDelegate) {
            GTBaseViewDelegate gTBaseViewDelegate = (GTBaseViewDelegate) this;
            LoadingProgressV5 mLoadingProgress = gTBaseViewDelegate.getMLoadingProgress();
            Dialog mDialog = mLoadingProgress != null ? mLoadingProgress.getMDialog() : null;
            boolean z10 = false;
            if (mDialog != null && mDialog.isShowing()) {
                z10 = true;
            }
            if (!z10 || (unknownErrorTip = HttpUtilsExt.getUnknownErrorTip(e10)) == 0) {
                return;
            }
            gTBaseViewDelegate.showUIForToast(MessageInfo.INSTANCE.stringId(unknownErrorTip, MessageInfo.Level.ERROR));
        }
    }

    default void initViewModelObserverForBiz(@NotNull final LifecycleOwner lifecycleOwner, @NotNull final GTBaseViewModel gTBaseViewModel) {
        final Observer<? super GTGlobalBiz> observer = new Observer() { // from class: com.gateio.biz.base.delegate.a
            @Override // androidx.lifecycle.Observer
            public final void onChanged(Object obj) {
                GTBaseBizDelegate.initViewModelObserverForBiz$lambda$1(this.f10981a, (GTGlobalBiz) obj);
            }
        };
        gTBaseViewModel.getBiz$biz_base_core_release().observeForever(observer);
        lifecycleOwner.getLifecycle().addObserver(new LifecycleEventObserver() { // from class: com.gateio.biz.base.delegate.GTBaseBizDelegate$initViewModelObserverForBiz$lifecycleObserver$1
            @Override // androidx.lifecycle.LifecycleEventObserver
            public void onStateChanged(@NotNull LifecycleOwner source, @NotNull Lifecycle.Event event) {
                if (event.getTargetState() == Lifecycle.State.DESTROYED) {
                    gTBaseViewModel.getBiz$biz_base_core_release().removeObserver(observer);
                    lifecycleOwner.getLifecycle().removeObserver(this);
                }
            }
        });
    }

    default void handleBizForMomentTokenExpired() {
    }

    default void handleBizForFingerPrintNeed(@Nullable String qrid) {
    }

    default void handleBizForNoNet(@NotNull String msg) {
    }
}