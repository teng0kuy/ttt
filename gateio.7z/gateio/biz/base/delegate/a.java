package com.gateio.biz.base.delegate;

import androidx.lifecycle.Observer;
import com.gateio.biz.base.mvvm.GTGlobalBiz;

/* compiled from: R8$$SyntheticClass */
/* loaded from: classes4.dex */
public final /* synthetic */ class a implements Observer {
    @Override // androidx.lifecycle.Observer
    public final void onChanged(Object obj) {
        GTBaseBizDelegate.initViewModelObserverForBiz$lambda$1(this.f10981a, (GTGlobalBiz) obj);
    }

    public /* synthetic */ a() {
    }
}