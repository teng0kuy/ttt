package com.gateio.biz.base;

/* loaded from: classes4.dex */
public final class BuildConfig {
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final boolean IS_APP_MODE = false;
    public static final String LIBRARY_PACKAGE_NAME = "com.gateio.biz.base";
}