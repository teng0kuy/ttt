package com.gateio.biz.base.mvvm;

import com.gateio.common.view.MessageInfo;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* compiled from: GTGlobalUI.kt */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bv\u0018\u00002\u00020\u0001:\u0002\u0002\u0003\u0082\u0001\u0002\u0004\u0005ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0006À\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTGlobalUI;", "", "SubmitLoading", "Toast", "Lcom/gateio/biz/base/mvvm/GTGlobalUI$SubmitLoading;", "Lcom/gateio/biz/base/mvvm/GTGlobalUI$Toast;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public interface GTGlobalUI {

    /* compiled from: GTGlobalUI.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001:\u0002\u0002\u0003ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0004À\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTGlobalUI$SubmitLoading;", "Lcom/gateio/biz/base/mvvm/GTGlobalUI;", "Dismiss", "Show", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public interface SubmitLoading extends GTGlobalUI {

        /* compiled from: GTGlobalUI.kt */
        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTGlobalUI$SubmitLoading$Dismiss;", "Lcom/gateio/biz/base/mvvm/GTGlobalUI$SubmitLoading;", "()V", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
        public static final class Dismiss implements SubmitLoading {

            @NotNull
            public static final Dismiss INSTANCE = new Dismiss();

            private Dismiss() {
            }
        }

        /* compiled from: GTGlobalUI.kt */
        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTGlobalUI$SubmitLoading$Show;", "Lcom/gateio/biz/base/mvvm/GTGlobalUI$SubmitLoading;", "()V", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
        public static final class Show implements SubmitLoading {

            @NotNull
            public static final Show INSTANCE = new Show();

            private Show() {
            }
        }
    }

    /* compiled from: GTGlobalUI.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTGlobalUI$Toast;", "Lcom/gateio/biz/base/mvvm/GTGlobalUI;", "messageInfo", "Lcom/gateio/common/view/MessageInfo;", "(Lcom/gateio/common/view/MessageInfo;)V", "getMessageInfo", "()Lcom/gateio/common/view/MessageInfo;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Toast implements GTGlobalUI {

        @NotNull
        private final MessageInfo messageInfo;

        @NotNull
        public final MessageInfo getMessageInfo() {
            return this.messageInfo;
        }

        public Toast(@NotNull MessageInfo messageInfo) {
            this.messageInfo = messageInfo;
        }
    }
}