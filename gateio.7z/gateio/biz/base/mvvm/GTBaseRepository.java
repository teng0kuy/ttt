package com.gateio.biz.base.mvvm;

import androidx.exifinterface.media.ExifInterface;
import com.alipay.zoloz.toyger.ToygerService;
import com.gateio.lib.core.mvvm.repository.IGTRepository;
import com.gateio.lib.http.GTApiServiceAppV1;
import com.gateio.lib.http.GTApiServiceV1;
import com.gateio.lib.http.GTApiServiceV3;
import com.gateio.lib.network.GTBizHttpClient;
import com.gateio.lib.storage.GTStorage;
import com.gateio.lib.storage.core.StorageDelete;
import com.gateio.lib.storage.core.StorageQuery;
import com.gateio.lib.storage.mmvk.GTStoreKVDomain;
import com.gateio.lib.storage.protocol.IGTStorageObject;
import com.google.gson.Gson;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GTBaseRepository.kt */
@Metadata(d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u001c\n\u0002\b\u0005\b&\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u001a\u0010\u0003\u001a\u0002H\u0004\"\n\b\u0000\u0010\u0004\u0018\u0001*\u00020\u0005H\u0086\b¢\u0006\u0002\u0010\u0006J\u001a\u0010\u0007\u001a\u0002H\u0004\"\n\b\u0000\u0010\u0004\u0018\u0001*\u00020\bH\u0086\b¢\u0006\u0002\u0010\tJ\u001a\u0010\n\u001a\u0002H\u0004\"\n\b\u0000\u0010\u0004\u0018\u0001*\u00020\u000bH\u0086\b¢\u0006\u0002\u0010\fJ$\u0010\r\u001a\b\u0012\u0004\u0012\u0002H\u000f0\u000e\"\b\b\u0000\u0010\u000f*\u00020\u00102\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u0002H\u000f0\u0012J\u000e\u0010\r\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015J,\u0010\u0016\u001a\b\u0012\u0004\u0012\u0002H\u000f0\u000e\"\b\b\u0000\u0010\u000f*\u00020\u00102\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u0002H\u000f0\u0012H\u0086@¢\u0006\u0002\u0010\u0017J\u0016\u0010\u0016\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015H\u0086@¢\u0006\u0002\u0010\u0018J\u000e\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001cJ$\u0010\u001d\u001a\b\u0012\u0004\u0012\u0002H\u000f0\u001e\"\b\b\u0000\u0010\u000f*\u00020\u00102\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u0002H\u000f0\u0012J,\u0010\u001d\u001a\u0004\u0018\u0001H\u001f\"\u0006\b\u0000\u0010\u001f\u0018\u00012\u0006\u0010\u0014\u001a\u00020\u00152\n\b\u0002\u0010 \u001a\u0004\u0018\u0001H\u001fH\u0086\b¢\u0006\u0002\u0010!J\u001d\u0010\"\u001a\u00020\u0013\"\b\b\u0000\u0010\u000f*\u00020\u00102\u0006\u0010#\u001a\u0002H\u000f¢\u0006\u0002\u0010$J\u0016\u0010\"\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010#\u001a\u00020\u001cJ\u001e\u0010\"\u001a\u00020\u0013\"\b\b\u0000\u0010\u000f*\u00020\u00102\f\u0010%\u001a\b\u0012\u0004\u0012\u0002H\u000f0&J \u0010'\u001a\u00020\u0013\"\b\b\u0000\u0010\u000f*\u00020\u00102\u0006\u0010#\u001a\u0002H\u000fH\u0086@¢\u0006\u0002\u0010(J\u001e\u0010'\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010#\u001a\u00020\u001cH\u0086@¢\u0006\u0002\u0010)J&\u0010'\u001a\u00020\u0013\"\b\b\u0000\u0010\u000f*\u00020\u00102\f\u0010%\u001a\b\u0012\u0004\u0012\u0002H\u000f0&H\u0086@¢\u0006\u0002\u0010*¨\u0006+"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTBaseRepository;", "Lcom/gateio/lib/core/mvvm/repository/IGTRepository;", "()V", "apiV1", "API_SERVICE", "Lcom/gateio/lib/http/GTApiServiceV1;", "()Lcom/gateio/lib/http/GTApiServiceV1;", "apiV3", "Lcom/gateio/lib/http/GTApiServiceV3;", "()Lcom/gateio/lib/http/GTApiServiceV3;", "appV1", "Lcom/gateio/lib/http/GTApiServiceAppV1;", "()Lcom/gateio/lib/http/GTApiServiceAppV1;", "delete", "Lcom/gateio/lib/storage/core/StorageDelete;", ExifInterface.LATITUDE_SOUTH, "Lcom/gateio/lib/storage/protocol/IGTStorageObject;", "clazz", "Ljava/lang/Class;", "", ToygerService.KEY_RES_9_KEY, "", "deleteOnSuspend", "(Ljava/lang/Class;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "mapToJsonRequestBody", "Lokhttp3/RequestBody;", "obj", "", "query", "Lcom/gateio/lib/storage/core/StorageQuery;", "R", "defValue", "(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;", "save", "value", "(Lcom/gateio/lib/storage/protocol/IGTStorageObject;)V", "values", "", "saveOnSuspend", "(Lcom/gateio/lib/storage/protocol/IGTStorageObject;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "(Ljava/lang/String;Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "(Ljava/lang/Iterable;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nGTBaseRepository.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GTBaseRepository.kt\ncom/gateio/biz/base/mvvm/GTBaseRepository\n+ 2 GTStorage.kt\ncom/gateio/lib/storage/GTStorage\n*L\n1#1,103:1\n384#2,10:104\n*S KotlinDebug\n*F\n+ 1 GTBaseRepository.kt\ncom/gateio/biz/base/mvvm/GTBaseRepository\n*L\n79#1:104,10\n*E\n"})
/* loaded from: classes4.dex */
public abstract class GTBaseRepository implements IGTRepository {
    public final void delete(@NotNull String key) {
        GTStorage.deleteKV$default(key, null, 2, null);
    }

    @Nullable
    public final Object deleteOnSuspend(@NotNull String str, @NotNull Continuation<? super Unit> continuation) {
        GTStorage.deleteKV$default(str, null, 2, null);
        return Unit.INSTANCE;
    }

    public final /* synthetic */ <R> R query(String key, R defValue) {
        GTStorage gTStorage = GTStorage.INSTANCE;
        GTStoreKVDomain gTStoreKVDomain = GTStoreKVDomain.Default;
        Intrinsics.reifiedOperationMarker(4, "R");
        if (gTStorage.isPrimitiveOrWrapper(Object.class)) {
            Intrinsics.reifiedOperationMarker(4, "R");
            return (R) GTStorage.queryKV(key, Object.class, (Object) defValue, gTStoreKVDomain);
        }
        Intrinsics.needClassReification();
        return (R) GTStorage.queryKV(key, new GTBaseRepository$query$$inlined$queryKV$default$1().getType(), defValue, gTStoreKVDomain);
    }

    public final void save(@NotNull String key, @NotNull Object value) {
        GTStorage.saveKV$default(key, value, null, 4, null);
    }

    @Nullable
    public final Object saveOnSuspend(@NotNull String str, @NotNull Object obj, @NotNull Continuation<? super Unit> continuation) {
        GTStorage.saveKV$default(str, obj, null, 4, null);
        return Unit.INSTANCE;
    }

    public static /* synthetic */ Object query$default(GTBaseRepository gTBaseRepository, String str, Object obj, int i10, Object obj2) {
        if (obj2 != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: query");
        }
        if ((i10 & 2) != 0) {
            obj = null;
        }
        GTStorage gTStorage = GTStorage.INSTANCE;
        GTStoreKVDomain gTStoreKVDomain = GTStoreKVDomain.Default;
        Intrinsics.reifiedOperationMarker(4, "R");
        if (gTStorage.isPrimitiveOrWrapper(Object.class)) {
            Intrinsics.reifiedOperationMarker(4, "R");
            return GTStorage.queryKV(str, (Class<Object>) Object.class, obj, gTStoreKVDomain);
        }
        Intrinsics.needClassReification();
        return GTStorage.queryKV(str, new GTBaseRepository$query$$inlined$queryKV$default$1().getType(), obj, gTStoreKVDomain);
    }

    public final /* synthetic */ <API_SERVICE extends GTApiServiceV1> API_SERVICE apiV1() {
        GTBizHttpClient gTBizHttpClient = GTBizHttpClient.INSTANCE;
        Intrinsics.reifiedOperationMarker(4, "API_SERVICE");
        return (API_SERVICE) gTBizHttpClient.apiV1(GTApiServiceV1.class);
    }

    public final /* synthetic */ <API_SERVICE extends GTApiServiceV3> API_SERVICE apiV3() {
        GTBizHttpClient gTBizHttpClient = GTBizHttpClient.INSTANCE;
        Intrinsics.reifiedOperationMarker(4, "API_SERVICE");
        return (API_SERVICE) gTBizHttpClient.apiV3(GTApiServiceV3.class);
    }

    public final /* synthetic */ <API_SERVICE extends GTApiServiceAppV1> API_SERVICE appV1() {
        GTBizHttpClient gTBizHttpClient = GTBizHttpClient.INSTANCE;
        Intrinsics.reifiedOperationMarker(4, "API_SERVICE");
        return (API_SERVICE) gTBizHttpClient.appV1(GTApiServiceAppV1.class);
    }

    @NotNull
    public final <S extends IGTStorageObject> StorageDelete<S> delete(@NotNull Class<S> clazz) {
        return GTStorage.delete(clazz);
    }

    @Nullable
    public final <S extends IGTStorageObject> Object deleteOnSuspend(@NotNull Class<S> cls, @NotNull Continuation<? super StorageDelete<S>> continuation) {
        return GTStorage.INSTANCE.deleteOnSuspend(cls, continuation);
    }

    @NotNull
    public final RequestBody mapToJsonRequestBody(@NotNull Object obj) {
        return RequestBody.INSTANCE.create(new Gson().toJson(obj), MediaType.INSTANCE.get("application/json"));
    }

    public final <S extends IGTStorageObject> void save(@NotNull S value) {
        GTStorage.save(value);
    }

    @Nullable
    public final <S extends IGTStorageObject> Object saveOnSuspend(@NotNull S s10, @NotNull Continuation<? super Unit> continuation) throws Throwable {
        Object objSaveOnSuspend = GTStorage.INSTANCE.saveOnSuspend((GTStorage) s10, continuation);
        return objSaveOnSuspend == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSaveOnSuspend : Unit.INSTANCE;
    }

    public final <S extends IGTStorageObject> void save(@NotNull Iterable<? extends S> values) {
        GTStorage.save(values);
    }

    @Nullable
    public final <S extends IGTStorageObject> Object saveOnSuspend(@NotNull Iterable<? extends S> iterable, @NotNull Continuation<? super Unit> continuation) throws Throwable {
        Object objSaveOnSuspend = GTStorage.saveOnSuspend(iterable, continuation);
        return objSaveOnSuspend == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objSaveOnSuspend : Unit.INSTANCE;
    }

    @NotNull
    public final <S extends IGTStorageObject> StorageQuery<S> query(@NotNull Class<S> clazz) {
        return GTStorage.query(clazz);
    }
}