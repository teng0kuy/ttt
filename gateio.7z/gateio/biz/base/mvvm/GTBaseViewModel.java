package com.gateio.biz.base.mvvm;

import androidx.annotation.MainThread;
import androidx.annotation.StringRes;
import androidx.exifinterface.media.ExifInterface;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.bytedance.apm.agent.v2.instrumentation.AppAgent;
import com.gateio.biz.base.delegate.GTRxViewModelDelegate;
import com.gateio.biz.base.mvvm.GTGlobalBiz;
import com.gateio.biz.base.mvvm.GTGlobalUI;
import com.gateio.common.kotlin.ext.AnyKt;
import com.gateio.common.view.MessageInfo;
import com.gateio.lib.core.mvvm.GTCoreViewModel;
import com.gateio.lib.logger.GTLog;
import com.gateio.lib.network.result.GTHttpResultKotlin;
import com.gateio.lib.network.result.GTHttpResultKotlinsForRxJavaKt;
import com.gateio.lib.thread.pool.GTThreadPool;
import com.gateio.lib.thread.utils.GTThreadUtils;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.tencent.qcloud.tuicore.TUIConstants;
import io.reactivex.rxjava3.core.s;
import java.util.Arrays;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt___ArraysKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlinx.coroutines.CoroutineScope;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.spongycastle.crypto.tls.CipherSuite;

/* compiled from: GTBaseViewModel.kt */
@Metadata(d1 = {"\u0000ª\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\t\b&\u0018\u00002\u00020\u0001:\u0001VB\u0007¢\u0006\u0004\bT\u0010UJ\u000e\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002J\u0010\u0010\b\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0006H\u0007J\u0010\u0010\u000b\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\tH\u0007J\u0010\u0010\u000e\u001a\u00020\u00042\u0006\u0010\r\u001a\u00020\fH\u0007J\u001c\u0010\u0013\u001a\u00020\u00042\b\u0010\u0010\u001a\u0004\u0018\u00010\u000f2\b\b\u0002\u0010\u0012\u001a\u00020\u0011H\u0007J\u001c\u0010\u0016\u001a\u00020\u00042\b\b\u0001\u0010\u0015\u001a\u00020\u00142\b\b\u0002\u0010\u0012\u001a\u00020\u0011H\u0007J\b\u0010\u0017\u001a\u00020\u0004H\u0007J\b\u0010\u0018\u001a\u00020\u0004H\u0007J\b\u0010\u0019\u001a\u00020\u0004H\u0007J[\u0010#\u001a\b\u0012\u0004\u0012\u00028\u00000\u001b\"\u0004\b\u0000\u0010\u001a*\b\u0012\u0004\u0012\u00028\u00000\u001b23\b\u0001\u0010\"\u001a-\b\u0001\u0012\u0013\u0012\u00118\u0000¢\u0006\f\b\u001d\u0012\b\b\u001e\u0012\u0004\b\b(\u001f\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00040 \u0012\u0006\u0012\u0004\u0018\u00010!0\u001cH\u0084@¢\u0006\u0004\b#\u0010$JY\u0010%\u001a\b\u0012\u0004\u0012\u00028\u00000\u001b\"\u0004\b\u0000\u0010\u001a*\b\u0012\u0004\u0012\u00028\u00000\u001b21\u0010\"\u001a-\b\u0001\u0012\u0013\u0012\u00118\u0000¢\u0006\f\b\u001d\u0012\b\b\u001e\u0012\u0004\b\b(\u001f\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00040 \u0012\u0006\u0012\u0004\u0018\u00010!0\u001cH\u0084@¢\u0006\u0004\b%\u0010$JQ\u0010(\u001a\b\u0012\u0004\u0012\u00028\u00000\u001b\"\u0004\b\u0000\u0010\u001a*\b\u0012\u0004\u0012\u00028\u00000\u001b2)\b\u0001\u0010\"\u001a#\b\u0001\u0012\u0004\u0012\u00020&\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00040 \u0012\u0006\u0012\u0004\u0018\u00010!0\u001c¢\u0006\u0002\b'H\u0084@¢\u0006\u0004\b(\u0010$JO\u0010)\u001a\b\u0012\u0004\u0012\u00028\u00000\u001b\"\u0004\b\u0000\u0010\u001a*\b\u0012\u0004\u0012\u00028\u00000\u001b2'\u0010\"\u001a#\b\u0001\u0012\u0004\u0012\u00020&\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00040 \u0012\u0006\u0012\u0004\u0018\u00010!0\u001c¢\u0006\u0002\b'H\u0084@¢\u0006\u0004\b)\u0010$JO\u0010#\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u001b0*\"\u0004\b\u0000\u0010\u001a*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u001b0*2#\b\u0001\u0010\"\u001a\u001d\u0012\u0013\u0012\u00118\u0000¢\u0006\f\b\u001d\u0012\b\b\u001e\u0012\u0004\b\b(\u001f\u0012\u0004\u0012\u00020\u00040+H\u0004JO\u0010%\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u001b0*\"\u0004\b\u0000\u0010\u001a*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u001b0*2#\b\u0001\u0010\"\u001a\u001d\u0012\u0013\u0012\u00118\u0000¢\u0006\f\b\u001d\u0012\b\b\u001e\u0012\u0004\b\b(\u001f\u0012\u0004\u0012\u00020\u00040+H\u0004JE\u0010(\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u001b0*\"\u0004\b\u0000\u0010\u001a*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u001b0*2\u0019\b\u0001\u0010\"\u001a\u0013\u0012\u0004\u0012\u00020&\u0012\u0004\u0012\u00020\u00040+¢\u0006\u0002\b'H\u0004JE\u0010)\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u001b0*\"\u0004\b\u0000\u0010\u001a*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u001b0*2\u0019\b\u0001\u0010\"\u001a\u0013\u0012\u0004\u0012\u00020&\u0012\u0004\u0012\u00020\u00040+¢\u0006\u0002\b'H\u0004JU\u0010/\u001a\b\u0012\u0004\u0012\u00028\u00000\u001b\"\u0004\b\u0000\u0010\u001a*\b\u0012\u0004\u0012\u00028\u00000\u001b2\u0012\u0010.\u001a\n\u0012\u0006\b\u0001\u0012\u00020-0,\"\u00020-2\u0019\b\u0001\u0010\"\u001a\u0013\u0012\u0004\u0012\u00020&\u0012\u0004\u0012\u00020\u00040+¢\u0006\u0002\b'H\u0084@¢\u0006\u0004\b/\u00100J`\u0010/\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u001b0*\"\u0004\b\u0000\u0010\u001a*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u001b0*2\u0012\u0010.\u001a\n\u0012\u0006\b\u0001\u0012\u00020-0,\"\u00020-2\u0019\b\u0001\u0010\"\u001a\u0013\u0012\u0004\u0012\u00020&\u0012\u0004\u0012\u00020\u00040+¢\u0006\u0002\b'H\u0004¢\u0006\u0004\b/\u00101J'\u00102\u001a\u00020\u0004*\u00020&2\u0012\u0010.\u001a\n\u0012\u0006\b\u0001\u0012\u00020-0,\"\u00020-H\u0015¢\u0006\u0004\b2\u00103J\u0010\u00106\u001a\u00020\u00042\u0006\u00105\u001a\u000204H\u0016J\b\u00107\u001a\u00020\u0004H\u0014R\u001a\u00109\u001a\b\u0012\u0004\u0012\u00020\u0002088\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b9\u0010:R\u001c\u0010;\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u0006088\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b;\u0010:R\u001c\u0010<\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\t088\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b<\u0010:R\"\u0010>\u001a\u00020=8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b>\u0010?\u001a\u0004\b>\u0010@\"\u0004\bA\u0010BR(\u0010E\u001a\b\u0012\u0004\u0012\u00020D0C8\u0006@\u0006X\u0086.¢\u0006\u0012\n\u0004\bE\u0010F\u001a\u0004\bG\u0010H\"\u0004\bI\u0010JR\u0016\u0010M\u001a\u0004\u0018\u00010\u00028DX\u0084\u0004¢\u0006\u0006\u001a\u0004\bK\u0010LR\u001c\u0010Q\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020N8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\bO\u0010PR\u001c\u0010\u0007\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00060N8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\bR\u0010PR\u001c\u0010\n\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\t0N8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\bS\u0010P¨\u0006W"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTBaseViewModel;", "Lcom/gateio/lib/core/mvvm/GTCoreViewModel;", "Lcom/gateio/biz/base/mvvm/GTPageState;", "state", "", "showPageState", "Lcom/gateio/biz/base/mvvm/GTGlobalUI;", "ui", "showUI", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz;", "biz", "handleBiz", "Lcom/gateio/common/view/MessageInfo;", "messageInfo", "showUIForToast", "", "string", "Lcom/gateio/common/view/MessageInfo$Level;", FirebaseAnalytics.Param.LEVEL, "showUIForToastString", "", "stringId", "showUIForToastStringId", "showUIForSubmitLoading", "showUIForSubmitDismiss", "handleBizForGoLogin", ExifInterface.GPS_DIRECTION_TRUE, "Lcom/gateio/lib/network/result/GTHttpResultKotlin;", "Lkotlin/Function2;", "Lkotlin/ParameterName;", "name", "value", "Lkotlin/coroutines/Continuation;", "", "action", "onSuccessMain", "(Lcom/gateio/lib/network/result/GTHttpResultKotlin;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "onSuccessAsync", "Lcom/gateio/lib/network/result/GTHttpResultKotlin$Failure;", "Lkotlin/ExtensionFunctionType;", "onFailureMain", "onFailureAsync", "Lio/reactivex/rxjava3/core/s;", "Lkotlin/Function1;", "", "Lcom/gateio/biz/base/mvvm/GTBaseViewModel$HttpFailureType;", "ignoreType", "onFailureHandleMain", "(Lcom/gateio/lib/network/result/GTHttpResultKotlin;[Lcom/gateio/biz/base/mvvm/GTBaseViewModel$HttpFailureType;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "(Lio/reactivex/rxjava3/core/s;[Lcom/gateio/biz/base/mvvm/GTBaseViewModel$HttpFailureType;Lkotlin/jvm/functions/Function1;)Lio/reactivex/rxjava3/core/s;", "handleFailure", "(Lcom/gateio/lib/network/result/GTHttpResultKotlin$Failure;[Lcom/gateio/biz/base/mvvm/GTBaseViewModel$HttpFailureType;)V", "Landroidx/lifecycle/LifecycleOwner;", TUIConstants.TUIChat.OWNER, AppAgent.ON_CREATE, "onCleared", "Landroidx/lifecycle/MutableLiveData;", "_pageState", "Landroidx/lifecycle/MutableLiveData;", "_ui", "_biz", "", "isSupportRx", "Z", "()Z", "setSupportRx", "(Z)V", "Lio/reactivex/rxjava3/subjects/a;", "Lcom/gateio/biz/base/delegate/GTRxViewModelDelegate$LifecycleEvent;", "rxLifecycleSubject", "Lio/reactivex/rxjava3/subjects/a;", "getRxLifecycleSubject", "()Lio/reactivex/rxjava3/subjects/a;", "setRxLifecycleSubject", "(Lio/reactivex/rxjava3/subjects/a;)V", "getCurrentPageState", "()Lcom/gateio/biz/base/mvvm/GTPageState;", "currentPageState", "Landroidx/lifecycle/LiveData;", "getPageState$biz_base_core_release", "()Landroidx/lifecycle/LiveData;", "pageState", "getUi$biz_base_core_release", "getBiz$biz_base_core_release", AppAgent.CONSTRUCT, "()V", "HttpFailureType", "biz_base_core_release"}, k = 1, mv = {1, 9, 0})
@SourceDebugExtension({"SMAP\nGTBaseViewModel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GTBaseViewModel.kt\ncom/gateio/biz/base/mvvm/GTBaseViewModel\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,387:1\n1#2:388\n*E\n"})
/* loaded from: classes4.dex */
public abstract class GTBaseViewModel extends GTCoreViewModel {
    private boolean isSupportRx;
    public io.reactivex.rxjava3.subjects.a<GTRxViewModelDelegate.LifecycleEvent> rxLifecycleSubject;

    @NotNull
    private final MutableLiveData<GTPageState> _pageState = new MutableLiveData<>();

    @NotNull
    private final MutableLiveData<GTGlobalUI> _ui = new MutableLiveData<>();

    @NotNull
    private final MutableLiveData<GTGlobalBiz> _biz = new MutableLiveData<>();

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: GTBaseViewModel.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u000b\b\u0084\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000b¨\u0006\f"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTBaseViewModel$HttpFailureType;", "", "(Ljava/lang/String;I)V", "HttpApi", "LoginError", "PassNeed", "PassSecondNeed", "FingerPrintNeed", "PassNoSet", "MomentTokenExpired", "NoNet", "Unknown", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class HttpFailureType {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ HttpFailureType[] $VALUES;
        public static final HttpFailureType HttpApi = new HttpFailureType("HttpApi", 0);
        public static final HttpFailureType LoginError = new HttpFailureType("LoginError", 1);
        public static final HttpFailureType PassNeed = new HttpFailureType("PassNeed", 2);
        public static final HttpFailureType PassSecondNeed = new HttpFailureType("PassSecondNeed", 3);
        public static final HttpFailureType FingerPrintNeed = new HttpFailureType("FingerPrintNeed", 4);
        public static final HttpFailureType PassNoSet = new HttpFailureType("PassNoSet", 5);
        public static final HttpFailureType MomentTokenExpired = new HttpFailureType("MomentTokenExpired", 6);
        public static final HttpFailureType NoNet = new HttpFailureType("NoNet", 7);
        public static final HttpFailureType Unknown = new HttpFailureType("Unknown", 8);

        private static final /* synthetic */ HttpFailureType[] $values() {
            return new HttpFailureType[]{HttpApi, LoginError, PassNeed, PassSecondNeed, FingerPrintNeed, PassNoSet, MomentTokenExpired, NoNet, Unknown};
        }

        static {
            HttpFailureType[] httpFailureTypeArr$values = $values();
            $VALUES = httpFailureTypeArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(httpFailureTypeArr$values);
        }

        @NotNull
        public static EnumEntries<HttpFailureType> getEntries() {
            return $ENTRIES;
        }

        public static HttpFailureType valueOf(String str) {
            return (HttpFailureType) Enum.valueOf(HttpFailureType.class, str);
        }

        public static HttpFailureType[] values() {
            return (HttpFailureType[]) $VALUES.clone();
        }

        private HttpFailureType(String str, int i10) {
        }
    }

    /* compiled from: GTBaseViewModel.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    @DebugMetadata(c = "com.gateio.biz.base.mvvm.GTBaseViewModel", f = "GTBaseViewModel.kt", i = {0}, l = {222}, m = "onFailureAsync", n = {"$this$onFailureAsync"}, s = {"L$0"})
    /* renamed from: com.gateio.biz.base.mvvm.GTBaseViewModel$onFailureAsync$1, reason: invalid class name and case insensitive filesystem */
    static final class C18541<T> extends ContinuationImpl {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        C18541(Continuation<? super C18541> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return GTBaseViewModel.this.onFailureAsync(null, null, this);
        }
    }

    /* compiled from: GTBaseViewModel.kt */
    @Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\u00020\u0003H\n¢\u0006\u0002\b\u0004"}, d2 = {"<anonymous>", "", ExifInterface.GPS_DIRECTION_TRUE, "Lcom/gateio/lib/network/result/GTHttpResultKotlin$Failure;", "invoke"}, k = 3, mv = {1, 9, 0}, xi = 48)
    /* renamed from: com.gateio.biz.base.mvvm.GTBaseViewModel$onFailureAsync$3, reason: invalid class name and case insensitive filesystem */
    static final class C18553 extends Lambda implements Function1<GTHttpResultKotlin.Failure, Unit> {
        final /* synthetic */ Function1<GTHttpResultKotlin.Failure, Unit> $action;

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(GTHttpResultKotlin.Failure failure) {
            invoke2(failure);
            return Unit.INSTANCE;
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        C18553(Function1<? super GTHttpResultKotlin.Failure, Unit> function1) {
            super(1);
            this.$action = function1;
        }

        /* renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2(@NotNull final GTHttpResultKotlin.Failure failure) {
            final Function1<GTHttpResultKotlin.Failure, Unit> function1 = this.$action;
            GTThreadPool.cpu(new Runnable() { // from class: com.gateio.biz.base.mvvm.a
                @Override // java.lang.Runnable
                public final void run() {
                    function1.invoke(failure);
                }
            });
        }
    }

    /* compiled from: GTBaseViewModel.kt */
    @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0003\u001a\u00020\u0002\"\u0004\b\u0000\u0010\u0000*\u00020\u0001H\u008a@"}, d2 = {ExifInterface.GPS_DIRECTION_TRUE, "Lcom/gateio/lib/network/result/GTHttpResultKotlin$Failure;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.base.mvvm.GTBaseViewModel$onFailureHandleMain$2", f = "GTBaseViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.base.mvvm.GTBaseViewModel$onFailureHandleMain$2, reason: invalid class name and case insensitive filesystem */
    static final class C18562 extends SuspendLambda implements Function2<GTHttpResultKotlin.Failure, Continuation<? super Unit>, Object> {
        final /* synthetic */ Function1<GTHttpResultKotlin.Failure, Unit> $action;
        final /* synthetic */ HttpFailureType[] $ignoreType;
        private /* synthetic */ Object L$0;
        int label;

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull GTHttpResultKotlin.Failure failure, @Nullable Continuation<? super Unit> continuation) {
            return ((C18562) create(failure, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        C18562(HttpFailureType[] httpFailureTypeArr, Function1<? super GTHttpResultKotlin.Failure, Unit> function1, Continuation<? super C18562> continuation) {
            super(2, continuation);
            this.$ignoreType = httpFailureTypeArr;
            this.$action = function1;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C18562 c18562 = GTBaseViewModel.this.new C18562(this.$ignoreType, this.$action, continuation);
            c18562.L$0 = obj;
            return c18562;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label == 0) {
                ResultKt.throwOnFailure(obj);
                GTHttpResultKotlin.Failure failure = (GTHttpResultKotlin.Failure) this.L$0;
                GTBaseViewModel gTBaseViewModel = GTBaseViewModel.this;
                HttpFailureType[] httpFailureTypeArr = this.$ignoreType;
                gTBaseViewModel.handleFailure(failure, (HttpFailureType[]) Arrays.copyOf(httpFailureTypeArr, httpFailureTypeArr.length));
                this.$action.invoke(failure);
                return Unit.INSTANCE;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }

    /* compiled from: GTBaseViewModel.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    @DebugMetadata(c = "com.gateio.biz.base.mvvm.GTBaseViewModel", f = "GTBaseViewModel.kt", i = {0}, l = {214}, m = "onFailureMain", n = {"$this$onFailureMain"}, s = {"L$0"})
    /* renamed from: com.gateio.biz.base.mvvm.GTBaseViewModel$onFailureMain$1, reason: invalid class name and case insensitive filesystem */
    static final class C18581<T> extends ContinuationImpl {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        C18581(Continuation<? super C18581> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return GTBaseViewModel.this.onFailureMain(null, null, this);
        }
    }

    /* compiled from: GTBaseViewModel.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    @DebugMetadata(c = "com.gateio.biz.base.mvvm.GTBaseViewModel", f = "GTBaseViewModel.kt", i = {0}, l = {206}, m = "onSuccessAsync", n = {"$this$onSuccessAsync"}, s = {"L$0"})
    /* renamed from: com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessAsync$1, reason: invalid class name and case insensitive filesystem */
    static final class C18601<T> extends ContinuationImpl {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        C18601(Continuation<? super C18601> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return GTBaseViewModel.this.onSuccessAsync(null, null, this);
        }
    }

    /* compiled from: GTBaseViewModel.kt */
    @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0003\u001a\u00020\u0002\"\u0004\b\u0000\u0010\u0000*\u00020\u0001H\u008a@"}, d2 = {ExifInterface.GPS_DIRECTION_TRUE, "Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessAsync$2", f = "GTBaseViewModel.kt", i = {}, l = {206}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessAsync$2, reason: invalid class name and case insensitive filesystem */
    static final class C18612 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Function2<T, Continuation<? super Unit>, Object> $action;
        final /* synthetic */ GTHttpResultKotlin<T> $this_onSuccessAsync;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        C18612(Function2<? super T, ? super Continuation<? super Unit>, ? extends Object> function2, GTHttpResultKotlin<? extends T> gTHttpResultKotlin, Continuation<? super C18612> continuation) {
            super(2, continuation);
            this.$action = function2;
            this.$this_onSuccessAsync = gTHttpResultKotlin;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            return new C18612(this.$action, this.$this_onSuccessAsync, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull CoroutineScope coroutineScope, @Nullable Continuation<? super Unit> continuation) {
            return ((C18612) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 == 1) {
                    ResultKt.throwOnFailure(obj);
                } else {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            } else {
                ResultKt.throwOnFailure(obj);
                Function2<T, Continuation<? super Unit>, Object> function2 = this.$action;
                Object value = this.$this_onSuccessAsync.getValue();
                this.label = 1;
                if (function2.mo2invoke(value, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: Add missing generic type declarations: [T] */
    /* compiled from: GTBaseViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u00022\u0006\u0010\u0003\u001a\u0002H\u0002H\n¢\u0006\u0004\b\u0004\u0010\u0005"}, d2 = {"<anonymous>", "", ExifInterface.GPS_DIRECTION_TRUE, "value", "invoke", "(Ljava/lang/Object;)V"}, k = 3, mv = {1, 9, 0}, xi = 48)
    /* renamed from: com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessAsync$3, reason: invalid class name and case insensitive filesystem */
    static final class C18623<T> extends Lambda implements Function1<T, Unit> {
        final /* synthetic */ Function1<T, Unit> $action;

        /* JADX WARN: Multi-variable type inference failed */
        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(Object obj) {
            invoke2((C18623<T>) obj);
            return Unit.INSTANCE;
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        C18623(Function1<? super T, Unit> function1) {
            super(1);
            this.$action = function1;
        }

        /* renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2(final T t10) {
            final Function1<T, Unit> function1 = this.$action;
            GTThreadPool.cpu(new Runnable() { // from class: com.gateio.biz.base.mvvm.b
                @Override // java.lang.Runnable
                public final void run() {
                    function1.invoke(t10);
                }
            });
        }
    }

    /* compiled from: GTBaseViewModel.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    @DebugMetadata(c = "com.gateio.biz.base.mvvm.GTBaseViewModel", f = "GTBaseViewModel.kt", i = {0}, l = {CipherSuite.TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256}, m = "onSuccessMain", n = {"$this$onSuccessMain"}, s = {"L$0"})
    /* renamed from: com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessMain$1, reason: invalid class name and case insensitive filesystem */
    static final class C18631<T> extends ContinuationImpl {
        Object L$0;
        int label;
        /* synthetic */ Object result;

        C18631(Continuation<? super C18631> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return GTBaseViewModel.this.onSuccessMain(null, null, this);
        }
    }

    /* compiled from: GTBaseViewModel.kt */
    @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0003\u001a\u00020\u0002\"\u0004\b\u0000\u0010\u0000*\u00020\u0001H\u008a@"}, d2 = {ExifInterface.GPS_DIRECTION_TRUE, "Lkotlinx/coroutines/CoroutineScope;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessMain$2", f = "GTBaseViewModel.kt", i = {}, l = {CipherSuite.TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessMain$2, reason: invalid class name and case insensitive filesystem */
    static final class C18642 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Function2<T, Continuation<? super Unit>, Object> $action;
        final /* synthetic */ GTHttpResultKotlin<T> $this_onSuccessMain;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        C18642(Function2<? super T, ? super Continuation<? super Unit>, ? extends Object> function2, GTHttpResultKotlin<? extends T> gTHttpResultKotlin, Continuation<? super C18642> continuation) {
            super(2, continuation);
            this.$action = function2;
            this.$this_onSuccessMain = gTHttpResultKotlin;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            return new C18642(this.$action, this.$this_onSuccessMain, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull CoroutineScope coroutineScope, @Nullable Continuation<? super Unit> continuation) {
            return ((C18642) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 == 1) {
                    ResultKt.throwOnFailure(obj);
                } else {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            } else {
                ResultKt.throwOnFailure(obj);
                Function2<T, Continuation<? super Unit>, Object> function2 = this.$action;
                Object value = this.$this_onSuccessMain.getValue();
                this.label = 1;
                if (function2.mo2invoke(value, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            return Unit.INSTANCE;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    @org.jetbrains.annotations.Nullable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected final <T> java.lang.Object onFailureAsync(@org.jetbrains.annotations.NotNull com.gateio.lib.network.result.GTHttpResultKotlin<? extends T> r7, @org.jetbrains.annotations.NotNull kotlin.jvm.functions.Function2<? super com.gateio.lib.network.result.GTHttpResultKotlin.Failure, ? super kotlin.coroutines.Continuation<? super kotlin.Unit>, ? extends java.lang.Object> r8, @org.jetbrains.annotations.NotNull kotlin.coroutines.Continuation<? super com.gateio.lib.network.result.GTHttpResultKotlin<? extends T>> r9) {
        /*
            r6 = this;
            boolean r0 = r9 instanceof com.gateio.biz.base.mvvm.GTBaseViewModel.C18541
            if (r0 == 0) goto L13
            r0 = r9
            com.gateio.biz.base.mvvm.GTBaseViewModel$onFailureAsync$1 r0 = (com.gateio.biz.base.mvvm.GTBaseViewModel.C18541) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.label = r1
            goto L18
        L13:
            com.gateio.biz.base.mvvm.GTBaseViewModel$onFailureAsync$1 r0 = new com.gateio.biz.base.mvvm.GTBaseViewModel$onFailureAsync$1
            r0.<init>(r9)
        L18:
            java.lang.Object r9 = r0.result
            java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L36
            if (r2 != r3) goto L2d
            java.lang.Object r7 = r0.L$0
            com.gateio.lib.network.result.GTHttpResultKotlin r7 = (com.gateio.lib.network.result.GTHttpResultKotlin) r7
            kotlin.ResultKt.throwOnFailure(r9)
            goto L54
        L2d:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r8)
            throw r7
        L36:
            kotlin.ResultKt.throwOnFailure(r9)
            com.gateio.lib.network.result.GTHttpResultKotlin$Failure r9 = r7.getFailureOrNull()
            if (r9 == 0) goto L54
            kotlinx.coroutines.CoroutineDispatcher r2 = kotlinx.coroutines.Dispatchers.getDefault()
            com.gateio.biz.base.mvvm.GTBaseViewModel$onFailureAsync$2$1 r4 = new com.gateio.biz.base.mvvm.GTBaseViewModel$onFailureAsync$2$1
            r5 = 0
            r4.<init>(r8, r9, r5)
            r0.L$0 = r7
            r0.label = r3
            java.lang.Object r8 = kotlinx.coroutines.BuildersKt.withContext(r2, r4, r0)
            if (r8 != r1) goto L54
            return r1
        L54:
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: com.gateio.biz.base.mvvm.GTBaseViewModel.onFailureAsync(com.gateio.lib.network.result.GTHttpResultKotlin, kotlin.jvm.functions.Function2, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Nullable
    public final <T> Object onFailureHandleMain(@NotNull GTHttpResultKotlin<? extends T> gTHttpResultKotlin, @NotNull HttpFailureType[] httpFailureTypeArr, @MainThread @NotNull Function1<? super GTHttpResultKotlin.Failure, Unit> function1, @NotNull Continuation<? super GTHttpResultKotlin<? extends T>> continuation) {
        return onFailureMain(gTHttpResultKotlin, new C18562(httpFailureTypeArr, function1, null), continuation);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    @org.jetbrains.annotations.Nullable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final <T> java.lang.Object onFailureMain(@org.jetbrains.annotations.NotNull com.gateio.lib.network.result.GTHttpResultKotlin<? extends T> r7, @androidx.annotation.MainThread @org.jetbrains.annotations.NotNull kotlin.jvm.functions.Function2<? super com.gateio.lib.network.result.GTHttpResultKotlin.Failure, ? super kotlin.coroutines.Continuation<? super kotlin.Unit>, ? extends java.lang.Object> r8, @org.jetbrains.annotations.NotNull kotlin.coroutines.Continuation<? super com.gateio.lib.network.result.GTHttpResultKotlin<? extends T>> r9) {
        /*
            r6 = this;
            boolean r0 = r9 instanceof com.gateio.biz.base.mvvm.GTBaseViewModel.C18581
            if (r0 == 0) goto L13
            r0 = r9
            com.gateio.biz.base.mvvm.GTBaseViewModel$onFailureMain$1 r0 = (com.gateio.biz.base.mvvm.GTBaseViewModel.C18581) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.label = r1
            goto L18
        L13:
            com.gateio.biz.base.mvvm.GTBaseViewModel$onFailureMain$1 r0 = new com.gateio.biz.base.mvvm.GTBaseViewModel$onFailureMain$1
            r0.<init>(r9)
        L18:
            java.lang.Object r9 = r0.result
            java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L36
            if (r2 != r3) goto L2d
            java.lang.Object r7 = r0.L$0
            com.gateio.lib.network.result.GTHttpResultKotlin r7 = (com.gateio.lib.network.result.GTHttpResultKotlin) r7
            kotlin.ResultKt.throwOnFailure(r9)
            goto L54
        L2d:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r8)
            throw r7
        L36:
            kotlin.ResultKt.throwOnFailure(r9)
            com.gateio.lib.network.result.GTHttpResultKotlin$Failure r9 = r7.getFailureOrNull()
            if (r9 == 0) goto L54
            kotlinx.coroutines.MainCoroutineDispatcher r2 = kotlinx.coroutines.Dispatchers.getMain()
            com.gateio.biz.base.mvvm.GTBaseViewModel$onFailureMain$2$1 r4 = new com.gateio.biz.base.mvvm.GTBaseViewModel$onFailureMain$2$1
            r5 = 0
            r4.<init>(r8, r9, r5)
            r0.L$0 = r7
            r0.label = r3
            java.lang.Object r8 = kotlinx.coroutines.BuildersKt.withContext(r2, r4, r0)
            if (r8 != r1) goto L54
            return r1
        L54:
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: com.gateio.biz.base.mvvm.GTBaseViewModel.onFailureMain(com.gateio.lib.network.result.GTHttpResultKotlin, kotlin.jvm.functions.Function2, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    @org.jetbrains.annotations.Nullable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final <T> java.lang.Object onSuccessAsync(@org.jetbrains.annotations.NotNull com.gateio.lib.network.result.GTHttpResultKotlin<? extends T> r6, @org.jetbrains.annotations.NotNull kotlin.jvm.functions.Function2<? super T, ? super kotlin.coroutines.Continuation<? super kotlin.Unit>, ? extends java.lang.Object> r7, @org.jetbrains.annotations.NotNull kotlin.coroutines.Continuation<? super com.gateio.lib.network.result.GTHttpResultKotlin<? extends T>> r8) {
        /*
            r5 = this;
            boolean r0 = r8 instanceof com.gateio.biz.base.mvvm.GTBaseViewModel.C18601
            if (r0 == 0) goto L13
            r0 = r8
            com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessAsync$1 r0 = (com.gateio.biz.base.mvvm.GTBaseViewModel.C18601) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.label = r1
            goto L18
        L13:
            com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessAsync$1 r0 = new com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessAsync$1
            r0.<init>(r8)
        L18:
            java.lang.Object r8 = r0.result
            java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L36
            if (r2 != r3) goto L2d
            java.lang.Object r6 = r0.L$0
            com.gateio.lib.network.result.GTHttpResultKotlin r6 = (com.gateio.lib.network.result.GTHttpResultKotlin) r6
            kotlin.ResultKt.throwOnFailure(r8)
            goto L54
        L2d:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r7)
            throw r6
        L36:
            kotlin.ResultKt.throwOnFailure(r8)
            boolean r8 = r6.isSuccess()
            if (r8 == 0) goto L54
            kotlinx.coroutines.CoroutineDispatcher r8 = kotlinx.coroutines.Dispatchers.getDefault()
            com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessAsync$2 r2 = new com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessAsync$2
            r4 = 0
            r2.<init>(r7, r6, r4)
            r0.L$0 = r6
            r0.label = r3
            java.lang.Object r7 = kotlinx.coroutines.BuildersKt.withContext(r8, r2, r0)
            if (r7 != r1) goto L54
            return r1
        L54:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.gateio.biz.base.mvvm.GTBaseViewModel.onSuccessAsync(com.gateio.lib.network.result.GTHttpResultKotlin, kotlin.jvm.functions.Function2, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    @org.jetbrains.annotations.Nullable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final <T> java.lang.Object onSuccessMain(@org.jetbrains.annotations.NotNull com.gateio.lib.network.result.GTHttpResultKotlin<? extends T> r6, @androidx.annotation.MainThread @org.jetbrains.annotations.NotNull kotlin.jvm.functions.Function2<? super T, ? super kotlin.coroutines.Continuation<? super kotlin.Unit>, ? extends java.lang.Object> r7, @org.jetbrains.annotations.NotNull kotlin.coroutines.Continuation<? super com.gateio.lib.network.result.GTHttpResultKotlin<? extends T>> r8) {
        /*
            r5 = this;
            boolean r0 = r8 instanceof com.gateio.biz.base.mvvm.GTBaseViewModel.C18631
            if (r0 == 0) goto L13
            r0 = r8
            com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessMain$1 r0 = (com.gateio.biz.base.mvvm.GTBaseViewModel.C18631) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.label = r1
            goto L18
        L13:
            com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessMain$1 r0 = new com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessMain$1
            r0.<init>(r8)
        L18:
            java.lang.Object r8 = r0.result
            java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L36
            if (r2 != r3) goto L2d
            java.lang.Object r6 = r0.L$0
            com.gateio.lib.network.result.GTHttpResultKotlin r6 = (com.gateio.lib.network.result.GTHttpResultKotlin) r6
            kotlin.ResultKt.throwOnFailure(r8)
            goto L54
        L2d:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r7)
            throw r6
        L36:
            kotlin.ResultKt.throwOnFailure(r8)
            boolean r8 = r6.isSuccess()
            if (r8 == 0) goto L54
            kotlinx.coroutines.MainCoroutineDispatcher r8 = kotlinx.coroutines.Dispatchers.getMain()
            com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessMain$2 r2 = new com.gateio.biz.base.mvvm.GTBaseViewModel$onSuccessMain$2
            r4 = 0
            r2.<init>(r7, r6, r4)
            r0.L$0 = r6
            r0.label = r3
            java.lang.Object r7 = kotlinx.coroutines.BuildersKt.withContext(r8, r2, r0)
            if (r7 != r1) goto L54
            return r1
        L54:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.gateio.biz.base.mvvm.GTBaseViewModel.onSuccessMain(com.gateio.lib.network.result.GTHttpResultKotlin, kotlin.jvm.functions.Function2, kotlin.coroutines.Continuation):java.lang.Object");
    }

    public static /* synthetic */ void showUIForToastString$default(GTBaseViewModel gTBaseViewModel, String str, MessageInfo.Level level, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: showUIForToastString");
        }
        if ((i10 & 2) != 0) {
            level = MessageInfo.Level.INFO;
        }
        gTBaseViewModel.showUIForToastString(str, level);
    }

    public static /* synthetic */ void showUIForToastStringId$default(GTBaseViewModel gTBaseViewModel, int i10, MessageInfo.Level level, int i11, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: showUIForToastStringId");
        }
        if ((i11 & 2) != 0) {
            level = MessageInfo.Level.INFO;
        }
        gTBaseViewModel.showUIForToastStringId(i10, level);
    }

    @NotNull
    public final LiveData<GTGlobalBiz> getBiz$biz_base_core_release() {
        return this._biz;
    }

    @NotNull
    public final LiveData<GTPageState> getPageState$biz_base_core_release() {
        return this._pageState;
    }

    @NotNull
    public final io.reactivex.rxjava3.subjects.a<GTRxViewModelDelegate.LifecycleEvent> getRxLifecycleSubject() {
        io.reactivex.rxjava3.subjects.a<GTRxViewModelDelegate.LifecycleEvent> aVar = this.rxLifecycleSubject;
        if (aVar != null) {
            return aVar;
        }
        return null;
    }

    @NotNull
    public final LiveData<GTGlobalUI> getUi$biz_base_core_release() {
        return this._ui;
    }

    @MainThread
    public final void handleBiz(@NotNull GTGlobalBiz biz) {
        this._biz.setValue(biz);
        this._biz.setValue(null);
    }

    @MainThread
    public final void handleBizForGoLogin() {
        handleBiz(GTGlobalBiz.GoLogin.INSTANCE);
    }

    @MainThread
    protected void handleFailure(@NotNull GTHttpResultKotlin.Failure failure, @NotNull HttpFailureType... httpFailureTypeArr) {
        if (!ArraysKt___ArraysKt.contains(httpFailureTypeArr, HttpFailureType.HttpApi)) {
            failure.onHttpApi(new Function2<String, String, Unit>() { // from class: com.gateio.biz.base.mvvm.GTBaseViewModel.handleFailure.1
                @Override // kotlin.jvm.functions.Function2
                /* renamed from: invoke */
                public /* bridge */ /* synthetic */ Unit mo2invoke(String str, String str2) {
                    invoke2(str, str2);
                    return Unit.INSTANCE;
                }

                {
                    super(2);
                }

                /* renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2(@NotNull String str, @NotNull String str2) {
                    GTBaseViewModel.this.handleBiz(new GTGlobalBiz.HttpApiError(str, str2));
                }
            });
        }
        if (!ArraysKt___ArraysKt.contains(httpFailureTypeArr, HttpFailureType.LoginError)) {
            failure.onLoginError(new Function1<String, Unit>() { // from class: com.gateio.biz.base.mvvm.GTBaseViewModel.handleFailure.2
                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(String str) {
                    invoke2(str);
                    return Unit.INSTANCE;
                }

                {
                    super(1);
                }

                /* renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2(@Nullable String str) {
                    GTBaseViewModel.this.handleBiz(GTGlobalBiz.GoLogin.INSTANCE);
                }
            });
        }
        if (!ArraysKt___ArraysKt.contains(httpFailureTypeArr, HttpFailureType.MomentTokenExpired)) {
            failure.onMomentTokenExpired(new Function0<Unit>() { // from class: com.gateio.biz.base.mvvm.GTBaseViewModel.handleFailure.3
                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                {
                    super(0);
                }

                /* renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    GTBaseViewModel.this.handleBiz(GTGlobalBiz.MomentTokenExpired.INSTANCE);
                }
            });
        }
        if (!ArraysKt___ArraysKt.contains(httpFailureTypeArr, HttpFailureType.PassNoSet)) {
            failure.onPassNoSet(new Function1<String, Unit>() { // from class: com.gateio.biz.base.mvvm.GTBaseViewModel.handleFailure.4
                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(String str) {
                    invoke2(str);
                    return Unit.INSTANCE;
                }

                {
                    super(1);
                }

                /* renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2(@Nullable String str) {
                    GTBaseViewModel.this.handleBiz(new GTGlobalBiz.PassNoSet(str));
                }
            });
        }
        if (!ArraysKt___ArraysKt.contains(httpFailureTypeArr, HttpFailureType.PassNeed)) {
            failure.onPassNeed(new Function2<Integer, String, Unit>() { // from class: com.gateio.biz.base.mvvm.GTBaseViewModel.handleFailure.5
                @Override // kotlin.jvm.functions.Function2
                /* renamed from: invoke */
                public /* bridge */ /* synthetic */ Unit mo2invoke(Integer num, String str) {
                    invoke(num.intValue(), str);
                    return Unit.INSTANCE;
                }

                {
                    super(2);
                }

                public final void invoke(int i10, @Nullable String str) {
                    GTBaseViewModel.this.handleBiz(new GTGlobalBiz.PassNeed(i10, str));
                }
            });
        }
        if (!ArraysKt___ArraysKt.contains(httpFailureTypeArr, HttpFailureType.PassSecondNeed)) {
            failure.onPassSecondNeed(new Function1<String, Unit>() { // from class: com.gateio.biz.base.mvvm.GTBaseViewModel.handleFailure.6
                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(String str) {
                    invoke2(str);
                    return Unit.INSTANCE;
                }

                {
                    super(1);
                }

                /* renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2(@Nullable String str) {
                    GTBaseViewModel.this.handleBiz(new GTGlobalBiz.PassSecondNeed(str));
                }
            });
        }
        if (!ArraysKt___ArraysKt.contains(httpFailureTypeArr, HttpFailureType.FingerPrintNeed)) {
            failure.onFingerPrintNeed(new Function1<String, Unit>() { // from class: com.gateio.biz.base.mvvm.GTBaseViewModel.handleFailure.7
                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(String str) {
                    invoke2(str);
                    return Unit.INSTANCE;
                }

                {
                    super(1);
                }

                /* renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2(@Nullable String str) {
                    GTBaseViewModel.this.handleBiz(new GTGlobalBiz.FingerPrintNeed(str));
                }
            });
        }
        if (!ArraysKt___ArraysKt.contains(httpFailureTypeArr, HttpFailureType.NoNet)) {
            failure.onNoNet(new Function1<String, Unit>() { // from class: com.gateio.biz.base.mvvm.GTBaseViewModel.handleFailure.8
                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(String str) {
                    invoke2(str);
                    return Unit.INSTANCE;
                }

                {
                    super(1);
                }

                /* renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2(@NotNull String str) {
                    GTBaseViewModel.this.handleBiz(new GTGlobalBiz.NoNet(str));
                }
            });
        }
        if (ArraysKt___ArraysKt.contains(httpFailureTypeArr, HttpFailureType.Unknown)) {
            return;
        }
        failure.onUnknown(new Function1<Throwable, Unit>() { // from class: com.gateio.biz.base.mvvm.GTBaseViewModel.handleFailure.9
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Throwable th) {
                invoke2(th);
                return Unit.INSTANCE;
            }

            {
                super(1);
            }

            /* renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Throwable th) {
                GTBaseViewModel.this.handleBiz(new GTGlobalBiz.Unknown(th));
            }
        });
    }

    /* renamed from: isSupportRx, reason: from getter */
    public final boolean getIsSupportRx() {
        return this.isSupportRx;
    }

    @Override // androidx.lifecycle.ViewModel
    protected void onCleared() {
        if (this instanceof GTRxViewModelDelegate) {
            getRxLifecycleSubject().onNext(GTRxViewModelDelegate.LifecycleEvent.DESTROYED);
        }
        super.onCleared();
    }

    @NotNull
    protected final <T> s<GTHttpResultKotlin<T>> onFailureHandleMain(@NotNull s<GTHttpResultKotlin<T>> sVar, @NotNull final HttpFailureType[] httpFailureTypeArr, @MainThread @NotNull final Function1<? super GTHttpResultKotlin.Failure, Unit> function1) {
        return onFailureMain(sVar, new Function1<GTHttpResultKotlin.Failure, Unit>() { // from class: com.gateio.biz.base.mvvm.GTBaseViewModel.onFailureHandleMain.3
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(GTHttpResultKotlin.Failure failure) {
                invoke2(failure);
                return Unit.INSTANCE;
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            {
                super(1);
            }

            /* renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull GTHttpResultKotlin.Failure failure) {
                GTBaseViewModel gTBaseViewModel = GTBaseViewModel.this;
                HttpFailureType[] httpFailureTypeArr2 = httpFailureTypeArr;
                gTBaseViewModel.handleFailure(failure, (HttpFailureType[]) Arrays.copyOf(httpFailureTypeArr2, httpFailureTypeArr2.length));
                function1.invoke(failure);
            }
        });
    }

    public final void setRxLifecycleSubject(@NotNull io.reactivex.rxjava3.subjects.a<GTRxViewModelDelegate.LifecycleEvent> aVar) {
        this.rxLifecycleSubject = aVar;
    }

    public final void setSupportRx(boolean z10) {
        this.isSupportRx = z10;
    }

    public final void showPageState(@NotNull GTPageState state) {
        this._pageState.setValue(state);
    }

    @MainThread
    public final void showUI(@NotNull GTGlobalUI ui) {
        this._ui.setValue(ui);
        this._ui.setValue(null);
    }

    @MainThread
    public final void showUIForSubmitDismiss() {
        showUI(GTGlobalUI.SubmitLoading.Dismiss.INSTANCE);
    }

    @MainThread
    public final void showUIForSubmitLoading() {
        showUI(GTGlobalUI.SubmitLoading.Show.INSTANCE);
    }

    @MainThread
    public final void showUIForToast(@NotNull MessageInfo messageInfo) {
        showUI(new GTGlobalUI.Toast(messageInfo));
    }

    @MainThread
    public final void showUIForToastString(@Nullable String string, @NotNull MessageInfo.Level level) {
        showUI(new GTGlobalUI.Toast(MessageInfo.INSTANCE.string(string, level)));
    }

    @MainThread
    public final void showUIForToastStringId(@StringRes int stringId, @NotNull MessageInfo.Level level) {
        showUI(new GTGlobalUI.Toast(MessageInfo.INSTANCE.stringId(stringId, level)));
    }

    @Nullable
    protected final GTPageState getCurrentPageState() {
        return getPageState$biz_base_core_release().getValue();
    }

    @Override // androidx.lifecycle.DefaultLifecycleObserver
    public void onCreate(@NotNull LifecycleOwner owner) {
        super.onCreate(owner);
        if (this instanceof GTRxViewModelDelegate) {
            GTLog.i("This isSupport RxLifecycle，" + this, false);
            this.isSupportRx = true;
            setRxLifecycleSubject(io.reactivex.rxjava3.subjects.a.d());
            getRxLifecycleSubject().onNext(GTRxViewModelDelegate.LifecycleEvent.CREATED);
        }
    }

    @NotNull
    protected final <T> s<GTHttpResultKotlin<T>> onFailureAsync(@NotNull s<GTHttpResultKotlin<T>> sVar, @MainThread @NotNull Function1<? super GTHttpResultKotlin.Failure, Unit> function1) {
        return GTHttpResultKotlinsForRxJavaKt.onFailure(sVar, new C18553(function1));
    }

    @NotNull
    protected final <T> s<GTHttpResultKotlin<T>> onFailureMain(@NotNull s<GTHttpResultKotlin<T>> sVar, @MainThread @NotNull final Function1<? super GTHttpResultKotlin.Failure, Unit> function1) {
        return GTHttpResultKotlinsForRxJavaKt.onFailure(sVar, new Function1<GTHttpResultKotlin.Failure, Unit>() { // from class: com.gateio.biz.base.mvvm.GTBaseViewModel.onFailureMain.3
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(GTHttpResultKotlin.Failure failure) {
                invoke2(failure);
                return Unit.INSTANCE;
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            {
                super(1);
            }

            /* renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull final GTHttpResultKotlin.Failure failure) {
                if (GTThreadUtils.isMainThread()) {
                    function1.invoke(failure);
                } else {
                    final Function1<GTHttpResultKotlin.Failure, Unit> function12 = function1;
                    AnyKt.runOnMainThread(new Function0<Unit>() { // from class: com.gateio.biz.base.mvvm.GTBaseViewModel.onFailureMain.3.1
                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        /* JADX WARN: Multi-variable type inference failed */
                        {
                            super(0);
                        }

                        /* renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            function12.invoke(failure);
                        }
                    });
                }
            }
        });
    }

    @NotNull
    protected final <T> s<GTHttpResultKotlin<T>> onSuccessAsync(@NotNull s<GTHttpResultKotlin<T>> sVar, @MainThread @NotNull Function1<? super T, Unit> function1) {
        return GTHttpResultKotlinsForRxJavaKt.onSuccess(sVar, new C18623(function1));
    }

    @NotNull
    protected final <T> s<GTHttpResultKotlin<T>> onSuccessMain(@NotNull s<GTHttpResultKotlin<T>> sVar, @MainThread @NotNull final Function1<? super T, Unit> function1) {
        return GTHttpResultKotlinsForRxJavaKt.onSuccess(sVar, new Function1<T, Unit>() { // from class: com.gateio.biz.base.mvvm.GTBaseViewModel.onSuccessMain.3
            /* JADX WARN: Multi-variable type inference failed */
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Object obj) {
                invoke2((C18653<T>) obj);
                return Unit.INSTANCE;
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            {
                super(1);
            }

            /* renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(final T t10) {
                if (GTThreadUtils.isMainThread()) {
                    function1.invoke(t10);
                } else {
                    final Function1<T, Unit> function12 = function1;
                    AnyKt.runOnMainThread(new Function0<Unit>() { // from class: com.gateio.biz.base.mvvm.GTBaseViewModel.onSuccessMain.3.1
                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        /* JADX WARN: Multi-variable type inference failed */
                        {
                            super(0);
                        }

                        /* renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            function12.invoke(t10);
                        }
                    });
                }
            }
        });
    }
}