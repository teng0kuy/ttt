package com.gateio.biz.base.mvvm;

import androidx.exifinterface.media.ExifInterface;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: GTPageState.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\"\u0010\u0000\u001a\u0004\u0018\u0001H\u0001\"\n\b\u0000\u0010\u0001\u0018\u0001*\u00020\u0002*\u0004\u0018\u00010\u0002H\u0086\b¢\u0006\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"getOrNullIfIs", ExifInterface.GPS_DIRECTION_TRUE, "Lcom/gateio/biz/base/mvvm/GTPageState;", "(Lcom/gateio/biz/base/mvvm/GTPageState;)Lcom/gateio/biz/base/mvvm/GTPageState;", "biz_base_core_release"}, k = 2, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class GTPageStateKt {
    /* JADX WARN: Multi-variable type inference failed */
    public static final /* synthetic */ <T extends GTPageState> T getOrNullIfIs(GTPageState gTPageState) {
        if (gTPageState == 0) {
            return null;
        }
        Intrinsics.reifiedOperationMarker(3, ExifInterface.GPS_DIRECTION_TRUE);
        return gTPageState;
    }
}