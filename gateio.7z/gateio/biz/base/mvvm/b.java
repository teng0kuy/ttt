package com.gateio.biz.base.mvvm;

/* compiled from: R8$$SyntheticClass */
/* loaded from: classes4.dex */
public final /* synthetic */ class b implements Runnable {

    /* renamed from: b */
    public final /* synthetic */ Object f10994b;

    @Override // java.lang.Runnable
    public final void run() {
        function1.invoke(t10);
    }

    public /* synthetic */ b(Object obj) {
        t10 = obj;
    }
}