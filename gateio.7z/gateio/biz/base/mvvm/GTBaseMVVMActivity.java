package com.gateio.biz.base.mvvm;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.CallSuper;
import androidx.annotation.ColorRes;
import androidx.annotation.MainThread;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelLazy;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewbinding.ViewBinding;
import com.bytedance.apm.agent.v2.instrumentation.AppAgent;
import com.gateio.biz.base.R;
import com.gateio.biz.base.delegate.GTBaseBizDelegate;
import com.gateio.biz.base.delegate.GTBaseLogDelegate;
import com.gateio.biz.base.delegate.GTBaseViewDelegate;
import com.gateio.biz.base.delegate.GTRxActivityDelegate;
import com.gateio.biz.base.delegate.GTViewModelProviderDelegate;
import com.gateio.biz.base.router.AppApiProvider;
import com.gateio.biz.base.utils.ConstUtil;
import com.gateio.common.base.translate.BaseTranslateKeyFactory;
import com.gateio.common.base.translate.TranslateKeyFactory;
import com.gateio.common.base.translate.TranslateKeyUtils;
import com.gateio.common.tool.BadgeUtil;
import com.gateio.common.tool.GlideUtils;
import com.gateio.common.tool.GlobalUtils;
import com.gateio.common.tool.LocalUtils;
import com.gateio.common.tool.RxTimerUtil;
import com.gateio.common.view.LoadingProgressV5;
import com.gateio.common.view.badge.BadgeSubscribe;
import com.gateio.keyboard.utils.KeyboardUtils;
import com.gateio.lib.core.GTCoreApplication;
import com.gateio.lib.core.mvvm.GTCoreMVVMActivity;
import com.gateio.lib.logger.GTLog;
import com.gateio.lib.uikit.daynight.IDayNightable;
import com.gateio.rxjava.CustomObserver;
import com.gyf.immersionbar.ImmersionBar;
import com.trello.rxlifecycle4.android.ActivityEvent;
import java.util.HashMap;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.Reflection;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GTBaseMVVMActivity.kt */
@Metadata(d1 = {"\u0000²\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\f\b&\u0018\u0000*\b\b\u0000\u0010\u0002*\u00020\u00012\b\u0012\u0004\u0012\u00028\u00000\u00032\u00020\u00042\u00020\u00052\u00020\u00062\u00020\u00072\u00020\bB\u0007¢\u0006\u0004\bl\u0010mJ\b\u0010\n\u001a\u00020\tH\u0002J\u0010\u0010\r\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\u000bH\u0002J\u0012\u0010\u0010\u001a\u00020\t2\b\u0010\u000f\u001a\u0004\u0018\u00010\u000eH\u0015J\u0012\u0010\u0013\u001a\u00020\t2\b\u0010\u0012\u001a\u0004\u0018\u00010\u0011H\u0015J\u0012\u0010\u0014\u001a\u00020\t2\b\u0010\u0012\u001a\u0004\u0018\u00010\u0011H\u0014J\u0012\u0010\u0015\u001a\u00020\t2\b\u0010\u0012\u001a\u0004\u0018\u00010\u0011H\u0016J\b\u0010\u0016\u001a\u00020\tH\u0014J\b\u0010\u0017\u001a\u00020\tH\u0014J\u0010\u0010\u001a\u001a\u00020\t2\u0006\u0010\u0019\u001a\u00020\u0018H\u0016J\u0012\u0010\u001b\u001a\u00020\t2\b\u0010\u0012\u001a\u0004\u0018\u00010\u0011H\u0016J\b\u0010\u001c\u001a\u00020\tH\u0015J\b\u0010\u001d\u001a\u00020\tH\u0015J\b\u0010\u001e\u001a\u00020\tH\u0015J\b\u0010\u001f\u001a\u00020\tH\u0015J\b\u0010 \u001a\u00020\tH\u0015J\u0010\u0010#\u001a\u00020\t2\u0006\u0010\"\u001a\u00020!H\u0016J\b\u0010%\u001a\u00020$H\u0016J\b\u0010&\u001a\u00020\tH\u0016J\b\u0010'\u001a\u00020$H\u0014J\b\u0010)\u001a\u00020(H\u0015J\b\u0010*\u001a\u00020(H\u0015J\b\u0010+\u001a\u00020$H\u0014J5\u00102\u001a\u0004\u0018\u00018\u0001\"\n\b\u0001\u0010-*\u0004\u0018\u00010,2\b\u0010/\u001a\u0004\u0018\u00010.2\f\u00101\u001a\b\u0012\u0004\u0012\u00028\u000100H\u0016¢\u0006\u0004\b2\u00103J+\u00104\u001a\u0004\u0018\u00018\u0001\"\n\b\u0001\u0010-*\u0004\u0018\u00010,2\f\u00101\u001a\b\u0012\u0004\u0012\u00028\u000100H\u0016¢\u0006\u0004\b4\u00105J\u001a\u00107\u001a\u00020\t2\b\u0010/\u001a\u0004\u0018\u00010.2\u0006\u00106\u001a\u00020,H\u0016J\u0012\u00108\u001a\u00020\t2\b\u0010/\u001a\u0004\u0018\u00010.H\u0016J\b\u00109\u001a\u00020\tH\u0016J\b\u0010:\u001a\u00020\tH\u0016J\b\u0010;\u001a\u00020\tH\u0016J\b\u0010<\u001a\u00020\tH\u0014J\b\u0010=\u001a\u00020\tH\u0014J\b\u0010?\u001a\u00020>H\u0016J0\u0010F\u001a\b\u0012\u0004\u0012\u00028\u00010E\"\n\b\u0001\u0010A\u0018\u0001*\u00020@2\u0010\b\n\u0010D\u001a\n\u0012\u0004\u0012\u00020C\u0018\u00010BH\u0087\bø\u0001\u0000R\"\u0010G\u001a\u00020\u000e8\u0016@\u0016X\u0096.¢\u0006\u0012\n\u0004\bG\u0010H\u001a\u0004\bI\u0010J\"\u0004\bK\u0010LR$\u0010N\u001a\u0004\u0018\u00010M8\u0016@\u0016X\u0096\u000e¢\u0006\u0012\n\u0004\bN\u0010O\u001a\u0004\bP\u0010Q\"\u0004\bR\u0010SRB\u0010V\u001a\"\u0012\u0004\u0012\u00020.\u0012\u0004\u0012\u00020,\u0018\u00010Tj\u0010\u0012\u0004\u0012\u00020.\u0012\u0004\u0012\u00020,\u0018\u0001`U8\u0004@\u0004X\u0084\u000e¢\u0006\u0012\n\u0004\bV\u0010W\u001a\u0004\bX\u0010Y\"\u0004\bZ\u0010[R\"\u0010\\\u001a\u00020$8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\\\u0010]\u001a\u0004\b\\\u0010^\"\u0004\b_\u0010`R(\u0010c\u001a\b\u0012\u0004\u0012\u00020b0a8\u0006@\u0006X\u0086.¢\u0006\u0012\n\u0004\bc\u0010d\u001a\u0004\be\u0010f\"\u0004\bg\u0010hR\u0016\u0010k\u001a\u0004\u0018\u00010@8$X¤\u0004¢\u0006\u0006\u001a\u0004\bi\u0010j\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006n"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTBaseMVVMActivity;", "Landroidx/viewbinding/ViewBinding;", "VB", "Lcom/gateio/lib/core/mvvm/GTCoreMVVMActivity;", "Lcom/gateio/common/view/badge/BadgeSubscribe$OnBadgeClearListener;", "Lcom/gateio/common/tool/GlobalUtils$OnNightModeChangeListener;", "Lcom/gateio/biz/base/delegate/GTBaseViewDelegate;", "Lcom/gateio/biz/base/delegate/GTBaseBizDelegate;", "Lcom/gateio/biz/base/delegate/GTBaseLogDelegate;", "", "themeSetting", "Landroid/view/View;", "view", "refreshViewDayNightModel", "Landroid/content/Context;", "newBase", AppAgent.ATTACH_BASE_CONTEXT, "Landroid/os/Bundle;", "savedInstanceState", AppAgent.ON_CREATE, "onSubclassCreate", "onInitViewModelObserver", "initImmersionBar", "initNavigationBar", "Landroidx/lifecycle/Lifecycle;", "lifecycle", "onAddLifecycleObserver", "onInitData", "onRestart", "onStart", "onResume", "onPause", "onDestroy", "Landroid/content/res/Configuration;", "newConfig", "onConfigurationChanged", "", "autoRefreshDayNight", "refreshDayNightModel", "isForceInitLanguage", "", "getStatusBarBgColor", "getNavigationBarBgColor", "isFullScreen", "Landroidx/fragment/app/Fragment;", "F", "", "TAG", "Ljava/lang/Class;", "fClass", "getFragmentByTag", "(Ljava/lang/String;Ljava/lang/Class;)Landroidx/fragment/app/Fragment;", "getFragmentByClass", "(Ljava/lang/Class;)Landroidx/fragment/app/Fragment;", "GTBaseMVPDialogFragment", "bindFragment", "unbindFragment", "finish", "onBadheClearListener", "onNightModeChangeListener", "launchAnimator", "finishAnimator", "Landroid/content/res/Resources;", "getResources", "Lcom/gateio/biz/base/mvvm/GTBaseViewModel;", "VM", "Lkotlin/Function0;", "Landroidx/lifecycle/ViewModelProvider$Factory;", "factoryProducer", "Lkotlin/Lazy;", "viewModels", "mContext", "Landroid/content/Context;", "getMContext", "()Landroid/content/Context;", "setMContext", "(Landroid/content/Context;)V", "Lcom/gateio/common/view/LoadingProgressV5;", "mLoadingProgress", "Lcom/gateio/common/view/LoadingProgressV5;", "getMLoadingProgress", "()Lcom/gateio/common/view/LoadingProgressV5;", "setMLoadingProgress", "(Lcom/gateio/common/view/LoadingProgressV5;)V", "Ljava/util/HashMap;", "Lkotlin/collections/HashMap;", "mFragmentMap", "Ljava/util/HashMap;", "getMFragmentMap", "()Ljava/util/HashMap;", "setMFragmentMap", "(Ljava/util/HashMap;)V", "isSupportRx", "Z", "()Z", "setSupportRx", "(Z)V", "Lio/reactivex/rxjava3/subjects/a;", "Lcom/trello/rxlifecycle4/android/ActivityEvent;", "rxLifecycleSubject", "Lio/reactivex/rxjava3/subjects/a;", "getRxLifecycleSubject", "()Lio/reactivex/rxjava3/subjects/a;", "setRxLifecycleSubject", "(Lio/reactivex/rxjava3/subjects/a;)V", "getMViewModel", "()Lcom/gateio/biz/base/mvvm/GTBaseViewModel;", "mViewModel", AppAgent.CONSTRUCT, "()V", "biz_base_core_release"}, k = 1, mv = {1, 9, 0})
@SourceDebugExtension({"SMAP\nGTBaseMVVMActivity.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GTBaseMVVMActivity.kt\ncom/gateio/biz/base/mvvm/GTBaseMVVMActivity\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 ActivityViewModelLazy.kt\nandroidx/activity/ActivityViewModelLazyKt\n*L\n1#1,334:1\n1#2:335\n75#3,13:336\n*S KotlinDebug\n*F\n+ 1 GTBaseMVVMActivity.kt\ncom/gateio/biz/base/mvvm/GTBaseMVVMActivity\n*L\n329#1:336,13\n*E\n"})
/* loaded from: classes4.dex */
public abstract class GTBaseMVVMActivity<VB extends ViewBinding> extends GTCoreMVVMActivity<VB> implements BadgeSubscribe.OnBadgeClearListener, GlobalUtils.OnNightModeChangeListener, GTBaseViewDelegate, GTBaseBizDelegate, GTBaseLogDelegate {
    private boolean isSupportRx;
    public Context mContext;

    @Nullable
    private HashMap<String, Fragment> mFragmentMap;

    @Nullable
    private LoadingProgressV5 mLoadingProgress;
    public io.reactivex.rxjava3.subjects.a<ActivityEvent> rxLifecycleSubject;

    /* JADX INFO: Add missing generic type declarations: [VM] */
    /* compiled from: GTBaseMVVMActivity.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0010\u0000\u001a\u00020\u0001\"\n\b\u0000\u0010\u0002\u0018\u0001*\u00020\u0003\"\b\b\u0001\u0010\u0004*\u00020\u00052\u0006\u0010\u0006\u001a\u0002H\u0002H\n¢\u0006\u0004\b\u0007\u0010\b"}, d2 = {"<anonymous>", "", "VM", "Lcom/gateio/biz/base/mvvm/GTBaseViewModel;", "VB", "Landroidx/viewbinding/ViewBinding;", "it", "invoke", "(Lcom/gateio/biz/base/mvvm/GTBaseViewModel;)V"}, k = 3, mv = {1, 9, 0}, xi = 176)
    @SourceDebugExtension({"SMAP\nGTBaseMVVMActivity.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GTBaseMVVMActivity.kt\ncom/gateio/biz/base/mvvm/GTBaseMVVMActivity$viewModels$1\n*L\n1#1,334:1\n*E\n"})
    /* renamed from: com.gateio.biz.base.mvvm.GTBaseMVVMActivity$viewModels$1, reason: invalid class name and case insensitive filesystem */
    public static final class C18511<VM> extends Lambda implements Function1<VM, Unit> {
        final /* synthetic */ GTBaseMVVMActivity<VB> this$0;

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(Object obj) {
            invoke((GTBaseViewModel) obj);
            return Unit.INSTANCE;
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public C18511(GTBaseMVVMActivity<VB> gTBaseMVVMActivity) {
            super(1);
            this.this$0 = gTBaseMVVMActivity;
        }

        /* JADX WARN: Incorrect types in method signature: (TVM;)V */
        public final void invoke(@NotNull GTBaseViewModel gTBaseViewModel) {
            GTBaseMVVMActivity<VB> gTBaseMVVMActivity = this.this$0;
            gTBaseMVVMActivity.initViewModelObserverForView(gTBaseMVVMActivity, gTBaseViewModel);
            GTBaseMVVMActivity<VB> gTBaseMVVMActivity2 = this.this$0;
            gTBaseMVVMActivity2.initViewModelObserverForBiz(gTBaseMVVMActivity2, gTBaseViewModel);
        }
    }

    public boolean autoRefreshDayNight() {
        return true;
    }

    @Override // com.gateio.lib.core.mvvm.GTCoreMVVMActivity
    @Nullable
    protected abstract GTBaseViewModel getMViewModel();

    protected boolean isForceInitLanguage() {
        return true;
    }

    protected boolean isFullScreen() {
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final void refreshViewDayNightModel(View view) {
        boolean z10 = view instanceof IDayNightable;
        if (z10 || (view instanceof ViewGroup)) {
            if (z10) {
                ((IDayNightable) view).refreshDayNightModel();
            }
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                int childCount = viewGroup.getChildCount();
                for (int i10 = 0; i10 < childCount; i10++) {
                    refreshViewDayNightModel(viewGroup.getChildAt(i10));
                }
            }
        }
    }

    private final void themeSetting() {
        if (ConstUtil.INSTANCE.isChangeTheme()) {
            int defaultNightMode = AppCompatDelegate.getDefaultNightMode();
            int i10 = 1;
            if (defaultNightMode == 1 || defaultNightMode == 2) {
                i10 = -1;
            } else if (GlobalUtils.isNightMode()) {
                i10 = 2;
            }
            AppCompatDelegate.setDefaultNightMode(i10);
            GlobalUtils.getDefault().notifyModechange();
            GlideUtils.onThemeChanged();
        }
    }

    public static /* synthetic */ Lazy viewModels$default(GTBaseMVVMActivity gTBaseMVVMActivity, Function0 function0, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: viewModels");
        }
        if ((i10 & 1) != 0) {
            function0 = null;
        }
        if (function0 == null) {
            function0 = new GTBaseMVVMActivity$viewModels$$inlined$viewModels$default$1(gTBaseMVVMActivity);
        }
        Intrinsics.reifiedOperationMarker(4, "VM");
        ViewModelLazy viewModelLazy = new ViewModelLazy(Reflection.getOrCreateKotlinClass(ViewModel.class), new GTBaseMVVMActivity$viewModels$$inlined$viewModels$default$2(gTBaseMVVMActivity), function0, new GTBaseMVVMActivity$viewModels$$inlined$viewModels$default$3(null, gTBaseMVVMActivity));
        Intrinsics.needClassReification();
        return new GTViewModelProviderDelegate(viewModelLazy, new C18511(gTBaseMVVMActivity));
    }

    public void bindFragment(@Nullable String TAG, @NotNull Fragment GTBaseMVPDialogFragment) {
        HashMap<String, Fragment> map;
        if (this.mFragmentMap == null || TAG == null) {
            this.mFragmentMap = new HashMap<>();
        }
        if (TAG == null || (map = this.mFragmentMap) == null) {
            return;
        }
        map.put(TAG, GTBaseMVPDialogFragment);
    }

    protected void finishAnimator() {
        overridePendingTransition(R.anim.uikit_anim_left_in_v3, R.anim.uikit_anim_right_out_v3);
    }

    @Nullable
    public <F extends Fragment> F getFragmentByClass(@NotNull Class<F> fClass) {
        HashMap<String, Fragment> map = this.mFragmentMap;
        if (map == null) {
            return null;
        }
        for (Fragment fragment : map.values()) {
            if (fClass.isInstance(fragment)) {
                return fClass.cast(fragment);
            }
        }
        return null;
    }

    @Override // com.gateio.biz.base.delegate.GTBaseViewDelegate, com.gateio.biz.base.delegate.GTBaseBizDelegate
    @NotNull
    public Context getMContext() {
        Context context = this.mContext;
        if (context != null) {
            return context;
        }
        return null;
    }

    @Nullable
    protected final HashMap<String, Fragment> getMFragmentMap() {
        return this.mFragmentMap;
    }

    @Override // com.gateio.biz.base.delegate.GTBaseViewDelegate
    @Nullable
    public LoadingProgressV5 getMLoadingProgress() {
        return this.mLoadingProgress;
    }

    @ColorRes
    protected int getNavigationBarBgColor() {
        return R.color.color_navigation_bar_bac;
    }

    @NotNull
    public final io.reactivex.rxjava3.subjects.a<ActivityEvent> getRxLifecycleSubject() {
        io.reactivex.rxjava3.subjects.a<ActivityEvent> aVar = this.rxLifecycleSubject;
        if (aVar != null) {
            return aVar;
        }
        return null;
    }

    @ColorRes
    protected int getStatusBarBgColor() {
        return R.color.uikit_main_header_bg;
    }

    /* renamed from: isSupportRx, reason: from getter */
    public final boolean getIsSupportRx() {
        return this.isSupportRx;
    }

    protected void launchAnimator() {
        overridePendingTransition(R.anim.uikit_anim_right_in_v3, R.anim.uikit_anim_left_out_v3);
    }

    @Override // com.gateio.biz.base.delegate.GTBaseViewDelegate, com.gateio.biz.base.delegate.GTBaseBizDelegate
    public void setMContext(@NotNull Context context) {
        this.mContext = context;
    }

    protected final void setMFragmentMap(@Nullable HashMap<String, Fragment> map) {
        this.mFragmentMap = map;
    }

    @Override // com.gateio.biz.base.delegate.GTBaseViewDelegate
    public void setMLoadingProgress(@Nullable LoadingProgressV5 loadingProgressV5) {
        this.mLoadingProgress = loadingProgressV5;
    }

    public final void setRxLifecycleSubject(@NotNull io.reactivex.rxjava3.subjects.a<ActivityEvent> aVar) {
        this.rxLifecycleSubject = aVar;
    }

    public final void setSupportRx(boolean z10) {
        this.isSupportRx = z10;
    }

    public void unbindFragment(@Nullable String TAG) {
        HashMap<String, Fragment> map;
        if (TAG == null || (map = this.mFragmentMap) == null) {
            return;
        }
        map.remove(TAG);
    }

    @MainThread
    public final /* synthetic */ <VM extends GTBaseViewModel> Lazy<VM> viewModels(Function0<? extends ViewModelProvider.Factory> factoryProducer) {
        if (factoryProducer == null) {
            factoryProducer = new GTBaseMVVMActivity$viewModels$$inlined$viewModels$default$1(this);
        }
        Intrinsics.reifiedOperationMarker(4, "VM");
        ViewModelLazy viewModelLazy = new ViewModelLazy(Reflection.getOrCreateKotlinClass(ViewModel.class), new GTBaseMVVMActivity$viewModels$$inlined$viewModels$default$2(this), factoryProducer, new GTBaseMVVMActivity$viewModels$$inlined$viewModels$default$3(null, this));
        Intrinsics.needClassReification();
        return new GTViewModelProviderDelegate(viewModelLazy, new C18511(this));
    }

    @Override // androidx.appcompat.app.AppCompatActivity, android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    @CallSuper
    protected void attachBaseContext(@Nullable Context newBase) {
        LocalUtils.initLanguage(newBase, isForceInitLanguage());
        super.attachBaseContext(newBase);
    }

    @Override // android.app.Activity
    public void finish() {
        super.finish();
        finishAnimator();
    }

    @Nullable
    public <F extends Fragment> F getFragmentByTag(@Nullable String TAG, @NotNull Class<F> fClass) {
        if (TextUtils.isEmpty(TAG)) {
            return (F) getFragmentByClass(fClass);
        }
        HashMap<String, Fragment> map = this.mFragmentMap;
        if (map != null) {
            Fragment fragment = map.get(TAG);
            Fragment fragment2 = fragment;
            if (fClass.isInstance(fragment)) {
                return fClass.cast(fragment2);
            }
        }
        return null;
    }

    @Override // androidx.appcompat.app.AppCompatActivity, android.view.ContextThemeWrapper, android.content.ContextWrapper, android.content.Context
    @NotNull
    public Resources getResources() {
        return TranslateKeyUtils.getInstance().getResourcesWrapper(super.getResources());
    }

    protected void initImmersionBar() {
        int statusBarBgColor;
        if (isFullScreen()) {
            statusBarBgColor = R.color.uikit_transparent;
        } else {
            statusBarBgColor = getStatusBarBgColor();
        }
        ImmersionBar.with(this).statusBarColor(statusBarBgColor).autoStatusBarDarkModeEnable(true).init();
    }

    protected void initNavigationBar() {
        ImmersionBar.with(this).navigationBarColor(getNavigationBarBgColor()).autoNavigationBarDarkModeEnable(true).init();
    }

    @Override // com.gateio.common.view.badge.BadgeSubscribe.OnBadgeClearListener
    public void onBadheClearListener() {
        BadgeUtil.resetBadgeCount(this);
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.activity.ComponentActivity, android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(@NotNull Configuration newConfig) {
        int i10;
        super.onConfigurationChanged(newConfig);
        LocalUtils.initLanguage(this);
        if (autoRefreshDayNight() && ((i10 = newConfig.uiMode & 48) == 16 || i10 == 32)) {
            refreshDayNightModel();
        }
        themeSetting();
    }

    @Override // com.gateio.lib.core.mvvm.GTCoreMVVMActivity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    @CallSuper
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        GTLog.i(getLifecycleLogMessage(), false);
        if (this instanceof GTRxActivityDelegate) {
            GTLog.i("This isSupport RxLifecycle, " + getLifecycleLogMessage(), false);
            this.isSupportRx = true;
            setRxLifecycleSubject(io.reactivex.rxjava3.subjects.a.d());
        }
        setMContext(this);
        TranslateKeyUtils.getInstance().setCreateFactory(this, new BaseTranslateKeyFactory(this));
        TranslateKeyUtils.getInstance().setCreateFactory(this, new TranslateKeyFactory());
        LocalUtils.initLanguage(this, isForceInitLanguage());
        super.onCreate(savedInstanceState);
    }

    @Override // com.gateio.lib.core.mvvm.GTCoreMVVMActivity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    @CallSuper
    protected void onDestroy() {
        GTLog.i(getLifecycleLogMessage(), false);
        if (this.isSupportRx) {
            getRxLifecycleSubject().onNext(ActivityEvent.DESTROY);
        }
        super.onDestroy();
        GlobalUtils.getDefault().detach(this);
    }

    @Override // com.gateio.common.tool.GlobalUtils.OnNightModeChangeListener
    public void onNightModeChangeListener() {
        long j10;
        if (GlobalUtils.isNightMode()) {
            j10 = 1800;
        } else {
            j10 = 900;
        }
        RxTimerUtil.timer(j10).subscribe(new CustomObserver<Long>(this) { // from class: com.gateio.biz.base.mvvm.GTBaseMVVMActivity.onNightModeChangeListener.1
            final /* synthetic */ GTBaseMVVMActivity<VB> this$0;

            @Override // com.gateio.rxjava.CustomObserver, io.reactivex.rxjava3.core.z, org.reactivestreams.Subscriber
            public /* bridge */ /* synthetic */ void onNext(Object obj) {
                onNext(((Number) obj).longValue());
            }

            {
                this.this$0 = this;
            }

            public void onNext(long aLong) {
                this.this$0.initImmersionBar();
            }
        });
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    @CallSuper
    protected void onPause() {
        GTLog.i(getLifecycleLogMessage(), false);
        if (this.isSupportRx) {
            getRxLifecycleSubject().onNext(ActivityEvent.PAUSE);
        }
        super.onPause();
        KeyboardUtils.closeSoftKeyboard((Activity) this);
        BadgeSubscribe.getInstance().unRegister(this);
    }

    @Override // android.app.Activity
    @CallSuper
    protected void onRestart() {
        GTLog.i(getLifecycleLogMessage(), false);
        super.onRestart();
        LocalUtils.initLanguage(this);
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    @CallSuper
    protected void onResume() {
        GTLog.i$default(getLifecycleLogMessage(), null, null, null, 14, null);
        super.onResume();
        BadgeSubscribe.getInstance().register(this);
        if (this.isSupportRx) {
            getRxLifecycleSubject().onNext(ActivityEvent.RESUME);
        }
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    @CallSuper
    protected void onStart() {
        GTLog.i(getLifecycleLogMessage(), false);
        super.onStart();
        themeSetting();
        if (this.isSupportRx) {
            getRxLifecycleSubject().onNext(ActivityEvent.START);
        }
    }

    @Override // com.gateio.lib.core.mvvm.GTCoreMVVMActivity
    protected void onSubclassCreate(@Nullable Bundle savedInstanceState) {
        GlobalUtils.getDefault().attach(this);
        initImmersionBar();
        initNavigationBar();
        launchAnimator();
        if (this.isSupportRx) {
            getRxLifecycleSubject().onNext(ActivityEvent.CREATE);
        }
        if (GTCoreApplication.INSTANCE.getHasbroke() == -1) {
            AppApiProvider.getDefaultAppCallbackApi().reStartApp(this);
        }
    }

    public void refreshDayNightModel() {
        refreshViewDayNightModel(getWindow().getDecorView().getRootView());
    }

    @Override // com.gateio.lib.core.mvvm.IGTMVVM
    public void onAddLifecycleObserver(@NotNull Lifecycle lifecycle) {
    }

    @Override // com.gateio.lib.core.mvvm.IGTMVVM
    public void onInitData(@Nullable Bundle savedInstanceState) {
    }

    @Override // com.gateio.lib.core.mvvm.IGTMVVM
    public void onInitViewModelObserver(@Nullable Bundle savedInstanceState) {
    }
}