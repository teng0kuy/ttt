package com.gateio.biz.base.mvvm;

import com.gateio.lib.network.result.GTHttpResultKotlin;

/* compiled from: R8$$SyntheticClass */
/* loaded from: classes4.dex */
public final /* synthetic */ class a implements Runnable {

    /* renamed from: b */
    public final /* synthetic */ GTHttpResultKotlin.Failure f10992b;

    @Override // java.lang.Runnable
    public final void run() {
        function1.invoke(failure);
    }

    public /* synthetic */ a(GTHttpResultKotlin.Failure failure) {
        failure = failure;
    }
}