package com.gateio.biz.base.mvvm.compat;

import android.app.Activity;
import androidx.viewbinding.ViewBinding;
import com.gateio.biz.base.delegate.GTRxFragmentDelegate;
import com.gateio.biz.base.mvvm.GTBaseMVVMFragment;
import com.gateio.rxjava.ToastType;
import com.gateio.rxjava.basemvp.IHostView;
import com.trello.rxlifecycle4.android.FragmentEvent;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GTBaseMVVMFragmentCompatMVP.kt */
@Metadata(d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\b&\u0018\u0000*\b\b\u0000\u0010\u0001*\u00020\u00022\b\u0012\u0004\u0012\u0002H\u00010\u00032\b\u0012\u0004\u0012\u00020\u00050\u00042\u00020\u0006B\u0005¢\u0006\u0002\u0010\u0007J\b\u0010\b\u001a\u00020\tH\u0016J\b\u0010\n\u001a\u00020\u000bH\u0016J\b\u0010\f\u001a\u00020\tH\u0016J\u0010\u0010\r\u001a\u00020\t2\u0006\u0010\u000e\u001a\u00020\u000fH\u0016J\b\u0010\u0010\u001a\u00020\tH\u0016J\b\u0010\u0011\u001a\u00020\tH\u0016J\u001a\u0010\u0012\u001a\u00020\t2\u0006\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0016H\u0016J\u0012\u0010\u0017\u001a\u00020\t2\b\u0010\u0015\u001a\u0004\u0018\u00010\u0016H\u0016J\u0012\u0010\u0018\u001a\u00020\t2\b\u0010\u0015\u001a\u0004\u0018\u00010\u0016H\u0016J\u001a\u0010\u0019\u001a\u00020\t2\b\u0010\u001a\u001a\u0004\u0018\u00010\u001b2\u0006\u0010\u001c\u001a\u00020\u0014H\u0016J\u001c\u0010\u0019\u001a\u00020\t2\b\u0010\u001a\u001a\u0004\u0018\u00010\u001b2\b\u0010\u0015\u001a\u0004\u0018\u00010\u0016H\u0016J\u0010\u0010\u0019\u001a\u00020\t2\u0006\u0010\u001c\u001a\u00020\u0014H\u0016J\u0012\u0010\u0019\u001a\u00020\t2\b\u0010\u0015\u001a\u0004\u0018\u00010\u0016H\u0016¨\u0006\u001d"}, d2 = {"Lcom/gateio/biz/base/mvvm/compat/GTBaseMVVMFragmentCompatMVP;", "VB", "Landroidx/viewbinding/ViewBinding;", "Lcom/gateio/biz/base/mvvm/GTBaseMVVMFragment;", "Lcom/gateio/biz/base/mvvm/compat/IBaseViewCompat;", "Lcom/trello/rxlifecycle4/android/FragmentEvent;", "Lcom/gateio/biz/base/delegate/GTRxFragmentDelegate;", "()V", "dismissLoadingProgress", "", "isNetWorkConnected", "", "logOut", "runOnUiThread", "action", "Ljava/lang/Runnable;", "showLoadingProgress", "showMomentTokenException", "showPassDialog", "passType", "", "msg", "", "showSecondPassDialog", "showSetFundPassTip", "showToast", "type", "Lcom/gateio/rxjava/ToastType;", "resId", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public abstract class GTBaseMVVMFragmentCompatMVP<VB extends ViewBinding> extends GTBaseMVVMFragment<VB> implements IBaseViewCompat<FragmentEvent>, GTRxFragmentDelegate {
    @Override // com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showToast(@Nullable String msg) {
        super.showToast(msg);
    }

    @Override // com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showToast(int resId) {
        super.showToast(resId);
    }

    @Override // com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void dismissLoadingProgress() {
        super.dismissLoadingProgress();
    }

    @Override // com.gateio.biz.base.delegate.GTBaseViewDelegate, com.gateio.rxjava.basemvp.IBaseView, com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public boolean isNetWorkConnected() {
        return super.isNetWorkConnected();
    }

    @Override // com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void logOut() {
        super.logOut();
    }

    @Override // com.gateio.rxjava.basemvp.IBaseView
    public void runOnUiThread(@NotNull Runnable action) {
        IHostView iHostView;
        Object host = getHost();
        Activity host2 = null;
        if (host instanceof IHostView) {
            iHostView = (IHostView) host;
        } else {
            iHostView = null;
        }
        if (iHostView != null) {
            host2 = iHostView.getHost();
        }
        if (host2 != null && !iHostView.getHost().isDestroyed() && !iHostView.getHost().isFinishing() && !isRemoving() && !isDetached()) {
            iHostView.runOnUiThread(action);
        }
    }

    @Override // com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showLoadingProgress() {
        super.showLoadingProgress();
    }

    @Override // com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showMomentTokenException() {
        super.showMomentTokenException();
    }

    @Override // com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showPassDialog(int passType, @Nullable String msg) {
        super.showPassDialog(passType, msg);
    }

    @Override // com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showSecondPassDialog(@Nullable String msg) {
        super.showSecondPassDialog(msg);
    }

    @Override // com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showSetFundPassTip(@Nullable String msg) {
        super.showSetFundPassTip(msg);
    }

    @Override // com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showToast(@Nullable ToastType type, @Nullable String msg) {
        super.showToast(type, msg);
    }

    @Override // com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showToast(@Nullable ToastType type, int resId) {
        super.showToast(type, resId);
    }
}