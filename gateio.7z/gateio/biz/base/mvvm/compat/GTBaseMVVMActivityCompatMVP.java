package com.gateio.biz.base.mvvm.compat;

import android.app.Activity;
import android.os.Bundle;
import androidx.exifinterface.media.ExifInterface;
import androidx.viewbinding.ViewBinding;
import com.bytedance.apm.agent.v2.instrumentation.AppAgent;
import com.gateio.biz.base.delegate.GTRxActivityDelegate;
import com.gateio.biz.base.mvvm.GTBaseMVVMActivity;
import com.gateio.rxjava.ToastType;
import com.gateio.rxjava.basemvp.IHostView;
import com.trello.rxlifecycle4.android.ActivityEvent;
import io.reactivex.rxjava3.core.s;
import io.reactivex.rxjava3.core.x;
import io.reactivex.rxjava3.core.y;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GTBaseMVVMActivityCompatMVP.kt */
@Metadata(d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b&\u0018\u0000*\b\b\u0000\u0010\u0002*\u00020\u00012\b\u0012\u0004\u0012\u00028\u00000\u00032\u00020\u00042\b\u0012\u0004\u0012\u00020\u00060\u00052\u00020\u0007B\u0007¢\u0006\u0004\b$\u0010%J\u0012\u0010\u000b\u001a\u00020\n2\b\u0010\t\u001a\u0004\u0018\u00010\bH\u0014J\u0012\u0010\u000e\u001a\u00020\n2\b\u0010\r\u001a\u0004\u0018\u00010\fH\u0016J\u0010\u0010\u000e\u001a\u00020\n2\u0006\u0010\u0010\u001a\u00020\u000fH\u0016J\u001c\u0010\u000e\u001a\u00020\n2\b\u0010\u0012\u001a\u0004\u0018\u00010\u00112\b\u0010\r\u001a\u0004\u0018\u00010\fH\u0016J\u001a\u0010\u000e\u001a\u00020\n2\b\u0010\u0012\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u0010\u001a\u00020\u000fH\u0016J\b\u0010\u0013\u001a\u00020\nH\u0016J\b\u0010\u0014\u001a\u00020\nH\u0016J\b\u0010\u0016\u001a\u00020\u0015H\u0016J\b\u0010\u0017\u001a\u00020\nH\u0016J\u001a\u0010\u0019\u001a\u00020\n2\u0006\u0010\u0018\u001a\u00020\u000f2\b\u0010\r\u001a\u0004\u0018\u00010\fH\u0016J\b\u0010\u001a\u001a\u00020\nH\u0016J\u0012\u0010\u001b\u001a\u00020\n2\b\u0010\r\u001a\u0004\u0018\u00010\fH\u0016J\u0012\u0010\u001c\u001a\u00020\n2\b\u0010\r\u001a\u0004\u0018\u00010\fH\u0016J\b\u0010\u001e\u001a\u00020\u001dH\u0016J\b\u0010\u001f\u001a\u00020\u0015H\u0016J\u001e\u0010#\u001a\u000e\u0012\u0004\u0012\u00028\u0001\u0012\u0004\u0012\u00028\u00010\"\"\b\b\u0001\u0010!*\u00020 H\u0016¨\u0006&"}, d2 = {"Lcom/gateio/biz/base/mvvm/compat/GTBaseMVVMActivityCompatMVP;", "Landroidx/viewbinding/ViewBinding;", "VB", "Lcom/gateio/biz/base/mvvm/GTBaseMVVMActivity;", "Lcom/gateio/rxjava/basemvp/IHostView;", "Lcom/gateio/biz/base/mvvm/compat/IBaseViewCompat;", "Lcom/trello/rxlifecycle4/android/ActivityEvent;", "Lcom/gateio/biz/base/delegate/GTRxActivityDelegate;", "Landroid/os/Bundle;", "savedInstanceState", "", AppAgent.ON_CREATE, "", "msg", "showToast", "", "resId", "Lcom/gateio/rxjava/ToastType;", "type", "showLoadingProgress", "dismissLoadingProgress", "", "isNetWorkConnected", "logOut", "passType", "showPassDialog", "showMomentTokenException", "showSecondPassDialog", "showSetFundPassTip", "Landroid/app/Activity;", "getHost", "isActive", "", ExifInterface.GPS_DIRECTION_TRUE, "Lio/reactivex/rxjava3/core/y;", "bindToActiveChanged", AppAgent.CONSTRUCT, "()V", "biz_base_core_release"}, k = 1, mv = {1, 9, 0})
/* loaded from: classes4.dex */
public abstract class GTBaseMVVMActivityCompatMVP<VB extends ViewBinding> extends GTBaseMVVMActivity<VB> implements IHostView, IBaseViewCompat<ActivityEvent>, GTRxActivityDelegate {
    @Override // com.gateio.rxjava.ActiveProvider
    public boolean isActive() {
        return true;
    }

    @Override // com.gateio.rxjava.basemvp.IBaseView, com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showToast(@Nullable String msg) {
        super.showToast(msg);
    }

    @Override // com.gateio.rxjava.ActiveProvider
    @NotNull
    public <T> y<T, T> bindToActiveChanged() {
        return new y() { // from class: com.gateio.biz.base.mvvm.compat.a
            @Override // io.reactivex.rxjava3.core.y
            public final x apply(s sVar) {
                return GTBaseMVVMActivityCompatMVP.bindToActiveChanged$lambda$0(sVar);
            }
        };
    }

    @Override // com.gateio.rxjava.basemvp.IBaseView, com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showToast(int resId) {
        super.showToast(resId);
    }

    @Override // com.gateio.rxjava.basemvp.IBaseView, com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void dismissLoadingProgress() {
        super.dismissLoadingProgress();
    }

    @Override // com.gateio.biz.base.delegate.GTBaseViewDelegate, com.gateio.rxjava.basemvp.IBaseView, com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public boolean isNetWorkConnected() {
        return super.isNetWorkConnected();
    }

    @Override // com.gateio.rxjava.basemvp.IBaseView, com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void logOut() {
        super.logOut();
    }

    @Override // com.gateio.biz.base.mvvm.GTBaseMVVMActivity, com.gateio.lib.core.mvvm.GTCoreMVVMActivity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override // com.gateio.rxjava.basemvp.IBaseView, com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showLoadingProgress() {
        super.showLoadingProgress();
    }

    @Override // com.gateio.rxjava.basemvp.IBaseView, com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showMomentTokenException() {
        super.showMomentTokenException();
    }

    @Override // com.gateio.rxjava.basemvp.IBaseView, com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showPassDialog(int passType, @Nullable String msg) {
        super.showPassDialog(passType, msg);
    }

    @Override // com.gateio.rxjava.basemvp.IBaseView, com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showSecondPassDialog(@Nullable String msg) {
        super.showSecondPassDialog(msg);
    }

    @Override // com.gateio.rxjava.basemvp.IBaseView, com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showSetFundPassTip(@Nullable String msg) {
        super.showSetFundPassTip(msg);
    }

    @Override // com.gateio.rxjava.basemvp.IBaseView, com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showToast(@Nullable ToastType type, @Nullable String msg) {
        super.showToast(type, msg);
    }

    @Override // com.gateio.rxjava.basemvp.IBaseView, com.gateio.biz.base.mvvm.compat.IBaseViewCompat
    public void showToast(@Nullable ToastType type, int resId) {
        super.showToast(type, resId);
    }

    @Override // com.gateio.rxjava.basemvp.IHostView
    @NotNull
    public Activity getHost() {
        return this;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final x bindToActiveChanged$lambda$0(s sVar) {
        return sVar;
    }
}