package com.gateio.biz.base.mvvm;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.CallSuper;
import androidx.annotation.ColorRes;
import androidx.annotation.MainThread;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.viewbinding.ViewBinding;
import com.bytedance.apm.agent.v2.instrumentation.AppAgent;
import com.gateio.biz.base.datafinder.GTPageDataFinderLifecycleEventObserver;
import com.gateio.biz.base.delegate.GTBaseBizDelegate;
import com.gateio.biz.base.delegate.GTBaseLogDelegate;
import com.gateio.biz.base.delegate.GTBaseViewDelegate;
import com.gateio.biz.base.delegate.GTRxFragmentDelegate;
import com.gateio.biz.base.delegate.GTViewModelProviderDelegate;
import com.gateio.common.view.LoadingProgressV5;
import com.gateio.lib.core.mvvm.GTCoreMVVMDialogFragment;
import com.gateio.lib.logger.GTLog;
import com.trello.rxlifecycle4.android.FragmentEvent;
import java.util.Arrays;
import kotlin.Lazy;
import kotlin.LazyKt__LazyJVMKt;
import kotlin.LazyThreadSafetyMode;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.Reflection;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.reflect.KClass;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GTBaseMVVMDialogFragment.kt */
@Metadata(d1 = {"\u0000\u0098\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\f\b&\u0018\u0000*\b\b\u0000\u0010\u0002*\u00020\u00012\b\u0012\u0004\u0012\u00028\u00000\u00032\u00020\u00042\u00020\u00052\u00020\u0006B\u0007¢\u0006\u0004\b[\u0010\\J\b\u0010\b\u001a\u00020\u0007H\u0002J\u0010\u0010\u000b\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\tH\u0017J\u0010\u0010\u000b\u001a\u00020\u00072\u0006\u0010\r\u001a\u00020\fH\u0017J\u0012\u0010\u0010\u001a\u00020\u00072\b\u0010\u000f\u001a\u0004\u0018\u00010\u000eH\u0017J\u001a\u0010\u0013\u001a\u00020\u00072\u0006\u0010\u0012\u001a\u00020\u00112\b\u0010\u000f\u001a\u0004\u0018\u00010\u000eH\u0017J\b\u0010\u0014\u001a\u00020\u0007H\u0017J\b\u0010\u0015\u001a\u00020\u0007H\u0017J\b\u0010\u0016\u001a\u00020\u0007H\u0017J\b\u0010\u0017\u001a\u00020\u0007H\u0017J\b\u0010\u0018\u001a\u00020\u0007H\u0017J\b\u0010\u0019\u001a\u00020\u0007H\u0017J\b\u0010\u001a\u001a\u00020\u0007H\u0017J\u0010\u0010\u001d\u001a\u00020\u00072\u0006\u0010\u001c\u001a\u00020\u001bH\u0016J\u0012\u0010\u001e\u001a\u00020\u00072\b\u0010\u000f\u001a\u0004\u0018\u00010\u000eH\u0014J\u0012\u0010\u001f\u001a\u00020\u00072\b\u0010\u000f\u001a\u0004\u0018\u00010\u000eH\u0016J\u0012\u0010 \u001a\u00020\u00072\b\u0010\u000f\u001a\u0004\u0018\u00010\u000eH\u0016J\u0010\u0010#\u001a\u00020\u00072\u0006\u0010\"\u001a\u00020!H\u0017J\b\u0010$\u001a\u00020\u0007H\u0016J\u0010\u0010&\u001a\u00020\u00072\u0006\u0010%\u001a\u00020!H\u0016J\u0006\u0010'\u001a\u00020!J\u0010\u0010)\u001a\u00020\u00072\u0006\u0010(\u001a\u00020!H\u0016J\u0014\u0010-\u001a\u0004\u0018\u00010,2\b\b\u0001\u0010+\u001a\u00020*H\u0014J3\u0010-\u001a\u0004\u0018\u00010,2\b\b\u0001\u0010+\u001a\u00020*2\u0016\u00100\u001a\f\u0012\b\b\u0001\u0012\u0004\u0018\u00010/0.\"\u0004\u0018\u00010/H\u0014¢\u0006\u0004\b-\u00101J\u0012\u00102\u001a\u00020*2\b\b\u0001\u0010+\u001a\u00020*H\u0014J@\u0010;\u001a\b\u0012\u0004\u0012\u00028\u00010:\"\n\b\u0001\u00104\u0018\u0001*\u0002032\u000e\b\n\u00107\u001a\b\u0012\u0004\u0012\u000206052\u0010\b\n\u00109\u001a\n\u0012\u0004\u0012\u000208\u0018\u000105H\u0087\bø\u0001\u0000J0\u0010<\u001a\b\u0012\u0004\u0012\u00028\u00010:\"\n\b\u0001\u00104\u0018\u0001*\u0002032\u0010\b\n\u00109\u001a\n\u0012\u0004\u0012\u000208\u0018\u000105H\u0087\bø\u0001\u0000R\"\u0010=\u001a\u00020\t8\u0016@\u0016X\u0096.¢\u0006\u0012\n\u0004\b=\u0010>\u001a\u0004\b?\u0010@\"\u0004\bA\u0010BR$\u0010D\u001a\u0004\u0018\u00010C8\u0016@\u0016X\u0096\u000e¢\u0006\u0012\n\u0004\bD\u0010E\u001a\u0004\bF\u0010G\"\u0004\bH\u0010IR\u0016\u0010J\u001a\u00020!8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bJ\u0010KR\"\u0010L\u001a\u00020!8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\bL\u0010K\u001a\u0004\bL\u0010M\"\u0004\bN\u0010OR(\u0010R\u001a\b\u0012\u0004\u0012\u00020Q0P8\u0006@\u0006X\u0086.¢\u0006\u0012\n\u0004\bR\u0010S\u001a\u0004\bT\u0010U\"\u0004\bV\u0010WR\u0016\u0010Z\u001a\u0004\u0018\u0001038$X¤\u0004¢\u0006\u0006\u001a\u0004\bX\u0010Y\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006]"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTBaseMVVMDialogFragment;", "Landroidx/viewbinding/ViewBinding;", "VB", "Lcom/gateio/lib/core/mvvm/GTCoreMVVMDialogFragment;", "Lcom/gateio/biz/base/delegate/GTBaseViewDelegate;", "Lcom/gateio/biz/base/delegate/GTBaseBizDelegate;", "Lcom/gateio/biz/base/delegate/GTBaseLogDelegate;", "", "notifyActiveChanged", "Landroid/content/Context;", "context", "onAttach", "Landroid/app/Activity;", "activity", "Landroid/os/Bundle;", "savedInstanceState", AppAgent.ON_CREATE, "Landroid/view/View;", "view", "onViewCreated", "onStart", "onResume", "onPause", "onStop", "onDestroyView", "onDestroy", "onDetach", "Landroidx/lifecycle/Lifecycle;", "lifecycle", "onAddLifecycleObserver", "onSubclassViewCreated", "onInitViewModelObserver", "onInitData", "", "isVisibleToUser", "setUserVisibleHint", "onLazyInit", "hidden", "onHiddenChanged", "isActive", "active", "onActiveChanged", "", "resId", "", "safetyGetString", "", "", "objs", "(I[Ljava/lang/Object;)Ljava/lang/String;", "safetyGetColor", "Lcom/gateio/biz/base/mvvm/GTBaseViewModel;", "VM", "Lkotlin/Function0;", "Landroidx/lifecycle/ViewModelStoreOwner;", "ownerProducer", "Landroidx/lifecycle/ViewModelProvider$Factory;", "factoryProducer", "Lkotlin/Lazy;", "viewModels", "activityViewModels", "mContext", "Landroid/content/Context;", "getMContext", "()Landroid/content/Context;", "setMContext", "(Landroid/content/Context;)V", "Lcom/gateio/common/view/LoadingProgressV5;", "mLoadingProgress", "Lcom/gateio/common/view/LoadingProgressV5;", "getMLoadingProgress", "()Lcom/gateio/common/view/LoadingProgressV5;", "setMLoadingProgress", "(Lcom/gateio/common/view/LoadingProgressV5;)V", "isFirstInit", "Z", "isSupportRx", "()Z", "setSupportRx", "(Z)V", "Lio/reactivex/rxjava3/subjects/a;", "Lcom/trello/rxlifecycle4/android/FragmentEvent;", "rxLifecycleSubject", "Lio/reactivex/rxjava3/subjects/a;", "getRxLifecycleSubject", "()Lio/reactivex/rxjava3/subjects/a;", "setRxLifecycleSubject", "(Lio/reactivex/rxjava3/subjects/a;)V", "getMViewModel", "()Lcom/gateio/biz/base/mvvm/GTBaseViewModel;", "mViewModel", AppAgent.CONSTRUCT, "()V", "biz_base_core_release"}, k = 1, mv = {1, 9, 0})
@SourceDebugExtension({"SMAP\nGTBaseMVVMDialogFragment.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GTBaseMVVMDialogFragment.kt\ncom/gateio/biz/base/mvvm/GTBaseMVVMDialogFragment\n+ 2 FragmentViewModelLazy.kt\nandroidx/fragment/app/FragmentViewModelLazyKt\n*L\n1#1,308:1\n106#2,15:309\n172#2,9:324\n*S KotlinDebug\n*F\n+ 1 GTBaseMVVMDialogFragment.kt\ncom/gateio/biz/base/mvvm/GTBaseMVVMDialogFragment\n*L\n293#1:309,15\n304#1:324,9\n*E\n"})
/* loaded from: classes4.dex */
public abstract class GTBaseMVVMDialogFragment<VB extends ViewBinding> extends GTCoreMVVMDialogFragment<VB> implements GTBaseViewDelegate, GTBaseBizDelegate, GTBaseLogDelegate {
    private boolean isFirstInit = true;
    private boolean isSupportRx;
    public Context mContext;

    @Nullable
    private LoadingProgressV5 mLoadingProgress;
    public io.reactivex.rxjava3.subjects.a<FragmentEvent> rxLifecycleSubject;

    /* JADX INFO: Add missing generic type declarations: [VM] */
    /* compiled from: GTBaseMVVMDialogFragment.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0010\u0000\u001a\u00020\u0001\"\n\b\u0000\u0010\u0002\u0018\u0001*\u00020\u0003\"\b\b\u0001\u0010\u0004*\u00020\u00052\u0006\u0010\u0006\u001a\u0002H\u0002H\n¢\u0006\u0004\b\u0007\u0010\b"}, d2 = {"<anonymous>", "", "VM", "Lcom/gateio/biz/base/mvvm/GTBaseViewModel;", "VB", "Landroidx/viewbinding/ViewBinding;", "it", "invoke", "(Lcom/gateio/biz/base/mvvm/GTBaseViewModel;)V"}, k = 3, mv = {1, 9, 0}, xi = 176)
    @SourceDebugExtension({"SMAP\nGTBaseMVVMDialogFragment.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GTBaseMVVMDialogFragment.kt\ncom/gateio/biz/base/mvvm/GTBaseMVVMDialogFragment$activityViewModels$1\n*L\n1#1,308:1\n*E\n"})
    /* renamed from: com.gateio.biz.base.mvvm.GTBaseMVVMDialogFragment$activityViewModels$1, reason: invalid class name */
    public static final class AnonymousClass1<VM> extends Lambda implements Function1<VM, Unit> {
        final /* synthetic */ GTBaseMVVMDialogFragment<VB> this$0;

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(Object obj) {
            invoke((GTBaseViewModel) obj);
            return Unit.INSTANCE;
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public AnonymousClass1(GTBaseMVVMDialogFragment<VB> gTBaseMVVMDialogFragment) {
            super(1);
            this.this$0 = gTBaseMVVMDialogFragment;
        }

        /* JADX WARN: Incorrect types in method signature: (TVM;)V */
        public final void invoke(@NotNull GTBaseViewModel gTBaseViewModel) {
            GTBaseMVVMDialogFragment<VB> gTBaseMVVMDialogFragment = this.this$0;
            gTBaseMVVMDialogFragment.initViewModelObserverForView(gTBaseMVVMDialogFragment, gTBaseViewModel);
            GTBaseMVVMDialogFragment<VB> gTBaseMVVMDialogFragment2 = this.this$0;
            gTBaseMVVMDialogFragment2.initViewModelObserverForBiz(gTBaseMVVMDialogFragment2, gTBaseViewModel);
        }
    }

    /* JADX INFO: Add missing generic type declarations: [VM] */
    /* compiled from: GTBaseMVVMDialogFragment.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0010\u0000\u001a\u00020\u0001\"\n\b\u0000\u0010\u0002\u0018\u0001*\u00020\u0003\"\b\b\u0001\u0010\u0004*\u00020\u00052\u0006\u0010\u0006\u001a\u0002H\u0002H\n¢\u0006\u0004\b\u0007\u0010\b"}, d2 = {"<anonymous>", "", "VM", "Lcom/gateio/biz/base/mvvm/GTBaseViewModel;", "VB", "Landroidx/viewbinding/ViewBinding;", "it", "invoke", "(Lcom/gateio/biz/base/mvvm/GTBaseViewModel;)V"}, k = 3, mv = {1, 9, 0}, xi = 176)
    @SourceDebugExtension({"SMAP\nGTBaseMVVMDialogFragment.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GTBaseMVVMDialogFragment.kt\ncom/gateio/biz/base/mvvm/GTBaseMVVMDialogFragment$viewModels$2\n*L\n1#1,308:1\n*E\n"})
    /* renamed from: com.gateio.biz.base.mvvm.GTBaseMVVMDialogFragment$viewModels$2, reason: invalid class name */
    public static final class AnonymousClass2<VM> extends Lambda implements Function1<VM, Unit> {
        final /* synthetic */ GTBaseMVVMDialogFragment<VB> this$0;

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(Object obj) {
            invoke((GTBaseViewModel) obj);
            return Unit.INSTANCE;
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public AnonymousClass2(GTBaseMVVMDialogFragment<VB> gTBaseMVVMDialogFragment) {
            super(1);
            this.this$0 = gTBaseMVVMDialogFragment;
        }

        /* JADX WARN: Incorrect types in method signature: (TVM;)V */
        public final void invoke(@NotNull GTBaseViewModel gTBaseViewModel) {
            GTBaseMVVMDialogFragment<VB> gTBaseMVVMDialogFragment = this.this$0;
            gTBaseMVVMDialogFragment.initViewModelObserverForView(gTBaseMVVMDialogFragment, gTBaseViewModel);
            GTBaseMVVMDialogFragment<VB> gTBaseMVVMDialogFragment2 = this.this$0;
            gTBaseMVVMDialogFragment2.initViewModelObserverForBiz(gTBaseMVVMDialogFragment2, gTBaseViewModel);
        }
    }

    @Override // com.gateio.lib.core.mvvm.GTCoreMVVMDialogFragment
    @Nullable
    protected abstract GTBaseViewModel getMViewModel();

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    @CallSuper
    public void onAttach(@NotNull Context context) {
        GTLog.i(getLifecycleLogMessage(), false);
        if (this instanceof GTRxFragmentDelegate) {
            GTLog.i("This isSupport RxLifecycle, " + getLifecycleLogMessage(), false);
            this.isSupportRx = true;
            setRxLifecycleSubject(io.reactivex.rxjava3.subjects.a.d());
        }
        setMContext(context);
        super.onAttach(context);
        if (this.isSupportRx) {
            getRxLifecycleSubject().onNext(FragmentEvent.ATTACH);
        }
    }

    public void onLazyInit() {
        this.isFirstInit = false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Nullable
    public String safetyGetString(@StringRes int resId) {
        return (getActivity() == null || !isAdded()) ? "" : getString(resId);
    }

    public static /* synthetic */ Lazy activityViewModels$default(GTBaseMVVMDialogFragment gTBaseMVVMDialogFragment, Function0 function0, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: activityViewModels");
        }
        if ((i10 & 1) != 0) {
            function0 = null;
        }
        Intrinsics.reifiedOperationMarker(4, "VM");
        KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(ViewModel.class);
        GTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$1 gTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$1 = new GTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$1(gTBaseMVVMDialogFragment);
        GTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$2 gTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$2 = new GTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$2(null, gTBaseMVVMDialogFragment);
        if (function0 == null) {
            function0 = new GTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$3(gTBaseMVVMDialogFragment);
        }
        Lazy lazyCreateViewModelLazy = FragmentViewModelLazyKt.createViewModelLazy(gTBaseMVVMDialogFragment, orCreateKotlinClass, gTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$1, gTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$2, function0);
        Intrinsics.needClassReification();
        return new GTViewModelProviderDelegate(lazyCreateViewModelLazy, new AnonymousClass1(gTBaseMVVMDialogFragment));
    }

    public static /* synthetic */ Lazy viewModels$default(GTBaseMVVMDialogFragment gTBaseMVVMDialogFragment, Function0 function0, Function0 function02, int i10, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: viewModels");
        }
        if ((i10 & 1) != 0) {
            function0 = new Function0<GTBaseMVVMDialogFragment<VB>>(gTBaseMVVMDialogFragment) { // from class: com.gateio.biz.base.mvvm.GTBaseMVVMDialogFragment.viewModels.1
                final /* synthetic */ GTBaseMVVMDialogFragment<VB> this$0;

                @Override // kotlin.jvm.functions.Function0
                @NotNull
                public final GTBaseMVVMDialogFragment<VB> invoke() {
                    return this.this$0;
                }

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                    this.this$0 = gTBaseMVVMDialogFragment;
                }
            };
        }
        if ((i10 & 2) != 0) {
            function02 = null;
        }
        Lazy lazy = LazyKt__LazyJVMKt.lazy(LazyThreadSafetyMode.NONE, (Function0) new GTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$1(function0));
        Intrinsics.reifiedOperationMarker(4, "VM");
        KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(ViewModel.class);
        GTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$2 gTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$2 = new GTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$2(lazy);
        GTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$3 gTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$3 = new GTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$3(null, lazy);
        if (function02 == null) {
            function02 = new GTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$4(gTBaseMVVMDialogFragment, lazy);
        }
        Lazy lazyCreateViewModelLazy = FragmentViewModelLazyKt.createViewModelLazy(gTBaseMVVMDialogFragment, orCreateKotlinClass, gTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$2, gTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$3, function02);
        Intrinsics.needClassReification();
        return new GTViewModelProviderDelegate(lazyCreateViewModelLazy, new AnonymousClass2(gTBaseMVVMDialogFragment));
    }

    @MainThread
    public final /* synthetic */ <VM extends GTBaseViewModel> Lazy<VM> activityViewModels(Function0<? extends ViewModelProvider.Factory> factoryProducer) {
        Intrinsics.reifiedOperationMarker(4, "VM");
        KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(ViewModel.class);
        GTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$1 gTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$1 = new GTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$1(this);
        GTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$2 gTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$2 = new GTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$2(null, this);
        if (factoryProducer == null) {
            factoryProducer = new GTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$3(this);
        }
        Lazy lazyCreateViewModelLazy = FragmentViewModelLazyKt.createViewModelLazy(this, orCreateKotlinClass, gTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$1, gTBaseMVVMDialogFragment$activityViewModels$$inlined$activityViewModels$default$2, factoryProducer);
        Intrinsics.needClassReification();
        return new GTViewModelProviderDelegate(lazyCreateViewModelLazy, new AnonymousClass1(this));
    }

    @Override // com.gateio.biz.base.delegate.GTBaseViewDelegate, com.gateio.biz.base.delegate.GTBaseBizDelegate
    @NotNull
    public Context getMContext() {
        Context context = this.mContext;
        if (context != null) {
            return context;
        }
        return null;
    }

    @Override // com.gateio.biz.base.delegate.GTBaseViewDelegate
    @Nullable
    public LoadingProgressV5 getMLoadingProgress() {
        return this.mLoadingProgress;
    }

    @NotNull
    public final io.reactivex.rxjava3.subjects.a<FragmentEvent> getRxLifecycleSubject() {
        io.reactivex.rxjava3.subjects.a<FragmentEvent> aVar = this.rxLifecycleSubject;
        if (aVar != null) {
            return aVar;
        }
        return null;
    }

    /* renamed from: isSupportRx, reason: from getter */
    public final boolean getIsSupportRx() {
        return this.isSupportRx;
    }

    @Override // com.gateio.biz.base.delegate.GTBaseViewDelegate, com.gateio.biz.base.delegate.GTBaseBizDelegate
    public void setMContext(@NotNull Context context) {
        this.mContext = context;
    }

    @Override // com.gateio.biz.base.delegate.GTBaseViewDelegate
    public void setMLoadingProgress(@Nullable LoadingProgressV5 loadingProgressV5) {
        this.mLoadingProgress = loadingProgressV5;
    }

    public final void setRxLifecycleSubject(@NotNull io.reactivex.rxjava3.subjects.a<FragmentEvent> aVar) {
        this.rxLifecycleSubject = aVar;
    }

    public final void setSupportRx(boolean z10) {
        this.isSupportRx = z10;
    }

    @MainThread
    public final /* synthetic */ <VM extends GTBaseViewModel> Lazy<VM> viewModels(Function0<? extends ViewModelStoreOwner> ownerProducer, Function0<? extends ViewModelProvider.Factory> factoryProducer) {
        Lazy lazy = LazyKt__LazyJVMKt.lazy(LazyThreadSafetyMode.NONE, (Function0) new GTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$1(ownerProducer));
        Intrinsics.reifiedOperationMarker(4, "VM");
        KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(ViewModel.class);
        GTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$2 gTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$2 = new GTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$2(lazy);
        GTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$3 gTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$3 = new GTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$3(null, lazy);
        if (factoryProducer == null) {
            factoryProducer = new GTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$4(this, lazy);
        }
        Lazy lazyCreateViewModelLazy = FragmentViewModelLazyKt.createViewModelLazy(this, orCreateKotlinClass, gTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$2, gTBaseMVVMDialogFragment$viewModels$$inlined$viewModels$default$3, factoryProducer);
        Intrinsics.needClassReification();
        return new GTViewModelProviderDelegate(lazyCreateViewModelLazy, new AnonymousClass2(this));
    }

    private final void notifyActiveChanged() {
        if (getHost() != null) {
            onActiveChanged(isActive());
            for (Fragment fragment : getChildFragmentManager().getFragments()) {
                if (fragment instanceof GTBaseMVVMDialogFragment) {
                    ((GTBaseMVVMDialogFragment) fragment).notifyActiveChanged();
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x0022  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean isActive() {
        /*
            r4 = this;
            androidx.fragment.app.Fragment r0 = r4.getParentFragment()
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L22
            boolean r3 = r0 instanceof com.gateio.biz.base.mvvm.GTBaseMVVMDialogFragment
            if (r3 == 0) goto L13
            com.gateio.biz.base.mvvm.GTBaseMVVMDialogFragment r0 = (com.gateio.biz.base.mvvm.GTBaseMVVMDialogFragment) r0
            boolean r0 = r0.isActive()
            goto L23
        L13:
            boolean r3 = r0.getUserVisibleHint()
            if (r3 == 0) goto L20
            boolean r0 = r0.isVisible()
            if (r0 == 0) goto L20
            goto L22
        L20:
            r0 = r1
            goto L23
        L22:
            r0 = r2
        L23:
            if (r0 == 0) goto L32
            boolean r0 = r4.getUserVisibleHint()
            if (r0 == 0) goto L32
            boolean r0 = r4.isVisible()
            if (r0 == 0) goto L32
            r1 = r2
        L32:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.gateio.biz.base.mvvm.GTBaseMVVMDialogFragment.isActive():boolean");
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    @CallSuper
    public void onCreate(@Nullable Bundle savedInstanceState) {
        GTLog.i(getLifecycleLogMessage(), false);
        super.onCreate(savedInstanceState);
        if (this.isSupportRx) {
            getRxLifecycleSubject().onNext(FragmentEvent.CREATE);
        }
        getLifecycle().addObserver(GTPageDataFinderLifecycleEventObserver.INSTANCE);
    }

    @Override // androidx.fragment.app.Fragment
    @CallSuper
    public void onDestroy() {
        GTLog.i(getLifecycleLogMessage(), false);
        super.onDestroy();
        if (this.isSupportRx) {
            getRxLifecycleSubject().onNext(FragmentEvent.DESTROY);
        }
    }

    @Override // com.gateio.lib.core.mvvm.GTCoreMVVMDialogFragment, androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    @CallSuper
    public void onDestroyView() {
        GTLog.i(getLifecycleLogMessage(), false);
        super.onDestroyView();
        if (this.isSupportRx) {
            getRxLifecycleSubject().onNext(FragmentEvent.DESTROY_VIEW);
        }
        getLifecycle().removeObserver(GTPageDataFinderLifecycleEventObserver.INSTANCE);
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    @CallSuper
    public void onDetach() {
        GTLog.i(getLifecycleLogMessage(), false);
        super.onDetach();
        if (this.isSupportRx) {
            getRxLifecycleSubject().onNext(FragmentEvent.DETACH);
        }
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        notifyActiveChanged();
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    @CallSuper
    public void onPause() {
        GTLog.i(getLifecycleLogMessage(), false);
        super.onPause();
        if (this.isSupportRx) {
            getRxLifecycleSubject().onNext(FragmentEvent.PAUSE);
        }
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    @CallSuper
    public void onResume() {
        GTLog.i$default(getLifecycleLogMessage(), null, null, null, 14, null);
        super.onResume();
        if (this.isSupportRx) {
            getRxLifecycleSubject().onNext(FragmentEvent.RESUME);
        }
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    @CallSuper
    public void onStart() {
        GTLog.i(getLifecycleLogMessage(), false);
        super.onStart();
        if (this.isSupportRx) {
            getRxLifecycleSubject().onNext(FragmentEvent.START);
        }
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    @CallSuper
    public void onStop() {
        GTLog.i(getLifecycleLogMessage(), false);
        super.onStop();
        if (this.isSupportRx) {
            getRxLifecycleSubject().onNext(FragmentEvent.STOP);
        }
    }

    @Override // com.gateio.lib.core.mvvm.GTCoreMVVMDialogFragment, androidx.fragment.app.Fragment
    @CallSuper
    public void onViewCreated(@NotNull View view, @Nullable Bundle savedInstanceState) {
        GTLog.i(getLifecycleLogMessage(), false);
        super.onViewCreated(view, savedInstanceState);
        if (this.isSupportRx) {
            getRxLifecycleSubject().onNext(FragmentEvent.CREATE_VIEW);
        }
    }

    protected int safetyGetColor(@ColorRes int resId) {
        if (getActivity() != null && isAdded()) {
            return getResources().getColor(resId);
        }
        return 0;
    }

    @Nullable
    protected String safetyGetString(@StringRes int resId, @NotNull Object... objs) {
        return (getActivity() == null || !isAdded()) ? "" : getString(resId, Arrays.copyOf(objs, objs.length));
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    @CallSuper
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser && isVisible() && this.isFirstInit) {
            onLazyInit();
        }
        notifyActiveChanged();
    }

    @Override // androidx.fragment.app.Fragment
    @CallSuper
    public void onAttach(@NotNull Activity activity) {
        GTLog.i(getLifecycleLogMessage(), false);
        setMContext(activity);
        super.onAttach(activity);
    }

    public void onActiveChanged(boolean active) {
    }

    @Override // com.gateio.lib.core.mvvm.IGTMVVM
    public void onAddLifecycleObserver(@NotNull Lifecycle lifecycle) {
    }

    @Override // com.gateio.lib.core.mvvm.IGTMVVM
    public void onInitData(@Nullable Bundle savedInstanceState) {
    }

    @Override // com.gateio.lib.core.mvvm.IGTMVVM
    public void onInitViewModelObserver(@Nullable Bundle savedInstanceState) {
    }

    @Override // com.gateio.lib.core.mvvm.GTCoreMVVMDialogFragment
    protected void onSubclassViewCreated(@Nullable Bundle savedInstanceState) {
    }
}