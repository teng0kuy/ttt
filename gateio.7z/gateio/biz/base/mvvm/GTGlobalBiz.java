package com.gateio.biz.base.mvvm;

import com.alipay.alipaysecuritysdk.common.legacy.model.DynamicModel;
import com.gateio.biz.safe.fido2.event.EventValue;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GTGlobalBiz.kt */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bv\u0018\u00002\u00020\u0001:\t\u0002\u0003\u0004\u0005\u0006\u0007\b\t\n\u0082\u0001\t\u000b\f\r\u000e\u000f\u0010\u0011\u0012\u0013ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0014À\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTGlobalBiz;", "", "FingerPrintNeed", "GoLogin", "HttpApiError", "MomentTokenExpired", "NoNet", "PassNeed", "PassNoSet", "PassSecondNeed", "Unknown", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz$FingerPrintNeed;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz$GoLogin;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz$HttpApiError;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz$MomentTokenExpired;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz$NoNet;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz$PassNeed;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz$PassNoSet;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz$PassSecondNeed;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz$Unknown;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public interface GTGlobalBiz {

    /* compiled from: GTGlobalBiz.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\u0002\u0010\u0004R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTGlobalBiz$FingerPrintNeed;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz;", EventValue.STRATEGY_QRID, "", "(Ljava/lang/String;)V", "getQrid", "()Ljava/lang/String;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class FingerPrintNeed implements GTGlobalBiz {

        @Nullable
        private final String qrid;

        @Nullable
        public final String getQrid() {
            return this.qrid;
        }

        public FingerPrintNeed(@Nullable String str) {
            this.qrid = str;
        }
    }

    /* compiled from: GTGlobalBiz.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTGlobalBiz$GoLogin;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz;", "()V", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class GoLogin implements GTGlobalBiz {

        @NotNull
        public static final GoLogin INSTANCE = new GoLogin();

        private GoLogin() {
        }
    }

    /* compiled from: GTGlobalBiz.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0007¨\u0006\t"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTGlobalBiz$HttpApiError;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz;", "code", "", "message", "(Ljava/lang/String;Ljava/lang/String;)V", "getCode", "()Ljava/lang/String;", "getMessage", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class HttpApiError implements GTGlobalBiz {

        @NotNull
        private final String code;

        @NotNull
        private final String message;

        @NotNull
        public final String getCode() {
            return this.code;
        }

        @NotNull
        public final String getMessage() {
            return this.message;
        }

        public HttpApiError(@NotNull String str, @NotNull String str2) {
            this.code = str;
            this.message = str2;
        }
    }

    /* compiled from: GTGlobalBiz.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTGlobalBiz$MomentTokenExpired;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz;", "()V", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class MomentTokenExpired implements GTGlobalBiz {

        @NotNull
        public static final MomentTokenExpired INSTANCE = new MomentTokenExpired();

        private MomentTokenExpired() {
        }
    }

    /* compiled from: GTGlobalBiz.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTGlobalBiz$NoNet;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz;", "message", "", "(Ljava/lang/String;)V", "getMessage", "()Ljava/lang/String;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class NoNet implements GTGlobalBiz {

        @NotNull
        private final String message;

        @NotNull
        public final String getMessage() {
            return this.message;
        }

        public NoNet(@NotNull String str) {
            this.message = str;
        }
    }

    /* compiled from: GTGlobalBiz.kt */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\u0002\u0010\u0006R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u000b"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTGlobalBiz$PassNeed;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz;", "passType", "", "message", "", "(ILjava/lang/String;)V", "getMessage", "()Ljava/lang/String;", "getPassType", "()I", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class PassNeed implements GTGlobalBiz {

        @Nullable
        private final String message;
        private final int passType;

        @Nullable
        public final String getMessage() {
            return this.message;
        }

        public final int getPassType() {
            return this.passType;
        }

        public PassNeed(int i10, @Nullable String str) {
            this.passType = i10;
            this.message = str;
        }
    }

    /* compiled from: GTGlobalBiz.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\u0002\u0010\u0004R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTGlobalBiz$PassNoSet;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz;", "message", "", "(Ljava/lang/String;)V", "getMessage", "()Ljava/lang/String;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class PassNoSet implements GTGlobalBiz {

        @Nullable
        private final String message;

        @Nullable
        public final String getMessage() {
            return this.message;
        }

        public PassNoSet(@Nullable String str) {
            this.message = str;
        }
    }

    /* compiled from: GTGlobalBiz.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\u0002\u0010\u0004R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTGlobalBiz$PassSecondNeed;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz;", "message", "", "(Ljava/lang/String;)V", "getMessage", "()Ljava/lang/String;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class PassSecondNeed implements GTGlobalBiz {

        @Nullable
        private final String message;

        @Nullable
        public final String getMessage() {
            return this.message;
        }

        public PassSecondNeed(@Nullable String str) {
            this.message = str;
        }
    }

    /* compiled from: GTGlobalBiz.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/base/mvvm/GTGlobalBiz$Unknown;", "Lcom/gateio/biz/base/mvvm/GTGlobalBiz;", DynamicModel.KEY_ABBR_DYNAMIC_EXPIRE, "", "(Ljava/lang/Throwable;)V", "getE", "()Ljava/lang/Throwable;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Unknown implements GTGlobalBiz {

        @NotNull
        private final Throwable e;

        @NotNull
        public final Throwable getE() {
            return this.e;
        }

        public Unknown(@NotNull Throwable th) {
            this.e = th;
        }
    }
}