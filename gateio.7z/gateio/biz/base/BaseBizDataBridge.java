package com.gateio.biz.base;

import android.content.Context;
import android.content.Intent;
import androidx.annotation.Nullable;
import com.gateio.lib.webview.client.GTIWebViewClient;

/* loaded from: classes4.dex */
public interface BaseBizDataBridge {
    void changeLanguage(String str, boolean z10);

    void exit();

    void fundPasswordReset(Context context);

    String getFutureQuestion();

    String getFutureQuestion(boolean z10);

    String getNickName();

    String getToken();

    String getUserId();

    String getUserName();

    String getUserPverWs();

    void handleResultForGTPayJSCallHandler(GTIWebViewClient gTIWebViewClient, int i10, int i11, @Nullable Intent intent);

    boolean isValid();

    void logOut();

    void showLogin(Context context);
}