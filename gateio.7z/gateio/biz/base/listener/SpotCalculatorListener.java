package com.gateio.biz.base.listener;

import com.gateio.biz.base.model.futures.entity.DepthAccuracy;
import java.util.List;

/* loaded from: classes4.dex */
public interface SpotCalculatorListener {
    void refreshCommitDialog(String str, String str2);

    void refreshCurrentPrice(String str);

    void refreshDepthPopWindow(List<DepthAccuracy> list);

    void refreshHeadUnitState(String str);

    void refreshInputEditView(String str, String str2);

    void refreshTranAccountInfo(String str, String str2, String str3, String str4);
}