package com.gateio.biz.base.listener;

/* loaded from: classes4.dex */
public interface DexFuturesMarketListener {
    void onSearchItemClickListener(String str, String str2, String str3);
}