package com.gateio.biz.base.listener;

/* loaded from: classes4.dex */
public interface MiniAppOnClickListener {
    void onBackListener();
}