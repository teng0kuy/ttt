package com.gateio.biz.base.listener;

import com.gateio.biz.base.model.futures.entity.DepthAccuracy;
import java.util.List;

/* loaded from: classes4.dex */
public interface FuturesCalculatorListener {
    void refreshDepthPopWindow(List<DepthAccuracy> list);
}