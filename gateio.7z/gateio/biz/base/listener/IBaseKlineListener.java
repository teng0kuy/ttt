package com.gateio.biz.base.listener;

import androidx.fragment.app.Fragment;

/* loaded from: classes4.dex */
public interface IBaseKlineListener {
    Fragment createCountDownFragment();

    default Object getBusinessRenderConsumer() {
        return null;
    }

    void onIntervalSelect(int i10);

    void onLoadMore(Object obj);

    default void onBaseKlineInit() {
    }

    default void onDoubleClick() {
    }

    default void onLongClick() {
    }

    default void showMainListener() {
    }

    default void enableRefresh(boolean z10) {
    }

    default void fullScreen(boolean z10) {
    }

    default void onScroll(Boolean bool) {
    }
}