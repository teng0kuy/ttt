package com.gateio.biz.base.listener;

/* loaded from: classes4.dex */
public interface IScanResultHandler {
    void scanCodeToLogin(String str);
}