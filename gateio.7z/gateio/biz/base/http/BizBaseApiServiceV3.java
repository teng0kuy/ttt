package com.gateio.biz.base.http;

import com.gateio.biz.base.model.ShortUrlServiceEntity;
import com.gateio.http.BaseApiService;
import com.gateio.http.entity.HttpResultV2;
import io.reactivex.rxjava3.core.s;
import java.util.Map;
import retrofit2.http.Body;
import retrofit2.http.POST;

/* loaded from: classes4.dex */
public interface BizBaseApiServiceV3 extends BaseApiService {
    @POST("tiny_url/gen")
    s<HttpResultV2<ShortUrlServiceEntity>> getShortUrl(@Body Map<String, String> map);
}