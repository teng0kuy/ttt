package com.gateio.biz.base.http;

import com.gateio.common.entity.GlobalNoticeEntity;
import com.gateio.http.BaseApiService;
import com.gateio.http.entity.HttpResultAppV1;
import io.reactivex.rxjava3.core.s;
import java.util.Map;
import retrofit2.http.GET;
import retrofit2.http.QueryMap;

/* loaded from: classes4.dex */
public interface BizBaseApiService extends BaseApiService {
    @GET("site/fullsiteBulletin")
    s<HttpResultAppV1<Map<String, GlobalNoticeEntity>>> getFullsiteBulletin(@QueryMap Map<String, String> map);
}