package com.gateio.biz.base.http;

import com.gateio.common.entity.GlobalNoticeEntity;
import com.gateio.http.BaseHttpMethods;
import com.gateio.http.HttpSubject;
import com.gateio.http.func.HttpResultFuncAppV1;
import com.gateio.http.tool.HttpPingUtil;
import io.reactivex.rxjava3.core.s;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes4.dex */
public class BizBaseHttpMethod extends BaseHttpMethods<BizBaseApiService> {
    private static volatile BizBaseHttpMethod instance;

    public static BizBaseHttpMethod getInstance() {
        if (instance == null) {
            synchronized (BizBaseHttpMethod.class) {
                if (instance == null) {
                    instance = new BizBaseHttpMethod();
                }
            }
        }
        return instance;
    }

    public s<Map<String, GlobalNoticeEntity>> getFullsiteBulletin() {
        return ((BizBaseApiService) this.apiService).getFullsiteBulletin(new HashMap()).map(new HttpResultFuncAppV1());
    }

    private BizBaseHttpMethod() {
        HttpSubject.getInstance().register(this);
        this.apiService = (T) init(true, HttpPingUtil.getApiAppUrl()).create(BizBaseApiService.class);
    }

    @Override // com.gateio.http.BaseRetrofitMethods
    protected void recycle() {
        super.recycle();
        instance = null;
    }

    @Override // com.gateio.http.HttpObserver
    public void reset() {
        recycle();
    }
}