package com.gateio.biz.base.http.network;

import android.text.SpannableStringBuilder;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import com.alipay.mobile.security.bio.utils.HanziToPinyin;
import com.gateio.biz.base.R;
import com.gateio.biz.base.router.RouterConst;
import com.gateio.common.tool.SpanUtils;
import com.gateio.lib.core.GTActivityLifecycle;
import com.gateio.lib.http.state.GTNetworkState;
import com.gateio.lib.http.state.GTNetworkStateListener;
import com.gateio.lib.http.state.GTNetworkStateManager;
import com.gateio.lib.http.weaknet.GTWeakNetWorkStateListener;
import com.gateio.lib.http.weaknet.GTWeakNetWorkStateManager;
import com.gateio.lib.http.weaknet.WeakNetworkChecker;
import com.gateio.lib.router.GTRouter;
import com.gateio.lib.uikit.alert.GTAlertV5;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: NetWorkStateAlertHandle.kt */
@Metadata(d1 = {"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u0003B\u0019\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\u0002\u0010\bJ\b\u0010\u0015\u001a\u00020\u0016H\u0002J\b\u0010\u0017\u001a\u00020\u0018H\u0002J\b\u0010\u0019\u001a\u00020\u0016H\u0002J\u0006\u0010\u001a\u001a\u00020\u0016J\b\u0010\u001b\u001a\u00020\u0016H\u0016J\b\u0010\u001c\u001a\u00020\u0016H\u0016J\b\u0010\u001d\u001a\u00020\u0016H\u0002J\u0018\u0010\u001e\u001a\u00020\u00162\u0006\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\"H\u0016J\u0010\u0010#\u001a\u00020\u00162\u0006\u0010$\u001a\u00020\fH\u0016J\u0012\u0010%\u001a\u00020\u00162\b\u0010&\u001a\u0004\u0018\u00010'H\u0002J\u001a\u0010(\u001a\u00020\u00162\b\u0010&\u001a\u0004\u0018\u00010'2\u0006\u0010)\u001a\u00020\nH\u0002J\b\u0010*\u001a\u00020\u0016H\u0002J\b\u0010+\u001a\u00020\u0016H\u0002R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\r\u001a\u00020\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006,"}, d2 = {"Lcom/gateio/biz/base/http/network/NetWorkStateAlertHandle;", "Lcom/gateio/lib/http/state/GTNetworkStateListener;", "Lcom/gateio/lib/http/weaknet/GTWeakNetWorkStateListener;", "Landroidx/lifecycle/LifecycleEventObserver;", "lifecycle", "Landroidx/lifecycle/Lifecycle;", "alertViewProvider", "Lcom/gateio/biz/base/http/network/INetWorkAlertViewProvider;", "(Landroidx/lifecycle/Lifecycle;Lcom/gateio/biz/base/http/network/INetWorkAlertViewProvider;)V", "close", "", "currentNetworkStatus", "Lcom/gateio/lib/http/weaknet/WeakNetworkChecker$NetworkStatus;", "lastStatus", "getLastStatus", "()Z", "setLastStatus", "(Z)V", "networkState", "Lcom/gateio/lib/http/state/GTNetworkState;", "weakTipsIsClose", "changeAlertView", "", "getAlertTextContent", "Landroid/text/SpannableStringBuilder;", "goFaqPage", "onConfigurationChanged", "onNetworkAvailable", "onNetworkLost", "onNetworkState", "onStateChanged", "source", "Landroidx/lifecycle/LifecycleOwner;", "event", "Landroidx/lifecycle/Lifecycle$Event;", "onWeakNetWork", "networkStatus", "reSetText", "alertView", "Lcom/gateio/lib/uikit/alert/GTAlertV5;", "showAlertView", "isShow", "showWeakOrNoNetStateTip", "updateAlertViewForConfigurationChange", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class NetWorkStateAlertHandle implements GTNetworkStateListener, GTWeakNetWorkStateListener, LifecycleEventObserver {

    @Nullable
    private final INetWorkAlertViewProvider alertViewProvider;
    private boolean close;

    @NotNull
    private volatile WeakNetworkChecker.NetworkStatus currentNetworkStatus;
    private boolean lastStatus;

    @NotNull
    private final Lifecycle lifecycle;

    @NotNull
    private volatile GTNetworkState networkState;
    private boolean weakTipsIsClose;

    public NetWorkStateAlertHandle(@NotNull Lifecycle lifecycle, @Nullable INetWorkAlertViewProvider iNetWorkAlertViewProvider) {
        this.lifecycle = lifecycle;
        this.alertViewProvider = iNetWorkAlertViewProvider;
        this.networkState = GTNetworkState.Available;
        this.currentNetworkStatus = WeakNetworkChecker.NetworkStatus.GOOD_NETWORK;
        onNetworkState();
        lifecycle.addObserver(this);
        this.lastStatus = true;
    }

    private final void onNetworkState() {
        this.networkState = GTNetworkStateManager.isNetWorkConnected$default(null, 1, null) ? GTNetworkState.Available : GTNetworkState.Lost;
    }

    /* compiled from: NetWorkStateAlertHandle.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;
        public static final /* synthetic */ int[] $EnumSwitchMapping$2;

        static {
            int[] iArr = new int[GTNetworkState.values().length];
            try {
                iArr[GTNetworkState.Available.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[GTNetworkState.Lost.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            $EnumSwitchMapping$0 = iArr;
            int[] iArr2 = new int[Lifecycle.Event.values().length];
            try {
                iArr2[Lifecycle.Event.ON_CREATE.ordinal()] = 1;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr2[Lifecycle.Event.ON_RESUME.ordinal()] = 2;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr2[Lifecycle.Event.ON_DESTROY.ordinal()] = 3;
            } catch (NoSuchFieldError unused5) {
            }
            $EnumSwitchMapping$1 = iArr2;
            int[] iArr3 = new int[WeakNetworkChecker.NetworkStatus.values().length];
            try {
                iArr3[WeakNetworkChecker.NetworkStatus.NO_NETWORK.ordinal()] = 1;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr3[WeakNetworkChecker.NetworkStatus.WEAK_NETWORK.ordinal()] = 2;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                iArr3[WeakNetworkChecker.NetworkStatus.GOOD_NETWORK.ordinal()] = 3;
            } catch (NoSuchFieldError unused8) {
            }
            $EnumSwitchMapping$2 = iArr3;
        }
    }

    private final void changeAlertView() {
        if (this.lifecycle.getState() != Lifecycle.State.RESUMED) {
            return;
        }
        int i10 = WhenMappings.$EnumSwitchMapping$0[this.networkState.ordinal()];
        if (i10 == 1) {
            showWeakOrNoNetStateTip();
        } else {
            if (i10 != 2) {
                return;
            }
            showWeakOrNoNetStateTip();
        }
    }

    private final SpannableStringBuilder getAlertTextContent() {
        return this.networkState == GTNetworkState.Lost ? new SpanUtils().append(GTActivityLifecycle.getTopContext().getString(R.string.network_down_please_check)).append(HanziToPinyin.Token.SEPARATOR).append(GTActivityLifecycle.getTopContext().getString(R.string.no_net_view)).setUnderline().create() : new SpanUtils().append(GTActivityLifecycle.getTopContext().getString(R.string.network_poor_please_check)).create();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void goFaqPage() {
        if (WeakNetworkChecker.NetworkStatus.WEAK_NETWORK == this.currentNetworkStatus) {
            return;
        }
        GTRouter.navigation$default(GTActivityLifecycle.getTopActivity(), RouterConst.Network.ACTIVITY_NETWORK_FAQ, null, null, null, 28, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void showAlertView(final GTAlertV5 alertView, boolean isShow) {
        if (alertView == null) {
            return;
        }
        if (!isShow) {
            alertView.setVisibility(8);
            return;
        }
        reSetText(alertView);
        alertView.setOnCloseClickListener(new Function0<Unit>() { // from class: com.gateio.biz.base.http.network.NetWorkStateAlertHandle.showAlertView.1
            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            /* renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                if (NetWorkStateAlertHandle.this.networkState == GTNetworkState.Lost) {
                    NetWorkStateAlertHandle.this.close = true;
                } else {
                    NetWorkStateAlertHandle.this.weakTipsIsClose = true;
                }
                NetWorkStateAlertHandle.this.showAlertView(alertView, false);
            }
        });
        alertView.setOnAlertClickListener(new GTAlertV5.OnAlertClickListener() { // from class: com.gateio.biz.base.http.network.NetWorkStateAlertHandle.showAlertView.2
            @Override // com.gateio.lib.uikit.alert.GTAlertV5.OnAlertClickListener
            public void onButtonClick() {
                NetWorkStateAlertHandle.this.goFaqPage();
            }

            @Override // com.gateio.lib.uikit.alert.GTAlertV5.OnAlertClickListener
            public void onTextClick() {
                NetWorkStateAlertHandle.this.goFaqPage();
            }
        });
        alertView.setVisibility(0);
    }

    private final void showWeakOrNoNetStateTip() {
        boolean z10 = this.networkState == GTNetworkState.Available && this.currentNetworkStatus == WeakNetworkChecker.NetworkStatus.GOOD_NETWORK;
        boolean z11 = (this.networkState == GTNetworkState.Lost && !this.close) || (this.currentNetworkStatus == WeakNetworkChecker.NetworkStatus.WEAK_NETWORK && !this.weakTipsIsClose);
        if (z10 && this.lastStatus) {
            return;
        }
        if (!z11 || this.lastStatus) {
            if (z10) {
                this.lastStatus = true;
            } else if (z11) {
                this.lastStatus = false;
            }
            INetWorkAlertViewProvider iNetWorkAlertViewProvider = this.alertViewProvider;
            GTAlertV5 alertView = iNetWorkAlertViewProvider != null ? iNetWorkAlertViewProvider.getAlertView(z10) : null;
            if (alertView == null) {
                return;
            }
            if (z10) {
                showAlertView(alertView, false);
            } else if (z11) {
                showAlertView(alertView, true);
            }
        }
    }

    private final void updateAlertViewForConfigurationChange() {
        INetWorkAlertViewProvider iNetWorkAlertViewProvider = this.alertViewProvider;
        GTAlertV5 alertView = iNetWorkAlertViewProvider != null ? iNetWorkAlertViewProvider.getAlertView(this.lastStatus) : null;
        boolean z10 = false;
        if (alertView != null && alertView.getVisibility() == 0) {
            z10 = true;
        }
        if (z10) {
            reSetText(alertView);
        }
    }

    public final boolean getLastStatus() {
        return this.lastStatus;
    }

    @Override // com.gateio.lib.http.state.GTNetworkStateListener
    public void onNetworkAvailable() {
        this.networkState = GTNetworkState.Available;
        if (this.currentNetworkStatus == WeakNetworkChecker.NetworkStatus.NO_NETWORK) {
            this.currentNetworkStatus = WeakNetworkChecker.NetworkStatus.GOOD_NETWORK;
        }
        changeAlertView();
    }

    @Override // com.gateio.lib.http.state.GTNetworkStateListener
    public void onNetworkLost() {
        this.networkState = GTNetworkState.Lost;
        this.currentNetworkStatus = WeakNetworkChecker.NetworkStatus.NO_NETWORK;
        changeAlertView();
    }

    @Override // androidx.lifecycle.LifecycleEventObserver
    public void onStateChanged(@NotNull LifecycleOwner source, @NotNull Lifecycle.Event event) {
        int i10 = WhenMappings.$EnumSwitchMapping$1[event.ordinal()];
        if (i10 == 1) {
            GTNetworkStateManager.attach(this);
            GTWeakNetWorkStateManager.INSTANCE.addListener(this);
        } else if (i10 == 2) {
            changeAlertView();
            GTWeakNetWorkStateManager.INSTANCE.checkWeakNetwork();
        } else {
            if (i10 != 3) {
                return;
            }
            GTNetworkStateManager.detach(this);
            GTWeakNetWorkStateManager.INSTANCE.removeListener(this);
        }
    }

    @Override // com.gateio.lib.http.weaknet.GTWeakNetWorkStateListener
    public void onWeakNetWork(@NotNull WeakNetworkChecker.NetworkStatus networkStatus) {
        this.currentNetworkStatus = networkStatus;
        int i10 = WhenMappings.$EnumSwitchMapping$2[networkStatus.ordinal()];
        if (i10 == 1) {
            onNetworkLost();
        } else if (i10 == 2) {
            onNetworkAvailable();
        } else {
            if (i10 != 3) {
                return;
            }
            onNetworkAvailable();
        }
    }

    public final void setLastStatus(boolean z10) {
        this.lastStatus = z10;
    }

    private final void reSetText(GTAlertV5 alertView) {
        int i10 = 1;
        if (GTActivityLifecycle.getTopContext().getResources().getConfiguration().getLayoutDirection() != 1) {
            i10 = 0;
        }
        if (alertView != null) {
            alertView.setLayoutDirection(i10);
        }
        if (alertView != null) {
            alertView.requestLayout();
        }
        if (alertView != null) {
            alertView.invalidate();
        }
        if (alertView != null) {
            alertView.setAlertText(getAlertTextContent());
        }
    }

    public final void onConfigurationChanged() {
        updateAlertViewForConfigurationChange();
    }

    public /* synthetic */ NetWorkStateAlertHandle(Lifecycle lifecycle, INetWorkAlertViewProvider iNetWorkAlertViewProvider, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this(lifecycle, (i10 & 2) != 0 ? null : iNetWorkAlertViewProvider);
    }
}