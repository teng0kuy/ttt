package com.gateio.biz.base.http;

import com.bytedance.apm.agent.v2.instrumentation.AppAgent;
import com.gateio.biz.base.model.ShortUrlServiceEntity;
import com.gateio.biz.safe.fido2.event.PageName;
import com.gateio.http.BaseHttpMethods;
import com.gateio.http.HttpSubject;
import com.gateio.http.entity.HttpResultV2;
import com.gateio.http.func.HttpResultFuncV2;
import com.gateio.http.tool.HttpPingUtil;
import com.gateio.rxjava.SchedulerConfig;
import io.reactivex.rxjava3.core.s;
import java.util.HashMap;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: BizBaseHttpMethodV3.kt */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\u0018\u0000 \u00132\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0013B\u0007¢\u0006\u0004\b\u0011\u0010\u0012J\b\u0010\u0004\u001a\u00020\u0003H\u0002J\b\u0010\u0005\u001a\u00020\u0003H\u0016J\u0014\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\b2\u0006\u0010\u0007\u001a\u00020\u0006R$\u0010\u000b\u001a\u0004\u0018\u00010\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u000b\u0010\f\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0010¨\u0006\u0014"}, d2 = {"Lcom/gateio/biz/base/http/BizBaseHttpMethodV3;", "Lcom/gateio/http/BaseHttpMethods;", "Lcom/gateio/biz/base/http/BizBaseApiServiceV3;", "", "initApiService", PageName.PASSKEY_RESET, "", "url", "Lio/reactivex/rxjava3/core/s;", "Lcom/gateio/biz/base/model/ShortUrlServiceEntity;", "getShortUrl", "apiServiceV3", "Lcom/gateio/biz/base/http/BizBaseApiServiceV3;", "getApiServiceV3", "()Lcom/gateio/biz/base/http/BizBaseApiServiceV3;", "setApiServiceV3", "(Lcom/gateio/biz/base/http/BizBaseApiServiceV3;)V", AppAgent.CONSTRUCT, "()V", "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0})
/* loaded from: classes4.dex */
public final class BizBaseHttpMethodV3 extends BaseHttpMethods<BizBaseApiServiceV3> {

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @Nullable
    private static BizBaseHttpMethodV3 instance;

    @Nullable
    private BizBaseApiServiceV3 apiServiceV3;

    private final void initApiService() {
        this.apiServiceV3 = (BizBaseApiServiceV3) init(false, HttpPingUtil.getBaseUrlV2()).create(BizBaseApiServiceV3.class);
    }

    /* compiled from: BizBaseHttpMethodV3.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u001e\u0010\u0003\u001a\u0004\u0018\u00010\u00048FX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"Lcom/gateio/biz/base/http/BizBaseHttpMethodV3$Companion;", "", "()V", "instance", "Lcom/gateio/biz/base/http/BizBaseHttpMethodV3;", "getInstance", "()Lcom/gateio/biz/base/http/BizBaseHttpMethodV3;", "setInstance", "(Lcom/gateio/biz/base/http/BizBaseHttpMethodV3;)V", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @Nullable
        public final BizBaseHttpMethodV3 getInstance() {
            if (BizBaseHttpMethodV3.instance != null) {
                return BizBaseHttpMethodV3.instance;
            }
            BizBaseHttpMethodV3 bizBaseHttpMethodV3 = new BizBaseHttpMethodV3();
            BizBaseHttpMethodV3.INSTANCE.setInstance(bizBaseHttpMethodV3);
            return bizBaseHttpMethodV3;
        }

        public final void setInstance(@Nullable BizBaseHttpMethodV3 bizBaseHttpMethodV3) {
            BizBaseHttpMethodV3.instance = bizBaseHttpMethodV3;
        }
    }

    @Nullable
    public final BizBaseApiServiceV3 getApiServiceV3() {
        return this.apiServiceV3;
    }

    @NotNull
    public final s<ShortUrlServiceEntity> getShortUrl(@NotNull String url) {
        s<HttpResultV2<ShortUrlServiceEntity>> shortUrl;
        s<R> map;
        HashMap map2 = new HashMap();
        map2.put("long-url", url);
        BizBaseApiServiceV3 bizBaseApiServiceV3 = this.apiServiceV3;
        s<ShortUrlServiceEntity> sVarCompose = (bizBaseApiServiceV3 == null || (shortUrl = bizBaseApiServiceV3.getShortUrl(map2)) == null || (map = shortUrl.map(new HttpResultFuncV2(true))) == 0) ? null : map.compose(SchedulerConfig.io_main());
        return sVarCompose == null ? s.empty() : sVarCompose;
    }

    public final void setApiServiceV3(@Nullable BizBaseApiServiceV3 bizBaseApiServiceV3) {
        this.apiServiceV3 = bizBaseApiServiceV3;
    }

    public BizBaseHttpMethodV3() {
        HttpSubject.getInstance().register(this);
        initApiService();
    }

    @Override // com.gateio.http.HttpObserver
    public void reset() {
        initApiService();
    }
}