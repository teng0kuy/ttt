package com.gateio.biz.base.realm;

import com.gateio.lib.storage.realm.GTRealmMigration;
import com.pichillilorenzo.flutter_inappwebview_android.credential_database.URLProtectionSpaceContract;
import io.realm.DynamicRealm;
import io.realm.FieldAttribute;
import io.realm.RealmObjectSchema;
import io.realm.RealmSchema;
import io.realm.com_gateio_biz_base_model_CurrencyDataRealmProxy;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* compiled from: APPRealmMigration.kt */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\u0018\u0000 \n2\u00020\u0001:\u0001\nB\u0005¢\u0006\u0002\u0010\u0002J \u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\bH\u0014¨\u0006\u000b"}, d2 = {"Lcom/gateio/biz/base/realm/APPRealmMigration;", "Lcom/gateio/lib/storage/realm/GTRealmMigration;", "()V", "customMigrate", "", URLProtectionSpaceContract.FeedEntry.COLUMN_NAME_REALM, "Lio/realm/DynamicRealm;", "oldVersion", "", "newVersion", "Companion", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class APPRealmMigration extends GTRealmMigration {
    public static final long schemaVersion = 4;

    @Override // com.gateio.lib.storage.realm.GTRealmMigration
    protected void customMigrate(@NotNull DynamicRealm realm, long oldVersion, long newVersion) {
        RealmObjectSchema realmObjectSchema;
        RealmSchema schema = realm.getSchema();
        if (oldVersion < 4 && (realmObjectSchema = schema.get(com_gateio_biz_base_model_CurrencyDataRealmProxy.ClassNameHelper.INTERNAL_CLASS_NAME)) != null) {
            realmObjectSchema.addField("create_time", String.class, new FieldAttribute[0]);
        }
    }
}