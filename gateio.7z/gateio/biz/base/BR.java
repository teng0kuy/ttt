package com.gateio.biz.base;

/* loaded from: classes4.dex */
public class BR {
    public static final int _all = 0;
}