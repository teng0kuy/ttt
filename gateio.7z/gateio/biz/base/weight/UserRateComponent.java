package com.gateio.biz.base.weight;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.RelativeLayout;
import androidx.appcompat.app.AppCompatActivity;
import com.apm.applog.UriConfig;
import com.gateio.biz.base.R;
import com.gateio.biz.base.databinding.UserRateComponentBinding;
import com.gateio.biz.base.datafinder.rate.UserRateDataFinderEvent;
import com.gateio.biz.base.model.RateComponentAb;
import com.gateio.common.tool.StringUtils;
import com.gateio.common.view.MessageInfo;
import com.gateio.lib.datafinder.GTDataFinder;
import com.gateio.lib.network.util.GateBrandDomainUtil;
import com.gateio.lib.storage.GTStorage;
import com.gateio.lib.uikit.widget.GTToastV3;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.TuplesKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__MutableCollectionsKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import kotlin.text.StringsKt__StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: UserRateComponent.kt */
@Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u001b\u0018\u00002\u00020\u0001:\u00018B\u0011\b\u0016\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\u0002\u0010\u0004B\u001b\b\u0016\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006¢\u0006\u0002\u0010\u0007B#\b\u0016\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\b\u001a\u0004\u0018\u00010\u0006\u0012\u0006\u0010\t\u001a\u00020\n¢\u0006\u0002\u0010\u000bJ\u0018\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u00152\u0006\u0010\u001b\u001a\u00020\u0015H\u0002J#\u0010\u001c\u001a\u0004\u0018\u00010\u000f2\b\u0010\u001d\u001a\u0004\u0018\u00010\u001e2\b\u0010\u0014\u001a\u0004\u0018\u00010\u0015H\u0002¢\u0006\u0002\u0010\u001fJ\u0012\u0010 \u001a\u00020\u00152\b\u0010\u0014\u001a\u0004\u0018\u00010\u0015H\u0002J\u0010\u0010!\u001a\u00020\u00152\u0006\u0010\"\u001a\u00020\nH\u0002J1\u0010#\u001a\u00020\u00192\b\u0010$\u001a\u0004\u0018\u00010\u00132\b\u0010\u0014\u001a\u0004\u0018\u00010\u00152\b\u0010\u0010\u001a\u0004\u0018\u00010\u000f2\u0006\u0010\u0016\u001a\u00020\u0017¢\u0006\u0002\u0010%J\u001c\u0010&\u001a\u00020\u00192\b\u0010\u0002\u001a\u0004\u0018\u00010\u00032\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\u0002J\u0018\u0010'\u001a\u00020\u000f2\u0006\u0010(\u001a\u00020\u00152\u0006\u0010)\u001a\u00020\nH\u0002J\b\u0010*\u001a\u00020\u000fH\u0003J\b\u0010+\u001a\u00020\u0019H\u0003J\u0010\u0010,\u001a\u00020\u00152\u0006\u0010-\u001a\u00020\u0015H\u0002JI\u0010.\u001a\u00020\u00192\u0006\u0010/\u001a\u00020\u000f2\u0006\u00100\u001a\u00020\u000f2\u0006\u00101\u001a\u00020\u00152\u0006\u00102\u001a\u00020\n2\b\u0010\u001d\u001a\u0004\u0018\u00010\u000f2\u0006\u00103\u001a\u00020\n2\b\u00104\u001a\u0004\u0018\u00010\u000fH\u0002¢\u0006\u0002\u00105J\u0010\u00106\u001a\u00020\u00192\u0006\u00107\u001a\u00020\nH\u0002R\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u0010\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u0011R\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u0017X\u0082\u000e¢\u0006\u0002\n\u0000¨\u00069"}, d2 = {"Lcom/gateio/biz/base/weight/UserRateComponent;", "Landroid/widget/RelativeLayout;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "attrs", "Landroid/util/AttributeSet;", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "attributeSet", "defStyleAttr", "", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "binding", "Lcom/gateio/biz/base/databinding/UserRateComponentBinding;", "isRegionMatched", "", "isValid", "Ljava/lang/Boolean;", "mActivity", "Landroidx/appcompat/app/AppCompatActivity;", "source", "", "userRateEventListener", "Lcom/gateio/biz/base/weight/UserRateComponent$UserRateEventListener;", "dataFinderPostEvent", "", "event", "buttonName", "getOpenStoreAbTest", "supportOpenStore", "Lcom/gateio/biz/base/model/RateComponentAb$SupportOpenStore;", "(Lcom/gateio/biz/base/model/RateComponentAb$SupportOpenStore;Ljava/lang/String;)Ljava/lang/Boolean;", "getRateTitle", "getStarDescription", "starRating", "initUserRateComponent", "activity", "(Landroidx/appcompat/app/AppCompatActivity;Ljava/lang/String;Ljava/lang/Boolean;Lcom/gateio/biz/base/weight/UserRateComponent$UserRateEventListener;)V", "initView", "isOutOfDaysRange", "timestamp", "daysRange", "openGooglePlay", "rateReward", "removeGateHost", "url", "selectRate", "isEnable", "isGoogle", "openStoreTime", "cycleOpenStore", "selectedNumber", "haveReward", "(ZZLjava/lang/String;ILjava/lang/Boolean;ILjava/lang/Boolean;)V", "showThankReview", "star", "UserRateEventListener", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nUserRateComponent.kt\nKotlin\n*S Kotlin\n*F\n+ 1 UserRateComponent.kt\ncom/gateio/biz/base/weight/UserRateComponent\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,441:1\n1#2:442\n1360#3:443\n1446#3,5:444\n*S KotlinDebug\n*F\n+ 1 UserRateComponent.kt\ncom/gateio/biz/base/weight/UserRateComponent\n*L\n363#1:443\n363#1:444,5\n*E\n"})
/* loaded from: classes5.dex */
public final class UserRateComponent extends RelativeLayout {

    @Nullable
    private UserRateComponentBinding binding;
    private boolean isRegionMatched;

    @Nullable
    private Boolean isValid;

    @Nullable
    private AppCompatActivity mActivity;

    @Nullable
    private String source;

    @Nullable
    private UserRateEventListener userRateEventListener;

    /* compiled from: UserRateComponent.kt */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\b\u0010\u0006\u001a\u00020\u0003H&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0007À\u0006\u0001"}, d2 = {"Lcom/gateio/biz/base/weight/UserRateComponent$UserRateEventListener;", "", "onJumpClaimNow", "", "rewardUrl", "", "onSubmitFeedBack", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public interface UserRateEventListener {
        void onJumpClaimNow(@NotNull String rewardUrl);

        void onSubmitFeedBack();
    }

    public UserRateComponent(@Nullable Context context) {
        super(context);
        this.source = "";
        this.isValid = Boolean.FALSE;
        initView(context, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String getStarDescription(int starRating) {
        return starRating != 1 ? starRating != 2 ? starRating != 3 ? starRating != 4 ? starRating != 5 ? "" : "five_star" : "four_star" : "three_star" : "two_star" : "one_star";
    }

    @SuppressLint({"QueryPermissionsNeeded"})
    private final boolean openGooglePlay() {
        PackageManager packageManager;
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            StringBuilder sb = new StringBuilder();
            sb.append("https://play.google.com/store/apps/details?id=");
            AppCompatActivity appCompatActivity = this.mActivity;
            ComponentName componentNameResolveActivity = null;
            sb.append(appCompatActivity != null ? appCompatActivity.getPackageName() : null);
            intent.setData(Uri.parse(sb.toString()));
            intent.setPackage("com.android.vending");
            AppCompatActivity appCompatActivity2 = this.mActivity;
            if (appCompatActivity2 != null && (packageManager = appCompatActivity2.getPackageManager()) != null) {
                componentNameResolveActivity = intent.resolveActivity(packageManager);
            }
            if (componentNameResolveActivity == null) {
                return false;
            }
            AppCompatActivity appCompatActivity3 = this.mActivity;
            if (appCompatActivity3 != null) {
                appCompatActivity3.startActivity(intent);
            }
            return true;
        } catch (Exception e10) {
            e10.printStackTrace();
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void selectRate(boolean isEnable, boolean isGoogle, String openStoreTime, int cycleOpenStore, Boolean supportOpenStore, int selectedNumber, Boolean haveReward) {
        this.binding.icRewardClose.setVisibility(0);
        GTStorage.saveKV$default("latest_rate_time", String.valueOf(System.currentTimeMillis()), null, 4, null);
        Boolean bool = this.isValid;
        Boolean bool2 = Boolean.TRUE;
        if (!Intrinsics.areEqual(bool, bool2)) {
            if (selectedNumber != 5 || !isOutOfDaysRange(openStoreTime, cycleOpenStore) || !this.isRegionMatched) {
                this.binding.rlRateShow.setVisibility(8);
                GTToastV3.showToast(getContext(), MessageInfo.Level.INFO, getResources().getString(R.string.about_us_thank_feedback));
                return;
            } else if (!openGooglePlay()) {
                this.binding.rlRateShow.setVisibility(8);
                GTToastV3.showToast(getContext(), MessageInfo.Level.INFO, getResources().getString(R.string.about_us_thank_feedback));
                return;
            } else {
                GTStorage.saveKV$default("latest_open_store_time", String.valueOf(System.currentTimeMillis()), null, 4, null);
                this.binding.rlRateShow.setVisibility(8);
                dataFinderPostEvent(UserRateDataFinderEvent.Event.CLICK_ON_THE_RATING_SCORE, "five_star_switch");
                return;
            }
        }
        if (!isEnable || !isGoogle || selectedNumber != 5) {
            showThankReview(selectedNumber);
            return;
        }
        if (!Intrinsics.areEqual(supportOpenStore, bool2) || !isOutOfDaysRange(openStoreTime, cycleOpenStore)) {
            showThankReview(selectedNumber);
            return;
        }
        if (!openGooglePlay()) {
            showThankReview(selectedNumber);
            return;
        }
        GTStorage.saveKV$default("latest_open_store_time", String.valueOf(System.currentTimeMillis()), null, 4, null);
        if (Intrinsics.areEqual(haveReward, bool2)) {
            this.binding.tvRateTitle.setText(getResources().getString(R.string.about_us_have_reward_to_claim));
            this.binding.ratingRate.setVisibility(8);
            this.binding.btClaimNow.setVisibility(0);
            this.binding.btSubmitFeedback.setVisibility(8);
        } else {
            this.binding.rlRateShow.setVisibility(8);
        }
        dataFinderPostEvent(UserRateDataFinderEvent.Event.CLICK_ON_THE_RATING_SCORE, "five_star_switch");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void dataFinderPostEvent(String event, String buttonName) {
        GTDataFinder.postEvent(new UserRateDataFinderEvent(event, MapsKt__MapsKt.mapOf(TuplesKt.to("button_name", buttonName), TuplesKt.to("source", this.source))));
    }

    private final Boolean getOpenStoreAbTest(RateComponentAb.SupportOpenStore supportOpenStore, String source) {
        if (StringUtils.equals(source, "withdrawal")) {
            if (supportOpenStore != null) {
                return Boolean.valueOf(supportOpenStore.isWithdrew_success());
            }
            return null;
        }
        if (StringUtils.equals(source, "startup")) {
            if (supportOpenStore != null) {
                return Boolean.valueOf(supportOpenStore.isStartup_success());
            }
            return null;
        }
        if (StringUtils.equals(source, UserRateDataFinderEvent.LEND_EARN)) {
            if (supportOpenStore != null) {
                return Boolean.valueOf(supportOpenStore.isSimple_earn_redeem_success());
            }
            return null;
        }
        if (StringUtils.equals(source, UserRateDataFinderEvent.GT_STAKING)) {
            if (supportOpenStore != null) {
                return Boolean.valueOf(supportOpenStore.isGtstaking_success());
            }
            return null;
        }
        if (StringUtils.equals(source, UserRateDataFinderEvent.SOL_STAKING)) {
            if (supportOpenStore != null) {
                return Boolean.valueOf(supportOpenStore.isSolstaking_success());
            }
            return null;
        }
        if (StringUtils.equals(source, UserRateDataFinderEvent.TRX_STAKING)) {
            if (supportOpenStore != null) {
                return Boolean.valueOf(supportOpenStore.isTrxstaking_success());
            }
            return null;
        }
        if (StringUtils.equals(source, UserRateDataFinderEvent.ETH2_STAKING)) {
            if (supportOpenStore != null) {
                return Boolean.valueOf(supportOpenStore.isEth2staking_success());
            }
            return null;
        }
        if (StringUtils.equals(source, UserRateDataFinderEvent.BEARISH_SHARKFIN)) {
            if (supportOpenStore != null) {
                return Boolean.valueOf(supportOpenStore.isBearish_shark_success());
            }
            return null;
        }
        if (StringUtils.equals(source, UserRateDataFinderEvent.BULLISH_SHARKFIN)) {
            if (supportOpenStore != null) {
                return Boolean.valueOf(supportOpenStore.isBullish_shark_success());
            }
            return null;
        }
        if (StringUtils.equals(source, UserRateDataFinderEvent.DUAL_STAKING)) {
            if (supportOpenStore != null) {
                return Boolean.valueOf(supportOpenStore.isDual_investment_success());
            }
            return null;
        }
        if (supportOpenStore != null) {
            return Boolean.valueOf(supportOpenStore.isAbout_us());
        }
        return null;
    }

    private final String getRateTitle(String source) {
        return StringUtils.equals(source, "withdrawal") ? getResources().getString(R.string.withdrawal_your_experience) : StringUtils.equals(source, "startup") ? getResources().getString(R.string.startup_your_experience) : StringUtils.equals(source, UserRateDataFinderEvent.LEND_EARN) ? getResources().getString(R.string.simple_earn_your_experience) : StringUtils.equals(source, UserRateDataFinderEvent.ETH2_STAKING) ? getResources().getString(R.string.staking_your_experience) : StringUtils.equals(source, UserRateDataFinderEvent.GT_STAKING) ? getResources().getString(R.string.staking_your_experience) : StringUtils.equals(source, UserRateDataFinderEvent.SOL_STAKING) ? getResources().getString(R.string.staking_your_experience) : StringUtils.equals(source, UserRateDataFinderEvent.TRX_STAKING) ? getResources().getString(R.string.staking_your_experience) : StringUtils.equals(source, UserRateDataFinderEvent.DUAL_STAKING) ? getResources().getString(R.string.dual_investment_your_experience) : StringUtils.equals(source, UserRateDataFinderEvent.BEARISH_SHARKFIN) ? getResources().getString(R.string.bearish_shark_fin_experience) : StringUtils.equals(source, UserRateDataFinderEvent.BULLISH_SHARKFIN) ? getResources().getString(R.string.bullish_shark_fin_experience) : getResources().getString(R.string.about_us_your_experience);
    }

    /* JADX WARN: Removed duplicated region for block: B:61:0x0138  */
    @android.annotation.SuppressLint({"CheckResult"})
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final void rateReward() {
        /*
            Method dump skipped, instructions count: 475
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.gateio.biz.base.weight.UserRateComponent.rateReward():void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String removeGateHost(String url) {
        List<String> gateHostList = GateBrandDomainUtil.INSTANCE.getGateHostList();
        if (gateHostList == null) {
            gateHostList = CollectionsKt__CollectionsKt.emptyList();
        }
        ArrayList<String> arrayList = new ArrayList();
        Iterator<T> it = gateHostList.iterator();
        while (it.hasNext()) {
            String strRemovePrefix = StringsKt__StringsKt.removePrefix(StringsKt__StringsKt.removePrefix((String) it.next(), (CharSequence) UriConfig.HTTPS), (CharSequence) "http://");
            CollectionsKt__MutableCollectionsKt.addAll(arrayList, CollectionsKt__CollectionsKt.listOf((Object[]) new String[]{UriConfig.HTTPS + strRemovePrefix, "http://" + strRemovePrefix}));
        }
        for (String str : arrayList) {
            if (StringsKt__StringsJVMKt.startsWith$default(url, str, false, 2, null)) {
                return StringsKt__StringsJVMKt.replaceFirst$default(url, str, "", false, 4, (Object) null);
            }
        }
        return url;
    }

    private final void showThankReview(int star) {
        this.binding.tvRateTitle.setText(getResources().getString(R.string.about_us_thank_review));
        if (star == 5) {
            this.binding.ratingRate.setEnabled(false);
        } else {
            this.binding.ratingRate.setVisibility(8);
            this.binding.btSubmitFeedback.setVisibility(0);
        }
    }

    public final void initUserRateComponent(@Nullable AppCompatActivity activity, @Nullable String source, @Nullable Boolean isValid, @NotNull UserRateEventListener userRateEventListener) {
        this.mActivity = activity;
        this.source = source;
        this.isValid = isValid;
        this.userRateEventListener = userRateEventListener;
        rateReward();
    }

    private final void initView(Context context, AttributeSet attrs) {
        this.binding = UserRateComponentBinding.inflate(LayoutInflater.from(context), this);
    }

    private final boolean isOutOfDaysRange(String timestamp, int daysRange) {
        boolean z10;
        Long longOrNull;
        if (timestamp.length() == 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (z10 || (longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(timestamp)) == null) {
            return true;
        }
        long jLongValue = longOrNull.longValue();
        Calendar calendar = Calendar.getInstance();
        Calendar.getInstance().setTimeInMillis(jLongValue);
        if ((calendar.getTimeInMillis() - r0.getTimeInMillis()) / 86400000 <= daysRange) {
            return false;
        }
        return true;
    }

    public UserRateComponent(@Nullable Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        this.source = "";
        this.isValid = Boolean.FALSE;
        initView(context, attributeSet);
    }

    public UserRateComponent(@Nullable Context context, @Nullable AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.source = "";
        this.isValid = Boolean.FALSE;
        initView(context, attributeSet);
    }
}