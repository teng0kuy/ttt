package com.gateio.biz.base.weight;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.PopupWindow;
import com.gateio.biz.base.databinding.MarketSelectFavPopBinding;
import com.gateio.common.tool.DeviceUtil;
import com.gateio.common.view.CustomPopWindow;
import com.gateio.gateio.datafinder.DataFinderConstant;
import com.gateio.lib.utils.ext.ViewExtensionsKt;
import com.zoloz.webcontainer.plugin.impl.H5PopupPlugin;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: MarketSelectFavWindow.kt */
@Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0006\u0010\t\u001a\u00020\nJ0\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\r2\f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\n0\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u00010\u0013J8\u0010\u000b\u001a\u00020\u00142\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u0015\u001a\u00020\r2\f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\n0\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\n\b\u0002\u0010\u0012\u001a\u0004\u0018\u00010\u0013R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082.¢\u0006\u0002\n\u0000¨\u0006\u0016"}, d2 = {"Lcom/gateio/biz/base/weight/MarketSelectFavWindow;", "", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "binding", "Lcom/gateio/biz/base/databinding/MarketSelectFavPopBinding;", H5PopupPlugin.POP_WINDOW, "Lcom/gateio/common/view/CustomPopWindow;", "dismiss", "", "show", DataFinderConstant.DataFinderParamsValue.key_value_anchor, "Landroid/view/View;", "onClick", "Lkotlin/Function0;", "favText", "", "onDismissListener", "Landroid/widget/PopupWindow$OnDismissListener;", "", "rootView", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes5.dex */
public final class MarketSelectFavWindow {

    @NotNull
    private MarketSelectFavPopBinding binding;

    @NotNull
    private final Context context;
    private CustomPopWindow popWindow;

    public static /* synthetic */ void show$default(MarketSelectFavWindow marketSelectFavWindow, View view, Function0 function0, String str, PopupWindow.OnDismissListener onDismissListener, int i10, Object obj) {
        if ((i10 & 8) != 0) {
            onDismissListener = null;
        }
        marketSelectFavWindow.show(view, function0, str, onDismissListener);
    }

    public final void show(@NotNull View anchor, @NotNull final Function0<Unit> onClick, @NotNull String favText, @Nullable PopupWindow.OnDismissListener onDismissListener) {
        this.popWindow = new CustomPopWindow.PopupWindowBuilder(this.context).setOnDissmissListener(onDismissListener).setView(this.binding.getRoot()).create();
        int[] iArr = new int[2];
        anchor.getLocationOnScreen(iArr);
        this.binding.tvFav.setText(favText);
        ViewExtensionsKt.clickJitter$default(this.binding.getRoot(), 0L, new Function1<View, Unit>() { // from class: com.gateio.biz.base.weight.MarketSelectFavWindow.show.1
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(View view) {
                invoke2(view);
                return Unit.INSTANCE;
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(1);
            }

            /* renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull View view) {
                onClick.invoke();
                CustomPopWindow customPopWindow = this.popWindow;
                if (customPopWindow == null) {
                    customPopWindow = null;
                }
                customPopWindow.dissmiss();
            }
        }, 1, null);
        this.binding.getRoot().measure(0, 0);
        int measuredWidth = this.binding.getRoot().getMeasuredWidth();
        int measuredHeight = this.binding.getRoot().getMeasuredHeight();
        CustomPopWindow customPopWindow = this.popWindow;
        if (customPopWindow == null) {
            customPopWindow = null;
        }
        customPopWindow.showAtLocation(anchor, 0, (iArr[0] + (anchor.getWidth() / 2)) - (measuredWidth / 2), iArr[1] - measuredHeight);
    }

    public static /* synthetic */ boolean show$default(MarketSelectFavWindow marketSelectFavWindow, View view, View view2, Function0 function0, String str, PopupWindow.OnDismissListener onDismissListener, int i10, Object obj) {
        if ((i10 & 16) != 0) {
            onDismissListener = null;
        }
        return marketSelectFavWindow.show(view, view2, function0, str, onDismissListener);
    }

    public final void dismiss() {
        CustomPopWindow customPopWindow = this.popWindow;
        if (customPopWindow != null) {
            if (customPopWindow == null) {
                customPopWindow = null;
            }
            customPopWindow.dissmiss();
        }
    }

    public MarketSelectFavWindow(@NotNull Context context) {
        this.context = context;
        this.binding = MarketSelectFavPopBinding.inflate(LayoutInflater.from(context));
    }

    public final boolean show(@NotNull View anchor, @NotNull View rootView, @NotNull final Function0<Unit> onClick, @NotNull String favText, @Nullable PopupWindow.OnDismissListener onDismissListener) {
        int[] iArr = new int[2];
        anchor.getLocationOnScreen(iArr);
        int i10 = iArr[1];
        if (i10 <= 0) {
            return false;
        }
        this.popWindow = new CustomPopWindow.PopupWindowBuilder(this.context).setOnDissmissListener(onDismissListener).setView(this.binding.getRoot()).create();
        this.binding.tvFav.setText(favText);
        ViewExtensionsKt.clickJitter$default(this.binding.getRoot(), 0L, new Function1<View, Unit>() { // from class: com.gateio.biz.base.weight.MarketSelectFavWindow.show.2
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(View view) {
                invoke2(view);
                return Unit.INSTANCE;
            }

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(1);
            }

            /* renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull View view) {
                onClick.invoke();
                CustomPopWindow customPopWindow = this.popWindow;
                if (customPopWindow == null) {
                    customPopWindow = null;
                }
                customPopWindow.dissmiss();
            }
        }, 1, null);
        this.binding.getRoot().measure(0, 0);
        int screenWidth = (DeviceUtil.getScreenWidth(this.context) - this.binding.getRoot().getMeasuredWidth()) / 2;
        int measuredHeight = ((i10 - this.binding.getRoot().getMeasuredHeight()) + DeviceUtil.dp2px(anchor.getContext(), 8.0f)) - (anchor.getHeight() / 2);
        CustomPopWindow customPopWindow = this.popWindow;
        if (customPopWindow == null) {
            customPopWindow = null;
        }
        customPopWindow.showAtLocation(rootView, 0, screenWidth, measuredHeight);
        return true;
    }
}