package com.gateio.biz.base.weight;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import androidx.media3.exoplayer.upstream.CmcdData;
import com.gateio.common.kotlin.util.Res;
import com.gateio.common.tool.DeviceUtil;
import com.gateio.lib.core.GTActivityLifecycle;
import kotlin.Metadata;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: MaskView.kt */
@Metadata(d1 = {"\u0000d\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0014\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0012\u0018\u00002\u00020\u0001B%\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\u0018\u0010&\u001a\u00020'2\u0006\u0010(\u001a\u00020\r2\u0006\u0010)\u001a\u00020*H\u0002J\b\u0010+\u001a\u00020'H\u0002J\u0010\u0010,\u001a\u00020'2\u0006\u0010-\u001a\u00020.H\u0014J\u0018\u0010/\u001a\u00020'2\u0006\u00100\u001a\u00020\u00072\u0006\u00101\u001a\u00020\u0007H\u0014J(\u00102\u001a\u00020'2\u0006\u00103\u001a\u00020\u00072\u0006\u00104\u001a\u00020\u00072\u0006\u00105\u001a\u00020\u00072\u0006\u00106\u001a\u00020\u0007H\u0014J\u0018\u00107\u001a\u00020'2\u0006\u00103\u001a\u00020\u00072\u0006\u00104\u001a\u00020\u0007H\u0002JB\u00108\u001a\u00020'2\u0006\u00109\u001a\u00020\u00132\u0006\u0010:\u001a\u00020\u00132\u0006\u0010;\u001a\u00020\u00132\u0006\u0010<\u001a\u00020\u00132\u0006\u0010=\u001a\u00020\u00172\b\b\u0002\u0010>\u001a\u00020\u00072\b\b\u0002\u0010?\u001a\u00020\u0007R\u000e\u0010\t\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010\u001e\u001a\u0004\u0018\u00010\u001fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b \u0010!\"\u0004\b\"\u0010#R\u000e\u0010$\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006@"}, d2 = {"Lcom/gateio/biz/base/weight/MaskView;", "Landroid/view/View;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "defStyleAttr", "", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "bgPaint", "Landroid/graphics/Paint;", "borderPaint", "borderPath", "Landroid/graphics/Path;", "defaultPaint", "fgPaint", "fgPath", "mHeight", "mRadiusW", "", "mScreenHeight", "mScreenWidth", "mShaper", "Lcom/gateio/biz/base/weight/Shaper;", "mStrokeWidth", "mTouchX", "mTouchY", "mWidth", "radii", "", "rectF", "Landroid/graphics/RectF;", "getRectF", "()Landroid/graphics/RectF;", "setRectF", "(Landroid/graphics/RectF;)V", "viewHeight", "viewWith", "getPath", "", "path", "isWinding", "", "initPaint", "onDraw", "canvas", "Landroid/graphics/Canvas;", "onMeasure", "widthMeasureSpec", "heightMeasureSpec", "onSizeChanged", "w", CmcdData.Factory.STREAMING_FORMAT_HLS, "oldw", "oldh", "resetViewSize", "setUpdate", "x", "y", "radiusW", "strokeWidth", "shaper", "width", "height", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nMaskView.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MaskView.kt\ncom/gateio/biz/base/weight/MaskView\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,249:1\n1#2:250\n*E\n"})
/* loaded from: classes5.dex */
public final class MaskView extends View {
    private Paint bgPaint;
    private Paint borderPaint;

    @NotNull
    private Path borderPath;
    private Paint defaultPaint;
    private Paint fgPaint;

    @NotNull
    private Path fgPath;
    private int mHeight;
    private float mRadiusW;
    private int mScreenHeight;
    private int mScreenWidth;

    @NotNull
    private Shaper mShaper;
    private float mStrokeWidth;
    private float mTouchX;
    private float mTouchY;
    private int mWidth;

    @NotNull
    private float[] radii;

    @Nullable
    private RectF rectF;
    private int viewHeight;
    private int viewWith;

    @JvmOverloads
    public MaskView(@NotNull Context context) {
        this(context, null, 0, 6, null);
    }

    /* compiled from: MaskView.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[Shaper.values().length];
            try {
                iArr[Shaper.CIRCLE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[Shaper.ROUND_RECTANGLE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[Shaper.RECTANGLE.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    @JvmOverloads
    public MaskView(@NotNull Context context, @Nullable AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
    }

    private final void initPaint() {
        this.defaultPaint = new Paint(1);
        Paint paint = this.defaultPaint;
        if (paint == null) {
            paint = null;
        }
        Paint paint2 = new Paint(paint);
        paint2.setColor(Color.argb(190, 0, 0, 0));
        paint2.setAntiAlias(true);
        this.bgPaint = paint2;
        Paint paint3 = this.defaultPaint;
        if (paint3 == null) {
            paint3 = null;
        }
        Paint paint4 = new Paint(paint3);
        paint4.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_OUT));
        paint4.setColor(Color.argb(1, 0, 0, 0));
        paint4.setAntiAlias(true);
        this.fgPaint = paint4;
        Paint paint5 = this.defaultPaint;
        Paint paint6 = new Paint(paint5 != null ? paint5 : null);
        paint6.setColor(Color.argb(25, 255, 255, 255));
        paint6.setStyle(Paint.Style.STROKE);
        paint6.setStrokeWidth(30.0f);
        paint6.setAntiAlias(true);
        this.borderPaint = paint6;
    }

    private final void resetViewSize(int w10, int h10) {
        setMeasuredDimension(this.viewWith, this.viewHeight);
        this.viewWith = w10;
        this.viewHeight = h10;
        invalidate();
    }

    @Nullable
    public final RectF getRectF() {
        return this.rectF;
    }

    public final void setRectF(@Nullable RectF rectF) {
        this.rectF = rectF;
    }

    public final void setUpdate(float x10, float y10, float radiusW, float strokeWidth, @NotNull Shaper shaper, int width, int height) {
        if (this.mTouchX == x10) {
            if (this.mTouchY == y10) {
                if (this.mRadiusW == radiusW) {
                    if (this.mStrokeWidth == strokeWidth) {
                        return;
                    }
                }
            }
        }
        this.mTouchX = x10;
        this.mTouchY = y10;
        this.mRadiusW = radiusW;
        this.mStrokeWidth = strokeWidth;
        this.mShaper = shaper;
        this.mWidth = width;
        this.mHeight = height;
        float f10 = 2;
        this.rectF = new RectF(0.0f, 0.0f, this.mTouchX * f10, this.mTouchY * f10);
        invalidate();
    }

    public /* synthetic */ MaskView(Context context, AttributeSet attributeSet, int i10, int i11, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, (i11 & 2) != 0 ? null : attributeSet, (i11 & 4) != 0 ? 0 : i10);
    }

    private final void getPath(Path path, boolean isWinding) {
        path.reset();
        int i10 = WhenMappings.$EnumSwitchMapping$0[this.mShaper.ordinal()];
        if (i10 != 1) {
            if (i10 == 2) {
                float fDp = this.mTouchY + (this.mHeight / 2);
                int contentViewHeight = DeviceUtil.getContentViewHeight(GTActivityLifecycle.getTopActivity());
                Res res = Res.INSTANCE;
                if (fDp > contentViewHeight - res.dp(60)) {
                    fDp = contentViewHeight - res.dp(60);
                    this.radii = new float[]{res.dp(8), res.dp(8), res.dp(8), res.dp(8), 0.0f, 0.0f, 0.0f, 0.0f};
                }
                path.addRoundRect(new RectF(res.dp(12), this.mTouchY - (this.mHeight / 2), res.dp(12) + this.mWidth, fDp), this.radii, Path.Direction.CW);
            }
        } else {
            path.addCircle(this.mTouchX, this.mTouchY, this.mRadiusW, Path.Direction.CW);
        }
        if (isWinding) {
            path.setFillType(Path.FillType.WINDING);
        }
    }

    @Override // android.view.View
    protected void onDraw(@NotNull Canvas canvas) {
        Paint paint;
        Paint paint2;
        Paint paint3;
        RectF rectF;
        super.onDraw(canvas);
        getPath(this.fgPath, true);
        this.borderPath.reset();
        int i10 = WhenMappings.$EnumSwitchMapping$0[this.mShaper.ordinal()];
        if (i10 != 1) {
            if (i10 == 2 && (rectF = this.rectF) != null) {
                this.borderPath.addRoundRect(rectF, this.radii, Path.Direction.CW);
            }
        } else {
            this.borderPath.addCircle(this.mTouchX, this.mTouchY, this.mRadiusW + (this.mStrokeWidth / 2), Path.Direction.CW);
        }
        Paint paint4 = this.borderPaint;
        Paint paint5 = null;
        if (paint4 == null) {
            paint4 = null;
        }
        paint4.setStrokeWidth(this.mStrokeWidth);
        float f10 = this.mScreenWidth;
        float f11 = this.mScreenHeight;
        Paint paint6 = this.defaultPaint;
        if (paint6 == null) {
            paint = null;
        } else {
            paint = paint6;
        }
        canvas.saveLayer(0.0f, 0.0f, f10, f11, paint);
        float f12 = this.mScreenWidth;
        float f13 = this.mScreenHeight;
        Paint paint7 = this.bgPaint;
        if (paint7 == null) {
            paint2 = null;
        } else {
            paint2 = paint7;
        }
        canvas.drawRect(0.0f, 0.0f, f12, f13, paint2);
        Path path = this.fgPath;
        Paint paint8 = this.fgPaint;
        if (paint8 == null) {
            paint8 = null;
        }
        canvas.drawPath(path, paint8);
        float f14 = this.mScreenWidth;
        float f15 = this.mScreenHeight;
        Paint paint9 = this.defaultPaint;
        if (paint9 == null) {
            paint3 = null;
        } else {
            paint3 = paint9;
        }
        canvas.saveLayer(0.0f, 0.0f, f14, f15, paint3);
        if (this.mShaper == Shaper.CIRCLE) {
            Path path2 = this.borderPath;
            Paint paint10 = this.borderPaint;
            if (paint10 != null) {
                paint5 = paint10;
            }
            canvas.drawPath(path2, paint5);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        resetViewSize(View.MeasureSpec.getSize(widthMeasureSpec), View.MeasureSpec.getSize(heightMeasureSpec));
    }

    @Override // android.view.View
    protected void onSizeChanged(int w10, int h10, int oldw, int oldh) {
        super.onSizeChanged(w10, h10, oldw, oldh);
        resetViewSize(w10, h10);
    }

    @JvmOverloads
    public MaskView(@NotNull Context context, @Nullable AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.mShaper = Shaper.CIRCLE;
        this.fgPath = new Path();
        this.borderPath = new Path();
        Res res = Res.INSTANCE;
        this.mScreenWidth = res.getScreenWidth();
        this.mScreenHeight = res.getScreenHeight();
        initPaint();
        this.radii = new float[]{res.dp(8), res.dp(8), res.dp(8), res.dp(8), res.dp(8), res.dp(8), res.dp(8), res.dp(8)};
    }
}