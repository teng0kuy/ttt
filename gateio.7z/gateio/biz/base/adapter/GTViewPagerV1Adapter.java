package com.gateio.biz.base.adapter;

import android.os.Parcelable;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.media3.extractor.text.ttml.TtmlNode;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GTViewPagerV1Adapter.kt */
@Metadata(d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0010\r\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b&\u0018\u00002\u00020\u0001B-\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0010\b\u0002\u0010\u0007\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u0005¢\u0006\u0002\u0010\bJ\u0010\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u0006H&J \u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015H\u0016J\b\u0010\u0016\u001a\u00020\u0013H\u0016J\u0010\u0010\u0017\u001a\u00020\u000b2\u0006\u0010\u0012\u001a\u00020\u0013H\u0016J\u0010\u0010\u0018\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015H\u0016J\u0010\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u0012\u001a\u00020\u0013H\u0016J\u000e\u0010\u001b\u001a\u00020\u00132\u0006\u0010\r\u001a\u00020\u0006J\n\u0010\u001c\u001a\u0004\u0018\u00010\u001dH\u0016R\u001a\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0007\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001e"}, d2 = {"Lcom/gateio/biz/base/adapter/GTViewPagerV1Adapter;", "Landroidx/fragment/app/FragmentStatePagerAdapter;", "fragmentManager", "Landroidx/fragment/app/FragmentManager;", "tabFragmentTags", "", "", "listTitles", "(Landroidx/fragment/app/FragmentManager;Ljava/util/List;Ljava/util/List;)V", "fragmentMap", "", "Landroidx/fragment/app/Fragment;", "createFragment", "tag", "destroyItem", "", TtmlNode.RUBY_CONTAINER, "Landroid/view/ViewGroup;", "position", "", "obj", "", "getCount", "getItem", "getItemPosition", "getPageTitle", "", "getPositionByTag", "saveState", "Landroid/os/Parcelable;", "biz_base_core_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nGTViewPagerV1Adapter.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GTViewPagerV1Adapter.kt\ncom/gateio/biz/base/adapter/GTViewPagerV1Adapter\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,61:1\n1#2:62\n*E\n"})
/* loaded from: classes4.dex */
public abstract class GTViewPagerV1Adapter extends FragmentStatePagerAdapter {

    @NotNull
    private final Map<String, Fragment> fragmentMap;

    @Nullable
    private final List<String> listTitles;

    @NotNull
    private final List<String> tabFragmentTags;

    public /* synthetic */ GTViewPagerV1Adapter(FragmentManager fragmentManager, List list, List list2, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this(fragmentManager, list, (i10 & 4) != 0 ? null : list2);
    }

    @NotNull
    public abstract Fragment createFragment(@NotNull String tag);

    @Override // androidx.fragment.app.FragmentStatePagerAdapter, androidx.viewpager.widget.PagerAdapter
    @Nullable
    public Parcelable saveState() {
        return null;
    }

    public GTViewPagerV1Adapter(@NotNull FragmentManager fragmentManager, @NotNull List<String> list, @Nullable List<String> list2) {
        super(fragmentManager, 1);
        this.tabFragmentTags = list;
        this.listTitles = list2;
        this.fragmentMap = new LinkedHashMap();
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    /* renamed from: getCount */
    public int getItemCount() {
        return this.tabFragmentTags.size();
    }

    @Override // androidx.fragment.app.FragmentStatePagerAdapter
    @NotNull
    public Fragment getItem(int position) {
        String str = this.tabFragmentTags.get(position);
        Fragment fragment = this.fragmentMap.get(str);
        if (fragment != null) {
            return fragment;
        }
        Fragment fragmentCreateFragment = createFragment(str);
        this.fragmentMap.put(str, fragmentCreateFragment);
        return fragmentCreateFragment;
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public int getItemPosition(@NotNull Object obj) {
        Object next;
        if (!(obj instanceof Fragment)) {
            return -2;
        }
        Iterator<T> it = this.fragmentMap.entrySet().iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            if (Intrinsics.areEqual(((Map.Entry) next).getValue(), obj)) {
                break;
            }
        }
        Map.Entry entry = (Map.Entry) next;
        String str = entry != null ? (String) entry.getKey() : null;
        if (str == null || !this.tabFragmentTags.contains(str)) {
            return -2;
        }
        return this.tabFragmentTags.indexOf(str);
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    @NotNull
    public CharSequence getPageTitle(int position) {
        List<String> list = this.listTitles;
        String str = list != null ? list.get(position) : null;
        return str == null ? "" : str;
    }

    public final int getPositionByTag(@NotNull String tag) {
        return this.tabFragmentTags.indexOf(tag);
    }

    @Override // androidx.fragment.app.FragmentStatePagerAdapter, androidx.viewpager.widget.PagerAdapter
    public void destroyItem(@NotNull ViewGroup container, int position, @NotNull Object obj) {
        super.destroyItem(container, position, obj);
        this.fragmentMap.remove(this.tabFragmentTags.get(position));
    }
}