package com.gateio.biz.add.funds.service.component;

import com.zoloz.webcontainer.env.H5Container;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GTAddFundsItem.kt */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\b\n\u0002\b\u0015\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\b\u0018\u00002\u00020\u0001BY\u0012\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\n¢\u0006\u0002\u0010\u000bJ\u000b\u0010\u0016\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0017\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0018\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0019\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u001a\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u001b\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u0010\u0010\u001c\u001a\u0004\u0018\u00010\nHÆ\u0003¢\u0006\u0002\u0010\u000fJb\u0010\u001d\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\nHÆ\u0001¢\u0006\u0002\u0010\u001eJ\u0013\u0010\u001f\u001a\u00020 2\b\u0010!\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\"\u001a\u00020\nHÖ\u0001J\t\u0010#\u001a\u00020\u0003HÖ\u0001R\u0013\u0010\u0007\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0015\u0010\t\u001a\u0004\u0018\u00010\n¢\u0006\n\n\u0002\u0010\u0010\u001a\u0004\b\u000e\u0010\u000fR\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\rR\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\rR\u0013\u0010\b\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\rR\u0013\u0010\u0005\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\rR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\r¨\u0006$"}, d2 = {"Lcom/gateio/biz/add/funds/service/component/TypeConvert;", "", "customType", "", "title", "subtitle", "iconfont", "currency", "link", "customIndex", "", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;)V", "getCurrency", "()Ljava/lang/String;", "getCustomIndex", "()Ljava/lang/Integer;", "Ljava/lang/Integer;", "getCustomType", "getIconfont", "getLink", "getSubtitle", "getTitle", "component1", "component2", "component3", "component4", "component5", "component6", "component7", H5Container.MENU_COPY, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;)Lcom/gateio/biz/add/funds/service/component/TypeConvert;", "equals", "", "other", "hashCode", "toString", "biz_add_funds_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class TypeConvert {

    @Nullable
    private final String currency;

    @Nullable
    private final Integer customIndex;

    @Nullable
    private final String customType;

    @Nullable
    private final String iconfont;

    @Nullable
    private final String link;

    @Nullable
    private final String subtitle;

    @Nullable
    private final String title;

    public TypeConvert() {
        this(null, null, null, null, null, null, null, 127, null);
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof TypeConvert)) {
            return false;
        }
        TypeConvert typeConvert = (TypeConvert) other;
        return Intrinsics.areEqual(this.customType, typeConvert.customType) && Intrinsics.areEqual(this.title, typeConvert.title) && Intrinsics.areEqual(this.subtitle, typeConvert.subtitle) && Intrinsics.areEqual(this.iconfont, typeConvert.iconfont) && Intrinsics.areEqual(this.currency, typeConvert.currency) && Intrinsics.areEqual(this.link, typeConvert.link) && Intrinsics.areEqual(this.customIndex, typeConvert.customIndex);
    }

    public TypeConvert(@Nullable String str, @Nullable String str2, @Nullable String str3, @Nullable String str4, @Nullable String str5, @Nullable String str6, @Nullable Integer num) {
        this.customType = str;
        this.title = str2;
        this.subtitle = str3;
        this.iconfont = str4;
        this.currency = str5;
        this.link = str6;
        this.customIndex = num;
    }

    public static /* synthetic */ TypeConvert copy$default(TypeConvert typeConvert, String str, String str2, String str3, String str4, String str5, String str6, Integer num, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = typeConvert.customType;
        }
        if ((i10 & 2) != 0) {
            str2 = typeConvert.title;
        }
        String str7 = str2;
        if ((i10 & 4) != 0) {
            str3 = typeConvert.subtitle;
        }
        String str8 = str3;
        if ((i10 & 8) != 0) {
            str4 = typeConvert.iconfont;
        }
        String str9 = str4;
        if ((i10 & 16) != 0) {
            str5 = typeConvert.currency;
        }
        String str10 = str5;
        if ((i10 & 32) != 0) {
            str6 = typeConvert.link;
        }
        String str11 = str6;
        if ((i10 & 64) != 0) {
            num = typeConvert.customIndex;
        }
        return typeConvert.copy(str, str7, str8, str9, str10, str11, num);
    }

    @Nullable
    /* renamed from: component1, reason: from getter */
    public final String getCustomType() {
        return this.customType;
    }

    @Nullable
    /* renamed from: component2, reason: from getter */
    public final String getTitle() {
        return this.title;
    }

    @Nullable
    /* renamed from: component3, reason: from getter */
    public final String getSubtitle() {
        return this.subtitle;
    }

    @Nullable
    /* renamed from: component4, reason: from getter */
    public final String getIconfont() {
        return this.iconfont;
    }

    @Nullable
    /* renamed from: component5, reason: from getter */
    public final String getCurrency() {
        return this.currency;
    }

    @Nullable
    /* renamed from: component6, reason: from getter */
    public final String getLink() {
        return this.link;
    }

    @Nullable
    /* renamed from: component7, reason: from getter */
    public final Integer getCustomIndex() {
        return this.customIndex;
    }

    @NotNull
    public final TypeConvert copy(@Nullable String customType, @Nullable String title, @Nullable String subtitle, @Nullable String iconfont, @Nullable String currency, @Nullable String link, @Nullable Integer customIndex) {
        return new TypeConvert(customType, title, subtitle, iconfont, currency, link, customIndex);
    }

    @Nullable
    public final String getCurrency() {
        return this.currency;
    }

    @Nullable
    public final Integer getCustomIndex() {
        return this.customIndex;
    }

    @Nullable
    public final String getCustomType() {
        return this.customType;
    }

    @Nullable
    public final String getIconfont() {
        return this.iconfont;
    }

    @Nullable
    public final String getLink() {
        return this.link;
    }

    @Nullable
    public final String getSubtitle() {
        return this.subtitle;
    }

    @Nullable
    public final String getTitle() {
        return this.title;
    }

    public int hashCode() {
        String str = this.customType;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.title;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.subtitle;
        int iHashCode3 = (iHashCode2 + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.iconfont;
        int iHashCode4 = (iHashCode3 + (str4 == null ? 0 : str4.hashCode())) * 31;
        String str5 = this.currency;
        int iHashCode5 = (iHashCode4 + (str5 == null ? 0 : str5.hashCode())) * 31;
        String str6 = this.link;
        int iHashCode6 = (iHashCode5 + (str6 == null ? 0 : str6.hashCode())) * 31;
        Integer num = this.customIndex;
        return iHashCode6 + (num != null ? num.hashCode() : 0);
    }

    @NotNull
    public String toString() {
        return "TypeConvert(customType=" + this.customType + ", title=" + this.title + ", subtitle=" + this.subtitle + ", iconfont=" + this.iconfont + ", currency=" + this.currency + ", link=" + this.link + ", customIndex=" + this.customIndex + ')';
    }

    public /* synthetic */ TypeConvert(String str, String str2, String str3, String str4, String str5, String str6, Integer num, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? "" : str, (i10 & 2) != 0 ? "" : str2, (i10 & 4) != 0 ? "" : str3, (i10 & 8) != 0 ? "" : str4, (i10 & 16) != 0 ? "" : str5, (i10 & 32) == 0 ? str6 : "", (i10 & 64) != 0 ? 0 : num);
    }
}