package com.gateio.biz.add.funds.service.component;

import android.content.Context;
import java.util.List;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: AddFunds.kt */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\bf\u0018\u00002\u00020\u0001JF\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00072\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00072\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u00072\u0010\b\u0002\u0010\n\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bH&JF\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\r2\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00072\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00072\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u00072\u0010\b\u0002\u0010\n\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bH&J,\u0010\u000e\u001a\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u00072\b\u0010\u0010\u001a\u0004\u0018\u00010\u00072\u0006\u0010\u0011\u001a\u00020\u00122\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H&¨\u0006\u0013"}, d2 = {"Lcom/gateio/biz/add/funds/service/component/AddFunds;", "", "addFunds", "", "source", "Lcom/gateio/biz/add/funds/service/component/ModuleSource;", "currency", "", "title", "headTips", "customList", "", "Lcom/gateio/biz/add/funds/service/component/GTAddFundsItem;", "Lcom/gateio/biz/add/funds/service/component/Source;", "dealExtScene", "code", "androidLink", "mContext", "Landroid/content/Context;", "biz_add_funds_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public interface AddFunds {

    /* compiled from: AddFunds.kt */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class DefaultImpls {
        public static /* synthetic */ void addFunds$default(AddFunds addFunds, ModuleSource moduleSource, String str, String str2, String str3, List list, int i10, Object obj) {
            if (obj != null) {
                throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: addFunds");
            }
            addFunds.addFunds(moduleSource, (i10 & 2) != 0 ? null : str, (i10 & 4) != 0 ? null : str2, (i10 & 8) != 0 ? null : str3, (List<GTAddFundsItem>) ((i10 & 16) != 0 ? null : list));
        }

        public static /* synthetic */ void addFunds$default(AddFunds addFunds, Source source, String str, String str2, String str3, List list, int i10, Object obj) {
            if (obj != null) {
                throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: addFunds");
            }
            addFunds.addFunds(source, (i10 & 2) != 0 ? null : str, (i10 & 4) != 0 ? null : str2, (i10 & 8) != 0 ? null : str3, (List<GTAddFundsItem>) ((i10 & 16) != 0 ? null : list));
        }
    }

    void addFunds(@NotNull ModuleSource source, @Nullable String currency, @Nullable String title, @Nullable String headTips, @Nullable List<GTAddFundsItem> customList);

    void addFunds(@NotNull Source source, @Nullable String currency, @Nullable String title, @Nullable String headTips, @Nullable List<GTAddFundsItem> customList);

    void dealExtScene(@NotNull String code, @Nullable String androidLink, @NotNull Context mContext, @Nullable String currency);
}