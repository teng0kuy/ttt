package com.gateio.biz.add.funds.service.component;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;

/* compiled from: ModuleSource.kt */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b6\u0018\u00002\u00020\u0001:\u0002\u0007\bB\u000f\b\u0004\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006\u0082\u0001\u0002\t\n¨\u0006\u000b"}, d2 = {"Lcom/gateio/biz/add/funds/service/component/Source;", "", "value", "", "(Ljava/lang/String;)V", "getValue", "()Ljava/lang/String;", "FlutterSource", "H5Source", "Lcom/gateio/biz/add/funds/service/component/Source$FlutterSource;", "Lcom/gateio/biz/add/funds/service/component/Source$H5Source;", "biz_add_funds_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public abstract class Source {

    @NotNull
    private final String value;

    /* compiled from: ModuleSource.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/add/funds/service/component/Source$FlutterSource;", "Lcom/gateio/biz/add/funds/service/component/Source;", "value", "", "(Ljava/lang/String;)V", "getValue", "()Ljava/lang/String;", "biz_add_funds_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class FlutterSource extends Source {

        @NotNull
        private final String value;

        public FlutterSource(@NotNull String str) {
            super(str, null);
            this.value = str;
        }

        @Override // com.gateio.biz.add.funds.service.component.Source
        @NotNull
        public String getValue() {
            return this.value;
        }
    }

    /* compiled from: ModuleSource.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/add/funds/service/component/Source$H5Source;", "Lcom/gateio/biz/add/funds/service/component/Source;", "value", "", "(Ljava/lang/String;)V", "getValue", "()Ljava/lang/String;", "biz_add_funds_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class H5Source extends Source {

        @NotNull
        private final String value;

        public H5Source(@NotNull String str) {
            super(str, null);
            this.value = str;
        }

        @Override // com.gateio.biz.add.funds.service.component.Source
        @NotNull
        public String getValue() {
            return this.value;
        }
    }

    public /* synthetic */ Source(String str, DefaultConstructorMarker defaultConstructorMarker) {
        this(str);
    }

    private Source(String str) {
        this.value = str;
    }

    @NotNull
    public String getValue() {
        return this.value;
    }
}