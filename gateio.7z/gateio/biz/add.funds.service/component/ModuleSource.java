package com.gateio.biz.add.funds.service.component;

import android.os.Parcel;
import android.os.Parcelable;
import com.gateio.biz.market.util.MarketConst;
import com.gateio.gateio.notification.NotificationConfig;
import com.zoloz.webcontainer.env.H5Container;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlinx.parcelize.Parcelize;
import org.jetbrains.annotations.NotNull;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: ModuleSource.kt */
@Parcelize
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u001d\b\u0087\u0081\u0002\u0018\u0000 )2\b\u0012\u0004\u0012\u00020\u00000\u00012\u00020\u0002:\u0001)B\u000f\b\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0005J\t\u0010\b\u001a\u00020\tHÖ\u0001J\u0019\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\tHÖ\u0001R\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007j\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011j\u0002\b\u0012j\u0002\b\u0013j\u0002\b\u0014j\u0002\b\u0015j\u0002\b\u0016j\u0002\b\u0017j\u0002\b\u0018j\u0002\b\u0019j\u0002\b\u001aj\u0002\b\u001bj\u0002\b\u001cj\u0002\b\u001dj\u0002\b\u001ej\u0002\b\u001fj\u0002\b j\u0002\b!j\u0002\b\"j\u0002\b#j\u0002\b$j\u0002\b%j\u0002\b&j\u0002\b'j\u0002\b(¨\u0006*"}, d2 = {"Lcom/gateio/biz/add/funds/service/component/ModuleSource;", "", "Landroid/os/Parcelable;", "value", "", "(Ljava/lang/String;ILjava/lang/String;)V", "getValue", "()Ljava/lang/String;", "describeContents", "", "writeToParcel", "", "parcel", "Landroid/os/Parcel;", "flags", "spot", "futures", MarketConst.searchBotsType, H5Container.MENU_COPY, "convert", "unifiedAccount", "simpleEarn", "dualInvestment", "vipWealthHub", "launchpad", MarketConst.searchLaunchpoolType, "airdrop", "loan", "staking", "quantFund", "dipSniper", "peakSniper", "rewardsHub", NotificationConfig.TYPE_REFERRAL, "assets", "home", "sideDeposit", "vip", "alpha", "uRLDefault", "aggregatedSearch", "Companion", "biz_add_funds_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class ModuleSource implements Parcelable {
    private static final /* synthetic */ EnumEntries $ENTRIES;
    private static final /* synthetic */ ModuleSource[] $VALUES;

    @NotNull
    public static final Parcelable.Creator<ModuleSource> CREATOR;

    /* renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE;

    @NotNull
    private final String value;
    public static final ModuleSource spot = new ModuleSource("spot", 0, "spot");
    public static final ModuleSource futures = new ModuleSource("futures", 1, "futures");
    public static final ModuleSource bots = new ModuleSource(MarketConst.searchBotsType, 2, MarketConst.searchBotsType);
    public static final ModuleSource copy = new ModuleSource(H5Container.MENU_COPY, 3, H5Container.MENU_COPY);
    public static final ModuleSource convert = new ModuleSource("convert", 4, "convert");
    public static final ModuleSource unifiedAccount = new ModuleSource("unifiedAccount", 5, "unified_account");
    public static final ModuleSource simpleEarn = new ModuleSource("simpleEarn", 6, "simple_earn");
    public static final ModuleSource dualInvestment = new ModuleSource("dualInvestment", 7, "dual_investment");
    public static final ModuleSource vipWealthHub = new ModuleSource("vipWealthHub", 8, "vip_wealth_hub");
    public static final ModuleSource launchpad = new ModuleSource("launchpad", 9, "launchpad");
    public static final ModuleSource launchpool = new ModuleSource(MarketConst.searchLaunchpoolType, 10, MarketConst.searchLaunchpoolType);
    public static final ModuleSource airdrop = new ModuleSource("airdrop", 11, "airdrop");
    public static final ModuleSource loan = new ModuleSource("loan", 12, "loan");
    public static final ModuleSource staking = new ModuleSource("staking", 13, "staking");
    public static final ModuleSource quantFund = new ModuleSource("quantFund", 14, "quant_fund");
    public static final ModuleSource dipSniper = new ModuleSource("dipSniper", 15, "dip_sniper");
    public static final ModuleSource peakSniper = new ModuleSource("peakSniper", 16, "peak_sniper");
    public static final ModuleSource rewardsHub = new ModuleSource("rewardsHub", 17, "rewards_hub");
    public static final ModuleSource referral = new ModuleSource(NotificationConfig.TYPE_REFERRAL, 18, NotificationConfig.TYPE_REFERRAL);
    public static final ModuleSource assets = new ModuleSource("assets", 19, "assets");
    public static final ModuleSource home = new ModuleSource("home", 20, "home");
    public static final ModuleSource sideDeposit = new ModuleSource("sideDeposit", 21, "side_deposit");
    public static final ModuleSource vip = new ModuleSource("vip", 22, "vip");
    public static final ModuleSource alpha = new ModuleSource("alpha", 23, "alpha");
    public static final ModuleSource uRLDefault = new ModuleSource("uRLDefault", 24, "URLDefault");
    public static final ModuleSource aggregatedSearch = new ModuleSource("aggregatedSearch", 25, "aggregated_search");

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    /* compiled from: ModuleSource.kt */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/add/funds/service/component/ModuleSource$Companion;", "", "()V", "fromValue", "Lcom/gateio/biz/add/funds/service/component/ModuleSource;", "value", "", "biz_add_funds_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nModuleSource.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ModuleSource.kt\ncom/gateio/biz/add/funds/service/component/ModuleSource$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,45:1\n1#2:46\n*E\n"})
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final ModuleSource fromValue(@NotNull String value) {
            ModuleSource next;
            Iterator<ModuleSource> it = ModuleSource.getEntries().iterator();
            while (true) {
                if (it.hasNext()) {
                    next = it.next();
                    if (Intrinsics.areEqual(next.getValue(), value)) {
                        break;
                    }
                } else {
                    next = null;
                    break;
                }
            }
            ModuleSource moduleSource = next;
            if (moduleSource == null) {
                return ModuleSource.home;
            }
            return moduleSource;
        }
    }

    private static final /* synthetic */ ModuleSource[] $values() {
        return new ModuleSource[]{spot, futures, bots, copy, convert, unifiedAccount, simpleEarn, dualInvestment, vipWealthHub, launchpad, launchpool, airdrop, loan, staking, quantFund, dipSniper, peakSniper, rewardsHub, referral, assets, home, sideDeposit, vip, alpha, uRLDefault, aggregatedSearch};
    }

    static {
        ModuleSource[] moduleSourceArr$values = $values();
        $VALUES = moduleSourceArr$values;
        $ENTRIES = EnumEntriesKt.enumEntries(moduleSourceArr$values);
        INSTANCE = new Companion(null);
        CREATOR = new Parcelable.Creator<ModuleSource>() { // from class: com.gateio.biz.add.funds.service.component.ModuleSource.Creator
            /* JADX WARN: Can't rename method to resolve collision */
            @Override // android.os.Parcelable.Creator
            @NotNull
            public final ModuleSource createFromParcel(@NotNull Parcel parcel) {
                return ModuleSource.valueOf(parcel.readString());
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // android.os.Parcelable.Creator
            @NotNull
            public final ModuleSource[] newArray(int i10) {
                return new ModuleSource[i10];
            }
        };
    }

    @NotNull
    public static EnumEntries<ModuleSource> getEntries() {
        return $ENTRIES;
    }

    public static ModuleSource valueOf(String str) {
        return (ModuleSource) Enum.valueOf(ModuleSource.class, str);
    }

    public static ModuleSource[] values() {
        return (ModuleSource[]) $VALUES.clone();
    }

    @NotNull
    public final String getValue() {
        return this.value;
    }

    private ModuleSource(String str, int i10, String str2) {
        this.value = str2;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(@NotNull Parcel parcel, int flags) {
        parcel.writeString(name());
    }
}