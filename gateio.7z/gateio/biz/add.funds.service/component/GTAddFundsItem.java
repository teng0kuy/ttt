package com.gateio.biz.add.funds.service.component;

import android.content.Context;
import com.gate_sdk.web3_wallet.DeFiConstants;
import com.zoloz.webcontainer.env.H5Container;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: GTAddFundsItem.kt */
@Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0019\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\b\u0018\u00002\u00020\u0001Bu\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\b\b\u0002\u0010\b\u001a\u00020\u0005\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\n\u00128\u0010\u000b\u001a4\u0012\u0013\u0012\u00110\r¢\u0006\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\b(\u0010\u0012\u0015\u0012\u0013\u0018\u00010\u0005¢\u0006\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\b(\u0011\u0012\u0004\u0012\u00020\u00120\f¢\u0006\u0002\u0010\u0013J\t\u0010\"\u001a\u00020\u0003HÆ\u0003J\t\u0010#\u001a\u00020\u0005HÆ\u0003J\t\u0010$\u001a\u00020\u0005HÆ\u0003J\t\u0010%\u001a\u00020\u0005HÆ\u0003J\t\u0010&\u001a\u00020\u0005HÆ\u0003J\u0010\u0010'\u001a\u0004\u0018\u00010\nHÆ\u0003¢\u0006\u0002\u0010\u0019J;\u0010(\u001a4\u0012\u0013\u0012\u00110\r¢\u0006\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\b(\u0010\u0012\u0015\u0012\u0013\u0018\u00010\u0005¢\u0006\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\b(\u0011\u0012\u0004\u0012\u00020\u00120\fHÆ\u0003J\u0088\u0001\u0010)\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u00052\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\n2:\b\u0002\u0010\u000b\u001a4\u0012\u0013\u0012\u00110\r¢\u0006\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\b(\u0010\u0012\u0015\u0012\u0013\u0018\u00010\u0005¢\u0006\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\b(\u0011\u0012\u0004\u0012\u00020\u00120\fHÆ\u0001¢\u0006\u0002\u0010*J\u0013\u0010+\u001a\u00020,2\b\u0010-\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010.\u001a\u00020\nHÖ\u0001J\t\u0010/\u001a\u00020\u0005HÖ\u0001RC\u0010\u000b\u001a4\u0012\u0013\u0012\u00110\r¢\u0006\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\b(\u0010\u0012\u0015\u0012\u0013\u0018\u00010\u0005¢\u0006\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\b(\u0011\u0012\u0004\u0012\u00020\u00120\f¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0015\u0010\t\u001a\u0004\u0018\u00010\n¢\u0006\n\n\u0002\u0010\u001a\u001a\u0004\b\u0018\u0010\u0019R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0017R\u001a\u0010\b\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001c\u0010\u0017\"\u0004\b\u001d\u0010\u001eR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u0017R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b \u0010!¨\u00060"}, d2 = {"Lcom/gateio/biz/add/funds/service/component/GTAddFundsItem;", "", "type", "Lcom/gateio/biz/add/funds/service/component/GTAddFundsType;", "title", "", "subTitle", "icon", "tagText", "index", "", "action", "Lkotlin/Function2;", "Landroid/content/Context;", "Lkotlin/ParameterName;", "name", "context", "currency", "", "(Lcom/gateio/biz/add/funds/service/component/GTAddFundsType;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Lkotlin/jvm/functions/Function2;)V", "getAction", "()Lkotlin/jvm/functions/Function2;", "getIcon", "()Ljava/lang/String;", "getIndex", "()Ljava/lang/Integer;", "Ljava/lang/Integer;", "getSubTitle", "getTagText", "setTagText", "(Ljava/lang/String;)V", "getTitle", DeFiConstants.GetType, "()Lcom/gateio/biz/add/funds/service/component/GTAddFundsType;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", H5Container.MENU_COPY, "(Lcom/gateio/biz/add/funds/service/component/GTAddFundsType;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Lkotlin/jvm/functions/Function2;)Lcom/gateio/biz/add/funds/service/component/GTAddFundsItem;", "equals", "", "other", "hashCode", "toString", "biz_add_funds_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final /* data */ class GTAddFundsItem {

    @NotNull
    private final Function2<Context, String, Unit> action;

    @NotNull
    private final String icon;

    @Nullable
    private final Integer index;

    @NotNull
    private final String subTitle;

    @NotNull
    private String tagText;

    @NotNull
    private final String title;

    @NotNull
    private final GTAddFundsType type;

    /* JADX WARN: Multi-variable type inference failed */
    public GTAddFundsItem(@NotNull GTAddFundsType gTAddFundsType, @NotNull String str, @NotNull String str2, @NotNull String str3, @NotNull String str4, @Nullable Integer num, @NotNull Function2<? super Context, ? super String, Unit> function2) {
        this.type = gTAddFundsType;
        this.title = str;
        this.subTitle = str2;
        this.icon = str3;
        this.tagText = str4;
        this.index = num;
        this.action = function2;
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof GTAddFundsItem)) {
            return false;
        }
        GTAddFundsItem gTAddFundsItem = (GTAddFundsItem) other;
        return this.type == gTAddFundsItem.type && Intrinsics.areEqual(this.title, gTAddFundsItem.title) && Intrinsics.areEqual(this.subTitle, gTAddFundsItem.subTitle) && Intrinsics.areEqual(this.icon, gTAddFundsItem.icon) && Intrinsics.areEqual(this.tagText, gTAddFundsItem.tagText) && Intrinsics.areEqual(this.index, gTAddFundsItem.index) && Intrinsics.areEqual(this.action, gTAddFundsItem.action);
    }

    public static /* synthetic */ GTAddFundsItem copy$default(GTAddFundsItem gTAddFundsItem, GTAddFundsType gTAddFundsType, String str, String str2, String str3, String str4, Integer num, Function2 function2, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            gTAddFundsType = gTAddFundsItem.type;
        }
        if ((i10 & 2) != 0) {
            str = gTAddFundsItem.title;
        }
        String str5 = str;
        if ((i10 & 4) != 0) {
            str2 = gTAddFundsItem.subTitle;
        }
        String str6 = str2;
        if ((i10 & 8) != 0) {
            str3 = gTAddFundsItem.icon;
        }
        String str7 = str3;
        if ((i10 & 16) != 0) {
            str4 = gTAddFundsItem.tagText;
        }
        String str8 = str4;
        if ((i10 & 32) != 0) {
            num = gTAddFundsItem.index;
        }
        Integer num2 = num;
        if ((i10 & 64) != 0) {
            function2 = gTAddFundsItem.action;
        }
        return gTAddFundsItem.copy(gTAddFundsType, str5, str6, str7, str8, num2, function2);
    }

    @NotNull
    /* renamed from: component1, reason: from getter */
    public final GTAddFundsType getType() {
        return this.type;
    }

    @NotNull
    /* renamed from: component2, reason: from getter */
    public final String getTitle() {
        return this.title;
    }

    @NotNull
    /* renamed from: component3, reason: from getter */
    public final String getSubTitle() {
        return this.subTitle;
    }

    @NotNull
    /* renamed from: component4, reason: from getter */
    public final String getIcon() {
        return this.icon;
    }

    @NotNull
    /* renamed from: component5, reason: from getter */
    public final String getTagText() {
        return this.tagText;
    }

    @Nullable
    /* renamed from: component6, reason: from getter */
    public final Integer getIndex() {
        return this.index;
    }

    @NotNull
    public final Function2<Context, String, Unit> component7() {
        return this.action;
    }

    @NotNull
    public final GTAddFundsItem copy(@NotNull GTAddFundsType type, @NotNull String title, @NotNull String subTitle, @NotNull String icon, @NotNull String tagText, @Nullable Integer index, @NotNull Function2<? super Context, ? super String, Unit> action) {
        return new GTAddFundsItem(type, title, subTitle, icon, tagText, index, action);
    }

    @NotNull
    public final Function2<Context, String, Unit> getAction() {
        return this.action;
    }

    @NotNull
    public final String getIcon() {
        return this.icon;
    }

    @Nullable
    public final Integer getIndex() {
        return this.index;
    }

    @NotNull
    public final String getSubTitle() {
        return this.subTitle;
    }

    @NotNull
    public final String getTagText() {
        return this.tagText;
    }

    @NotNull
    public final String getTitle() {
        return this.title;
    }

    @NotNull
    public final GTAddFundsType getType() {
        return this.type;
    }

    public int hashCode() {
        int iHashCode = ((((((((this.type.hashCode() * 31) + this.title.hashCode()) * 31) + this.subTitle.hashCode()) * 31) + this.icon.hashCode()) * 31) + this.tagText.hashCode()) * 31;
        Integer num = this.index;
        return ((iHashCode + (num == null ? 0 : num.hashCode())) * 31) + this.action.hashCode();
    }

    public final void setTagText(@NotNull String str) {
        this.tagText = str;
    }

    @NotNull
    public String toString() {
        return "GTAddFundsItem(type=" + this.type + ", title=" + this.title + ", subTitle=" + this.subTitle + ", icon=" + this.icon + ", tagText=" + this.tagText + ", index=" + this.index + ", action=" + this.action + ')';
    }

    public /* synthetic */ GTAddFundsItem(GTAddFundsType gTAddFundsType, String str, String str2, String str3, String str4, Integer num, Function2 function2, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this(gTAddFundsType, str, str2, str3, (i10 & 16) != 0 ? "" : str4, (i10 & 32) != 0 ? 0 : num, function2);
    }
}