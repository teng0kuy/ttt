package com.gateio.biz.add.funds.service.component;

import android.content.Context;
import androidx.fragment.app.Fragment;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: AddFunds.kt */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bf\u0018\u00002\u00020\u0001J0\u0010\u0002\u001a\u0018\u0012\u0004\u0012\u00020\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u00032\u0006\u0010\u0007\u001a\u00020\u00052\b\u0010\b\u001a\u0004\u0018\u00010\u0005H&J\n\u0010\t\u001a\u0004\u0018\u00010\u0005H&J6\u0010\n\u001a\u0004\u0018\u00010\u000b2\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\r2\b\u0010\u000f\u001a\u0004\u0018\u00010\u00052\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u00060\u0011H&¨\u0006\u0013"}, d2 = {"Lcom/gateio/biz/add/funds/service/component/FiatComponent;", "", "getDepositItemAction", "Lkotlin/Function2;", "Landroid/content/Context;", "", "", "code", "androidLink", "getFiat", "getP2pComponentFragment", "Landroidx/fragment/app/Fragment;", "list", "", "Lcom/gateio/biz/add/funds/service/component/AddFundsEntity;", "currency", "callBack", "Lkotlin/Function1;", "Lcom/gateio/biz/add/funds/service/component/GTAddFundsType;", "biz_add_funds_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public interface FiatComponent {
    @Nullable
    Function2<Context, String, Unit> getDepositItemAction(@NotNull String code, @Nullable String androidLink);

    @Nullable
    String getFiat();

    @Nullable
    Fragment getP2pComponentFragment(@NotNull List<AddFundsEntity> list, @Nullable String currency, @NotNull Function1<? super GTAddFundsType, Unit> callBack);
}