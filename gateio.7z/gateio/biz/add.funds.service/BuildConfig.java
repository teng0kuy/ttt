package com.gateio.biz.add.funds.service;

/* loaded from: classes4.dex */
public final class BuildConfig {
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "com.gateio.biz.add.funds.service";
}