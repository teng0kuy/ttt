package com.gateio.biz.add.funds.service;

/* loaded from: classes4.dex */
public final class R {

    public static final class anim {
        public static final int fragment_fast_out_extra_slow_in = 0x7f010046;

        private anim() {
        }
    }

    public static final class animator {
        public static final int fragment_close_enter = 0x7f020006;
        public static final int fragment_close_exit = 0x7f020007;
        public static final int fragment_fade_enter = 0x7f020008;
        public static final int fragment_fade_exit = 0x7f020009;
        public static final int fragment_open_enter = 0x7f02000a;
        public static final int fragment_open_exit = 0x7f02000b;

        private animator() {
        }
    }

    public static final class attr {
        public static final int alpha = 0x7f040041;
        public static final int coordinatorLayoutStyle = 0x7f0401f8;
        public static final int font = 0x7f040334;
        public static final int fontProviderAuthority = 0x7f040336;
        public static final int fontProviderCerts = 0x7f040337;
        public static final int fontProviderFetchStrategy = 0x7f040338;
        public static final int fontProviderFetchTimeout = 0x7f040339;
        public static final int fontProviderPackage = 0x7f04033a;
        public static final int fontProviderQuery = 0x7f04033b;
        public static final int fontProviderSystemFontFamily = 0x7f04033c;
        public static final int fontStyle = 0x7f04033d;
        public static final int fontVariationSettings = 0x7f04033e;
        public static final int fontWeight = 0x7f04033f;
        public static final int keylines = 0x7f0404dd;
        public static final int lStar = 0x7f0404de;
        public static final int layout_anchor = 0x7f0404ee;
        public static final int layout_anchorGravity = 0x7f0404ef;
        public static final int layout_behavior = 0x7f0404f0;
        public static final int layout_dodgeInsetEdges = 0x7f040524;
        public static final int layout_insetEdge = 0x7f040532;
        public static final int layout_keyline = 0x7f040533;
        public static final int nestedScrollViewStyle = 0x7f04063b;
        public static final int queryPatterns = 0x7f0406ac;
        public static final int shortcutMatchRequired = 0x7f040731;
        public static final int statusBarBackground = 0x7f04086d;
        public static final int ttcIndex = 0x7f040997;

        private attr() {
        }
    }

    public static final class color {
        public static final int androidx_core_ripple_material_light = 0x7f06003c;
        public static final int androidx_core_secondary_text_default_material_light = 0x7f06003d;
        public static final int call_notification_answer_color = 0x7f0600af;
        public static final int call_notification_decline_color = 0x7f0600b0;
        public static final int notification_action_color_filter = 0x7f060616;
        public static final int notification_icon_bg_color = 0x7f060617;
        public static final int notification_material_background_media_default_color = 0x7f060618;
        public static final int primary_text_default_material_dark = 0x7f060654;
        public static final int ripple_material_light = 0x7f06068f;
        public static final int secondary_text_default_material_dark = 0x7f0606a0;
        public static final int secondary_text_default_material_light = 0x7f0606a1;

        private color() {
        }
    }

    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 0x7f070155;
        public static final int compat_button_inset_vertical_material = 0x7f070156;
        public static final int compat_button_padding_horizontal_material = 0x7f070157;
        public static final int compat_button_padding_vertical_material = 0x7f070158;
        public static final int compat_control_corner_material = 0x7f070159;
        public static final int compat_notification_large_icon_max_height = 0x7f07015a;
        public static final int compat_notification_large_icon_max_width = 0x7f07015b;
        public static final int notification_action_icon_size = 0x7f0704ad;
        public static final int notification_action_text_size = 0x7f0704ae;
        public static final int notification_big_circle_margin = 0x7f0704af;
        public static final int notification_content_margin_start = 0x7f0704b0;
        public static final int notification_large_icon_height = 0x7f0704b1;
        public static final int notification_large_icon_width = 0x7f0704b2;
        public static final int notification_main_column_padding_top = 0x7f0704b3;
        public static final int notification_media_narrow_margin = 0x7f0704b4;
        public static final int notification_right_icon_size = 0x7f0704b5;
        public static final int notification_right_side_padding_top = 0x7f0704b6;
        public static final int notification_small_icon_background_padding = 0x7f0704b7;
        public static final int notification_small_icon_size_as_large = 0x7f0704b8;
        public static final int notification_subtext_size = 0x7f0704b9;
        public static final int notification_top_pad = 0x7f0704ba;
        public static final int notification_top_pad_large_text = 0x7f0704bb;

        private dimen() {
        }
    }

    public static final class drawable {
        public static final int ic_call_answer = 0x7f0803df;
        public static final int ic_call_answer_low = 0x7f0803e0;
        public static final int ic_call_answer_video = 0x7f0803e1;
        public static final int ic_call_answer_video_low = 0x7f0803e2;
        public static final int ic_call_decline = 0x7f0803e3;
        public static final int ic_call_decline_low = 0x7f0803e4;
        public static final int notification_action_background = 0x7f08055f;
        public static final int notification_bg = 0x7f080560;
        public static final int notification_bg_low = 0x7f080561;
        public static final int notification_bg_low_normal = 0x7f080562;
        public static final int notification_bg_low_pressed = 0x7f080563;
        public static final int notification_bg_normal = 0x7f080564;
        public static final int notification_bg_normal_pressed = 0x7f080565;
        public static final int notification_icon_background = 0x7f080566;
        public static final int notification_oversize_large_icon_bg = 0x7f080567;
        public static final int notification_template_icon_bg = 0x7f080568;
        public static final int notification_template_icon_low_bg = 0x7f080569;
        public static final int notification_tile_bg = 0x7f08056a;
        public static final int notify_panel_notification_icon_bg = 0x7f08056b;

        private drawable() {
        }
    }

    public static final class id {
        public static final int accessibility_action_clickable_span = 0x7f0b0041;
        public static final int accessibility_custom_action_0 = 0x7f0b0042;
        public static final int accessibility_custom_action_1 = 0x7f0b0043;
        public static final int accessibility_custom_action_10 = 0x7f0b0044;
        public static final int accessibility_custom_action_11 = 0x7f0b0045;
        public static final int accessibility_custom_action_12 = 0x7f0b0046;
        public static final int accessibility_custom_action_13 = 0x7f0b0047;
        public static final int accessibility_custom_action_14 = 0x7f0b0048;
        public static final int accessibility_custom_action_15 = 0x7f0b0049;
        public static final int accessibility_custom_action_16 = 0x7f0b004a;
        public static final int accessibility_custom_action_17 = 0x7f0b004b;
        public static final int accessibility_custom_action_18 = 0x7f0b004c;
        public static final int accessibility_custom_action_19 = 0x7f0b004d;
        public static final int accessibility_custom_action_2 = 0x7f0b004e;
        public static final int accessibility_custom_action_20 = 0x7f0b004f;
        public static final int accessibility_custom_action_21 = 0x7f0b0050;
        public static final int accessibility_custom_action_22 = 0x7f0b0051;
        public static final int accessibility_custom_action_23 = 0x7f0b0052;
        public static final int accessibility_custom_action_24 = 0x7f0b0053;
        public static final int accessibility_custom_action_25 = 0x7f0b0054;
        public static final int accessibility_custom_action_26 = 0x7f0b0055;
        public static final int accessibility_custom_action_27 = 0x7f0b0056;
        public static final int accessibility_custom_action_28 = 0x7f0b0057;
        public static final int accessibility_custom_action_29 = 0x7f0b0058;
        public static final int accessibility_custom_action_3 = 0x7f0b0059;
        public static final int accessibility_custom_action_30 = 0x7f0b005a;
        public static final int accessibility_custom_action_31 = 0x7f0b005b;
        public static final int accessibility_custom_action_4 = 0x7f0b005c;
        public static final int accessibility_custom_action_5 = 0x7f0b005d;
        public static final int accessibility_custom_action_6 = 0x7f0b005e;
        public static final int accessibility_custom_action_7 = 0x7f0b005f;
        public static final int accessibility_custom_action_8 = 0x7f0b0060;
        public static final int accessibility_custom_action_9 = 0x7f0b0061;
        public static final int action0 = 0x7f0b0072;
        public static final int action_container = 0x7f0b0084;
        public static final int action_divider = 0x7f0b0086;
        public static final int action_image = 0x7f0b008a;
        public static final int action_text = 0x7f0b0093;
        public static final int actions = 0x7f0b0094;
        public static final int async = 0x7f0b0264;
        public static final int blocking = 0x7f0b032c;
        public static final int bottom = 0x7f0b034b;
        public static final int cancel_action = 0x7f0b0447;
        public static final int chronometer = 0x7f0b054a;
        public static final int dialog_button = 0x7f0b074e;
        public static final int edit_text_id = 0x7f0b084a;
        public static final int end = 0x7f0b087b;
        public static final int end_padder = 0x7f0b087d;
        public static final int forever = 0x7f0b09f1;
        public static final int fragment_container_view_tag = 0x7f0b0a03;
        public static final int hide_ime_id = 0x7f0b0c10;
        public static final int icon = 0x7f0b0c62;
        public static final int icon_group = 0x7f0b0c96;
        public static final int info = 0x7f0b0db4;
        public static final int italic = 0x7f0b0e1d;
        public static final int left = 0x7f0b1176;
        public static final int line1 = 0x7f0b11b2;
        public static final int line3 = 0x7f0b11b4;
        public static final int media_actions = 0x7f0b16cb;
        public static final int none = 0x7f0b17aa;
        public static final int normal = 0x7f0b17ab;
        public static final int notification_background = 0x7f0b17bb;
        public static final int notification_main_column = 0x7f0b17bd;
        public static final int notification_main_column_container = 0x7f0b17be;
        public static final int report_drawn = 0x7f0b1b88;
        public static final int right = 0x7f0b1bb6;
        public static final int right_icon = 0x7f0b1bbb;
        public static final int right_side = 0x7f0b1bbe;
        public static final int special_effects_controller_view_tag = 0x7f0b1ea8;
        public static final int start = 0x7f0b1ecd;
        public static final int status_bar_latest_event_content = 0x7f0b1ef2;
        public static final int tag_accessibility_actions = 0x7f0b1fb0;
        public static final int tag_accessibility_clickable_spans = 0x7f0b1fb1;
        public static final int tag_accessibility_heading = 0x7f0b1fb2;
        public static final int tag_accessibility_pane_title = 0x7f0b1fb3;
        public static final int tag_on_apply_window_listener = 0x7f0b1fc3;
        public static final int tag_on_receive_content_listener = 0x7f0b1fc4;
        public static final int tag_on_receive_content_mime_types = 0x7f0b1fc5;
        public static final int tag_screen_reader_focusable = 0x7f0b1fc8;
        public static final int tag_state_description = 0x7f0b1fce;
        public static final int tag_transition_group = 0x7f0b1fd3;
        public static final int tag_unhandled_key_event_manager = 0x7f0b1fd8;
        public static final int tag_unhandled_key_listeners = 0x7f0b1fd9;
        public static final int tag_window_insets_animation_callback = 0x7f0b1fdc;
        public static final int text = 0x7f0b2001;
        public static final int text2 = 0x7f0b2003;
        public static final int time = 0x7f0b205a;
        public static final int title = 0x7f0b207e;

        /* renamed from: top, reason: collision with root package name */
        public static final int f10903top = 0x7f0b20c9;
        public static final int view_tree_lifecycle_owner = 0x7f0b2d4c;
        public static final int view_tree_on_back_pressed_dispatcher_owner = 0x7f0b2d4d;
        public static final int view_tree_saved_state_registry_owner = 0x7f0b2d4e;
        public static final int view_tree_view_model_store_owner = 0x7f0b2d4f;
        public static final int visible_removing_fragment_view_tag = 0x7f0b2d59;

        private id() {
        }
    }

    public static final class integer {
        public static final int cancel_button_image_alpha = 0x7f0c0005;
        public static final int status_bar_notification_info_maxnum = 0x7f0c0034;

        private integer() {
        }
    }

    public static final class layout {
        public static final int custom_dialog = 0x7f0e0107;
        public static final int ime_base_split_test_activity = 0x7f0e051d;
        public static final int ime_secondary_split_test_activity = 0x7f0e051e;
        public static final int notification_action = 0x7f0e07d1;
        public static final int notification_action_tombstone = 0x7f0e07d2;
        public static final int notification_media_action = 0x7f0e07d3;
        public static final int notification_media_cancel_action = 0x7f0e07d4;
        public static final int notification_template_big_media = 0x7f0e07d5;
        public static final int notification_template_big_media_custom = 0x7f0e07d6;
        public static final int notification_template_big_media_narrow = 0x7f0e07d7;
        public static final int notification_template_big_media_narrow_custom = 0x7f0e07d8;
        public static final int notification_template_custom_big = 0x7f0e07d9;
        public static final int notification_template_icon_group = 0x7f0e07da;
        public static final int notification_template_lines_media = 0x7f0e07db;
        public static final int notification_template_media = 0x7f0e07dc;
        public static final int notification_template_media_custom = 0x7f0e07dd;
        public static final int notification_template_part_chronometer = 0x7f0e07de;
        public static final int notification_template_part_time = 0x7f0e07df;

        private layout() {
        }
    }

    public static final class string {
        public static final int call_notification_answer_action = 0x7f1403c4;
        public static final int call_notification_answer_video_action = 0x7f1403c5;
        public static final int call_notification_decline_action = 0x7f1403c6;
        public static final int call_notification_hang_up_action = 0x7f1403c7;
        public static final int call_notification_incoming_text = 0x7f1403c8;
        public static final int call_notification_ongoing_text = 0x7f1403c9;
        public static final int call_notification_screening_text = 0x7f1403ca;
        public static final int status_bar_notification_info_overflow = 0x7f14293a;

        private string() {
        }
    }

    public static final class style {
        public static final int TextAppearance_Compat_Notification = 0x7f150254;
        public static final int TextAppearance_Compat_Notification_Info = 0x7f150255;
        public static final int TextAppearance_Compat_Notification_Info_Media = 0x7f150256;
        public static final int TextAppearance_Compat_Notification_Line2 = 0x7f150257;
        public static final int TextAppearance_Compat_Notification_Line2_Media = 0x7f150258;
        public static final int TextAppearance_Compat_Notification_Media = 0x7f150259;
        public static final int TextAppearance_Compat_Notification_Time = 0x7f15025a;
        public static final int TextAppearance_Compat_Notification_Time_Media = 0x7f15025b;
        public static final int TextAppearance_Compat_Notification_Title = 0x7f15025c;
        public static final int TextAppearance_Compat_Notification_Title_Media = 0x7f15025d;
        public static final int Widget_Compat_NotificationActionContainer = 0x7f15043f;
        public static final int Widget_Compat_NotificationActionText = 0x7f150440;
        public static final int Widget_Support_CoordinatorLayout = 0x7f150599;

        private style() {
        }
    }

    public static final class styleable {
        public static final int Capability_queryPatterns = 0x00000000;
        public static final int Capability_shortcutMatchRequired = 0x00000001;
        public static final int ColorStateListItem_alpha = 0x00000003;
        public static final int ColorStateListItem_android_alpha = 0x00000001;
        public static final int ColorStateListItem_android_color = 0x00000000;
        public static final int ColorStateListItem_android_lStar = 0x00000002;
        public static final int ColorStateListItem_lStar = 0x00000004;
        public static final int CoordinatorLayout_Layout_android_layout_gravity = 0x00000000;
        public static final int CoordinatorLayout_Layout_layout_anchor = 0x00000001;
        public static final int CoordinatorLayout_Layout_layout_anchorGravity = 0x00000002;
        public static final int CoordinatorLayout_Layout_layout_behavior = 0x00000003;
        public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 0x00000004;
        public static final int CoordinatorLayout_Layout_layout_insetEdge = 0x00000005;
        public static final int CoordinatorLayout_Layout_layout_keyline = 0x00000006;
        public static final int CoordinatorLayout_keylines = 0x00000000;
        public static final int CoordinatorLayout_statusBarBackground = 0x00000001;
        public static final int FontFamilyFont_android_font = 0x00000000;
        public static final int FontFamilyFont_android_fontStyle = 0x00000002;
        public static final int FontFamilyFont_android_fontVariationSettings = 0x00000004;
        public static final int FontFamilyFont_android_fontWeight = 0x00000001;
        public static final int FontFamilyFont_android_ttcIndex = 0x00000003;
        public static final int FontFamilyFont_font = 0x00000005;
        public static final int FontFamilyFont_fontStyle = 0x00000006;
        public static final int FontFamilyFont_fontVariationSettings = 0x00000007;
        public static final int FontFamilyFont_fontWeight = 0x00000008;
        public static final int FontFamilyFont_ttcIndex = 0x00000009;
        public static final int FontFamily_fontProviderAuthority = 0x00000000;
        public static final int FontFamily_fontProviderCerts = 0x00000001;
        public static final int FontFamily_fontProviderFetchStrategy = 0x00000002;
        public static final int FontFamily_fontProviderFetchTimeout = 0x00000003;
        public static final int FontFamily_fontProviderPackage = 0x00000004;
        public static final int FontFamily_fontProviderQuery = 0x00000005;
        public static final int FontFamily_fontProviderSystemFontFamily = 0x00000006;
        public static final int FragmentContainerView_android_name = 0x00000000;
        public static final int FragmentContainerView_android_tag = 0x00000001;
        public static final int Fragment_android_id = 0x00000001;
        public static final int Fragment_android_name = 0x00000000;
        public static final int Fragment_android_tag = 0x00000002;
        public static final int GradientColorItem_android_color = 0x00000000;
        public static final int GradientColorItem_android_offset = 0x00000001;
        public static final int GradientColor_android_centerColor = 0x00000007;
        public static final int GradientColor_android_centerX = 0x00000003;
        public static final int GradientColor_android_centerY = 0x00000004;
        public static final int GradientColor_android_endColor = 0x00000001;
        public static final int GradientColor_android_endX = 0x0000000a;
        public static final int GradientColor_android_endY = 0x0000000b;
        public static final int GradientColor_android_gradientRadius = 0x00000005;
        public static final int GradientColor_android_startColor = 0x00000000;
        public static final int GradientColor_android_startX = 0x00000008;
        public static final int GradientColor_android_startY = 0x00000009;
        public static final int GradientColor_android_tileMode = 0x00000006;
        public static final int GradientColor_android_type = 0x00000002;
        public static final int[] Capability = {com.gateio.gateio.R.attr.queryPatterns, com.gateio.gateio.R.attr.shortcutMatchRequired};
        public static final int[] ColorStateListItem = {android.R.attr.color, android.R.attr.alpha, android.R.attr.lStar, com.gateio.gateio.R.attr.alpha, com.gateio.gateio.R.attr.lStar};
        public static final int[] CoordinatorLayout = {com.gateio.gateio.R.attr.keylines, com.gateio.gateio.R.attr.statusBarBackground};
        public static final int[] CoordinatorLayout_Layout = {android.R.attr.layout_gravity, com.gateio.gateio.R.attr.layout_anchor, com.gateio.gateio.R.attr.layout_anchorGravity, com.gateio.gateio.R.attr.layout_behavior, com.gateio.gateio.R.attr.layout_dodgeInsetEdges, com.gateio.gateio.R.attr.layout_insetEdge, com.gateio.gateio.R.attr.layout_keyline};
        public static final int[] FontFamily = {com.gateio.gateio.R.attr.fontProviderAuthority, com.gateio.gateio.R.attr.fontProviderCerts, com.gateio.gateio.R.attr.fontProviderFetchStrategy, com.gateio.gateio.R.attr.fontProviderFetchTimeout, com.gateio.gateio.R.attr.fontProviderPackage, com.gateio.gateio.R.attr.fontProviderQuery, com.gateio.gateio.R.attr.fontProviderSystemFontFamily};
        public static final int[] FontFamilyFont = {android.R.attr.font, android.R.attr.fontWeight, android.R.attr.fontStyle, android.R.attr.ttcIndex, android.R.attr.fontVariationSettings, com.gateio.gateio.R.attr.font, com.gateio.gateio.R.attr.fontStyle, com.gateio.gateio.R.attr.fontVariationSettings, com.gateio.gateio.R.attr.fontWeight, com.gateio.gateio.R.attr.ttcIndex};
        public static final int[] Fragment = {android.R.attr.name, android.R.attr.id, android.R.attr.tag};
        public static final int[] FragmentContainerView = {android.R.attr.name, android.R.attr.tag};
        public static final int[] GradientColor = {android.R.attr.startColor, android.R.attr.endColor, android.R.attr.type, android.R.attr.centerX, android.R.attr.centerY, android.R.attr.gradientRadius, android.R.attr.tileMode, android.R.attr.centerColor, android.R.attr.startX, android.R.attr.startY, android.R.attr.endX, android.R.attr.endY};
        public static final int[] GradientColorItem = {android.R.attr.color, android.R.attr.offset};

        private styleable() {
        }
    }

    private R() {
    }
}