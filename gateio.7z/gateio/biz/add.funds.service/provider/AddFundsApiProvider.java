package com.gateio.biz.add.funds.service.provider;

import com.gateio.biz.add.funds.service.component.AddFunds;
import com.gateio.biz.add.funds.service.component.FiatComponent;
import com.gateio.biz.base.router.RouterConst;
import com.gateio.lib.router.GTRouter;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: AddFundsApiProvider.kt */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\n\u0010\u0003\u001a\u0004\u0018\u00010\u0004H\u0007J\n\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\u0007¨\u0006\u0007"}, d2 = {"Lcom/gateio/biz/add/funds/service/provider/AddFundsApiProvider;", "", "()V", "getAddFundsApi", "Lcom/gateio/biz/add/funds/service/component/AddFunds;", "getFiatComponetApi", "Lcom/gateio/biz/add/funds/service/component/FiatComponent;", "biz_add_funds_service_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes4.dex */
public final class AddFundsApiProvider {

    @NotNull
    public static final AddFundsApiProvider INSTANCE = new AddFundsApiProvider();

    private AddFundsApiProvider() {
    }

    @JvmStatic
    @Nullable
    public static final AddFunds getAddFundsApi() {
        Object objServiceAPI = GTRouter.serviceAPI(RouterConst.Wallets.ADD_FUNDS);
        if (objServiceAPI instanceof AddFunds) {
            return (AddFunds) objServiceAPI;
        }
        return null;
    }

    @JvmStatic
    @Nullable
    public static final FiatComponent getFiatComponetApi() {
        Object objServiceAPI = GTRouter.serviceAPI(RouterConst.FiatOtc.FIAT_OTC_P2P_DEPOSIT);
        if (objServiceAPI instanceof FiatComponent) {
            return (FiatComponent) objServiceAPI;
        }
        return null;
    }
}