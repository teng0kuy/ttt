package com.gateio.biz.fiatloan_android;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* compiled from: Fiatloan_androidInitializer.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/gateio/biz/fiatloan_android/Fiatloan_androidInitializer;", "", "()V", "biz_fiatloan_android_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes38.dex */
public final class Fiatloan_androidInitializer {

    @NotNull
    public static final Fiatloan_androidInitializer INSTANCE = new Fiatloan_androidInitializer();

    private Fiatloan_androidInitializer() {
    }
}