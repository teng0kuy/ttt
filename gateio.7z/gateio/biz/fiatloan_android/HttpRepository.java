package com.gateio.biz.fiatloan_android;

import com.gateio.baselib.utils.HttpBaseServices;
import com.gateio.fiatloan.IFiatLoanService;
import com.gateio.fiatloan.bean.AddCollateralQuery;
import com.gateio.fiatloan.bean.AddCollateralRecord;
import com.gateio.fiatloan.bean.AddCollateralResult;
import com.gateio.fiatloan.bean.AppealHistory;
import com.gateio.fiatloan.bean.BalanceBean;
import com.gateio.fiatloan.bean.ChatBean;
import com.gateio.fiatloan.bean.CurrentOrder;
import com.gateio.fiatloan.bean.HistoryOrder;
import com.gateio.fiatloan.bean.Notices;
import com.gateio.fiatloan.bean.OrderDetail;
import com.gateio.fiatloan.bean.OrderMarket;
import com.gateio.fiatloan.bean.PaymentBean;
import com.gateio.fiatloan.bean.PublishOrder;
import com.gateio.fiatloan.bean.SettingConfig;
import com.gateio.http.entity.HttpResult;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.FlowKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* compiled from: HttpRepository.kt */
@Metadata(d1 = {"\u0000\u0082\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\bÆ\u0002\u0018\u00002\u00020\u0001:\u00010B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J&\u0010\u0003\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J&\u0010\t\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J,\u0010\u000b\u001a\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\r0\f0\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J,\u0010\u000e\u001a\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000f0\f0\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J&\u0010\u0010\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00110\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J&\u0010\u0012\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00130\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J,\u0010\u0014\u001a\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00150\f0\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J(\u0010\u0016\u001a\u0010\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00170\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J,\u0010\u0018\u001a\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00190\f0\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J(\u0010\u001a\u001a\u0010\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u001b0\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J,\u0010\u001c\u001a\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001d0\f0\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J,\u0010\u001e\u001a\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001f0\f0\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J6\u0010 \u001a\u001e\u0012\u001a\u0012\u0018\u0012\u0014\u0012\u0012\u0012\u0004\u0012\u00020\"0!j\b\u0012\u0004\u0012\u00020\"`#0\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J&\u0010$\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020%0\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J&\u0010&\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020'0\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J&\u0010(\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J&\u0010)\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J&\u0010*\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J&\u0010+\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J&\u0010,\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J&\u0010-\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J&\u0010.\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007J&\u0010/\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00010\u00050\u00042\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007¨\u00061"}, d2 = {"Lcom/gateio/biz/fiatloan_android/HttpRepository;", "", "()V", "cancelAdC2CLoanOrder", "Lkotlinx/coroutines/flow/Flow;", "Lcom/gateio/http/entity/HttpResult;", "params", "", "", "fastCoverC2CLoanTransaction", "Lcom/gateio/fiatloan/bean/AddCollateralResult;", "fastCoverC2CLoanTransactionQuery", "", "Lcom/gateio/fiatloan/bean/AddCollateralQuery;", "getC2CLoanOrders", "Lcom/gateio/fiatloan/bean/OrderMarket;", "getC2CLoanSetting", "Lcom/gateio/fiatloan/bean/SettingConfig;", "getMyC2CLoanBalance", "Lcom/gateio/fiatloan/bean/BalanceBean;", "getMyC2CLoanBroCovers", "Lcom/gateio/fiatloan/bean/AddCollateralRecord;", "getMyC2CLoanNotices", "Lcom/gateio/fiatloan/bean/Notices;", "getMyC2CLoanOrders", "Lcom/gateio/fiatloan/bean/PublishOrder;", "getMyC2CLoanTransactionDetails", "Lcom/gateio/fiatloan/bean/OrderDetail;", "getMyC2CLoanTransactions", "Lcom/gateio/fiatloan/bean/CurrentOrder;", "getMyC2CLoanTransactionsHistory", "Lcom/gateio/fiatloan/bean/HistoryOrder;", "getPayment", "Ljava/util/ArrayList;", "Lcom/gateio/fiatloan/bean/PaymentBean;", "Lkotlin/collections/ArrayList;", "getPushChats", "Lcom/gateio/fiatloan/bean/ChatBean;", "p2pAppealRecord", "Lcom/gateio/fiatloan/bean/AppealHistory;", "p2pSubmitAppealV2", "placeC2CLoanOrder", "postPushChat", "publishC2cLoanOrders", "setOnlineAdC2CLoanOrder", "setRenewAdC2CLoanOrder", "updateC2CLoanTransaction", "uploadFile", "serviceImp", "biz_fiatloan_android_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* loaded from: classes38.dex */
public final class HttpRepository {

    @NotNull
    public static final HttpRepository INSTANCE = new HttpRepository();

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$cancelAdC2CLoanOrder$1", f = "HttpRepository.kt", i = {}, l = {84, 84}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$cancelAdC2CLoanOrder$1, reason: invalid class name */
    static final class AnonymousClass1 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<Object>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(Map<String, String> map, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            AnonymousClass1 anonymousClass1 = new AnonymousClass1(this.$params, continuation);
            anonymousClass1.L$0 = obj;
            return anonymousClass1;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<Object>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.cancelAdC2CLoanOrder(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "Lcom/gateio/fiatloan/bean/AddCollateralResult;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$fastCoverC2CLoanTransaction$1", f = "HttpRepository.kt", i = {}, l = {122, 122}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$fastCoverC2CLoanTransaction$1, reason: invalid class name and case insensitive filesystem */
    static final class C19121 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<AddCollateralResult>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19121(Map<String, String> map, Continuation<? super C19121> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19121 c19121 = new C19121(this.$params, continuation);
            c19121.L$0 = obj;
            return c19121;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<AddCollateralResult>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19121) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.fastCoverC2CLoanTransaction(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0005\u001a\u00020\u0004*\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "", "Lcom/gateio/fiatloan/bean/AddCollateralQuery;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$fastCoverC2CLoanTransactionQuery$1", f = "HttpRepository.kt", i = {}, l = {127, 127}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$fastCoverC2CLoanTransactionQuery$1, reason: invalid class name and case insensitive filesystem */
    static final class C19131 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<List<? extends AddCollateralQuery>>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        @Override // kotlin.jvm.functions.Function2
        /* renamed from: invoke */
        public /* bridge */ /* synthetic */ Object mo2invoke(FlowCollector<? super HttpResult<List<? extends AddCollateralQuery>>> flowCollector, Continuation<? super Unit> continuation) {
            return invoke2((FlowCollector<? super HttpResult<List<AddCollateralQuery>>>) flowCollector, continuation);
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19131(Map<String, String> map, Continuation<? super C19131> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19131 c19131 = new C19131(this.$params, continuation);
            c19131.L$0 = obj;
            return c19131;
        }

        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method */
        public final Object invoke2(@NotNull FlowCollector<? super HttpResult<List<AddCollateralQuery>>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19131) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.fastCoverC2CLoanTransactionQuery(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0005\u001a\u00020\u0004*\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "", "Lcom/gateio/fiatloan/bean/OrderMarket;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$getC2CLoanOrders$1", f = "HttpRepository.kt", i = {}, l = {53, 53}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$getC2CLoanOrders$1, reason: invalid class name and case insensitive filesystem */
    static final class C19141 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<List<? extends OrderMarket>>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        @Override // kotlin.jvm.functions.Function2
        /* renamed from: invoke */
        public /* bridge */ /* synthetic */ Object mo2invoke(FlowCollector<? super HttpResult<List<? extends OrderMarket>>> flowCollector, Continuation<? super Unit> continuation) {
            return invoke2((FlowCollector<? super HttpResult<List<OrderMarket>>>) flowCollector, continuation);
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19141(Map<String, String> map, Continuation<? super C19141> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19141 c19141 = new C19141(this.$params, continuation);
            c19141.L$0 = obj;
            return c19141;
        }

        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method */
        public final Object invoke2(@NotNull FlowCollector<? super HttpResult<List<OrderMarket>>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19141) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.getC2CLoanOrders(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "Lcom/gateio/fiatloan/bean/SettingConfig;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$getC2CLoanSetting$1", f = "HttpRepository.kt", i = {}, l = {38, 38}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$getC2CLoanSetting$1, reason: invalid class name and case insensitive filesystem */
    static final class C19151 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<SettingConfig>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19151(Map<String, String> map, Continuation<? super C19151> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19151 c19151 = new C19151(this.$params, continuation);
            c19151.L$0 = obj;
            return c19151;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<SettingConfig>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19151) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.getC2CLoanSetting(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "Lcom/gateio/fiatloan/bean/BalanceBean;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$getMyC2CLoanBalance$1", f = "HttpRepository.kt", i = {}, l = {43, 43}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$getMyC2CLoanBalance$1, reason: invalid class name and case insensitive filesystem */
    static final class C19161 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<BalanceBean>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19161(Map<String, String> map, Continuation<? super C19161> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19161 c19161 = new C19161(this.$params, continuation);
            c19161.L$0 = obj;
            return c19161;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<BalanceBean>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19161) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.getMyC2CLoanBalance(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0005\u001a\u00020\u0004*\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "", "Lcom/gateio/fiatloan/bean/AddCollateralRecord;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$getMyC2CLoanBroCovers$1", f = "HttpRepository.kt", i = {}, l = {97, 97}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$getMyC2CLoanBroCovers$1, reason: invalid class name and case insensitive filesystem */
    static final class C19171 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<List<? extends AddCollateralRecord>>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        @Override // kotlin.jvm.functions.Function2
        /* renamed from: invoke */
        public /* bridge */ /* synthetic */ Object mo2invoke(FlowCollector<? super HttpResult<List<? extends AddCollateralRecord>>> flowCollector, Continuation<? super Unit> continuation) {
            return invoke2((FlowCollector<? super HttpResult<List<AddCollateralRecord>>>) flowCollector, continuation);
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19171(Map<String, String> map, Continuation<? super C19171> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19171 c19171 = new C19171(this.$params, continuation);
            c19171.L$0 = obj;
            return c19171;
        }

        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method */
        public final Object invoke2(@NotNull FlowCollector<? super HttpResult<List<AddCollateralRecord>>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19171) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.getMyC2CLoanBroCovers(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003*\u0010\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "Lcom/gateio/fiatloan/bean/Notices;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$getMyC2CLoanNotices$1", f = "HttpRepository.kt", i = {}, l = {61, 61}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$getMyC2CLoanNotices$1, reason: invalid class name and case insensitive filesystem */
    static final class C19181 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<Notices>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19181(Map<String, String> map, Continuation<? super C19181> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19181 c19181 = new C19181(this.$params, continuation);
            c19181.L$0 = obj;
            return c19181;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<Notices>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19181) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.getMyC2CLoanNotices(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0005\u001a\u00020\u0004*\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "", "Lcom/gateio/fiatloan/bean/PublishOrder;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$getMyC2CLoanOrders$1", f = "HttpRepository.kt", i = {}, l = {76, 76}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$getMyC2CLoanOrders$1, reason: invalid class name and case insensitive filesystem */
    static final class C19191 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<List<? extends PublishOrder>>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        @Override // kotlin.jvm.functions.Function2
        /* renamed from: invoke */
        public /* bridge */ /* synthetic */ Object mo2invoke(FlowCollector<? super HttpResult<List<? extends PublishOrder>>> flowCollector, Continuation<? super Unit> continuation) {
            return invoke2((FlowCollector<? super HttpResult<List<PublishOrder>>>) flowCollector, continuation);
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19191(Map<String, String> map, Continuation<? super C19191> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19191 c19191 = new C19191(this.$params, continuation);
            c19191.L$0 = obj;
            return c19191;
        }

        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method */
        public final Object invoke2(@NotNull FlowCollector<? super HttpResult<List<PublishOrder>>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19191) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.getMyC2CLoanOrders(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003*\u0010\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "Lcom/gateio/fiatloan/bean/OrderDetail;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$getMyC2CLoanTransactionDetails$1", f = "HttpRepository.kt", i = {}, l = {48, 48}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$getMyC2CLoanTransactionDetails$1, reason: invalid class name and case insensitive filesystem */
    static final class C19201 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<OrderDetail>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19201(Map<String, String> map, Continuation<? super C19201> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19201 c19201 = new C19201(this.$params, continuation);
            c19201.L$0 = obj;
            return c19201;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<OrderDetail>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19201) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.getMyC2CLoanTransactionDetails(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0005\u001a\u00020\u0004*\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "", "Lcom/gateio/fiatloan/bean/CurrentOrder;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$getMyC2CLoanTransactions$1", f = "HttpRepository.kt", i = {}, l = {66, 66}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$getMyC2CLoanTransactions$1, reason: invalid class name and case insensitive filesystem */
    static final class C19211 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<List<? extends CurrentOrder>>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        @Override // kotlin.jvm.functions.Function2
        /* renamed from: invoke */
        public /* bridge */ /* synthetic */ Object mo2invoke(FlowCollector<? super HttpResult<List<? extends CurrentOrder>>> flowCollector, Continuation<? super Unit> continuation) {
            return invoke2((FlowCollector<? super HttpResult<List<CurrentOrder>>>) flowCollector, continuation);
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19211(Map<String, String> map, Continuation<? super C19211> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19211 c19211 = new C19211(this.$params, continuation);
            c19211.L$0 = obj;
            return c19211;
        }

        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method */
        public final Object invoke2(@NotNull FlowCollector<? super HttpResult<List<CurrentOrder>>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19211) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.getMyC2CLoanTransactions(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0005\u001a\u00020\u0004*\u0014\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "", "Lcom/gateio/fiatloan/bean/HistoryOrder;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$getMyC2CLoanTransactionsHistory$1", f = "HttpRepository.kt", i = {}, l = {71, 71}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$getMyC2CLoanTransactionsHistory$1, reason: invalid class name and case insensitive filesystem */
    static final class C19221 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<List<? extends HistoryOrder>>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        @Override // kotlin.jvm.functions.Function2
        /* renamed from: invoke */
        public /* bridge */ /* synthetic */ Object mo2invoke(FlowCollector<? super HttpResult<List<? extends HistoryOrder>>> flowCollector, Continuation<? super Unit> continuation) {
            return invoke2((FlowCollector<? super HttpResult<List<HistoryOrder>>>) flowCollector, continuation);
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19221(Map<String, String> map, Continuation<? super C19221> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19221 c19221 = new C19221(this.$params, continuation);
            c19221.L$0 = obj;
            return c19221;
        }

        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method */
        public final Object invoke2(@NotNull FlowCollector<? super HttpResult<List<HistoryOrder>>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19221) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.getMyC2CLoanTransactionsHistory(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0006\u001a\u00020\u0005*\u001e\u0012\u001a\u0012\u0018\u0012\u0014\u0012\u0012\u0012\u0004\u0012\u00020\u00030\u0002j\b\u0012\u0004\u0012\u00020\u0003`\u00040\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "Ljava/util/ArrayList;", "Lcom/gateio/fiatloan/bean/PaymentBean;", "Lkotlin/collections/ArrayList;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$getPayment$1", f = "HttpRepository.kt", i = {}, l = {33, 33}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$getPayment$1, reason: invalid class name and case insensitive filesystem */
    static final class C19231 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<ArrayList<PaymentBean>>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19231(Map<String, String> map, Continuation<? super C19231> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19231 c19231 = new C19231(this.$params, continuation);
            c19231.L$0 = obj;
            return c19231;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<ArrayList<PaymentBean>>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19231) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.getPayment(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "Lcom/gateio/fiatloan/bean/ChatBean;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$getPushChats$1", f = "HttpRepository.kt", i = {}, l = {113, 113}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$getPushChats$1, reason: invalid class name and case insensitive filesystem */
    static final class C19241 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<ChatBean>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19241(Map<String, String> map, Continuation<? super C19241> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19241 c19241 = new C19241(this.$params, continuation);
            c19241.L$0 = obj;
            return c19241;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<ChatBean>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19241) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.getPushChats(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "Lcom/gateio/fiatloan/bean/AppealHistory;", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$p2pAppealRecord$1", f = "HttpRepository.kt", i = {}, l = {109, 109}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$p2pAppealRecord$1, reason: invalid class name and case insensitive filesystem */
    static final class C19251 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<AppealHistory>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19251(Map<String, String> map, Continuation<? super C19251> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19251 c19251 = new C19251(this.$params, continuation);
            c19251.L$0 = obj;
            return c19251;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<AppealHistory>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19251) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.p2pAppealRecord(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$p2pSubmitAppealV2$1", f = "HttpRepository.kt", i = {}, l = {101, 101}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$p2pSubmitAppealV2$1, reason: invalid class name and case insensitive filesystem */
    static final class C19261 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<Object>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19261(Map<String, String> map, Continuation<? super C19261> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19261 c19261 = new C19261(this.$params, continuation);
            c19261.L$0 = obj;
            return c19261;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<Object>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19261) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.p2pSubmitAppealV2(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$placeC2CLoanOrder$1", f = "HttpRepository.kt", i = {}, l = {57, 57}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$placeC2CLoanOrder$1, reason: invalid class name and case insensitive filesystem */
    static final class C19271 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<Object>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19271(Map<String, String> map, Continuation<? super C19271> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19271 c19271 = new C19271(this.$params, continuation);
            c19271.L$0 = obj;
            return c19271;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<Object>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19271) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.placeC2CLoanOrder(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$postPushChat$1", f = "HttpRepository.kt", i = {}, l = {117, 117}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$postPushChat$1, reason: invalid class name and case insensitive filesystem */
    static final class C19281 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<Object>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19281(Map<String, String> map, Continuation<? super C19281> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19281 c19281 = new C19281(this.$params, continuation);
            c19281.L$0 = obj;
            return c19281;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<Object>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19281) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.postPushChat(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$publishC2cLoanOrders$1", f = "HttpRepository.kt", i = {}, l = {28, 28}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$publishC2cLoanOrders$1, reason: invalid class name and case insensitive filesystem */
    static final class C19291 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<Object>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19291(Map<String, String> map, Continuation<? super C19291> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19291 c19291 = new C19291(this.$params, continuation);
            c19291.L$0 = obj;
            return c19291;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<Object>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19291) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.publishC2cLoanOrders(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÂ\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lcom/gateio/biz/fiatloan_android/HttpRepository$serviceImp;", "Lcom/gateio/baselib/utils/HttpBaseServices;", "Lcom/gateio/fiatloan/IFiatLoanService;", "()V", "biz_fiatloan_android_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    private static final class serviceImp extends HttpBaseServices<IFiatLoanService> {

        @NotNull
        public static final serviceImp INSTANCE = new serviceImp();

        private serviceImp() {
            super(IFiatLoanService.class);
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$setOnlineAdC2CLoanOrder$1", f = "HttpRepository.kt", i = {}, l = {92, 92}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$setOnlineAdC2CLoanOrder$1, reason: invalid class name and case insensitive filesystem */
    static final class C19301 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<Object>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19301(Map<String, String> map, Continuation<? super C19301> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19301 c19301 = new C19301(this.$params, continuation);
            c19301.L$0 = obj;
            return c19301;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<Object>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19301) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.setOnlineAdC2CLoanOrder(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$setRenewAdC2CLoanOrder$1", f = "HttpRepository.kt", i = {}, l = {88, 88}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$setRenewAdC2CLoanOrder$1, reason: invalid class name and case insensitive filesystem */
    static final class C19311 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<Object>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19311(Map<String, String> map, Continuation<? super C19311> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19311 c19311 = new C19311(this.$params, continuation);
            c19311.L$0 = obj;
            return c19311;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<Object>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19311) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.setRenewAdC2CLoanOrder(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$updateC2CLoanTransaction$1", f = "HttpRepository.kt", i = {}, l = {80, 80}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$updateC2CLoanTransaction$1, reason: invalid class name and case insensitive filesystem */
    static final class C19321 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<Object>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19321(Map<String, String> map, Continuation<? super C19321> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19321 c19321 = new C19321(this.$params, continuation);
            c19321.L$0 = obj;
            return c19321;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<Object>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19321) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.updateC2CLoanTransaction(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    /* compiled from: HttpRepository.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00010\u0000H\u008a@"}, d2 = {"Lkotlinx/coroutines/flow/FlowCollector;", "Lcom/gateio/http/entity/HttpResult;", "", "", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    @DebugMetadata(c = "com.gateio.biz.fiatloan_android.HttpRepository$uploadFile$1", f = "HttpRepository.kt", i = {}, l = {105, 105}, m = "invokeSuspend", n = {}, s = {})
    /* renamed from: com.gateio.biz.fiatloan_android.HttpRepository$uploadFile$1, reason: invalid class name and case insensitive filesystem */
    static final class C19331 extends SuspendLambda implements Function2<FlowCollector<? super HttpResult<Object>>, Continuation<? super Unit>, Object> {
        final /* synthetic */ Map<String, String> $params;
        private /* synthetic */ Object L$0;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C19331(Map<String, String> map, Continuation<? super C19331> continuation) {
            super(2, continuation);
            this.$params = map;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C19331 c19331 = new C19331(this.$params, continuation);
            c19331.L$0 = obj;
            return c19331;
        }

        @Override // kotlin.jvm.functions.Function2
        @Nullable
        /* renamed from: invoke, reason: avoid collision after fix types in other method and merged with bridge method [inline-methods] */
        public final Object mo2invoke(@NotNull FlowCollector<? super HttpResult<Object>> flowCollector, @Nullable Continuation<? super Unit> continuation) {
            return ((C19331) create(flowCollector, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            FlowCollector flowCollector;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i10 = this.label;
            if (i10 != 0) {
                if (i10 != 1) {
                    if (i10 == 2) {
                        ResultKt.throwOnFailure(obj);
                        return Unit.INSTANCE;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                flowCollector = (FlowCollector) this.L$0;
                ResultKt.throwOnFailure(obj);
            } else {
                ResultKt.throwOnFailure(obj);
                flowCollector = (FlowCollector) this.L$0;
                IFiatLoanService iFiatLoanService = serviceImp.INSTANCE.get();
                Map<String, String> map = this.$params;
                this.L$0 = flowCollector;
                this.label = 1;
                obj = iFiatLoanService.uploadFile(map, this);
                if (obj == coroutine_suspended) {
                    return coroutine_suspended;
                }
            }
            this.L$0 = null;
            this.label = 2;
            if (flowCollector.emit(obj, this) == coroutine_suspended) {
                return coroutine_suspended;
            }
            return Unit.INSTANCE;
        }
    }

    private HttpRepository() {
    }

    @NotNull
    public final Flow<HttpResult<Object>> cancelAdC2CLoanOrder(@NotNull Map<String, String> params) {
        return FlowKt.flow(new AnonymousClass1(params, null));
    }

    @NotNull
    public final Flow<HttpResult<AddCollateralResult>> fastCoverC2CLoanTransaction(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19121(params, null));
    }

    @NotNull
    public final Flow<HttpResult<List<AddCollateralQuery>>> fastCoverC2CLoanTransactionQuery(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19131(params, null));
    }

    @NotNull
    public final Flow<HttpResult<List<OrderMarket>>> getC2CLoanOrders(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19141(params, null));
    }

    @NotNull
    public final Flow<HttpResult<SettingConfig>> getC2CLoanSetting(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19151(params, null));
    }

    @NotNull
    public final Flow<HttpResult<BalanceBean>> getMyC2CLoanBalance(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19161(params, null));
    }

    @NotNull
    public final Flow<HttpResult<List<AddCollateralRecord>>> getMyC2CLoanBroCovers(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19171(params, null));
    }

    @NotNull
    public final Flow<HttpResult<Notices>> getMyC2CLoanNotices(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19181(params, null));
    }

    @NotNull
    public final Flow<HttpResult<List<PublishOrder>>> getMyC2CLoanOrders(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19191(params, null));
    }

    @NotNull
    public final Flow<HttpResult<OrderDetail>> getMyC2CLoanTransactionDetails(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19201(params, null));
    }

    @NotNull
    public final Flow<HttpResult<List<CurrentOrder>>> getMyC2CLoanTransactions(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19211(params, null));
    }

    @NotNull
    public final Flow<HttpResult<List<HistoryOrder>>> getMyC2CLoanTransactionsHistory(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19221(params, null));
    }

    @NotNull
    public final Flow<HttpResult<ArrayList<PaymentBean>>> getPayment(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19231(params, null));
    }

    @NotNull
    public final Flow<HttpResult<ChatBean>> getPushChats(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19241(params, null));
    }

    @NotNull
    public final Flow<HttpResult<AppealHistory>> p2pAppealRecord(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19251(params, null));
    }

    @NotNull
    public final Flow<HttpResult<Object>> p2pSubmitAppealV2(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19261(params, null));
    }

    @NotNull
    public final Flow<HttpResult<Object>> placeC2CLoanOrder(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19271(params, null));
    }

    @NotNull
    public final Flow<HttpResult<Object>> postPushChat(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19281(params, null));
    }

    @NotNull
    public final Flow<HttpResult<Object>> publishC2cLoanOrders(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19291(params, null));
    }

    @NotNull
    public final Flow<HttpResult<Object>> setOnlineAdC2CLoanOrder(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19301(params, null));
    }

    @NotNull
    public final Flow<HttpResult<Object>> setRenewAdC2CLoanOrder(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19311(params, null));
    }

    @NotNull
    public final Flow<HttpResult<Object>> updateC2CLoanTransaction(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19321(params, null));
    }

    @NotNull
    public final Flow<HttpResult<Object>> uploadFile(@NotNull Map<String, String> params) {
        return FlowKt.flow(new C19331(params, null));
    }
}