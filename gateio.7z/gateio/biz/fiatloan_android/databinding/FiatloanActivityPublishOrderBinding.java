package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.alert.GTAlertV3;
import com.gateio.lib.uikit.button.GTButtonV3;
import com.gateio.lib.uikit.dropdown.GTDropdownV3;
import com.gateio.lib.uikit.input.GTEditTextV3;
import com.gateio.lib.uikit.reminder.GTReminderV3;
import com.gateio.lib.uikit.selector.GTSelectorViewV3;
import com.gateio.lib.uikit.stepper.GTStepperV3;
import com.gateio.lib.uikit.switchview.GTSwitchV3;
import com.gateio.lib.uikit.text.DashTextViewV3;
import com.gateio.lib.uikit.title.GTTitleViewV3;
import com.gateio.lib.uikit.widget.GTCheckBoxV3;
import com.gateio.uiComponent.GateIconFont;
import com.ruffian.library.widget.RView;

/* loaded from: classes38.dex */
public final class FiatloanActivityPublishOrderBinding implements ViewBinding {

    @NonNull
    public final GTCheckBoxV3 agreement;

    @NonNull
    public final EditText amountInput;

    @NonNull
    public final TextView amountLabel;

    @NonNull
    public final TextView amountRange;

    @NonNull
    public final GTSelectorViewV3 amountSelector;

    @NonNull
    public final TextView annualizedRate;

    @NonNull
    public final TextView available;

    @NonNull
    public final DashTextViewV3 availableLabel;

    @NonNull
    public final GTDropdownV3 dropdownPeriod;

    @NonNull
    public final TextView dueInterest;

    @NonNull
    public final TextView dueInterestLabel;

    @NonNull
    public final TextView dueTotal;

    @NonNull
    public final TextView dueTotalLabel;

    @NonNull
    public final TextView fee;

    @NonNull
    public final LinearLayout feeLayout;

    @NonNull
    public final GTEditTextV3 limitMax;

    @NonNull
    public final GTEditTextV3 limitMin;

    @NonNull
    public final LinearLayout llBottom;

    @NonNull
    public final GTButtonV3 minus;

    @NonNull
    public final GTReminderV3 noPayMethodTip;

    @NonNull
    public final LinearLayout payMethodAli;

    @NonNull
    public final TextView payMethodAliAccount;

    @NonNull
    public final RView payMethodAliColor;

    @NonNull
    public final GateIconFont payMethodArrow;

    @NonNull
    public final LinearLayout payMethodBank;

    @NonNull
    public final TextView payMethodBankAccount;

    @NonNull
    public final RView payMethodBankColor;

    @NonNull
    public final View payMethodDivider1;

    @NonNull
    public final View payMethodDivider2;

    @NonNull
    public final LinearLayout payMethodLayout;

    @NonNull
    public final LinearLayout payMethodSelect;

    @NonNull
    public final LinearLayout payMethodWechat;

    @NonNull
    public final TextView payMethodWechatAccount;

    @NonNull
    public final RView payMethodWechatColor;

    @NonNull
    public final GTAlertV3 pledgeAlert;

    @NonNull
    public final GTEditTextV3 pledgeAmount;

    @NonNull
    public final TextView pledgeLabel;

    @NonNull
    public final TextView pledgeRate;

    @NonNull
    public final TextView pledgeRateLabel;

    @NonNull
    public final RelativeLayout pledgeRateLayout;

    @NonNull
    public final GTButtonV3 plus;

    @NonNull
    public final GTButtonV3 publish;

    @NonNull
    public final GTStepperV3 rate;

    @NonNull
    public final GateIconFont renewIcon;

    @NonNull
    public final RelativeLayout renewLayout;

    @NonNull
    public final GTSwitchV3 renewSwitch;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final NestedScrollView scrollView;

    @NonNull
    public final GTTitleViewV3 title;

    private FiatloanActivityPublishOrderBinding(@NonNull LinearLayout linearLayout, @NonNull GTCheckBoxV3 gTCheckBoxV3, @NonNull EditText editText, @NonNull TextView textView, @NonNull TextView textView2, @NonNull GTSelectorViewV3 gTSelectorViewV3, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull DashTextViewV3 dashTextViewV3, @NonNull GTDropdownV3 gTDropdownV3, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textView9, @NonNull LinearLayout linearLayout2, @NonNull GTEditTextV3 gTEditTextV3, @NonNull GTEditTextV3 gTEditTextV32, @NonNull LinearLayout linearLayout3, @NonNull GTButtonV3 gTButtonV3, @NonNull GTReminderV3 gTReminderV3, @NonNull LinearLayout linearLayout4, @NonNull TextView textView10, @NonNull RView rView, @NonNull GateIconFont gateIconFont, @NonNull LinearLayout linearLayout5, @NonNull TextView textView11, @NonNull RView rView2, @NonNull View view, @NonNull View view2, @NonNull LinearLayout linearLayout6, @NonNull LinearLayout linearLayout7, @NonNull LinearLayout linearLayout8, @NonNull TextView textView12, @NonNull RView rView3, @NonNull GTAlertV3 gTAlertV3, @NonNull GTEditTextV3 gTEditTextV33, @NonNull TextView textView13, @NonNull TextView textView14, @NonNull TextView textView15, @NonNull RelativeLayout relativeLayout, @NonNull GTButtonV3 gTButtonV32, @NonNull GTButtonV3 gTButtonV33, @NonNull GTStepperV3 gTStepperV3, @NonNull GateIconFont gateIconFont2, @NonNull RelativeLayout relativeLayout2, @NonNull GTSwitchV3 gTSwitchV3, @NonNull NestedScrollView nestedScrollView, @NonNull GTTitleViewV3 gTTitleViewV3) {
        this.rootView = linearLayout;
        this.agreement = gTCheckBoxV3;
        this.amountInput = editText;
        this.amountLabel = textView;
        this.amountRange = textView2;
        this.amountSelector = gTSelectorViewV3;
        this.annualizedRate = textView3;
        this.available = textView4;
        this.availableLabel = dashTextViewV3;
        this.dropdownPeriod = gTDropdownV3;
        this.dueInterest = textView5;
        this.dueInterestLabel = textView6;
        this.dueTotal = textView7;
        this.dueTotalLabel = textView8;
        this.fee = textView9;
        this.feeLayout = linearLayout2;
        this.limitMax = gTEditTextV3;
        this.limitMin = gTEditTextV32;
        this.llBottom = linearLayout3;
        this.minus = gTButtonV3;
        this.noPayMethodTip = gTReminderV3;
        this.payMethodAli = linearLayout4;
        this.payMethodAliAccount = textView10;
        this.payMethodAliColor = rView;
        this.payMethodArrow = gateIconFont;
        this.payMethodBank = linearLayout5;
        this.payMethodBankAccount = textView11;
        this.payMethodBankColor = rView2;
        this.payMethodDivider1 = view;
        this.payMethodDivider2 = view2;
        this.payMethodLayout = linearLayout6;
        this.payMethodSelect = linearLayout7;
        this.payMethodWechat = linearLayout8;
        this.payMethodWechatAccount = textView12;
        this.payMethodWechatColor = rView3;
        this.pledgeAlert = gTAlertV3;
        this.pledgeAmount = gTEditTextV33;
        this.pledgeLabel = textView13;
        this.pledgeRate = textView14;
        this.pledgeRateLabel = textView15;
        this.pledgeRateLayout = relativeLayout;
        this.plus = gTButtonV32;
        this.publish = gTButtonV33;
        this.rate = gTStepperV3;
        this.renewIcon = gateIconFont2;
        this.renewLayout = relativeLayout2;
        this.renewSwitch = gTSwitchV3;
        this.scrollView = nestedScrollView;
        this.title = gTTitleViewV3;
    }

    @NonNull
    public static FiatloanActivityPublishOrderBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanActivityPublishOrderBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        int i10 = R.id.agreement;
        GTCheckBoxV3 gTCheckBoxV3 = (GTCheckBoxV3) ViewBindings.findChildViewById(view, i10);
        if (gTCheckBoxV3 != null) {
            i10 = R.id.amount_input;
            EditText editText = (EditText) ViewBindings.findChildViewById(view, i10);
            if (editText != null) {
                i10 = R.id.amount_label;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView != null) {
                    i10 = R.id.amount_range;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView2 != null) {
                        i10 = R.id.amount_selector;
                        GTSelectorViewV3 gTSelectorViewV3 = (GTSelectorViewV3) ViewBindings.findChildViewById(view, i10);
                        if (gTSelectorViewV3 != null) {
                            i10 = R.id.annualized_rate;
                            TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView3 != null) {
                                i10 = R.id.available;
                                TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView4 != null) {
                                    i10 = R.id.available_label;
                                    DashTextViewV3 dashTextViewV3 = (DashTextViewV3) ViewBindings.findChildViewById(view, i10);
                                    if (dashTextViewV3 != null) {
                                        i10 = R.id.dropdown_period;
                                        GTDropdownV3 gTDropdownV3 = (GTDropdownV3) ViewBindings.findChildViewById(view, i10);
                                        if (gTDropdownV3 != null) {
                                            i10 = R.id.due_interest;
                                            TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView5 != null) {
                                                i10 = R.id.due_interest_label;
                                                TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView6 != null) {
                                                    i10 = R.id.due_total;
                                                    TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                    if (textView7 != null) {
                                                        i10 = R.id.due_total_label;
                                                        TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                        if (textView8 != null) {
                                                            i10 = R.id.fee;
                                                            TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                            if (textView9 != null) {
                                                                i10 = R.id.fee_layout;
                                                                LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                if (linearLayout != null) {
                                                                    i10 = R.id.limit_max;
                                                                    GTEditTextV3 gTEditTextV3 = (GTEditTextV3) ViewBindings.findChildViewById(view, i10);
                                                                    if (gTEditTextV3 != null) {
                                                                        i10 = R.id.limit_min;
                                                                        GTEditTextV3 gTEditTextV32 = (GTEditTextV3) ViewBindings.findChildViewById(view, i10);
                                                                        if (gTEditTextV32 != null) {
                                                                            i10 = R.id.ll_bottom;
                                                                            LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                            if (linearLayout2 != null) {
                                                                                i10 = R.id.minus;
                                                                                GTButtonV3 gTButtonV3 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                                                                                if (gTButtonV3 != null) {
                                                                                    i10 = R.id.no_pay_method_tip;
                                                                                    GTReminderV3 gTReminderV3 = (GTReminderV3) ViewBindings.findChildViewById(view, i10);
                                                                                    if (gTReminderV3 != null) {
                                                                                        i10 = R.id.pay_method_ali;
                                                                                        LinearLayout linearLayout3 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                                        if (linearLayout3 != null) {
                                                                                            i10 = R.id.pay_method_ali_account;
                                                                                            TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                            if (textView10 != null) {
                                                                                                i10 = R.id.pay_method_ali_color;
                                                                                                RView rView = (RView) ViewBindings.findChildViewById(view, i10);
                                                                                                if (rView != null) {
                                                                                                    i10 = R.id.pay_method_arrow;
                                                                                                    GateIconFont gateIconFont = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                                                                                    if (gateIconFont != null) {
                                                                                                        i10 = R.id.pay_method_bank;
                                                                                                        LinearLayout linearLayout4 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                        if (linearLayout4 != null) {
                                                                                                            i10 = R.id.pay_method_bank_account;
                                                                                                            TextView textView11 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                            if (textView11 != null) {
                                                                                                                i10 = R.id.pay_method_bank_color;
                                                                                                                RView rView2 = (RView) ViewBindings.findChildViewById(view, i10);
                                                                                                                if (rView2 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.pay_method_divider1))) != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i10 = R.id.pay_method_divider2))) != null) {
                                                                                                                    i10 = R.id.pay_method_layout;
                                                                                                                    LinearLayout linearLayout5 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                                    if (linearLayout5 != null) {
                                                                                                                        i10 = R.id.pay_method_select;
                                                                                                                        LinearLayout linearLayout6 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                                        if (linearLayout6 != null) {
                                                                                                                            i10 = R.id.pay_method_wechat;
                                                                                                                            LinearLayout linearLayout7 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                                            if (linearLayout7 != null) {
                                                                                                                                i10 = R.id.pay_method_wechat_account;
                                                                                                                                TextView textView12 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                if (textView12 != null) {
                                                                                                                                    i10 = R.id.pay_method_wechat_color;
                                                                                                                                    RView rView3 = (RView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                    if (rView3 != null) {
                                                                                                                                        i10 = R.id.pledge_alert;
                                                                                                                                        GTAlertV3 gTAlertV3 = (GTAlertV3) ViewBindings.findChildViewById(view, i10);
                                                                                                                                        if (gTAlertV3 != null) {
                                                                                                                                            i10 = R.id.pledge_amount;
                                                                                                                                            GTEditTextV3 gTEditTextV33 = (GTEditTextV3) ViewBindings.findChildViewById(view, i10);
                                                                                                                                            if (gTEditTextV33 != null) {
                                                                                                                                                i10 = R.id.pledge_label;
                                                                                                                                                TextView textView13 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                if (textView13 != null) {
                                                                                                                                                    i10 = R.id.pledge_rate;
                                                                                                                                                    TextView textView14 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                    if (textView14 != null) {
                                                                                                                                                        i10 = R.id.pledge_rate_label;
                                                                                                                                                        TextView textView15 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                        if (textView15 != null) {
                                                                                                                                                            i10 = R.id.pledge_rate_layout;
                                                                                                                                                            RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                            if (relativeLayout != null) {
                                                                                                                                                                i10 = R.id.plus;
                                                                                                                                                                GTButtonV3 gTButtonV32 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                if (gTButtonV32 != null) {
                                                                                                                                                                    i10 = R.id.publish;
                                                                                                                                                                    GTButtonV3 gTButtonV33 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                    if (gTButtonV33 != null) {
                                                                                                                                                                        i10 = R.id.rate;
                                                                                                                                                                        GTStepperV3 gTStepperV3 = (GTStepperV3) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                        if (gTStepperV3 != null) {
                                                                                                                                                                            i10 = R.id.renew_icon;
                                                                                                                                                                            GateIconFont gateIconFont2 = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                            if (gateIconFont2 != null) {
                                                                                                                                                                                i10 = R.id.renew_layout;
                                                                                                                                                                                RelativeLayout relativeLayout2 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                if (relativeLayout2 != null) {
                                                                                                                                                                                    i10 = R.id.renew_switch;
                                                                                                                                                                                    GTSwitchV3 gTSwitchV3 = (GTSwitchV3) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                    if (gTSwitchV3 != null) {
                                                                                                                                                                                        i10 = R.id.scrollView;
                                                                                                                                                                                        NestedScrollView nestedScrollView = (NestedScrollView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                        if (nestedScrollView != null) {
                                                                                                                                                                                            i10 = R.id.title;
                                                                                                                                                                                            GTTitleViewV3 gTTitleViewV3 = (GTTitleViewV3) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                            if (gTTitleViewV3 != null) {
                                                                                                                                                                                                return new FiatloanActivityPublishOrderBinding((LinearLayout) view, gTCheckBoxV3, editText, textView, textView2, gTSelectorViewV3, textView3, textView4, dashTextViewV3, gTDropdownV3, textView5, textView6, textView7, textView8, textView9, linearLayout, gTEditTextV3, gTEditTextV32, linearLayout2, gTButtonV3, gTReminderV3, linearLayout3, textView10, rView, gateIconFont, linearLayout4, textView11, rView2, viewFindChildViewById, viewFindChildViewById2, linearLayout5, linearLayout6, linearLayout7, textView12, rView3, gTAlertV3, gTEditTextV33, textView13, textView14, textView15, relativeLayout, gTButtonV32, gTButtonV33, gTStepperV3, gateIconFont2, relativeLayout2, gTSwitchV3, nestedScrollView, gTTitleViewV3);
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    }
                                                                                                                                                                                }
                                                                                                                                                                            }
                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanActivityPublishOrderBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_activity_publish_order, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }
}