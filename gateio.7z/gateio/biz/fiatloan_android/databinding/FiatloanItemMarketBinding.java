package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.common.view.GateioAvatarView;
import com.gateio.lib.uikit.button.GTButtonV3;
import com.gateio.lib.uikit.tag.GTTagV3;
import com.gateio.uiComponent.GateIconFont;
import com.ruffian.library.widget.RView;

/* loaded from: classes38.dex */
public final class FiatloanItemMarketBinding implements ViewBinding {

    @NonNull
    public final TextView ali;

    @NonNull
    public final RView aliColor;

    @NonNull
    public final TextView amount;

    @NonNull
    public final GateioAvatarView avatar;

    @NonNull
    public final TextView bank;

    @NonNull
    public final RView bankColor;

    @NonNull
    public final TextView interest;

    @NonNull
    public final TextView interestRate;

    @NonNull
    public final TextView minAmount;

    @NonNull
    public final View minAmountDivider;

    @NonNull
    public final TextView name;

    @NonNull
    public final GateIconFont nameIcon;

    @NonNull
    public final TextView onlineTime;

    @NonNull
    public final GTButtonV3 operate;

    @NonNull
    public final LinearLayout payMethod;

    @NonNull
    public final TextView period;

    @NonNull
    public final GTTagV3 renewable;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final TextView wechat;

    @NonNull
    public final RView wechatColor;

    private FiatloanItemMarketBinding(@NonNull RelativeLayout relativeLayout, @NonNull TextView textView, @NonNull RView rView, @NonNull TextView textView2, @NonNull GateioAvatarView gateioAvatarView, @NonNull TextView textView3, @NonNull RView rView2, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull View view, @NonNull TextView textView7, @NonNull GateIconFont gateIconFont, @NonNull TextView textView8, @NonNull GTButtonV3 gTButtonV3, @NonNull LinearLayout linearLayout, @NonNull TextView textView9, @NonNull GTTagV3 gTTagV3, @NonNull TextView textView10, @NonNull RView rView3) {
        this.rootView = relativeLayout;
        this.ali = textView;
        this.aliColor = rView;
        this.amount = textView2;
        this.avatar = gateioAvatarView;
        this.bank = textView3;
        this.bankColor = rView2;
        this.interest = textView4;
        this.interestRate = textView5;
        this.minAmount = textView6;
        this.minAmountDivider = view;
        this.name = textView7;
        this.nameIcon = gateIconFont;
        this.onlineTime = textView8;
        this.operate = gTButtonV3;
        this.payMethod = linearLayout;
        this.period = textView9;
        this.renewable = gTTagV3;
        this.wechat = textView10;
        this.wechatColor = rView3;
    }

    @NonNull
    public static FiatloanItemMarketBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanItemMarketBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.ali;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
        if (textView != null) {
            i10 = R.id.ali_color;
            RView rView = (RView) ViewBindings.findChildViewById(view, i10);
            if (rView != null) {
                i10 = R.id.amount;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView2 != null) {
                    i10 = R.id.avatar;
                    GateioAvatarView gateioAvatarView = (GateioAvatarView) ViewBindings.findChildViewById(view, i10);
                    if (gateioAvatarView != null) {
                        i10 = R.id.bank;
                        TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView3 != null) {
                            i10 = R.id.bank_color;
                            RView rView2 = (RView) ViewBindings.findChildViewById(view, i10);
                            if (rView2 != null) {
                                i10 = R.id.interest;
                                TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView4 != null) {
                                    i10 = R.id.interest_rate;
                                    TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView5 != null) {
                                        i10 = R.id.min_amount;
                                        TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView6 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.min_amount_divider))) != null) {
                                            i10 = R.id.name;
                                            TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView7 != null) {
                                                i10 = R.id.name_icon;
                                                GateIconFont gateIconFont = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                                if (gateIconFont != null) {
                                                    i10 = R.id.online_time;
                                                    TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                    if (textView8 != null) {
                                                        i10 = R.id.operate;
                                                        GTButtonV3 gTButtonV3 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                                                        if (gTButtonV3 != null) {
                                                            i10 = R.id.pay_method;
                                                            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                            if (linearLayout != null) {
                                                                i10 = R.id.period;
                                                                TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                if (textView9 != null) {
                                                                    i10 = R.id.renewable;
                                                                    GTTagV3 gTTagV3 = (GTTagV3) ViewBindings.findChildViewById(view, i10);
                                                                    if (gTTagV3 != null) {
                                                                        i10 = R.id.wechat;
                                                                        TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                        if (textView10 != null) {
                                                                            i10 = R.id.wechat_color;
                                                                            RView rView3 = (RView) ViewBindings.findChildViewById(view, i10);
                                                                            if (rView3 != null) {
                                                                                return new FiatloanItemMarketBinding((RelativeLayout) view, textView, rView, textView2, gateioAvatarView, textView3, rView2, textView4, textView5, textView6, viewFindChildViewById, textView7, gateIconFont, textView8, gTButtonV3, linearLayout, textView9, gTTagV3, textView10, rView3);
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanItemMarketBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_item_market, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }
}