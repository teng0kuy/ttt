package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.alert.GTAlertV3;
import com.gateio.lib.uikit.button.GTButtonV3;
import com.gateio.lib.uikit.input.GTEditTextV3;
import com.gateio.lib.uikit.title.GTTitleViewV3;
import com.gateio.uiComponent.GateIconFont;

/* loaded from: classes38.dex */
public final class FiatloanActivityChatBinding implements ViewBinding {

    @NonNull
    public final GateIconFont add;

    @NonNull
    public final LinearLayout album;

    @NonNull
    public final LinearLayout albumCameraLayout;

    @NonNull
    public final GTAlertV3 alert;

    @NonNull
    public final LinearLayout camera;

    @NonNull
    public final GTEditTextV3 input;

    @NonNull
    public final LinearLayout inputLayout;

    @NonNull
    public final RecyclerView recyclerView;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final GTButtonV3 send;

    @NonNull
    public final LinearLayout sendLayout;

    @NonNull
    public final GTTitleViewV3 title;

    @NonNull
    public static FiatloanActivityChatBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanActivityChatBinding bind(@NonNull View view) {
        int i10 = R.id.add;
        GateIconFont gateIconFont = (GateIconFont) ViewBindings.findChildViewById(view, i10);
        if (gateIconFont != null) {
            i10 = R.id.album;
            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
            if (linearLayout != null) {
                i10 = R.id.album_camera_layout;
                LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                if (linearLayout2 != null) {
                    i10 = R.id.alert;
                    GTAlertV3 gTAlertV3 = (GTAlertV3) ViewBindings.findChildViewById(view, i10);
                    if (gTAlertV3 != null) {
                        i10 = R.id.camera;
                        LinearLayout linearLayout3 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                        if (linearLayout3 != null) {
                            i10 = R.id.input;
                            GTEditTextV3 gTEditTextV3 = (GTEditTextV3) ViewBindings.findChildViewById(view, i10);
                            if (gTEditTextV3 != null) {
                                i10 = R.id.input_layout;
                                LinearLayout linearLayout4 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                if (linearLayout4 != null) {
                                    i10 = R.id.recyclerView;
                                    RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                                    if (recyclerView != null) {
                                        i10 = R.id.send;
                                        GTButtonV3 gTButtonV3 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                                        if (gTButtonV3 != null) {
                                            i10 = R.id.send_layout;
                                            LinearLayout linearLayout5 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                            if (linearLayout5 != null) {
                                                i10 = R.id.title;
                                                GTTitleViewV3 gTTitleViewV3 = (GTTitleViewV3) ViewBindings.findChildViewById(view, i10);
                                                if (gTTitleViewV3 != null) {
                                                    return new FiatloanActivityChatBinding((RelativeLayout) view, gateIconFont, linearLayout, linearLayout2, gTAlertV3, linearLayout3, gTEditTextV3, linearLayout4, recyclerView, gTButtonV3, linearLayout5, gTTitleViewV3);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanActivityChatBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_activity_chat, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private FiatloanActivityChatBinding(@NonNull RelativeLayout relativeLayout, @NonNull GateIconFont gateIconFont, @NonNull LinearLayout linearLayout, @NonNull LinearLayout linearLayout2, @NonNull GTAlertV3 gTAlertV3, @NonNull LinearLayout linearLayout3, @NonNull GTEditTextV3 gTEditTextV3, @NonNull LinearLayout linearLayout4, @NonNull RecyclerView recyclerView, @NonNull GTButtonV3 gTButtonV3, @NonNull LinearLayout linearLayout5, @NonNull GTTitleViewV3 gTTitleViewV3) {
        this.rootView = relativeLayout;
        this.add = gateIconFont;
        this.album = linearLayout;
        this.albumCameraLayout = linearLayout2;
        this.alert = gTAlertV3;
        this.camera = linearLayout3;
        this.input = gTEditTextV3;
        this.inputLayout = linearLayout4;
        this.recyclerView = recyclerView;
        this.send = gTButtonV3;
        this.sendLayout = linearLayout5;
        this.title = gTTitleViewV3;
    }
}