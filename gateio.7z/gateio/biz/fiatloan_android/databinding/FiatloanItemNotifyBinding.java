package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.widget.GTCheckBoxV3;

/* loaded from: classes38.dex */
public final class FiatloanItemNotifyBinding implements ViewBinding {

    @NonNull
    public final GTCheckBoxV3 check;

    @NonNull
    public final TextView message;

    @NonNull
    public final TextView orderId;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final TextView time;

    @NonNull
    public final FrameLayout unread;

    @NonNull
    public static FiatloanItemNotifyBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanItemNotifyBinding bind(@NonNull View view) {
        int i10 = R.id.check;
        GTCheckBoxV3 gTCheckBoxV3 = (GTCheckBoxV3) ViewBindings.findChildViewById(view, i10);
        if (gTCheckBoxV3 != null) {
            i10 = R.id.message;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                i10 = R.id.order_id;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView2 != null) {
                    i10 = R.id.time;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView3 != null) {
                        i10 = R.id.unread;
                        FrameLayout frameLayout = (FrameLayout) ViewBindings.findChildViewById(view, i10);
                        if (frameLayout != null) {
                            return new FiatloanItemNotifyBinding((RelativeLayout) view, gTCheckBoxV3, textView, textView2, textView3, frameLayout);
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanItemNotifyBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_item_notify, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private FiatloanItemNotifyBinding(@NonNull RelativeLayout relativeLayout, @NonNull GTCheckBoxV3 gTCheckBoxV3, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull FrameLayout frameLayout) {
        this.rootView = relativeLayout;
        this.check = gTCheckBoxV3;
        this.message = textView;
        this.orderId = textView2;
        this.time = textView3;
        this.unread = frameLayout;
    }
}