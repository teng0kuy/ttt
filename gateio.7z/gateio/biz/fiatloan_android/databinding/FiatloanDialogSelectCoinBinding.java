package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.fiatloan.view.SelectCoinHeader;
import com.gateio.lib.uikit.search.GTSearchViewV3;
import com.gateio.lib.uikit.state.GTEmptyViewV3;
import com.ruffian.library.widget.RLinearLayout;

/* loaded from: classes38.dex */
public final class FiatloanDialogSelectCoinBinding implements ViewBinding {

    @NonNull
    public final GTEmptyViewV3 emptyView;

    @NonNull
    public final SelectCoinHeader popupHeader;

    @NonNull
    private final RLinearLayout rootView;

    @NonNull
    public final RecyclerView rvPopup;

    @NonNull
    public final GTSearchViewV3 searchView;

    @NonNull
    public static FiatloanDialogSelectCoinBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanDialogSelectCoinBinding bind(@NonNull View view) {
        int i10 = R.id.empty_view;
        GTEmptyViewV3 gTEmptyViewV3 = (GTEmptyViewV3) ViewBindings.findChildViewById(view, i10);
        if (gTEmptyViewV3 != null) {
            i10 = R.id.popup_header;
            SelectCoinHeader selectCoinHeader = (SelectCoinHeader) ViewBindings.findChildViewById(view, i10);
            if (selectCoinHeader != null) {
                i10 = R.id.rv_popup;
                RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                if (recyclerView != null) {
                    i10 = R.id.search_view;
                    GTSearchViewV3 gTSearchViewV3 = (GTSearchViewV3) ViewBindings.findChildViewById(view, i10);
                    if (gTSearchViewV3 != null) {
                        return new FiatloanDialogSelectCoinBinding((RLinearLayout) view, gTEmptyViewV3, selectCoinHeader, recyclerView, gTSearchViewV3);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanDialogSelectCoinBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_dialog_select_coin, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RLinearLayout getRoot() {
        return this.rootView;
    }

    private FiatloanDialogSelectCoinBinding(@NonNull RLinearLayout rLinearLayout, @NonNull GTEmptyViewV3 gTEmptyViewV3, @NonNull SelectCoinHeader selectCoinHeader, @NonNull RecyclerView recyclerView, @NonNull GTSearchViewV3 gTSearchViewV3) {
        this.rootView = rLinearLayout;
        this.emptyView = gTEmptyViewV3;
        this.popupHeader = selectCoinHeader;
        this.rvPopup = recyclerView;
        this.searchView = gTSearchViewV3;
    }
}