package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.selector.GTSelectorViewV3;

/* loaded from: classes38.dex */
public final class FiatloanDialogMarketFilterBinding implements ViewBinding {

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final GTSelectorViewV3 selectorPayType;

    @NonNull
    public final GTSelectorViewV3 selectorPeriod;

    @NonNull
    public final GTSelectorViewV3 selectorSort;

    @NonNull
    public static FiatloanDialogMarketFilterBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanDialogMarketFilterBinding bind(@NonNull View view) {
        int i10 = R.id.selector_pay_type;
        GTSelectorViewV3 gTSelectorViewV3 = (GTSelectorViewV3) ViewBindings.findChildViewById(view, i10);
        if (gTSelectorViewV3 != null) {
            i10 = R.id.selector_period;
            GTSelectorViewV3 gTSelectorViewV32 = (GTSelectorViewV3) ViewBindings.findChildViewById(view, i10);
            if (gTSelectorViewV32 != null) {
                i10 = R.id.selector_sort;
                GTSelectorViewV3 gTSelectorViewV33 = (GTSelectorViewV3) ViewBindings.findChildViewById(view, i10);
                if (gTSelectorViewV33 != null) {
                    return new FiatloanDialogMarketFilterBinding((LinearLayout) view, gTSelectorViewV3, gTSelectorViewV32, gTSelectorViewV33);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanDialogMarketFilterBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_dialog_market_filter, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private FiatloanDialogMarketFilterBinding(@NonNull LinearLayout linearLayout, @NonNull GTSelectorViewV3 gTSelectorViewV3, @NonNull GTSelectorViewV3 gTSelectorViewV32, @NonNull GTSelectorViewV3 gTSelectorViewV33) {
        this.rootView = linearLayout;
        this.selectorPayType = gTSelectorViewV3;
        this.selectorPeriod = gTSelectorViewV32;
        this.selectorSort = gTSelectorViewV33;
    }
}