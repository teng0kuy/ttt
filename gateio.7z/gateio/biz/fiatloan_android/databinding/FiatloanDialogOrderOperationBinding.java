package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.reminder.GTReminderV3;

/* loaded from: classes38.dex */
public final class FiatloanDialogOrderOperationBinding implements ViewBinding {

    @NonNull
    public final TextView amount;

    @NonNull
    public final TextView amountLabel;

    @NonNull
    public final RelativeLayout amountLayout;

    @NonNull
    public final TextView interest;

    @NonNull
    public final TextView interestLabel;

    @NonNull
    public final RelativeLayout interestLayout;

    @NonNull
    public final TextView name;

    @NonNull
    public final TextView nameLabel;

    @NonNull
    public final RelativeLayout nameLayout;

    @NonNull
    public final TextView orderId;

    @NonNull
    public final TextView orderIdLabel;

    @NonNull
    public final RelativeLayout orderIdLayout;

    @NonNull
    public final TextView overdueInterest;

    @NonNull
    public final TextView overdueInterestLabel;

    @NonNull
    public final RelativeLayout overdueInterestLayout;

    @NonNull
    public final TextView periodCycle;

    @NonNull
    public final TextView periodCycleLabel;

    @NonNull
    public final RelativeLayout periodCycleLayout;

    @NonNull
    public final TextView pledgeType;

    @NonNull
    public final TextView pledgeTypeLabel;

    @NonNull
    public final RelativeLayout pledgeTypeLayout;

    @NonNull
    public final TextView principalInterest;

    @NonNull
    public final TextView principalInterestLabel;

    @NonNull
    public final RelativeLayout principalInterestLayout;

    @NonNull
    public final GTReminderV3 reminder;

    @NonNull
    public final TextView reminderLabel;

    @NonNull
    private final LinearLayout rootView;

    private FiatloanDialogOrderOperationBinding(@NonNull LinearLayout linearLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull RelativeLayout relativeLayout, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull RelativeLayout relativeLayout2, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull RelativeLayout relativeLayout3, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull RelativeLayout relativeLayout4, @NonNull TextView textView9, @NonNull TextView textView10, @NonNull RelativeLayout relativeLayout5, @NonNull TextView textView11, @NonNull TextView textView12, @NonNull RelativeLayout relativeLayout6, @NonNull TextView textView13, @NonNull TextView textView14, @NonNull RelativeLayout relativeLayout7, @NonNull TextView textView15, @NonNull TextView textView16, @NonNull RelativeLayout relativeLayout8, @NonNull GTReminderV3 gTReminderV3, @NonNull TextView textView17) {
        this.rootView = linearLayout;
        this.amount = textView;
        this.amountLabel = textView2;
        this.amountLayout = relativeLayout;
        this.interest = textView3;
        this.interestLabel = textView4;
        this.interestLayout = relativeLayout2;
        this.name = textView5;
        this.nameLabel = textView6;
        this.nameLayout = relativeLayout3;
        this.orderId = textView7;
        this.orderIdLabel = textView8;
        this.orderIdLayout = relativeLayout4;
        this.overdueInterest = textView9;
        this.overdueInterestLabel = textView10;
        this.overdueInterestLayout = relativeLayout5;
        this.periodCycle = textView11;
        this.periodCycleLabel = textView12;
        this.periodCycleLayout = relativeLayout6;
        this.pledgeType = textView13;
        this.pledgeTypeLabel = textView14;
        this.pledgeTypeLayout = relativeLayout7;
        this.principalInterest = textView15;
        this.principalInterestLabel = textView16;
        this.principalInterestLayout = relativeLayout8;
        this.reminder = gTReminderV3;
        this.reminderLabel = textView17;
    }

    @NonNull
    public static FiatloanDialogOrderOperationBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanDialogOrderOperationBinding bind(@NonNull View view) {
        int i10 = R.id.amount;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
        if (textView != null) {
            i10 = R.id.amount_label;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView2 != null) {
                i10 = R.id.amount_layout;
                RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                if (relativeLayout != null) {
                    i10 = R.id.interest;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView3 != null) {
                        i10 = R.id.interest_label;
                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView4 != null) {
                            i10 = R.id.interest_layout;
                            RelativeLayout relativeLayout2 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                            if (relativeLayout2 != null) {
                                i10 = R.id.name;
                                TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView5 != null) {
                                    i10 = R.id.name_label;
                                    TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView6 != null) {
                                        i10 = R.id.name_layout;
                                        RelativeLayout relativeLayout3 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                        if (relativeLayout3 != null) {
                                            i10 = R.id.order_id;
                                            TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView7 != null) {
                                                i10 = R.id.order_id_label;
                                                TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView8 != null) {
                                                    i10 = R.id.order_id_layout;
                                                    RelativeLayout relativeLayout4 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                    if (relativeLayout4 != null) {
                                                        i10 = R.id.overdue_interest;
                                                        TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                        if (textView9 != null) {
                                                            i10 = R.id.overdue_interest_label;
                                                            TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                            if (textView10 != null) {
                                                                i10 = R.id.overdue_interest_layout;
                                                                RelativeLayout relativeLayout5 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                                if (relativeLayout5 != null) {
                                                                    i10 = R.id.period_cycle;
                                                                    TextView textView11 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                    if (textView11 != null) {
                                                                        i10 = R.id.period_cycle_label;
                                                                        TextView textView12 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                        if (textView12 != null) {
                                                                            i10 = R.id.period_cycle_layout;
                                                                            RelativeLayout relativeLayout6 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                                            if (relativeLayout6 != null) {
                                                                                i10 = R.id.pledge_type;
                                                                                TextView textView13 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                if (textView13 != null) {
                                                                                    i10 = R.id.pledge_type_label;
                                                                                    TextView textView14 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                    if (textView14 != null) {
                                                                                        i10 = R.id.pledge_type_layout;
                                                                                        RelativeLayout relativeLayout7 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                                                        if (relativeLayout7 != null) {
                                                                                            i10 = R.id.principal_interest;
                                                                                            TextView textView15 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                            if (textView15 != null) {
                                                                                                i10 = R.id.principal_interest_label;
                                                                                                TextView textView16 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                if (textView16 != null) {
                                                                                                    i10 = R.id.principal_interest_layout;
                                                                                                    RelativeLayout relativeLayout8 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                    if (relativeLayout8 != null) {
                                                                                                        i10 = R.id.reminder;
                                                                                                        GTReminderV3 gTReminderV3 = (GTReminderV3) ViewBindings.findChildViewById(view, i10);
                                                                                                        if (gTReminderV3 != null) {
                                                                                                            i10 = R.id.reminder_label;
                                                                                                            TextView textView17 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                            if (textView17 != null) {
                                                                                                                return new FiatloanDialogOrderOperationBinding((LinearLayout) view, textView, textView2, relativeLayout, textView3, textView4, relativeLayout2, textView5, textView6, relativeLayout3, textView7, textView8, relativeLayout4, textView9, textView10, relativeLayout5, textView11, textView12, relativeLayout6, textView13, textView14, relativeLayout7, textView15, textView16, relativeLayout8, gTReminderV3, textView17);
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanDialogOrderOperationBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_dialog_order_operation, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }
}