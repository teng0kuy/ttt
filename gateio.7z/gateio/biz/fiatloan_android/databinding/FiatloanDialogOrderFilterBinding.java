package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.input.GTEditTextV3;
import com.gateio.lib.uikit.selector.GTSelectorViewV3;

/* loaded from: classes38.dex */
public final class FiatloanDialogOrderFilterBinding implements ViewBinding {

    @NonNull
    public final GTEditTextV3 endTime;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final GTSelectorViewV3 selectorPeriod;

    @NonNull
    public final GTSelectorViewV3 selectorStatus;

    @NonNull
    public final GTEditTextV3 startTime;

    @NonNull
    public static FiatloanDialogOrderFilterBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanDialogOrderFilterBinding bind(@NonNull View view) {
        int i10 = R.id.end_time;
        GTEditTextV3 gTEditTextV3 = (GTEditTextV3) ViewBindings.findChildViewById(view, i10);
        if (gTEditTextV3 != null) {
            i10 = R.id.selector_period;
            GTSelectorViewV3 gTSelectorViewV3 = (GTSelectorViewV3) ViewBindings.findChildViewById(view, i10);
            if (gTSelectorViewV3 != null) {
                i10 = R.id.selector_status;
                GTSelectorViewV3 gTSelectorViewV32 = (GTSelectorViewV3) ViewBindings.findChildViewById(view, i10);
                if (gTSelectorViewV32 != null) {
                    i10 = R.id.start_time;
                    GTEditTextV3 gTEditTextV32 = (GTEditTextV3) ViewBindings.findChildViewById(view, i10);
                    if (gTEditTextV32 != null) {
                        return new FiatloanDialogOrderFilterBinding((LinearLayout) view, gTEditTextV3, gTSelectorViewV3, gTSelectorViewV32, gTEditTextV32);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanDialogOrderFilterBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_dialog_order_filter, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private FiatloanDialogOrderFilterBinding(@NonNull LinearLayout linearLayout, @NonNull GTEditTextV3 gTEditTextV3, @NonNull GTSelectorViewV3 gTSelectorViewV3, @NonNull GTSelectorViewV3 gTSelectorViewV32, @NonNull GTEditTextV3 gTEditTextV32) {
        this.rootView = linearLayout;
        this.endTime = gTEditTextV3;
        this.selectorPeriod = gTSelectorViewV3;
        this.selectorStatus = gTSelectorViewV32;
        this.startTime = gTEditTextV32;
    }
}