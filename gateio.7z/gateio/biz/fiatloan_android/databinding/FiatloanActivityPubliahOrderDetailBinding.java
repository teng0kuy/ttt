package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.button.GTButtonV3;
import com.gateio.lib.uikit.switchview.GTSwitchV3;
import com.gateio.lib.uikit.title.GTTitleViewV3;
import com.gateio.uiComponent.GateIconFont;

/* loaded from: classes38.dex */
public final class FiatloanActivityPubliahOrderDetailBinding implements ViewBinding {

    @NonNull
    public final LinearLayout buttonLayout;

    @NonNull
    public final GTButtonV3 cancel;

    @NonNull
    public final FiatloanLayoutOrderDetailHeadBinding head;

    @NonNull
    public final TextView initialAmount;

    @NonNull
    public final TextView initialAmountLabel;

    @NonNull
    public final TextView limitAmount;

    @NonNull
    public final TextView limitLabel;

    @NonNull
    public final GTButtonV3 online;

    @NonNull
    public final TextView pledge;

    @NonNull
    public final TextView pledgeLabel;

    @NonNull
    public final View renewDivider;

    @NonNull
    public final GateIconFont renewIcon;

    @NonNull
    public final RelativeLayout renewLayout;

    @NonNull
    public final GTSwitchV3 renewSwitch;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final NestedScrollView scrollView;

    @NonNull
    public final GTTitleViewV3 title;

    private FiatloanActivityPubliahOrderDetailBinding(@NonNull LinearLayout linearLayout, @NonNull LinearLayout linearLayout2, @NonNull GTButtonV3 gTButtonV3, @NonNull FiatloanLayoutOrderDetailHeadBinding fiatloanLayoutOrderDetailHeadBinding, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull GTButtonV3 gTButtonV32, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull View view, @NonNull GateIconFont gateIconFont, @NonNull RelativeLayout relativeLayout, @NonNull GTSwitchV3 gTSwitchV3, @NonNull NestedScrollView nestedScrollView, @NonNull GTTitleViewV3 gTTitleViewV3) {
        this.rootView = linearLayout;
        this.buttonLayout = linearLayout2;
        this.cancel = gTButtonV3;
        this.head = fiatloanLayoutOrderDetailHeadBinding;
        this.initialAmount = textView;
        this.initialAmountLabel = textView2;
        this.limitAmount = textView3;
        this.limitLabel = textView4;
        this.online = gTButtonV32;
        this.pledge = textView5;
        this.pledgeLabel = textView6;
        this.renewDivider = view;
        this.renewIcon = gateIconFont;
        this.renewLayout = relativeLayout;
        this.renewSwitch = gTSwitchV3;
        this.scrollView = nestedScrollView;
        this.title = gTTitleViewV3;
    }

    @NonNull
    public static FiatloanActivityPubliahOrderDetailBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanActivityPubliahOrderDetailBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        int i10 = R.id.button_layout;
        LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
        if (linearLayout != null) {
            i10 = R.id.cancel;
            GTButtonV3 gTButtonV3 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
            if (gTButtonV3 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.head))) != null) {
                FiatloanLayoutOrderDetailHeadBinding fiatloanLayoutOrderDetailHeadBindingBind = FiatloanLayoutOrderDetailHeadBinding.bind(viewFindChildViewById);
                i10 = R.id.initial_amount;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView != null) {
                    i10 = R.id.initial_amount_label;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView2 != null) {
                        i10 = R.id.limit_amount;
                        TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView3 != null) {
                            i10 = R.id.limit_label;
                            TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView4 != null) {
                                i10 = R.id.online;
                                GTButtonV3 gTButtonV32 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                                if (gTButtonV32 != null) {
                                    i10 = R.id.pledge;
                                    TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView5 != null) {
                                        i10 = R.id.pledge_label;
                                        TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView6 != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i10 = R.id.renew_divider))) != null) {
                                            i10 = R.id.renew_icon;
                                            GateIconFont gateIconFont = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                            if (gateIconFont != null) {
                                                i10 = R.id.renew_layout;
                                                RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                if (relativeLayout != null) {
                                                    i10 = R.id.renew_switch;
                                                    GTSwitchV3 gTSwitchV3 = (GTSwitchV3) ViewBindings.findChildViewById(view, i10);
                                                    if (gTSwitchV3 != null) {
                                                        i10 = R.id.scroll_view;
                                                        NestedScrollView nestedScrollView = (NestedScrollView) ViewBindings.findChildViewById(view, i10);
                                                        if (nestedScrollView != null) {
                                                            i10 = R.id.title;
                                                            GTTitleViewV3 gTTitleViewV3 = (GTTitleViewV3) ViewBindings.findChildViewById(view, i10);
                                                            if (gTTitleViewV3 != null) {
                                                                return new FiatloanActivityPubliahOrderDetailBinding((LinearLayout) view, linearLayout, gTButtonV3, fiatloanLayoutOrderDetailHeadBindingBind, textView, textView2, textView3, textView4, gTButtonV32, textView5, textView6, viewFindChildViewById2, gateIconFont, relativeLayout, gTSwitchV3, nestedScrollView, gTTitleViewV3);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanActivityPubliahOrderDetailBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_activity_publiah_order_detail, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }
}