package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.common.view.CustomViewpager;
import com.gateio.lib.uikit.title.GTTitleViewV3;

/* loaded from: classes38.dex */
public final class FiatloanActivityOrderBinding implements ViewBinding {

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final GTTitleViewV3 title;

    @NonNull
    public final CustomViewpager viewpager;

    @NonNull
    public static FiatloanActivityOrderBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanActivityOrderBinding bind(@NonNull View view) {
        int i10 = R.id.title;
        GTTitleViewV3 gTTitleViewV3 = (GTTitleViewV3) ViewBindings.findChildViewById(view, i10);
        if (gTTitleViewV3 != null) {
            i10 = R.id.viewpager;
            CustomViewpager customViewpager = (CustomViewpager) ViewBindings.findChildViewById(view, i10);
            if (customViewpager != null) {
                return new FiatloanActivityOrderBinding((LinearLayout) view, gTTitleViewV3, customViewpager);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanActivityOrderBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_activity_order, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private FiatloanActivityOrderBinding(@NonNull LinearLayout linearLayout, @NonNull GTTitleViewV3 gTTitleViewV3, @NonNull CustomViewpager customViewpager) {
        this.rootView = linearLayout;
        this.title = gTTitleViewV3;
        this.viewpager = customViewpager;
    }
}