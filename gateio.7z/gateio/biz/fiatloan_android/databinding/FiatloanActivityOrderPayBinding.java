package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.common.view.GateioAvatarView;
import com.gateio.lib.uikit.alert.GTAlertV3;
import com.gateio.lib.uikit.button.GTButtonV3;
import com.gateio.lib.uikit.title.GTTitleViewV3;
import com.gateio.lib.uikit.widget.GTCheckBoxV3;
import com.gateio.uiComponent.GateIconFont;
import com.ruffian.library.widget.RView;

/* loaded from: classes38.dex */
public final class FiatloanActivityOrderPayBinding implements ViewBinding {

    @NonNull
    public final GTAlertV3 alert;

    @NonNull
    public final TextView aliAccount;

    @NonNull
    public final GateIconFont aliAccountCopy;

    @NonNull
    public final TextView aliAccountLabel;

    @NonNull
    public final RelativeLayout aliAccountLayout;

    @NonNull
    public final TextView aliAmount;

    @NonNull
    public final GateIconFont aliAmountCopy;

    @NonNull
    public final TextView aliAmountLabel;

    @NonNull
    public final GTCheckBoxV3 aliCheck;

    @NonNull
    public final RView aliColor;

    @NonNull
    public final RelativeLayout aliLabelLayout;

    @NonNull
    public final ImageView aliQrcode;

    @NonNull
    public final TextView aliRealName;

    @NonNull
    public final GateIconFont aliRealNameCopy;

    @NonNull
    public final TextView aliRealNameLabel;

    @NonNull
    public final GTButtonV3 appeal;

    @NonNull
    public final GateioAvatarView avatar;

    @NonNull
    public final TextView bankAccount;

    @NonNull
    public final GateIconFont bankAccountCopy;

    @NonNull
    public final TextView bankAccountLabel;

    @NonNull
    public final RelativeLayout bankAccountLayout;

    @NonNull
    public final TextView bankAmount;

    @NonNull
    public final GateIconFont bankAmountCopy;

    @NonNull
    public final TextView bankAmountLabel;

    @NonNull
    public final GTCheckBoxV3 bankCheck;

    @NonNull
    public final RView bankColor;

    @NonNull
    public final RelativeLayout bankLabelLayout;

    @NonNull
    public final TextView bankName;

    @NonNull
    public final GateIconFont bankNameCopy;

    @NonNull
    public final TextView bankNameLabel;

    @NonNull
    public final TextView bankRealName;

    @NonNull
    public final GateIconFont bankRealNameCopy;

    @NonNull
    public final TextView bankRealNameLabel;

    @NonNull
    public final LinearLayout buttonLayout;

    @NonNull
    public final TextView orderId;

    @NonNull
    public final GTButtonV3 pay;

    @NonNull
    public final TextView period;

    @NonNull
    public final TextView periodLabel;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final GTTitleViewV3 title;

    @NonNull
    public final TextView userName;

    @NonNull
    public final TextView wechatAccount;

    @NonNull
    public final GateIconFont wechatAccountCopy;

    @NonNull
    public final TextView wechatAccountLabel;

    @NonNull
    public final RelativeLayout wechatAccountLayout;

    @NonNull
    public final TextView wechatAmount;

    @NonNull
    public final GateIconFont wechatAmountCopy;

    @NonNull
    public final TextView wechatAmountLabel;

    @NonNull
    public final GTCheckBoxV3 wechatCheck;

    @NonNull
    public final RView wechatColor;

    @NonNull
    public final RelativeLayout wechatLabelLayout;

    @NonNull
    public final ImageView wechatQrcode;

    @NonNull
    public final TextView wechatRealName;

    @NonNull
    public final GateIconFont wechatRealNameCopy;

    @NonNull
    public final TextView wechatRealNameLabel;

    private FiatloanActivityOrderPayBinding(@NonNull LinearLayout linearLayout, @NonNull GTAlertV3 gTAlertV3, @NonNull TextView textView, @NonNull GateIconFont gateIconFont, @NonNull TextView textView2, @NonNull RelativeLayout relativeLayout, @NonNull TextView textView3, @NonNull GateIconFont gateIconFont2, @NonNull TextView textView4, @NonNull GTCheckBoxV3 gTCheckBoxV3, @NonNull RView rView, @NonNull RelativeLayout relativeLayout2, @NonNull ImageView imageView, @NonNull TextView textView5, @NonNull GateIconFont gateIconFont3, @NonNull TextView textView6, @NonNull GTButtonV3 gTButtonV3, @NonNull GateioAvatarView gateioAvatarView, @NonNull TextView textView7, @NonNull GateIconFont gateIconFont4, @NonNull TextView textView8, @NonNull RelativeLayout relativeLayout3, @NonNull TextView textView9, @NonNull GateIconFont gateIconFont5, @NonNull TextView textView10, @NonNull GTCheckBoxV3 gTCheckBoxV32, @NonNull RView rView2, @NonNull RelativeLayout relativeLayout4, @NonNull TextView textView11, @NonNull GateIconFont gateIconFont6, @NonNull TextView textView12, @NonNull TextView textView13, @NonNull GateIconFont gateIconFont7, @NonNull TextView textView14, @NonNull LinearLayout linearLayout2, @NonNull TextView textView15, @NonNull GTButtonV3 gTButtonV32, @NonNull TextView textView16, @NonNull TextView textView17, @NonNull GTTitleViewV3 gTTitleViewV3, @NonNull TextView textView18, @NonNull TextView textView19, @NonNull GateIconFont gateIconFont8, @NonNull TextView textView20, @NonNull RelativeLayout relativeLayout5, @NonNull TextView textView21, @NonNull GateIconFont gateIconFont9, @NonNull TextView textView22, @NonNull GTCheckBoxV3 gTCheckBoxV33, @NonNull RView rView3, @NonNull RelativeLayout relativeLayout6, @NonNull ImageView imageView2, @NonNull TextView textView23, @NonNull GateIconFont gateIconFont10, @NonNull TextView textView24) {
        this.rootView = linearLayout;
        this.alert = gTAlertV3;
        this.aliAccount = textView;
        this.aliAccountCopy = gateIconFont;
        this.aliAccountLabel = textView2;
        this.aliAccountLayout = relativeLayout;
        this.aliAmount = textView3;
        this.aliAmountCopy = gateIconFont2;
        this.aliAmountLabel = textView4;
        this.aliCheck = gTCheckBoxV3;
        this.aliColor = rView;
        this.aliLabelLayout = relativeLayout2;
        this.aliQrcode = imageView;
        this.aliRealName = textView5;
        this.aliRealNameCopy = gateIconFont3;
        this.aliRealNameLabel = textView6;
        this.appeal = gTButtonV3;
        this.avatar = gateioAvatarView;
        this.bankAccount = textView7;
        this.bankAccountCopy = gateIconFont4;
        this.bankAccountLabel = textView8;
        this.bankAccountLayout = relativeLayout3;
        this.bankAmount = textView9;
        this.bankAmountCopy = gateIconFont5;
        this.bankAmountLabel = textView10;
        this.bankCheck = gTCheckBoxV32;
        this.bankColor = rView2;
        this.bankLabelLayout = relativeLayout4;
        this.bankName = textView11;
        this.bankNameCopy = gateIconFont6;
        this.bankNameLabel = textView12;
        this.bankRealName = textView13;
        this.bankRealNameCopy = gateIconFont7;
        this.bankRealNameLabel = textView14;
        this.buttonLayout = linearLayout2;
        this.orderId = textView15;
        this.pay = gTButtonV32;
        this.period = textView16;
        this.periodLabel = textView17;
        this.title = gTTitleViewV3;
        this.userName = textView18;
        this.wechatAccount = textView19;
        this.wechatAccountCopy = gateIconFont8;
        this.wechatAccountLabel = textView20;
        this.wechatAccountLayout = relativeLayout5;
        this.wechatAmount = textView21;
        this.wechatAmountCopy = gateIconFont9;
        this.wechatAmountLabel = textView22;
        this.wechatCheck = gTCheckBoxV33;
        this.wechatColor = rView3;
        this.wechatLabelLayout = relativeLayout6;
        this.wechatQrcode = imageView2;
        this.wechatRealName = textView23;
        this.wechatRealNameCopy = gateIconFont10;
        this.wechatRealNameLabel = textView24;
    }

    @NonNull
    public static FiatloanActivityOrderPayBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanActivityOrderPayBinding bind(@NonNull View view) {
        int i10 = R.id.alert;
        GTAlertV3 gTAlertV3 = (GTAlertV3) ViewBindings.findChildViewById(view, i10);
        if (gTAlertV3 != null) {
            i10 = R.id.ali_account;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                i10 = R.id.ali_account_copy;
                GateIconFont gateIconFont = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                if (gateIconFont != null) {
                    i10 = R.id.ali_account_label;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView2 != null) {
                        i10 = R.id.ali_account_layout;
                        RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                        if (relativeLayout != null) {
                            i10 = R.id.ali_amount;
                            TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView3 != null) {
                                i10 = R.id.ali_amount_copy;
                                GateIconFont gateIconFont2 = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                if (gateIconFont2 != null) {
                                    i10 = R.id.ali_amount_label;
                                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView4 != null) {
                                        i10 = R.id.ali_check;
                                        GTCheckBoxV3 gTCheckBoxV3 = (GTCheckBoxV3) ViewBindings.findChildViewById(view, i10);
                                        if (gTCheckBoxV3 != null) {
                                            i10 = R.id.ali_color;
                                            RView rView = (RView) ViewBindings.findChildViewById(view, i10);
                                            if (rView != null) {
                                                i10 = R.id.ali_label_layout;
                                                RelativeLayout relativeLayout2 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                if (relativeLayout2 != null) {
                                                    i10 = R.id.ali_qrcode;
                                                    ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
                                                    if (imageView != null) {
                                                        i10 = R.id.ali_real_name;
                                                        TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                        if (textView5 != null) {
                                                            i10 = R.id.ali_real_name_copy;
                                                            GateIconFont gateIconFont3 = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                                            if (gateIconFont3 != null) {
                                                                i10 = R.id.ali_real_name_label;
                                                                TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                if (textView6 != null) {
                                                                    i10 = R.id.appeal;
                                                                    GTButtonV3 gTButtonV3 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                                                                    if (gTButtonV3 != null) {
                                                                        i10 = R.id.avatar;
                                                                        GateioAvatarView gateioAvatarView = (GateioAvatarView) ViewBindings.findChildViewById(view, i10);
                                                                        if (gateioAvatarView != null) {
                                                                            i10 = R.id.bank_account;
                                                                            TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                            if (textView7 != null) {
                                                                                i10 = R.id.bank_account_copy;
                                                                                GateIconFont gateIconFont4 = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                                                                if (gateIconFont4 != null) {
                                                                                    i10 = R.id.bank_account_label;
                                                                                    TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                    if (textView8 != null) {
                                                                                        i10 = R.id.bank_account_layout;
                                                                                        RelativeLayout relativeLayout3 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                                                        if (relativeLayout3 != null) {
                                                                                            i10 = R.id.bank_amount;
                                                                                            TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                            if (textView9 != null) {
                                                                                                i10 = R.id.bank_amount_copy;
                                                                                                GateIconFont gateIconFont5 = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                                                                                if (gateIconFont5 != null) {
                                                                                                    i10 = R.id.bank_amount_label;
                                                                                                    TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                    if (textView10 != null) {
                                                                                                        i10 = R.id.bank_check;
                                                                                                        GTCheckBoxV3 gTCheckBoxV32 = (GTCheckBoxV3) ViewBindings.findChildViewById(view, i10);
                                                                                                        if (gTCheckBoxV32 != null) {
                                                                                                            i10 = R.id.bank_color;
                                                                                                            RView rView2 = (RView) ViewBindings.findChildViewById(view, i10);
                                                                                                            if (rView2 != null) {
                                                                                                                i10 = R.id.bank_label_layout;
                                                                                                                RelativeLayout relativeLayout4 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                                if (relativeLayout4 != null) {
                                                                                                                    i10 = R.id.bank_name;
                                                                                                                    TextView textView11 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                    if (textView11 != null) {
                                                                                                                        i10 = R.id.bank_name_copy;
                                                                                                                        GateIconFont gateIconFont6 = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                                                                                                        if (gateIconFont6 != null) {
                                                                                                                            i10 = R.id.bank_name_label;
                                                                                                                            TextView textView12 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                            if (textView12 != null) {
                                                                                                                                i10 = R.id.bank_real_name;
                                                                                                                                TextView textView13 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                if (textView13 != null) {
                                                                                                                                    i10 = R.id.bank_real_name_copy;
                                                                                                                                    GateIconFont gateIconFont7 = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                                                                                                                    if (gateIconFont7 != null) {
                                                                                                                                        i10 = R.id.bank_real_name_label;
                                                                                                                                        TextView textView14 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                        if (textView14 != null) {
                                                                                                                                            i10 = R.id.button_layout;
                                                                                                                                            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                                                            if (linearLayout != null) {
                                                                                                                                                i10 = R.id.order_id;
                                                                                                                                                TextView textView15 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                if (textView15 != null) {
                                                                                                                                                    i10 = R.id.pay;
                                                                                                                                                    GTButtonV3 gTButtonV32 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                    if (gTButtonV32 != null) {
                                                                                                                                                        i10 = R.id.period;
                                                                                                                                                        TextView textView16 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                        if (textView16 != null) {
                                                                                                                                                            i10 = R.id.period_label;
                                                                                                                                                            TextView textView17 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                            if (textView17 != null) {
                                                                                                                                                                i10 = R.id.title;
                                                                                                                                                                GTTitleViewV3 gTTitleViewV3 = (GTTitleViewV3) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                if (gTTitleViewV3 != null) {
                                                                                                                                                                    i10 = R.id.user_name;
                                                                                                                                                                    TextView textView18 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                    if (textView18 != null) {
                                                                                                                                                                        i10 = R.id.wechat_account;
                                                                                                                                                                        TextView textView19 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                        if (textView19 != null) {
                                                                                                                                                                            i10 = R.id.wechat_account_copy;
                                                                                                                                                                            GateIconFont gateIconFont8 = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                            if (gateIconFont8 != null) {
                                                                                                                                                                                i10 = R.id.wechat_account_label;
                                                                                                                                                                                TextView textView20 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                if (textView20 != null) {
                                                                                                                                                                                    i10 = R.id.wechat_account_layout;
                                                                                                                                                                                    RelativeLayout relativeLayout5 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                    if (relativeLayout5 != null) {
                                                                                                                                                                                        i10 = R.id.wechat_amount;
                                                                                                                                                                                        TextView textView21 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                        if (textView21 != null) {
                                                                                                                                                                                            i10 = R.id.wechat_amount_copy;
                                                                                                                                                                                            GateIconFont gateIconFont9 = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                            if (gateIconFont9 != null) {
                                                                                                                                                                                                i10 = R.id.wechat_amount_label;
                                                                                                                                                                                                TextView textView22 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                                if (textView22 != null) {
                                                                                                                                                                                                    i10 = R.id.wechat_check;
                                                                                                                                                                                                    GTCheckBoxV3 gTCheckBoxV33 = (GTCheckBoxV3) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                                    if (gTCheckBoxV33 != null) {
                                                                                                                                                                                                        i10 = R.id.wechat_color;
                                                                                                                                                                                                        RView rView3 = (RView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                                        if (rView3 != null) {
                                                                                                                                                                                                            i10 = R.id.wechat_label_layout;
                                                                                                                                                                                                            RelativeLayout relativeLayout6 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                                            if (relativeLayout6 != null) {
                                                                                                                                                                                                                i10 = R.id.wechat_qrcode;
                                                                                                                                                                                                                ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                                                if (imageView2 != null) {
                                                                                                                                                                                                                    i10 = R.id.wechat_real_name;
                                                                                                                                                                                                                    TextView textView23 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                                                    if (textView23 != null) {
                                                                                                                                                                                                                        i10 = R.id.wechat_real_name_copy;
                                                                                                                                                                                                                        GateIconFont gateIconFont10 = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                                                        if (gateIconFont10 != null) {
                                                                                                                                                                                                                            i10 = R.id.wechat_real_name_label;
                                                                                                                                                                                                                            TextView textView24 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                                                            if (textView24 != null) {
                                                                                                                                                                                                                                return new FiatloanActivityOrderPayBinding((LinearLayout) view, gTAlertV3, textView, gateIconFont, textView2, relativeLayout, textView3, gateIconFont2, textView4, gTCheckBoxV3, rView, relativeLayout2, imageView, textView5, gateIconFont3, textView6, gTButtonV3, gateioAvatarView, textView7, gateIconFont4, textView8, relativeLayout3, textView9, gateIconFont5, textView10, gTCheckBoxV32, rView2, relativeLayout4, textView11, gateIconFont6, textView12, textView13, gateIconFont7, textView14, linearLayout, textView15, gTButtonV32, textView16, textView17, gTTitleViewV3, textView18, textView19, gateIconFont8, textView20, relativeLayout5, textView21, gateIconFont9, textView22, gTCheckBoxV33, rView3, relativeLayout6, imageView2, textView23, gateIconFont10, textView24);
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                        }
                                                                                                                                                                                                    }
                                                                                                                                                                                                }
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    }
                                                                                                                                                                                }
                                                                                                                                                                            }
                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanActivityOrderPayBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_activity_order_pay, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }
}