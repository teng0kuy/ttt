package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.fiatloan.view.MaxHeightRecyclerView;
import com.gateio.lib.uikit.button.GTButtonV3;
import com.gateio.lib.uikit.state.GTEmptyViewV3;
import com.gateio.lib.uikit.widget.GTCheckBoxV3;
import com.gateio.uiComponent.GateIconFont;

/* loaded from: classes38.dex */
public final class FiatloanFragmentFlexibleAddCollateralBinding implements ViewBinding {

    @NonNull
    public final GTButtonV3 addCollateral;

    @NonNull
    public final LinearLayout addCollateralContainer;

    @NonNull
    public final MaxHeightRecyclerView addCollateralInfo;

    @NonNull
    public final TextView addCollateralRate;

    @NonNull
    public final TextView addCollateralRateLabel;

    @NonNull
    public final LinearLayout addCollateralTitle;

    @NonNull
    public final TextView currentRate;

    @NonNull
    public final TextView currentRateLabel;

    @NonNull
    public final GateIconFont edit;

    @NonNull
    public final GTEmptyViewV3 empty;

    @NonNull
    public final ConstraintLayout pledgeRateLayout;

    @NonNull
    public final RecyclerView recyclerView;

    @NonNull
    private final ConstraintLayout rootView;

    @NonNull
    public final GTCheckBoxV3 selectAllBtn;

    @NonNull
    public final TextView selectedCountTx;

    @NonNull
    public static FiatloanFragmentFlexibleAddCollateralBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanFragmentFlexibleAddCollateralBinding bind(@NonNull View view) {
        int i10 = R.id.add_collateral;
        GTButtonV3 gTButtonV3 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
        if (gTButtonV3 != null) {
            i10 = R.id.add_collateral_container;
            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
            if (linearLayout != null) {
                i10 = R.id.add_collateral_info;
                MaxHeightRecyclerView maxHeightRecyclerView = (MaxHeightRecyclerView) ViewBindings.findChildViewById(view, i10);
                if (maxHeightRecyclerView != null) {
                    i10 = R.id.add_collateral_rate;
                    TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView != null) {
                        i10 = R.id.add_collateral_rate_label;
                        TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView2 != null) {
                            i10 = R.id.add_collateral_title;
                            LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                            if (linearLayout2 != null) {
                                i10 = R.id.current_rate;
                                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView3 != null) {
                                    i10 = R.id.current_rate_label;
                                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView4 != null) {
                                        i10 = R.id.edit;
                                        GateIconFont gateIconFont = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                        if (gateIconFont != null) {
                                            i10 = R.id.empty;
                                            GTEmptyViewV3 gTEmptyViewV3 = (GTEmptyViewV3) ViewBindings.findChildViewById(view, i10);
                                            if (gTEmptyViewV3 != null) {
                                                i10 = R.id.pledge_rate_layout;
                                                ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(view, i10);
                                                if (constraintLayout != null) {
                                                    i10 = R.id.recycler_view;
                                                    RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                                                    if (recyclerView != null) {
                                                        i10 = R.id.select_all_btn;
                                                        GTCheckBoxV3 gTCheckBoxV3 = (GTCheckBoxV3) ViewBindings.findChildViewById(view, i10);
                                                        if (gTCheckBoxV3 != null) {
                                                            i10 = R.id.selected_count_tx;
                                                            TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                            if (textView5 != null) {
                                                                return new FiatloanFragmentFlexibleAddCollateralBinding((ConstraintLayout) view, gTButtonV3, linearLayout, maxHeightRecyclerView, textView, textView2, linearLayout2, textView3, textView4, gateIconFont, gTEmptyViewV3, constraintLayout, recyclerView, gTCheckBoxV3, textView5);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanFragmentFlexibleAddCollateralBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_fragment_flexible_add_collateral, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    private FiatloanFragmentFlexibleAddCollateralBinding(@NonNull ConstraintLayout constraintLayout, @NonNull GTButtonV3 gTButtonV3, @NonNull LinearLayout linearLayout, @NonNull MaxHeightRecyclerView maxHeightRecyclerView, @NonNull TextView textView, @NonNull TextView textView2, @NonNull LinearLayout linearLayout2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull GateIconFont gateIconFont, @NonNull GTEmptyViewV3 gTEmptyViewV3, @NonNull ConstraintLayout constraintLayout2, @NonNull RecyclerView recyclerView, @NonNull GTCheckBoxV3 gTCheckBoxV3, @NonNull TextView textView5) {
        this.rootView = constraintLayout;
        this.addCollateral = gTButtonV3;
        this.addCollateralContainer = linearLayout;
        this.addCollateralInfo = maxHeightRecyclerView;
        this.addCollateralRate = textView;
        this.addCollateralRateLabel = textView2;
        this.addCollateralTitle = linearLayout2;
        this.currentRate = textView3;
        this.currentRateLabel = textView4;
        this.edit = gateIconFont;
        this.empty = gTEmptyViewV3;
        this.pledgeRateLayout = constraintLayout2;
        this.recyclerView = recyclerView;
        this.selectAllBtn = gTCheckBoxV3;
        this.selectedCountTx = textView5;
    }
}