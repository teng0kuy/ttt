package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.widget.GTCheckBoxV3;

/* loaded from: classes38.dex */
public final class FiatloanItemPayMethodBinding implements ViewBinding {

    @NonNull
    public final TextView payAccount;

    @NonNull
    public final GTCheckBoxV3 payCheck;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public static FiatloanItemPayMethodBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanItemPayMethodBinding bind(@NonNull View view) {
        int i10 = R.id.pay_account;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
        if (textView != null) {
            i10 = R.id.pay_check;
            GTCheckBoxV3 gTCheckBoxV3 = (GTCheckBoxV3) ViewBindings.findChildViewById(view, i10);
            if (gTCheckBoxV3 != null) {
                return new FiatloanItemPayMethodBinding((LinearLayout) view, textView, gTCheckBoxV3);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanItemPayMethodBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_item_pay_method, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private FiatloanItemPayMethodBinding(@NonNull LinearLayout linearLayout, @NonNull TextView textView, @NonNull GTCheckBoxV3 gTCheckBoxV3) {
        this.rootView = linearLayout;
        this.payAccount = textView;
        this.payCheck = gTCheckBoxV3;
    }
}