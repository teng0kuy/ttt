package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.reminder.GTReminderV3;

/* loaded from: classes38.dex */
public final class FiatloanItemChatRiskBinding implements ViewBinding {

    @NonNull
    public final GTReminderV3 reminder;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final TextView time;

    @NonNull
    public static FiatloanItemChatRiskBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanItemChatRiskBinding bind(@NonNull View view) {
        int i10 = R.id.reminder;
        GTReminderV3 gTReminderV3 = (GTReminderV3) ViewBindings.findChildViewById(view, i10);
        if (gTReminderV3 != null) {
            i10 = R.id.time;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                return new FiatloanItemChatRiskBinding((LinearLayout) view, gTReminderV3, textView);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanItemChatRiskBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_item_chat_risk, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private FiatloanItemChatRiskBinding(@NonNull LinearLayout linearLayout, @NonNull GTReminderV3 gTReminderV3, @NonNull TextView textView) {
        this.rootView = linearLayout;
        this.reminder = gTReminderV3;
        this.time = textView;
    }
}