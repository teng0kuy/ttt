package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.widget.GTCheckBoxV3;

/* loaded from: classes38.dex */
public final class FiatloanItemFlexibleAddCollateralBinding implements ViewBinding {

    @NonNull
    public final TextView addCollateralAmount;

    @NonNull
    public final TextView addCollateralAmountLabel;

    @NonNull
    public final TextView amount;

    @NonNull
    public final TextView amountLabel;

    @NonNull
    public final GTCheckBoxV3 check;

    @NonNull
    public final View divider;

    @NonNull
    public final TextView orderId;

    @NonNull
    public final TextView pledgeAmount;

    @NonNull
    public final TextView pledgeAmountLabel;

    @NonNull
    public final TextView pledgeRate;

    @NonNull
    public final TextView pledgeRateLabel;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public static FiatloanItemFlexibleAddCollateralBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanItemFlexibleAddCollateralBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.add_collateral_amount;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
        if (textView != null) {
            i10 = R.id.add_collateral_amount_label;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView2 != null) {
                i10 = R.id.amount;
                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView3 != null) {
                    i10 = R.id.amount_label;
                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView4 != null) {
                        i10 = R.id.check;
                        GTCheckBoxV3 gTCheckBoxV3 = (GTCheckBoxV3) ViewBindings.findChildViewById(view, i10);
                        if (gTCheckBoxV3 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.divider))) != null) {
                            i10 = R.id.order_id;
                            TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView5 != null) {
                                i10 = R.id.pledge_amount;
                                TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView6 != null) {
                                    i10 = R.id.pledge_amount_label;
                                    TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView7 != null) {
                                        i10 = R.id.pledge_rate;
                                        TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView8 != null) {
                                            i10 = R.id.pledge_rate_label;
                                            TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView9 != null) {
                                                return new FiatloanItemFlexibleAddCollateralBinding((RelativeLayout) view, textView, textView2, textView3, textView4, gTCheckBoxV3, viewFindChildViewById, textView5, textView6, textView7, textView8, textView9);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanItemFlexibleAddCollateralBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_item_flexible_add_collateral, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private FiatloanItemFlexibleAddCollateralBinding(@NonNull RelativeLayout relativeLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull GTCheckBoxV3 gTCheckBoxV3, @NonNull View view, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textView9) {
        this.rootView = relativeLayout;
        this.addCollateralAmount = textView;
        this.addCollateralAmountLabel = textView2;
        this.amount = textView3;
        this.amountLabel = textView4;
        this.check = gTCheckBoxV3;
        this.divider = view;
        this.orderId = textView5;
        this.pledgeAmount = textView6;
        this.pledgeAmountLabel = textView7;
        this.pledgeRate = textView8;
        this.pledgeRateLabel = textView9;
    }
}