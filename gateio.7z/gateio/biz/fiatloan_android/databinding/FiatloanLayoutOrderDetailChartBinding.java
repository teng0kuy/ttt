package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.sparkhuu.klinelib.chart.FlowBarChart;

/* loaded from: classes38.dex */
public final class FiatloanLayoutOrderDetailChartBinding implements ViewBinding {

    @NonNull
    public final TextView closePrice;

    @NonNull
    public final TextView closePriceLabel;

    @NonNull
    public final TextView currentPrice;

    @NonNull
    public final TextView currentPriceLabel;

    @NonNull
    public final View divider;

    @NonNull
    public final TextView label;

    @NonNull
    public final FlowBarChart pledgeChart;

    @NonNull
    public final TextView pledgeType;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final TextView tip;

    @NonNull
    public final TextView unitPrice;

    @NonNull
    public final TextView warningPrice;

    @NonNull
    public final TextView warningPriceLabel;

    @NonNull
    public static FiatloanLayoutOrderDetailChartBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanLayoutOrderDetailChartBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.close_price;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
        if (textView != null) {
            i10 = R.id.close_price_label;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView2 != null) {
                i10 = R.id.current_price;
                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView3 != null) {
                    i10 = R.id.current_price_label;
                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView4 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.divider))) != null) {
                        i10 = R.id.label;
                        TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView5 != null) {
                            i10 = R.id.pledge_chart;
                            FlowBarChart flowBarChart = (FlowBarChart) ViewBindings.findChildViewById(view, i10);
                            if (flowBarChart != null) {
                                i10 = R.id.pledge_type;
                                TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView6 != null) {
                                    i10 = R.id.tip;
                                    TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView7 != null) {
                                        i10 = R.id.unit_price;
                                        TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView8 != null) {
                                            i10 = R.id.warning_price;
                                            TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView9 != null) {
                                                i10 = R.id.warning_price_label;
                                                TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView10 != null) {
                                                    return new FiatloanLayoutOrderDetailChartBinding((RelativeLayout) view, textView, textView2, textView3, textView4, viewFindChildViewById, textView5, flowBarChart, textView6, textView7, textView8, textView9, textView10);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanLayoutOrderDetailChartBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_layout_order_detail_chart, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private FiatloanLayoutOrderDetailChartBinding(@NonNull RelativeLayout relativeLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull View view, @NonNull TextView textView5, @NonNull FlowBarChart flowBarChart, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textView9, @NonNull TextView textView10) {
        this.rootView = relativeLayout;
        this.closePrice = textView;
        this.closePriceLabel = textView2;
        this.currentPrice = textView3;
        this.currentPriceLabel = textView4;
        this.divider = view;
        this.label = textView5;
        this.pledgeChart = flowBarChart;
        this.pledgeType = textView6;
        this.tip = textView7;
        this.unitPrice = textView8;
        this.warningPrice = textView9;
        this.warningPriceLabel = textView10;
    }
}