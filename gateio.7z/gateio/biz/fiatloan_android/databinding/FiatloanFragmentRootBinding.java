package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.button.GTButtonV3;
import com.gateio.lib.uikit.number.GTNumberViewV3;
import com.gateio.uiComponent.GateIconFont;
import com.google.android.material.appbar.AppBarLayout;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;

/* loaded from: classes38.dex */
public final class FiatloanFragmentRootBinding implements ViewBinding {

    @NonNull
    public final LinearLayout addCollateralManage;

    @NonNull
    public final AppBarLayout appBar;

    @NonNull
    public final GTNumberViewV3 currentAmount;

    @NonNull
    public final LinearLayout currentOrder;

    @NonNull
    public final TextView currentOrderLabel;

    @NonNull
    public final GateIconFont filter;

    @NonNull
    public final LinearLayout head;

    @NonNull
    public final LinearLayout historyOrder;

    @NonNull
    public final TextView historyOrderLabel;

    @NonNull
    public final TextView marketLabel;

    @NonNull
    public final LinearLayout myOrder;

    @NonNull
    public final TextView myOrderLabel;

    @NonNull
    public final GTNumberViewV3 paymentDate;

    @NonNull
    public final GTButtonV3 publish;

    @NonNull
    public final RecyclerView recyclerView;

    @NonNull
    public final SmartRefreshLayout refresh;

    @NonNull
    private final SmartRefreshLayout rootView;

    @NonNull
    public final GTNumberViewV3 totalAmount;

    @NonNull
    public final GTNumberViewV3 totalInterest;

    private FiatloanFragmentRootBinding(@NonNull SmartRefreshLayout smartRefreshLayout, @NonNull LinearLayout linearLayout, @NonNull AppBarLayout appBarLayout, @NonNull GTNumberViewV3 gTNumberViewV3, @NonNull LinearLayout linearLayout2, @NonNull TextView textView, @NonNull GateIconFont gateIconFont, @NonNull LinearLayout linearLayout3, @NonNull LinearLayout linearLayout4, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull LinearLayout linearLayout5, @NonNull TextView textView4, @NonNull GTNumberViewV3 gTNumberViewV32, @NonNull GTButtonV3 gTButtonV3, @NonNull RecyclerView recyclerView, @NonNull SmartRefreshLayout smartRefreshLayout2, @NonNull GTNumberViewV3 gTNumberViewV33, @NonNull GTNumberViewV3 gTNumberViewV34) {
        this.rootView = smartRefreshLayout;
        this.addCollateralManage = linearLayout;
        this.appBar = appBarLayout;
        this.currentAmount = gTNumberViewV3;
        this.currentOrder = linearLayout2;
        this.currentOrderLabel = textView;
        this.filter = gateIconFont;
        this.head = linearLayout3;
        this.historyOrder = linearLayout4;
        this.historyOrderLabel = textView2;
        this.marketLabel = textView3;
        this.myOrder = linearLayout5;
        this.myOrderLabel = textView4;
        this.paymentDate = gTNumberViewV32;
        this.publish = gTButtonV3;
        this.recyclerView = recyclerView;
        this.refresh = smartRefreshLayout2;
        this.totalAmount = gTNumberViewV33;
        this.totalInterest = gTNumberViewV34;
    }

    @NonNull
    public static FiatloanFragmentRootBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanFragmentRootBinding bind(@NonNull View view) {
        int i10 = R.id.add_collateral_manage;
        LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
        if (linearLayout != null) {
            i10 = R.id.app_bar;
            AppBarLayout appBarLayout = (AppBarLayout) ViewBindings.findChildViewById(view, i10);
            if (appBarLayout != null) {
                i10 = R.id.current_amount;
                GTNumberViewV3 gTNumberViewV3 = (GTNumberViewV3) ViewBindings.findChildViewById(view, i10);
                if (gTNumberViewV3 != null) {
                    i10 = R.id.current_order;
                    LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                    if (linearLayout2 != null) {
                        i10 = R.id.current_order_label;
                        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView != null) {
                            i10 = R.id.filter;
                            GateIconFont gateIconFont = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                            if (gateIconFont != null) {
                                i10 = R.id.head;
                                LinearLayout linearLayout3 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                if (linearLayout3 != null) {
                                    i10 = R.id.history_order;
                                    LinearLayout linearLayout4 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                    if (linearLayout4 != null) {
                                        i10 = R.id.history_order_label;
                                        TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView2 != null) {
                                            i10 = R.id.market_label;
                                            TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView3 != null) {
                                                i10 = R.id.my_order;
                                                LinearLayout linearLayout5 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                if (linearLayout5 != null) {
                                                    i10 = R.id.my_order_label;
                                                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                    if (textView4 != null) {
                                                        i10 = R.id.payment_date;
                                                        GTNumberViewV3 gTNumberViewV32 = (GTNumberViewV3) ViewBindings.findChildViewById(view, i10);
                                                        if (gTNumberViewV32 != null) {
                                                            i10 = R.id.publish;
                                                            GTButtonV3 gTButtonV3 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                                                            if (gTButtonV3 != null) {
                                                                i10 = R.id.recycler_view;
                                                                RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                                                                if (recyclerView != null) {
                                                                    SmartRefreshLayout smartRefreshLayout = (SmartRefreshLayout) view;
                                                                    i10 = R.id.total_amount;
                                                                    GTNumberViewV3 gTNumberViewV33 = (GTNumberViewV3) ViewBindings.findChildViewById(view, i10);
                                                                    if (gTNumberViewV33 != null) {
                                                                        i10 = R.id.total_interest;
                                                                        GTNumberViewV3 gTNumberViewV34 = (GTNumberViewV3) ViewBindings.findChildViewById(view, i10);
                                                                        if (gTNumberViewV34 != null) {
                                                                            return new FiatloanFragmentRootBinding(smartRefreshLayout, linearLayout, appBarLayout, gTNumberViewV3, linearLayout2, textView, gateIconFont, linearLayout3, linearLayout4, textView2, textView3, linearLayout5, textView4, gTNumberViewV32, gTButtonV3, recyclerView, smartRefreshLayout, gTNumberViewV33, gTNumberViewV34);
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanFragmentRootBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_fragment_root, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public SmartRefreshLayout getRoot() {
        return this.rootView;
    }
}