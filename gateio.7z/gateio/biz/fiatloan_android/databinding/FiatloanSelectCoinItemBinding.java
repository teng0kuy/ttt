package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.common.view.CircleImageView;
import com.gateio.uiComponent.GateIconFont;

/* loaded from: classes38.dex */
public final class FiatloanSelectCoinItemBinding implements ViewBinding {

    @NonNull
    public final CircleImageView ivCoin;

    @NonNull
    public final GateIconFont ivEnd;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final TextView tvEnd;

    @NonNull
    public final TextView tvSubTitle;

    @NonNull
    public final TextView tvTitle;

    @NonNull
    public static FiatloanSelectCoinItemBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanSelectCoinItemBinding bind(@NonNull View view) {
        int i10 = R.id.iv_coin;
        CircleImageView circleImageView = (CircleImageView) ViewBindings.findChildViewById(view, i10);
        if (circleImageView != null) {
            i10 = R.id.iv_end;
            GateIconFont gateIconFont = (GateIconFont) ViewBindings.findChildViewById(view, i10);
            if (gateIconFont != null) {
                i10 = R.id.tv_end;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView != null) {
                    i10 = R.id.tv_sub_title;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView2 != null) {
                        i10 = R.id.tv_title;
                        TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView3 != null) {
                            return new FiatloanSelectCoinItemBinding((LinearLayout) view, circleImageView, gateIconFont, textView, textView2, textView3);
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanSelectCoinItemBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_select_coin_item, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private FiatloanSelectCoinItemBinding(@NonNull LinearLayout linearLayout, @NonNull CircleImageView circleImageView, @NonNull GateIconFont gateIconFont, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3) {
        this.rootView = linearLayout;
        this.ivCoin = circleImageView;
        this.ivEnd = gateIconFont;
        this.tvEnd = textView;
        this.tvSubTitle = textView2;
        this.tvTitle = textView3;
    }
}