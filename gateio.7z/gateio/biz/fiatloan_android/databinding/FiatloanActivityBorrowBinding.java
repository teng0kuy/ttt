package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.alert.GTAlertV3;
import com.gateio.lib.uikit.button.GTButtonV3;
import com.gateio.lib.uikit.input.GTEditTextV3;
import com.gateio.lib.uikit.reminder.GTReminderV3;
import com.gateio.lib.uikit.selector.GTSelectorViewV3;
import com.gateio.lib.uikit.text.DashTextViewV3;
import com.gateio.lib.uikit.title.GTTitleViewV3;
import com.gateio.lib.uikit.widget.GTCheckBoxV3;
import com.gateio.uiComponent.GateIconFont;
import com.ruffian.library.widget.RView;

/* loaded from: classes38.dex */
public final class FiatloanActivityBorrowBinding implements ViewBinding {

    @NonNull
    public final GTCheckBoxV3 agreement;

    @NonNull
    public final EditText amountInput;

    @NonNull
    public final TextView amountLabel;

    @NonNull
    public final TextView amountRange;

    @NonNull
    public final GTSelectorViewV3 amountSelector;

    @NonNull
    public final TextView annualizedRate;

    @NonNull
    public final TextView available;

    @NonNull
    public final DashTextViewV3 availableLabel;

    @NonNull
    public final TextView dailyRate;

    @NonNull
    public final TextView dueInterest;

    @NonNull
    public final TextView dueInterestLabel;

    @NonNull
    public final TextView dueTotal;

    @NonNull
    public final TextView dueTotalLabel;

    @NonNull
    public final TextView fee;

    @NonNull
    public final LinearLayout feeLayout;

    @NonNull
    public final LinearLayout llBottom;

    @NonNull
    public final GTButtonV3 minus;

    @NonNull
    public final GTReminderV3 noPayMethodTip;

    @NonNull
    public final LinearLayout payMethodAli;

    @NonNull
    public final TextView payMethodAliAccount;

    @NonNull
    public final RView payMethodAliColor;

    @NonNull
    public final GateIconFont payMethodArrow;

    @NonNull
    public final LinearLayout payMethodBank;

    @NonNull
    public final TextView payMethodBankAccount;

    @NonNull
    public final RView payMethodBankColor;

    @NonNull
    public final View payMethodDivider1;

    @NonNull
    public final View payMethodDivider2;

    @NonNull
    public final FrameLayout payMethodFrame;

    @NonNull
    public final LinearLayout payMethodLabelLayout;

    @NonNull
    public final LinearLayout payMethodLayout;

    @NonNull
    public final LinearLayout payMethodSelect;

    @NonNull
    public final LinearLayout payMethodWechat;

    @NonNull
    public final TextView payMethodWechatAccount;

    @NonNull
    public final RView payMethodWechatColor;

    @NonNull
    public final TextView period;

    @NonNull
    public final GTButtonV3 place;

    @NonNull
    public final GTAlertV3 pledgeAlert;

    @NonNull
    public final GTEditTextV3 pledgeAmount;

    @NonNull
    public final TextView pledgeLabel;

    @NonNull
    public final TextView pledgeRate;

    @NonNull
    public final TextView pledgeRateLabel;

    @NonNull
    public final RelativeLayout pledgeRateLayout;

    @NonNull
    public final GTButtonV3 plus;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final NestedScrollView scrollView;

    @NonNull
    public final GTTitleViewV3 title;

    private FiatloanActivityBorrowBinding(@NonNull LinearLayout linearLayout, @NonNull GTCheckBoxV3 gTCheckBoxV3, @NonNull EditText editText, @NonNull TextView textView, @NonNull TextView textView2, @NonNull GTSelectorViewV3 gTSelectorViewV3, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull DashTextViewV3 dashTextViewV3, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textView9, @NonNull TextView textView10, @NonNull LinearLayout linearLayout2, @NonNull LinearLayout linearLayout3, @NonNull GTButtonV3 gTButtonV3, @NonNull GTReminderV3 gTReminderV3, @NonNull LinearLayout linearLayout4, @NonNull TextView textView11, @NonNull RView rView, @NonNull GateIconFont gateIconFont, @NonNull LinearLayout linearLayout5, @NonNull TextView textView12, @NonNull RView rView2, @NonNull View view, @NonNull View view2, @NonNull FrameLayout frameLayout, @NonNull LinearLayout linearLayout6, @NonNull LinearLayout linearLayout7, @NonNull LinearLayout linearLayout8, @NonNull LinearLayout linearLayout9, @NonNull TextView textView13, @NonNull RView rView3, @NonNull TextView textView14, @NonNull GTButtonV3 gTButtonV32, @NonNull GTAlertV3 gTAlertV3, @NonNull GTEditTextV3 gTEditTextV3, @NonNull TextView textView15, @NonNull TextView textView16, @NonNull TextView textView17, @NonNull RelativeLayout relativeLayout, @NonNull GTButtonV3 gTButtonV33, @NonNull NestedScrollView nestedScrollView, @NonNull GTTitleViewV3 gTTitleViewV3) {
        this.rootView = linearLayout;
        this.agreement = gTCheckBoxV3;
        this.amountInput = editText;
        this.amountLabel = textView;
        this.amountRange = textView2;
        this.amountSelector = gTSelectorViewV3;
        this.annualizedRate = textView3;
        this.available = textView4;
        this.availableLabel = dashTextViewV3;
        this.dailyRate = textView5;
        this.dueInterest = textView6;
        this.dueInterestLabel = textView7;
        this.dueTotal = textView8;
        this.dueTotalLabel = textView9;
        this.fee = textView10;
        this.feeLayout = linearLayout2;
        this.llBottom = linearLayout3;
        this.minus = gTButtonV3;
        this.noPayMethodTip = gTReminderV3;
        this.payMethodAli = linearLayout4;
        this.payMethodAliAccount = textView11;
        this.payMethodAliColor = rView;
        this.payMethodArrow = gateIconFont;
        this.payMethodBank = linearLayout5;
        this.payMethodBankAccount = textView12;
        this.payMethodBankColor = rView2;
        this.payMethodDivider1 = view;
        this.payMethodDivider2 = view2;
        this.payMethodFrame = frameLayout;
        this.payMethodLabelLayout = linearLayout6;
        this.payMethodLayout = linearLayout7;
        this.payMethodSelect = linearLayout8;
        this.payMethodWechat = linearLayout9;
        this.payMethodWechatAccount = textView13;
        this.payMethodWechatColor = rView3;
        this.period = textView14;
        this.place = gTButtonV32;
        this.pledgeAlert = gTAlertV3;
        this.pledgeAmount = gTEditTextV3;
        this.pledgeLabel = textView15;
        this.pledgeRate = textView16;
        this.pledgeRateLabel = textView17;
        this.pledgeRateLayout = relativeLayout;
        this.plus = gTButtonV33;
        this.scrollView = nestedScrollView;
        this.title = gTTitleViewV3;
    }

    @NonNull
    public static FiatloanActivityBorrowBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanActivityBorrowBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        int i10 = R.id.agreement;
        GTCheckBoxV3 gTCheckBoxV3 = (GTCheckBoxV3) ViewBindings.findChildViewById(view, i10);
        if (gTCheckBoxV3 != null) {
            i10 = R.id.amount_input;
            EditText editText = (EditText) ViewBindings.findChildViewById(view, i10);
            if (editText != null) {
                i10 = R.id.amount_label;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView != null) {
                    i10 = R.id.amount_range;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView2 != null) {
                        i10 = R.id.amount_selector;
                        GTSelectorViewV3 gTSelectorViewV3 = (GTSelectorViewV3) ViewBindings.findChildViewById(view, i10);
                        if (gTSelectorViewV3 != null) {
                            i10 = R.id.annualized_rate;
                            TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView3 != null) {
                                i10 = R.id.available;
                                TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView4 != null) {
                                    i10 = R.id.available_label;
                                    DashTextViewV3 dashTextViewV3 = (DashTextViewV3) ViewBindings.findChildViewById(view, i10);
                                    if (dashTextViewV3 != null) {
                                        i10 = R.id.daily_rate;
                                        TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView5 != null) {
                                            i10 = R.id.due_interest;
                                            TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView6 != null) {
                                                i10 = R.id.due_interest_label;
                                                TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView7 != null) {
                                                    i10 = R.id.due_total;
                                                    TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                    if (textView8 != null) {
                                                        i10 = R.id.due_total_label;
                                                        TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                        if (textView9 != null) {
                                                            i10 = R.id.fee;
                                                            TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                            if (textView10 != null) {
                                                                i10 = R.id.fee_layout;
                                                                LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                if (linearLayout != null) {
                                                                    i10 = R.id.ll_bottom;
                                                                    LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                    if (linearLayout2 != null) {
                                                                        i10 = R.id.minus;
                                                                        GTButtonV3 gTButtonV3 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                                                                        if (gTButtonV3 != null) {
                                                                            i10 = R.id.no_pay_method_tip;
                                                                            GTReminderV3 gTReminderV3 = (GTReminderV3) ViewBindings.findChildViewById(view, i10);
                                                                            if (gTReminderV3 != null) {
                                                                                i10 = R.id.pay_method_ali;
                                                                                LinearLayout linearLayout3 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                                if (linearLayout3 != null) {
                                                                                    i10 = R.id.pay_method_ali_account;
                                                                                    TextView textView11 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                    if (textView11 != null) {
                                                                                        i10 = R.id.pay_method_ali_color;
                                                                                        RView rView = (RView) ViewBindings.findChildViewById(view, i10);
                                                                                        if (rView != null) {
                                                                                            i10 = R.id.pay_method_arrow;
                                                                                            GateIconFont gateIconFont = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                                                                            if (gateIconFont != null) {
                                                                                                i10 = R.id.pay_method_bank;
                                                                                                LinearLayout linearLayout4 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                if (linearLayout4 != null) {
                                                                                                    i10 = R.id.pay_method_bank_account;
                                                                                                    TextView textView12 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                    if (textView12 != null) {
                                                                                                        i10 = R.id.pay_method_bank_color;
                                                                                                        RView rView2 = (RView) ViewBindings.findChildViewById(view, i10);
                                                                                                        if (rView2 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.pay_method_divider1))) != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i10 = R.id.pay_method_divider2))) != null) {
                                                                                                            i10 = R.id.pay_method_frame;
                                                                                                            FrameLayout frameLayout = (FrameLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                            if (frameLayout != null) {
                                                                                                                i10 = R.id.pay_method_label_layout;
                                                                                                                LinearLayout linearLayout5 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                                if (linearLayout5 != null) {
                                                                                                                    i10 = R.id.pay_method_layout;
                                                                                                                    LinearLayout linearLayout6 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                                    if (linearLayout6 != null) {
                                                                                                                        i10 = R.id.pay_method_select;
                                                                                                                        LinearLayout linearLayout7 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                                        if (linearLayout7 != null) {
                                                                                                                            i10 = R.id.pay_method_wechat;
                                                                                                                            LinearLayout linearLayout8 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                                            if (linearLayout8 != null) {
                                                                                                                                i10 = R.id.pay_method_wechat_account;
                                                                                                                                TextView textView13 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                if (textView13 != null) {
                                                                                                                                    i10 = R.id.pay_method_wechat_color;
                                                                                                                                    RView rView3 = (RView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                    if (rView3 != null) {
                                                                                                                                        i10 = R.id.period;
                                                                                                                                        TextView textView14 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                        if (textView14 != null) {
                                                                                                                                            i10 = R.id.place;
                                                                                                                                            GTButtonV3 gTButtonV32 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                                                                                                                                            if (gTButtonV32 != null) {
                                                                                                                                                i10 = R.id.pledge_alert;
                                                                                                                                                GTAlertV3 gTAlertV3 = (GTAlertV3) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                if (gTAlertV3 != null) {
                                                                                                                                                    i10 = R.id.pledge_amount;
                                                                                                                                                    GTEditTextV3 gTEditTextV3 = (GTEditTextV3) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                    if (gTEditTextV3 != null) {
                                                                                                                                                        i10 = R.id.pledge_label;
                                                                                                                                                        TextView textView15 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                        if (textView15 != null) {
                                                                                                                                                            i10 = R.id.pledge_rate;
                                                                                                                                                            TextView textView16 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                            if (textView16 != null) {
                                                                                                                                                                i10 = R.id.pledge_rate_label;
                                                                                                                                                                TextView textView17 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                if (textView17 != null) {
                                                                                                                                                                    i10 = R.id.pledge_rate_layout;
                                                                                                                                                                    RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                    if (relativeLayout != null) {
                                                                                                                                                                        i10 = R.id.plus;
                                                                                                                                                                        GTButtonV3 gTButtonV33 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                        if (gTButtonV33 != null) {
                                                                                                                                                                            i10 = R.id.scrollView;
                                                                                                                                                                            NestedScrollView nestedScrollView = (NestedScrollView) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                            if (nestedScrollView != null) {
                                                                                                                                                                                i10 = R.id.title;
                                                                                                                                                                                GTTitleViewV3 gTTitleViewV3 = (GTTitleViewV3) ViewBindings.findChildViewById(view, i10);
                                                                                                                                                                                if (gTTitleViewV3 != null) {
                                                                                                                                                                                    return new FiatloanActivityBorrowBinding((LinearLayout) view, gTCheckBoxV3, editText, textView, textView2, gTSelectorViewV3, textView3, textView4, dashTextViewV3, textView5, textView6, textView7, textView8, textView9, textView10, linearLayout, linearLayout2, gTButtonV3, gTReminderV3, linearLayout3, textView11, rView, gateIconFont, linearLayout4, textView12, rView2, viewFindChildViewById, viewFindChildViewById2, frameLayout, linearLayout5, linearLayout6, linearLayout7, linearLayout8, textView13, rView3, textView14, gTButtonV32, gTAlertV3, gTEditTextV3, textView15, textView16, textView17, relativeLayout, gTButtonV33, nestedScrollView, gTTitleViewV3);
                                                                                                                                                                                }
                                                                                                                                                                            }
                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanActivityBorrowBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_activity_borrow, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }
}