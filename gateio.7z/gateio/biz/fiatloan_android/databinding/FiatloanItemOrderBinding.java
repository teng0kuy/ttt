package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.number.GTNumberViewV3;
import com.gateio.lib.uikit.reminder.GTReminderV3;
import com.gateio.lib.uikit.tag.GTTagV3;
import com.ruffian.library.widget.RView;

/* loaded from: classes38.dex */
public final class FiatloanItemOrderBinding implements ViewBinding {

    @NonNull
    public final TextView dailyRate;

    @NonNull
    public final TextView dailyRateLabel;

    @NonNull
    public final TextView dealAmount;

    @NonNull
    public final TextView dealAmountLabel;

    @NonNull
    public final TextView interest;

    @NonNull
    public final TextView interestLabel;

    @NonNull
    public final TextView orderId;

    @NonNull
    public final TextView orderIdLabel;

    @NonNull
    public final TextView period;

    @NonNull
    public final TextView periodLabel;

    @NonNull
    public final GTReminderV3 pledgeAlert;

    @NonNull
    public final GTNumberViewV3 pledgeAmount;

    @NonNull
    public final TextView pledgeRate;

    @NonNull
    public final TextView pledgeRateLabel;

    @NonNull
    public final TextView progress;

    @NonNull
    public final RView progressBar;

    @NonNull
    public final RView progressBarBg;

    @NonNull
    public final RelativeLayout progressLayout;

    @NonNull
    public final GTTagV3 renewable;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final TextView status;

    @NonNull
    public final RelativeLayout statusIcon;

    @NonNull
    public final RView statusIcon1;

    @NonNull
    public final RView statusIcon2;

    @NonNull
    public final TextView time;

    @NonNull
    public final TextView timeLabel;

    @NonNull
    public final TextView totalAmount;

    @NonNull
    public final TextView totalAmountLabel;

    private FiatloanItemOrderBinding(@NonNull RelativeLayout relativeLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textView9, @NonNull TextView textView10, @NonNull GTReminderV3 gTReminderV3, @NonNull GTNumberViewV3 gTNumberViewV3, @NonNull TextView textView11, @NonNull TextView textView12, @NonNull TextView textView13, @NonNull RView rView, @NonNull RView rView2, @NonNull RelativeLayout relativeLayout2, @NonNull GTTagV3 gTTagV3, @NonNull TextView textView14, @NonNull RelativeLayout relativeLayout3, @NonNull RView rView3, @NonNull RView rView4, @NonNull TextView textView15, @NonNull TextView textView16, @NonNull TextView textView17, @NonNull TextView textView18) {
        this.rootView = relativeLayout;
        this.dailyRate = textView;
        this.dailyRateLabel = textView2;
        this.dealAmount = textView3;
        this.dealAmountLabel = textView4;
        this.interest = textView5;
        this.interestLabel = textView6;
        this.orderId = textView7;
        this.orderIdLabel = textView8;
        this.period = textView9;
        this.periodLabel = textView10;
        this.pledgeAlert = gTReminderV3;
        this.pledgeAmount = gTNumberViewV3;
        this.pledgeRate = textView11;
        this.pledgeRateLabel = textView12;
        this.progress = textView13;
        this.progressBar = rView;
        this.progressBarBg = rView2;
        this.progressLayout = relativeLayout2;
        this.renewable = gTTagV3;
        this.status = textView14;
        this.statusIcon = relativeLayout3;
        this.statusIcon1 = rView3;
        this.statusIcon2 = rView4;
        this.time = textView15;
        this.timeLabel = textView16;
        this.totalAmount = textView17;
        this.totalAmountLabel = textView18;
    }

    @NonNull
    public static FiatloanItemOrderBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanItemOrderBinding bind(@NonNull View view) {
        int i10 = R.id.daily_rate;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
        if (textView != null) {
            i10 = R.id.daily_rate_label;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView2 != null) {
                i10 = R.id.deal_amount;
                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView3 != null) {
                    i10 = R.id.deal_amount_label;
                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView4 != null) {
                        i10 = R.id.interest;
                        TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView5 != null) {
                            i10 = R.id.interest_label;
                            TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView6 != null) {
                                i10 = R.id.order_id;
                                TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView7 != null) {
                                    i10 = R.id.order_id_label;
                                    TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView8 != null) {
                                        i10 = R.id.period;
                                        TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView9 != null) {
                                            i10 = R.id.period_label;
                                            TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView10 != null) {
                                                i10 = R.id.pledge_alert;
                                                GTReminderV3 gTReminderV3 = (GTReminderV3) ViewBindings.findChildViewById(view, i10);
                                                if (gTReminderV3 != null) {
                                                    i10 = R.id.pledge_amount;
                                                    GTNumberViewV3 gTNumberViewV3 = (GTNumberViewV3) ViewBindings.findChildViewById(view, i10);
                                                    if (gTNumberViewV3 != null) {
                                                        i10 = R.id.pledge_rate;
                                                        TextView textView11 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                        if (textView11 != null) {
                                                            i10 = R.id.pledge_rate_label;
                                                            TextView textView12 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                            if (textView12 != null) {
                                                                i10 = R.id.progress;
                                                                TextView textView13 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                if (textView13 != null) {
                                                                    i10 = R.id.progress_bar;
                                                                    RView rView = (RView) ViewBindings.findChildViewById(view, i10);
                                                                    if (rView != null) {
                                                                        i10 = R.id.progress_bar_bg;
                                                                        RView rView2 = (RView) ViewBindings.findChildViewById(view, i10);
                                                                        if (rView2 != null) {
                                                                            i10 = R.id.progress_layout;
                                                                            RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                                            if (relativeLayout != null) {
                                                                                i10 = R.id.renewable;
                                                                                GTTagV3 gTTagV3 = (GTTagV3) ViewBindings.findChildViewById(view, i10);
                                                                                if (gTTagV3 != null) {
                                                                                    i10 = R.id.status;
                                                                                    TextView textView14 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                    if (textView14 != null) {
                                                                                        i10 = R.id.status_icon;
                                                                                        RelativeLayout relativeLayout2 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                                                        if (relativeLayout2 != null) {
                                                                                            i10 = R.id.status_icon1;
                                                                                            RView rView3 = (RView) ViewBindings.findChildViewById(view, i10);
                                                                                            if (rView3 != null) {
                                                                                                i10 = R.id.status_icon2;
                                                                                                RView rView4 = (RView) ViewBindings.findChildViewById(view, i10);
                                                                                                if (rView4 != null) {
                                                                                                    i10 = R.id.time;
                                                                                                    TextView textView15 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                    if (textView15 != null) {
                                                                                                        i10 = R.id.time_label;
                                                                                                        TextView textView16 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                        if (textView16 != null) {
                                                                                                            i10 = R.id.total_amount;
                                                                                                            TextView textView17 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                            if (textView17 != null) {
                                                                                                                i10 = R.id.total_amount_label;
                                                                                                                TextView textView18 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                                if (textView18 != null) {
                                                                                                                    return new FiatloanItemOrderBinding((RelativeLayout) view, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9, textView10, gTReminderV3, gTNumberViewV3, textView11, textView12, textView13, rView, rView2, relativeLayout, gTTagV3, textView14, relativeLayout2, rView3, rView4, textView15, textView16, textView17, textView18);
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanItemOrderBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_item_order, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }
}