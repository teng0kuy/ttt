package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;

/* loaded from: classes38.dex */
public final class FiatloanDialogBorrowOrderConfirmBinding implements ViewBinding {

    @NonNull
    public final TextView amount;

    @NonNull
    public final TextView amountLabel;

    @NonNull
    public final TextView annualizedRate;

    @NonNull
    public final TextView annualizedRateLabel;

    @NonNull
    public final TextView dailyRate;

    @NonNull
    public final TextView dailyRateLabel;

    @NonNull
    public final TextView fee;

    @NonNull
    public final RelativeLayout feeItem;

    @NonNull
    public final TextView feeLabel;

    @NonNull
    public final TextView interest;

    @NonNull
    public final TextView interestLabel;

    @NonNull
    public final TextView payMethod;

    @NonNull
    public final TextView payMethodLabel;

    @NonNull
    public final TextView period;

    @NonNull
    public final TextView periodLabel;

    @NonNull
    public final TextView pledgeAmount;

    @NonNull
    public final RelativeLayout pledgeAmountItem;

    @NonNull
    public final TextView pledgeAmountLabel;

    @NonNull
    public final TextView pledgeRate;

    @NonNull
    public final RelativeLayout pledgeRateItem;

    @NonNull
    public final TextView pledgeRateLabel;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final TextView total;

    @NonNull
    public final TextView totalLabel;

    private FiatloanDialogBorrowOrderConfirmBinding(@NonNull LinearLayout linearLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull RelativeLayout relativeLayout, @NonNull TextView textView8, @NonNull TextView textView9, @NonNull TextView textView10, @NonNull TextView textView11, @NonNull TextView textView12, @NonNull TextView textView13, @NonNull TextView textView14, @NonNull TextView textView15, @NonNull RelativeLayout relativeLayout2, @NonNull TextView textView16, @NonNull TextView textView17, @NonNull RelativeLayout relativeLayout3, @NonNull TextView textView18, @NonNull TextView textView19, @NonNull TextView textView20) {
        this.rootView = linearLayout;
        this.amount = textView;
        this.amountLabel = textView2;
        this.annualizedRate = textView3;
        this.annualizedRateLabel = textView4;
        this.dailyRate = textView5;
        this.dailyRateLabel = textView6;
        this.fee = textView7;
        this.feeItem = relativeLayout;
        this.feeLabel = textView8;
        this.interest = textView9;
        this.interestLabel = textView10;
        this.payMethod = textView11;
        this.payMethodLabel = textView12;
        this.period = textView13;
        this.periodLabel = textView14;
        this.pledgeAmount = textView15;
        this.pledgeAmountItem = relativeLayout2;
        this.pledgeAmountLabel = textView16;
        this.pledgeRate = textView17;
        this.pledgeRateItem = relativeLayout3;
        this.pledgeRateLabel = textView18;
        this.total = textView19;
        this.totalLabel = textView20;
    }

    @NonNull
    public static FiatloanDialogBorrowOrderConfirmBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanDialogBorrowOrderConfirmBinding bind(@NonNull View view) {
        int i10 = R.id.amount;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
        if (textView != null) {
            i10 = R.id.amount_label;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView2 != null) {
                i10 = R.id.annualized_rate;
                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView3 != null) {
                    i10 = R.id.annualized_rate_label;
                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView4 != null) {
                        i10 = R.id.daily_rate;
                        TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView5 != null) {
                            i10 = R.id.daily_rate_label;
                            TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView6 != null) {
                                i10 = R.id.fee;
                                TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView7 != null) {
                                    i10 = R.id.fee_item;
                                    RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                    if (relativeLayout != null) {
                                        i10 = R.id.fee_label;
                                        TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView8 != null) {
                                            i10 = R.id.interest;
                                            TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView9 != null) {
                                                i10 = R.id.interest_label;
                                                TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView10 != null) {
                                                    i10 = R.id.pay_method;
                                                    TextView textView11 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                    if (textView11 != null) {
                                                        i10 = R.id.pay_method_label;
                                                        TextView textView12 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                        if (textView12 != null) {
                                                            i10 = R.id.period;
                                                            TextView textView13 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                            if (textView13 != null) {
                                                                i10 = R.id.period_label;
                                                                TextView textView14 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                if (textView14 != null) {
                                                                    i10 = R.id.pledge_amount;
                                                                    TextView textView15 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                    if (textView15 != null) {
                                                                        i10 = R.id.pledge_amount_item;
                                                                        RelativeLayout relativeLayout2 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                                        if (relativeLayout2 != null) {
                                                                            i10 = R.id.pledge_amount_label;
                                                                            TextView textView16 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                            if (textView16 != null) {
                                                                                i10 = R.id.pledge_rate;
                                                                                TextView textView17 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                if (textView17 != null) {
                                                                                    i10 = R.id.pledge_rate_item;
                                                                                    RelativeLayout relativeLayout3 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                                                    if (relativeLayout3 != null) {
                                                                                        i10 = R.id.pledge_rate_label;
                                                                                        TextView textView18 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                        if (textView18 != null) {
                                                                                            i10 = R.id.total;
                                                                                            TextView textView19 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                            if (textView19 != null) {
                                                                                                i10 = R.id.total_label;
                                                                                                TextView textView20 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                if (textView20 != null) {
                                                                                                    return new FiatloanDialogBorrowOrderConfirmBinding((LinearLayout) view, textView, textView2, textView3, textView4, textView5, textView6, textView7, relativeLayout, textView8, textView9, textView10, textView11, textView12, textView13, textView14, textView15, relativeLayout2, textView16, textView17, relativeLayout3, textView18, textView19, textView20);
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanDialogBorrowOrderConfirmBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_dialog_borrow_order_confirm, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }
}