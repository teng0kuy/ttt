package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.common.view.GateioAvatarView;

/* loaded from: classes38.dex */
public final class FiatloanItemAppealMeBinding implements ViewBinding {

    @NonNull
    public final GateioAvatarView avatar;

    @NonNull
    public final TextView message;

    @NonNull
    public final TextView nickname;

    @NonNull
    public final AppCompatImageView pic1;

    @NonNull
    public final AppCompatImageView pic2;

    @NonNull
    public final AppCompatImageView pic3;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public static FiatloanItemAppealMeBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanItemAppealMeBinding bind(@NonNull View view) {
        int i10 = R.id.avatar;
        GateioAvatarView gateioAvatarView = (GateioAvatarView) ViewBindings.findChildViewById(view, i10);
        if (gateioAvatarView != null) {
            i10 = R.id.message;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                i10 = R.id.nickname;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView2 != null) {
                    i10 = R.id.pic1;
                    AppCompatImageView appCompatImageView = (AppCompatImageView) ViewBindings.findChildViewById(view, i10);
                    if (appCompatImageView != null) {
                        i10 = R.id.pic2;
                        AppCompatImageView appCompatImageView2 = (AppCompatImageView) ViewBindings.findChildViewById(view, i10);
                        if (appCompatImageView2 != null) {
                            i10 = R.id.pic3;
                            AppCompatImageView appCompatImageView3 = (AppCompatImageView) ViewBindings.findChildViewById(view, i10);
                            if (appCompatImageView3 != null) {
                                return new FiatloanItemAppealMeBinding((RelativeLayout) view, gateioAvatarView, textView, textView2, appCompatImageView, appCompatImageView2, appCompatImageView3);
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanItemAppealMeBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_item_appeal_me, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private FiatloanItemAppealMeBinding(@NonNull RelativeLayout relativeLayout, @NonNull GateioAvatarView gateioAvatarView, @NonNull TextView textView, @NonNull TextView textView2, @NonNull AppCompatImageView appCompatImageView, @NonNull AppCompatImageView appCompatImageView2, @NonNull AppCompatImageView appCompatImageView3) {
        this.rootView = relativeLayout;
        this.avatar = gateioAvatarView;
        this.message = textView;
        this.nickname = textView2;
        this.pic1 = appCompatImageView;
        this.pic2 = appCompatImageView2;
        this.pic3 = appCompatImageView3;
    }
}