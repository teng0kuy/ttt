package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;

/* loaded from: classes38.dex */
public final class FiatloanDialogSelectCoinTitleBinding implements ViewBinding {

    @NonNull
    public final ConstraintLayout contentLayout;

    @NonNull
    public final ConstraintLayout customLayout;

    @NonNull
    public final View driveView;

    @NonNull
    private final ConstraintLayout rootView;

    @NonNull
    public final AppCompatTextView title;

    @NonNull
    public static FiatloanDialogSelectCoinTitleBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanDialogSelectCoinTitleBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.contentLayout;
        ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(view, i10);
        if (constraintLayout != null) {
            i10 = R.id.customLayout;
            ConstraintLayout constraintLayout2 = (ConstraintLayout) ViewBindings.findChildViewById(view, i10);
            if (constraintLayout2 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.driveView))) != null) {
                i10 = R.id.title;
                AppCompatTextView appCompatTextView = (AppCompatTextView) ViewBindings.findChildViewById(view, i10);
                if (appCompatTextView != null) {
                    return new FiatloanDialogSelectCoinTitleBinding((ConstraintLayout) view, constraintLayout, constraintLayout2, viewFindChildViewById, appCompatTextView);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanDialogSelectCoinTitleBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_dialog_select_coin_title, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    private FiatloanDialogSelectCoinTitleBinding(@NonNull ConstraintLayout constraintLayout, @NonNull ConstraintLayout constraintLayout2, @NonNull ConstraintLayout constraintLayout3, @NonNull View view, @NonNull AppCompatTextView appCompatTextView) {
        this.rootView = constraintLayout;
        this.contentLayout = constraintLayout2;
        this.customLayout = constraintLayout3;
        this.driveView = view;
        this.title = appCompatTextView;
    }
}