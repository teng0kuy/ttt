package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.button.GTButtonV3;
import com.gateio.lib.uikit.reminder.GTReminderV3;
import com.gateio.lib.uikit.steps.GTStepBarV3;
import com.gateio.lib.uikit.switchview.GTSwitchV3;
import com.gateio.lib.uikit.tag.GTTagV3;
import com.gateio.uiComponent.GateIconFont;

/* loaded from: classes38.dex */
public final class FiatloanLayoutOrderDetailPeriodBinding implements ViewBinding {

    @NonNull
    public final GTTagV3 period;

    @NonNull
    public final TextView periodLabel;

    @NonNull
    public final RelativeLayout periodLabelLayout;

    @NonNull
    public final GTReminderV3 periodReminder;

    @NonNull
    public final LinearLayout periodStatus1;

    @NonNull
    public final GTStepBarV3 periodStep;

    @NonNull
    public final View renewDivider;

    @NonNull
    public final GateIconFont renewIcon;

    @NonNull
    public final RelativeLayout renewLayout;

    @NonNull
    public final GTSwitchV3 renewSwitch;

    @NonNull
    public final GTTagV3 renewable;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final TextView status1;

    @NonNull
    public final GateIconFont status1Icon;

    @NonNull
    public final LinearLayout tagLayout;

    @NonNull
    public final GTButtonV3 wantRenew;

    private FiatloanLayoutOrderDetailPeriodBinding(@NonNull RelativeLayout relativeLayout, @NonNull GTTagV3 gTTagV3, @NonNull TextView textView, @NonNull RelativeLayout relativeLayout2, @NonNull GTReminderV3 gTReminderV3, @NonNull LinearLayout linearLayout, @NonNull GTStepBarV3 gTStepBarV3, @NonNull View view, @NonNull GateIconFont gateIconFont, @NonNull RelativeLayout relativeLayout3, @NonNull GTSwitchV3 gTSwitchV3, @NonNull GTTagV3 gTTagV32, @NonNull TextView textView2, @NonNull GateIconFont gateIconFont2, @NonNull LinearLayout linearLayout2, @NonNull GTButtonV3 gTButtonV3) {
        this.rootView = relativeLayout;
        this.period = gTTagV3;
        this.periodLabel = textView;
        this.periodLabelLayout = relativeLayout2;
        this.periodReminder = gTReminderV3;
        this.periodStatus1 = linearLayout;
        this.periodStep = gTStepBarV3;
        this.renewDivider = view;
        this.renewIcon = gateIconFont;
        this.renewLayout = relativeLayout3;
        this.renewSwitch = gTSwitchV3;
        this.renewable = gTTagV32;
        this.status1 = textView2;
        this.status1Icon = gateIconFont2;
        this.tagLayout = linearLayout2;
        this.wantRenew = gTButtonV3;
    }

    @NonNull
    public static FiatloanLayoutOrderDetailPeriodBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanLayoutOrderDetailPeriodBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.period;
        GTTagV3 gTTagV3 = (GTTagV3) ViewBindings.findChildViewById(view, i10);
        if (gTTagV3 != null) {
            i10 = R.id.period_label;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                i10 = R.id.period_label_layout;
                RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                if (relativeLayout != null) {
                    i10 = R.id.period_reminder;
                    GTReminderV3 gTReminderV3 = (GTReminderV3) ViewBindings.findChildViewById(view, i10);
                    if (gTReminderV3 != null) {
                        i10 = R.id.period_status1;
                        LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                        if (linearLayout != null) {
                            i10 = R.id.period_step;
                            GTStepBarV3 gTStepBarV3 = (GTStepBarV3) ViewBindings.findChildViewById(view, i10);
                            if (gTStepBarV3 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.renew_divider))) != null) {
                                i10 = R.id.renew_icon;
                                GateIconFont gateIconFont = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                if (gateIconFont != null) {
                                    i10 = R.id.renew_layout;
                                    RelativeLayout relativeLayout2 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                    if (relativeLayout2 != null) {
                                        i10 = R.id.renew_switch;
                                        GTSwitchV3 gTSwitchV3 = (GTSwitchV3) ViewBindings.findChildViewById(view, i10);
                                        if (gTSwitchV3 != null) {
                                            i10 = R.id.renewable;
                                            GTTagV3 gTTagV32 = (GTTagV3) ViewBindings.findChildViewById(view, i10);
                                            if (gTTagV32 != null) {
                                                i10 = R.id.status1;
                                                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView2 != null) {
                                                    i10 = R.id.status1_icon;
                                                    GateIconFont gateIconFont2 = (GateIconFont) ViewBindings.findChildViewById(view, i10);
                                                    if (gateIconFont2 != null) {
                                                        i10 = R.id.tag_layout;
                                                        LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                        if (linearLayout2 != null) {
                                                            i10 = R.id.want_renew;
                                                            GTButtonV3 gTButtonV3 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                                                            if (gTButtonV3 != null) {
                                                                return new FiatloanLayoutOrderDetailPeriodBinding((RelativeLayout) view, gTTagV3, textView, relativeLayout, gTReminderV3, linearLayout, gTStepBarV3, viewFindChildViewById, gateIconFont, relativeLayout2, gTSwitchV3, gTTagV32, textView2, gateIconFont2, linearLayout2, gTButtonV3);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanLayoutOrderDetailPeriodBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_layout_order_detail_period, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }
}