package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import com.gateio.biz.fiatloan_android.R;
import com.ruffian.library.widget.RLinearLayout;

/* loaded from: classes38.dex */
public final class FiatloanBubbleCopyBinding implements ViewBinding {

    @NonNull
    private final RLinearLayout rootView;

    @NonNull
    public static FiatloanBubbleCopyBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanBubbleCopyBinding bind(@NonNull View view) {
        if (view != null) {
            return new FiatloanBubbleCopyBinding((RLinearLayout) view);
        }
        throw new NullPointerException("rootView");
    }

    @NonNull
    public static FiatloanBubbleCopyBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_bubble_copy, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RLinearLayout getRoot() {
        return this.rootView;
    }

    private FiatloanBubbleCopyBinding(@NonNull RLinearLayout rLinearLayout) {
        this.rootView = rLinearLayout;
    }
}