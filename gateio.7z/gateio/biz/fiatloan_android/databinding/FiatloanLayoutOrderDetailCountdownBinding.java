package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.countdown.GTCountDownV3;
import com.gateio.lib.uikit.reminder.GTReminderV3;

/* loaded from: classes38.dex */
public final class FiatloanLayoutOrderDetailCountdownBinding implements ViewBinding {

    @NonNull
    public final GTCountDownV3 countdown;

    @NonNull
    public final GTReminderV3 countdownReminder;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public static FiatloanLayoutOrderDetailCountdownBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanLayoutOrderDetailCountdownBinding bind(@NonNull View view) {
        int i10 = R.id.countdown;
        GTCountDownV3 gTCountDownV3 = (GTCountDownV3) ViewBindings.findChildViewById(view, i10);
        if (gTCountDownV3 != null) {
            i10 = R.id.countdown_reminder;
            GTReminderV3 gTReminderV3 = (GTReminderV3) ViewBindings.findChildViewById(view, i10);
            if (gTReminderV3 != null) {
                return new FiatloanLayoutOrderDetailCountdownBinding((LinearLayout) view, gTCountDownV3, gTReminderV3);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanLayoutOrderDetailCountdownBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_layout_order_detail_countdown, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private FiatloanLayoutOrderDetailCountdownBinding(@NonNull LinearLayout linearLayout, @NonNull GTCountDownV3 gTCountDownV3, @NonNull GTReminderV3 gTReminderV3) {
        this.rootView = linearLayout;
        this.countdown = gTCountDownV3;
        this.countdownReminder = gTReminderV3;
    }
}