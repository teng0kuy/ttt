package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.search.GTSearchViewV3;
import com.gateio.lib.uikit.state.GTEmptyViewV3;
import com.gateio.lib.uikit.title.GTTitleViewV3;

/* loaded from: classes38.dex */
public final class FiatloanActivitySearchOrderBinding implements ViewBinding {

    @NonNull
    public final GTEmptyViewV3 empty;

    @NonNull
    public final RecyclerView recyclerView;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final GTSearchViewV3 searchView;

    @NonNull
    public final GTTitleViewV3 title;

    @NonNull
    public static FiatloanActivitySearchOrderBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanActivitySearchOrderBinding bind(@NonNull View view) {
        int i10 = R.id.empty;
        GTEmptyViewV3 gTEmptyViewV3 = (GTEmptyViewV3) ViewBindings.findChildViewById(view, i10);
        if (gTEmptyViewV3 != null) {
            i10 = R.id.recyclerView;
            RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
            if (recyclerView != null) {
                i10 = R.id.search_view;
                GTSearchViewV3 gTSearchViewV3 = (GTSearchViewV3) ViewBindings.findChildViewById(view, i10);
                if (gTSearchViewV3 != null) {
                    i10 = R.id.title;
                    GTTitleViewV3 gTTitleViewV3 = (GTTitleViewV3) ViewBindings.findChildViewById(view, i10);
                    if (gTTitleViewV3 != null) {
                        return new FiatloanActivitySearchOrderBinding((LinearLayout) view, gTEmptyViewV3, recyclerView, gTSearchViewV3, gTTitleViewV3);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanActivitySearchOrderBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_activity_search_order, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private FiatloanActivitySearchOrderBinding(@NonNull LinearLayout linearLayout, @NonNull GTEmptyViewV3 gTEmptyViewV3, @NonNull RecyclerView recyclerView, @NonNull GTSearchViewV3 gTSearchViewV3, @NonNull GTTitleViewV3 gTTitleViewV3) {
        this.rootView = linearLayout;
        this.empty = gTEmptyViewV3;
        this.recyclerView = recyclerView;
        this.searchView = gTSearchViewV3;
        this.title = gTTitleViewV3;
    }
}