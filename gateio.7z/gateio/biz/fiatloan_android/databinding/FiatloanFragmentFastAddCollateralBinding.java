package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.alert.GTAlertV3;
import com.gateio.lib.uikit.button.GTButtonV3;
import com.gateio.lib.uikit.input.GTEditTextV3;

/* loaded from: classes38.dex */
public final class FiatloanFragmentFastAddCollateralBinding implements ViewBinding {

    @NonNull
    public final GTButtonV3 addCollateral;

    @NonNull
    public final GTEditTextV3 addCollateralRate;

    @NonNull
    public final GTAlertV3 alert;

    @NonNull
    public final GTEditTextV3 queryRate;

    @NonNull
    public final GTButtonV3 reset;

    @NonNull
    private final ConstraintLayout rootView;

    @NonNull
    public static FiatloanFragmentFastAddCollateralBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanFragmentFastAddCollateralBinding bind(@NonNull View view) {
        int i10 = R.id.add_collateral;
        GTButtonV3 gTButtonV3 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
        if (gTButtonV3 != null) {
            i10 = R.id.add_collateral_rate;
            GTEditTextV3 gTEditTextV3 = (GTEditTextV3) ViewBindings.findChildViewById(view, i10);
            if (gTEditTextV3 != null) {
                i10 = R.id.alert;
                GTAlertV3 gTAlertV3 = (GTAlertV3) ViewBindings.findChildViewById(view, i10);
                if (gTAlertV3 != null) {
                    i10 = R.id.query_rate;
                    GTEditTextV3 gTEditTextV32 = (GTEditTextV3) ViewBindings.findChildViewById(view, i10);
                    if (gTEditTextV32 != null) {
                        i10 = R.id.reset;
                        GTButtonV3 gTButtonV32 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                        if (gTButtonV32 != null) {
                            return new FiatloanFragmentFastAddCollateralBinding((ConstraintLayout) view, gTButtonV3, gTEditTextV3, gTAlertV3, gTEditTextV32, gTButtonV32);
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanFragmentFastAddCollateralBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_fragment_fast_add_collateral, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    private FiatloanFragmentFastAddCollateralBinding(@NonNull ConstraintLayout constraintLayout, @NonNull GTButtonV3 gTButtonV3, @NonNull GTEditTextV3 gTEditTextV3, @NonNull GTAlertV3 gTAlertV3, @NonNull GTEditTextV3 gTEditTextV32, @NonNull GTButtonV3 gTButtonV32) {
        this.rootView = constraintLayout;
        this.addCollateral = gTButtonV3;
        this.addCollateralRate = gTEditTextV3;
        this.alert = gTAlertV3;
        this.queryRate = gTEditTextV32;
        this.reset = gTButtonV32;
    }
}