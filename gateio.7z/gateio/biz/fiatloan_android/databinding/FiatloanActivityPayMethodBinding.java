package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.button.GTButtonV3;
import com.gateio.lib.uikit.switchview.GTSwitchV3;
import com.gateio.lib.uikit.title.GTTitleViewV3;
import com.ruffian.library.widget.RView;

/* loaded from: classes38.dex */
public final class FiatloanActivityPayMethodBinding implements ViewBinding {

    @NonNull
    public final RView aliColor;

    @NonNull
    public final LinearLayout aliLayout;

    @NonNull
    public final TextView aliName;

    @NonNull
    public final GTSwitchV3 aliSwitch;

    @NonNull
    public final RecyclerView alis;

    @NonNull
    public final RView bankColor;

    @NonNull
    public final LinearLayout bankLayout;

    @NonNull
    public final TextView bankName;

    @NonNull
    public final GTSwitchV3 bankSwitch;

    @NonNull
    public final RecyclerView banks;

    @NonNull
    public final GTButtonV3 confirm;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final GTTitleViewV3 title;

    @NonNull
    public final RView wechatColor;

    @NonNull
    public final LinearLayout wechatLayout;

    @NonNull
    public final TextView wechatName;

    @NonNull
    public final GTSwitchV3 wechatSwitch;

    @NonNull
    public final RecyclerView wechats;

    private FiatloanActivityPayMethodBinding(@NonNull LinearLayout linearLayout, @NonNull RView rView, @NonNull LinearLayout linearLayout2, @NonNull TextView textView, @NonNull GTSwitchV3 gTSwitchV3, @NonNull RecyclerView recyclerView, @NonNull RView rView2, @NonNull LinearLayout linearLayout3, @NonNull TextView textView2, @NonNull GTSwitchV3 gTSwitchV32, @NonNull RecyclerView recyclerView2, @NonNull GTButtonV3 gTButtonV3, @NonNull GTTitleViewV3 gTTitleViewV3, @NonNull RView rView3, @NonNull LinearLayout linearLayout4, @NonNull TextView textView3, @NonNull GTSwitchV3 gTSwitchV33, @NonNull RecyclerView recyclerView3) {
        this.rootView = linearLayout;
        this.aliColor = rView;
        this.aliLayout = linearLayout2;
        this.aliName = textView;
        this.aliSwitch = gTSwitchV3;
        this.alis = recyclerView;
        this.bankColor = rView2;
        this.bankLayout = linearLayout3;
        this.bankName = textView2;
        this.bankSwitch = gTSwitchV32;
        this.banks = recyclerView2;
        this.confirm = gTButtonV3;
        this.title = gTTitleViewV3;
        this.wechatColor = rView3;
        this.wechatLayout = linearLayout4;
        this.wechatName = textView3;
        this.wechatSwitch = gTSwitchV33;
        this.wechats = recyclerView3;
    }

    @NonNull
    public static FiatloanActivityPayMethodBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanActivityPayMethodBinding bind(@NonNull View view) {
        int i10 = R.id.ali_color;
        RView rView = (RView) ViewBindings.findChildViewById(view, i10);
        if (rView != null) {
            i10 = R.id.ali_layout;
            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
            if (linearLayout != null) {
                i10 = R.id.ali_name;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView != null) {
                    i10 = R.id.ali_switch;
                    GTSwitchV3 gTSwitchV3 = (GTSwitchV3) ViewBindings.findChildViewById(view, i10);
                    if (gTSwitchV3 != null) {
                        i10 = R.id.alis;
                        RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                        if (recyclerView != null) {
                            i10 = R.id.bank_color;
                            RView rView2 = (RView) ViewBindings.findChildViewById(view, i10);
                            if (rView2 != null) {
                                i10 = R.id.bank_layout;
                                LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                if (linearLayout2 != null) {
                                    i10 = R.id.bank_name;
                                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView2 != null) {
                                        i10 = R.id.bank_switch;
                                        GTSwitchV3 gTSwitchV32 = (GTSwitchV3) ViewBindings.findChildViewById(view, i10);
                                        if (gTSwitchV32 != null) {
                                            i10 = R.id.banks;
                                            RecyclerView recyclerView2 = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                                            if (recyclerView2 != null) {
                                                i10 = R.id.confirm;
                                                GTButtonV3 gTButtonV3 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                                                if (gTButtonV3 != null) {
                                                    i10 = R.id.title;
                                                    GTTitleViewV3 gTTitleViewV3 = (GTTitleViewV3) ViewBindings.findChildViewById(view, i10);
                                                    if (gTTitleViewV3 != null) {
                                                        i10 = R.id.wechat_color;
                                                        RView rView3 = (RView) ViewBindings.findChildViewById(view, i10);
                                                        if (rView3 != null) {
                                                            i10 = R.id.wechat_layout;
                                                            LinearLayout linearLayout3 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                            if (linearLayout3 != null) {
                                                                i10 = R.id.wechat_name;
                                                                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                if (textView3 != null) {
                                                                    i10 = R.id.wechat_switch;
                                                                    GTSwitchV3 gTSwitchV33 = (GTSwitchV3) ViewBindings.findChildViewById(view, i10);
                                                                    if (gTSwitchV33 != null) {
                                                                        i10 = R.id.wechats;
                                                                        RecyclerView recyclerView3 = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                                                                        if (recyclerView3 != null) {
                                                                            return new FiatloanActivityPayMethodBinding((LinearLayout) view, rView, linearLayout, textView, gTSwitchV3, recyclerView, rView2, linearLayout2, textView2, gTSwitchV32, recyclerView2, gTButtonV3, gTTitleViewV3, rView3, linearLayout3, textView3, gTSwitchV33, recyclerView3);
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanActivityPayMethodBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_activity_pay_method, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }
}