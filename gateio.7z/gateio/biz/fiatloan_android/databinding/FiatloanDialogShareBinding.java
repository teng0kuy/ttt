package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.ruffian.library.widget.RView;

/* loaded from: classes38.dex */
public final class FiatloanDialogShareBinding implements ViewBinding {

    @NonNull
    public final TextView ali;

    @NonNull
    public final RView aliColor;

    @NonNull
    public final FrameLayout avatar;

    @NonNull
    public final ImageView avatarImg;

    @NonNull
    public final AppCompatTextView avatarText;

    @NonNull
    public final TextView bank;

    @NonNull
    public final RView bankColor;

    @NonNull
    public final LinearLayout dueIncomeLayout;

    @NonNull
    public final AppCompatTextView fiatloanAmount;

    @NonNull
    public final AppCompatTextView fiatloanDueIncome;

    @NonNull
    public final AppCompatTextView fiatloanDueType;

    @NonNull
    public final AppCompatTextView fiatloanMinAmount;

    @NonNull
    public final AppCompatTextView fiatloanTypeLabel;

    @NonNull
    public final AppCompatTextView message;

    @NonNull
    public final AppCompatTextView name;

    @NonNull
    public final AppCompatTextView payWayLabel;

    @NonNull
    public final LinearLayout payWayLayout;

    @NonNull
    public final AppCompatTextView period;

    @NonNull
    public final LinearLayout periodLayout;

    @NonNull
    private final ConstraintLayout rootView;

    @NonNull
    public final AppCompatTextView title;

    @NonNull
    public final TextView wechat;

    @NonNull
    public final RView wechatColor;

    private FiatloanDialogShareBinding(@NonNull ConstraintLayout constraintLayout, @NonNull TextView textView, @NonNull RView rView, @NonNull FrameLayout frameLayout, @NonNull ImageView imageView, @NonNull AppCompatTextView appCompatTextView, @NonNull TextView textView2, @NonNull RView rView2, @NonNull LinearLayout linearLayout, @NonNull AppCompatTextView appCompatTextView2, @NonNull AppCompatTextView appCompatTextView3, @NonNull AppCompatTextView appCompatTextView4, @NonNull AppCompatTextView appCompatTextView5, @NonNull AppCompatTextView appCompatTextView6, @NonNull AppCompatTextView appCompatTextView7, @NonNull AppCompatTextView appCompatTextView8, @NonNull AppCompatTextView appCompatTextView9, @NonNull LinearLayout linearLayout2, @NonNull AppCompatTextView appCompatTextView10, @NonNull LinearLayout linearLayout3, @NonNull AppCompatTextView appCompatTextView11, @NonNull TextView textView3, @NonNull RView rView3) {
        this.rootView = constraintLayout;
        this.ali = textView;
        this.aliColor = rView;
        this.avatar = frameLayout;
        this.avatarImg = imageView;
        this.avatarText = appCompatTextView;
        this.bank = textView2;
        this.bankColor = rView2;
        this.dueIncomeLayout = linearLayout;
        this.fiatloanAmount = appCompatTextView2;
        this.fiatloanDueIncome = appCompatTextView3;
        this.fiatloanDueType = appCompatTextView4;
        this.fiatloanMinAmount = appCompatTextView5;
        this.fiatloanTypeLabel = appCompatTextView6;
        this.message = appCompatTextView7;
        this.name = appCompatTextView8;
        this.payWayLabel = appCompatTextView9;
        this.payWayLayout = linearLayout2;
        this.period = appCompatTextView10;
        this.periodLayout = linearLayout3;
        this.title = appCompatTextView11;
        this.wechat = textView3;
        this.wechatColor = rView3;
    }

    @NonNull
    public static FiatloanDialogShareBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanDialogShareBinding bind(@NonNull View view) {
        int i10 = R.id.ali;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
        if (textView != null) {
            i10 = R.id.ali_color;
            RView rView = (RView) ViewBindings.findChildViewById(view, i10);
            if (rView != null) {
                i10 = R.id.avatar;
                FrameLayout frameLayout = (FrameLayout) ViewBindings.findChildViewById(view, i10);
                if (frameLayout != null) {
                    i10 = R.id.avatar_img;
                    ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
                    if (imageView != null) {
                        i10 = R.id.avatar_text;
                        AppCompatTextView appCompatTextView = (AppCompatTextView) ViewBindings.findChildViewById(view, i10);
                        if (appCompatTextView != null) {
                            i10 = R.id.bank;
                            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView2 != null) {
                                i10 = R.id.bank_color;
                                RView rView2 = (RView) ViewBindings.findChildViewById(view, i10);
                                if (rView2 != null) {
                                    i10 = R.id.due_income_layout;
                                    LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                    if (linearLayout != null) {
                                        i10 = R.id.fiatloan_amount;
                                        AppCompatTextView appCompatTextView2 = (AppCompatTextView) ViewBindings.findChildViewById(view, i10);
                                        if (appCompatTextView2 != null) {
                                            i10 = R.id.fiatloan_due_income;
                                            AppCompatTextView appCompatTextView3 = (AppCompatTextView) ViewBindings.findChildViewById(view, i10);
                                            if (appCompatTextView3 != null) {
                                                i10 = R.id.fiatloan_due_type;
                                                AppCompatTextView appCompatTextView4 = (AppCompatTextView) ViewBindings.findChildViewById(view, i10);
                                                if (appCompatTextView4 != null) {
                                                    i10 = R.id.fiatloan_min_amount;
                                                    AppCompatTextView appCompatTextView5 = (AppCompatTextView) ViewBindings.findChildViewById(view, i10);
                                                    if (appCompatTextView5 != null) {
                                                        i10 = R.id.fiatloan_type_label;
                                                        AppCompatTextView appCompatTextView6 = (AppCompatTextView) ViewBindings.findChildViewById(view, i10);
                                                        if (appCompatTextView6 != null) {
                                                            i10 = R.id.message;
                                                            AppCompatTextView appCompatTextView7 = (AppCompatTextView) ViewBindings.findChildViewById(view, i10);
                                                            if (appCompatTextView7 != null) {
                                                                i10 = R.id.name;
                                                                AppCompatTextView appCompatTextView8 = (AppCompatTextView) ViewBindings.findChildViewById(view, i10);
                                                                if (appCompatTextView8 != null) {
                                                                    i10 = R.id.pay_way_label;
                                                                    AppCompatTextView appCompatTextView9 = (AppCompatTextView) ViewBindings.findChildViewById(view, i10);
                                                                    if (appCompatTextView9 != null) {
                                                                        i10 = R.id.pay_way_layout;
                                                                        LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                        if (linearLayout2 != null) {
                                                                            i10 = R.id.period;
                                                                            AppCompatTextView appCompatTextView10 = (AppCompatTextView) ViewBindings.findChildViewById(view, i10);
                                                                            if (appCompatTextView10 != null) {
                                                                                i10 = R.id.period_layout;
                                                                                LinearLayout linearLayout3 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                                if (linearLayout3 != null) {
                                                                                    i10 = R.id.title;
                                                                                    AppCompatTextView appCompatTextView11 = (AppCompatTextView) ViewBindings.findChildViewById(view, i10);
                                                                                    if (appCompatTextView11 != null) {
                                                                                        i10 = R.id.wechat;
                                                                                        TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                        if (textView3 != null) {
                                                                                            i10 = R.id.wechat_color;
                                                                                            RView rView3 = (RView) ViewBindings.findChildViewById(view, i10);
                                                                                            if (rView3 != null) {
                                                                                                return new FiatloanDialogShareBinding((ConstraintLayout) view, textView, rView, frameLayout, imageView, appCompatTextView, textView2, rView2, linearLayout, appCompatTextView2, appCompatTextView3, appCompatTextView4, appCompatTextView5, appCompatTextView6, appCompatTextView7, appCompatTextView8, appCompatTextView9, linearLayout2, appCompatTextView10, linearLayout3, appCompatTextView11, textView3, rView3);
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanDialogShareBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_dialog_share, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public ConstraintLayout getRoot() {
        return this.rootView;
    }
}