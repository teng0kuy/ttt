package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.button.GTButtonV3;
import com.gateio.lib.uikit.title.GTTitleViewV3;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;

/* loaded from: classes38.dex */
public final class FiatloanActivityCurrentOrderDetailBinding implements ViewBinding {

    @NonNull
    public final LinearLayout animWait;

    @NonNull
    public final TextView animWaitTip;

    @NonNull
    public final GTButtonV3 appeal;

    @NonNull
    public final LinearLayout buttonLayout;

    @NonNull
    public final FiatloanLayoutOrderDetailCountdownBinding countdown;

    @NonNull
    public final FiatloanLayoutOrderDetailHeadBinding head;

    @NonNull
    public final GTButtonV3 operate1;

    @NonNull
    public final GTButtonV3 operate2;

    @NonNull
    public final FiatloanLayoutOrderDetailPeriodBinding period;

    @NonNull
    public final FiatloanLayoutOrderDetailProcessBinding process;

    @NonNull
    public final FiatloanLayoutOrderDetailChartBinding riskChart;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final NestedScrollView scrollView;

    @NonNull
    public final SmartRefreshLayout swipeRefresh;

    @NonNull
    public final GTTitleViewV3 title;

    @NonNull
    public static FiatloanActivityCurrentOrderDetailBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanActivityCurrentOrderDetailBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        int i10 = R.id.anim_wait;
        LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
        if (linearLayout != null) {
            i10 = R.id.anim_wait_tip;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                i10 = R.id.appeal;
                GTButtonV3 gTButtonV3 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                if (gTButtonV3 != null) {
                    i10 = R.id.button_layout;
                    LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                    if (linearLayout2 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.countdown))) != null) {
                        FiatloanLayoutOrderDetailCountdownBinding fiatloanLayoutOrderDetailCountdownBindingBind = FiatloanLayoutOrderDetailCountdownBinding.bind(viewFindChildViewById);
                        i10 = R.id.head;
                        View viewFindChildViewById3 = ViewBindings.findChildViewById(view, i10);
                        if (viewFindChildViewById3 != null) {
                            FiatloanLayoutOrderDetailHeadBinding fiatloanLayoutOrderDetailHeadBindingBind = FiatloanLayoutOrderDetailHeadBinding.bind(viewFindChildViewById3);
                            i10 = R.id.operate1;
                            GTButtonV3 gTButtonV32 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                            if (gTButtonV32 != null) {
                                i10 = R.id.operate2;
                                GTButtonV3 gTButtonV33 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                                if (gTButtonV33 != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i10 = R.id.period))) != null) {
                                    FiatloanLayoutOrderDetailPeriodBinding fiatloanLayoutOrderDetailPeriodBindingBind = FiatloanLayoutOrderDetailPeriodBinding.bind(viewFindChildViewById2);
                                    i10 = R.id.process;
                                    View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i10);
                                    if (viewFindChildViewById4 != null) {
                                        FiatloanLayoutOrderDetailProcessBinding fiatloanLayoutOrderDetailProcessBindingBind = FiatloanLayoutOrderDetailProcessBinding.bind(viewFindChildViewById4);
                                        i10 = R.id.risk_chart;
                                        View viewFindChildViewById5 = ViewBindings.findChildViewById(view, i10);
                                        if (viewFindChildViewById5 != null) {
                                            FiatloanLayoutOrderDetailChartBinding fiatloanLayoutOrderDetailChartBindingBind = FiatloanLayoutOrderDetailChartBinding.bind(viewFindChildViewById5);
                                            i10 = R.id.scroll_view;
                                            NestedScrollView nestedScrollView = (NestedScrollView) ViewBindings.findChildViewById(view, i10);
                                            if (nestedScrollView != null) {
                                                i10 = R.id.swipe_refresh;
                                                SmartRefreshLayout smartRefreshLayout = (SmartRefreshLayout) ViewBindings.findChildViewById(view, i10);
                                                if (smartRefreshLayout != null) {
                                                    i10 = R.id.title;
                                                    GTTitleViewV3 gTTitleViewV3 = (GTTitleViewV3) ViewBindings.findChildViewById(view, i10);
                                                    if (gTTitleViewV3 != null) {
                                                        return new FiatloanActivityCurrentOrderDetailBinding((LinearLayout) view, linearLayout, textView, gTButtonV3, linearLayout2, fiatloanLayoutOrderDetailCountdownBindingBind, fiatloanLayoutOrderDetailHeadBindingBind, gTButtonV32, gTButtonV33, fiatloanLayoutOrderDetailPeriodBindingBind, fiatloanLayoutOrderDetailProcessBindingBind, fiatloanLayoutOrderDetailChartBindingBind, nestedScrollView, smartRefreshLayout, gTTitleViewV3);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanActivityCurrentOrderDetailBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_activity_current_order_detail, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private FiatloanActivityCurrentOrderDetailBinding(@NonNull LinearLayout linearLayout, @NonNull LinearLayout linearLayout2, @NonNull TextView textView, @NonNull GTButtonV3 gTButtonV3, @NonNull LinearLayout linearLayout3, @NonNull FiatloanLayoutOrderDetailCountdownBinding fiatloanLayoutOrderDetailCountdownBinding, @NonNull FiatloanLayoutOrderDetailHeadBinding fiatloanLayoutOrderDetailHeadBinding, @NonNull GTButtonV3 gTButtonV32, @NonNull GTButtonV3 gTButtonV33, @NonNull FiatloanLayoutOrderDetailPeriodBinding fiatloanLayoutOrderDetailPeriodBinding, @NonNull FiatloanLayoutOrderDetailProcessBinding fiatloanLayoutOrderDetailProcessBinding, @NonNull FiatloanLayoutOrderDetailChartBinding fiatloanLayoutOrderDetailChartBinding, @NonNull NestedScrollView nestedScrollView, @NonNull SmartRefreshLayout smartRefreshLayout, @NonNull GTTitleViewV3 gTTitleViewV3) {
        this.rootView = linearLayout;
        this.animWait = linearLayout2;
        this.animWaitTip = textView;
        this.appeal = gTButtonV3;
        this.buttonLayout = linearLayout3;
        this.countdown = fiatloanLayoutOrderDetailCountdownBinding;
        this.head = fiatloanLayoutOrderDetailHeadBinding;
        this.operate1 = gTButtonV32;
        this.operate2 = gTButtonV33;
        this.period = fiatloanLayoutOrderDetailPeriodBinding;
        this.process = fiatloanLayoutOrderDetailProcessBinding;
        this.riskChart = fiatloanLayoutOrderDetailChartBinding;
        this.scrollView = nestedScrollView;
        this.swipeRefresh = smartRefreshLayout;
        this.title = gTTitleViewV3;
    }
}