package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.steps.GTStepBarV3;

/* loaded from: classes38.dex */
public final class FiatloanLayoutOrderDetailProcessBinding implements ViewBinding {

    @NonNull
    public final TextView processLabel;

    @NonNull
    public final GTStepBarV3 processStep;

    @NonNull
    public final TextView processTip;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public static FiatloanLayoutOrderDetailProcessBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanLayoutOrderDetailProcessBinding bind(@NonNull View view) {
        int i10 = R.id.process_label;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
        if (textView != null) {
            i10 = R.id.process_step;
            GTStepBarV3 gTStepBarV3 = (GTStepBarV3) ViewBindings.findChildViewById(view, i10);
            if (gTStepBarV3 != null) {
                i10 = R.id.process_tip;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView2 != null) {
                    return new FiatloanLayoutOrderDetailProcessBinding((RelativeLayout) view, textView, gTStepBarV3, textView2);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanLayoutOrderDetailProcessBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_layout_order_detail_process, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private FiatloanLayoutOrderDetailProcessBinding(@NonNull RelativeLayout relativeLayout, @NonNull TextView textView, @NonNull GTStepBarV3 gTStepBarV3, @NonNull TextView textView2) {
        this.rootView = relativeLayout;
        this.processLabel = textView;
        this.processStep = gTStepBarV3;
        this.processTip = textView2;
    }
}