package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.button.GTButtonV3;
import com.gateio.lib.uikit.state.GTEmptyViewV3;
import com.gateio.lib.uikit.title.GTTitleViewV3;
import com.gateio.lib.uikit.upload.GTUploadV3;

/* loaded from: classes38.dex */
public final class FiatloanActivityAppealBinding implements ViewBinding {

    @NonNull
    public final TextView appealHistoryLabel;

    @NonNull
    public final GTEmptyViewV3 empty;

    @NonNull
    public final EditText input;

    @NonNull
    public final GTUploadV3 pic1;

    @NonNull
    public final GTUploadV3 pic2;

    @NonNull
    public final GTUploadV3 pic3;

    @NonNull
    public final HorizontalScrollView picLayout;

    @NonNull
    public final TextView picTip;

    @NonNull
    public final RecyclerView recyclerView;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final GTButtonV3 submit;

    @NonNull
    public final GTTitleViewV3 title;

    @NonNull
    public static FiatloanActivityAppealBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanActivityAppealBinding bind(@NonNull View view) {
        int i10 = R.id.appeal_history_label;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
        if (textView != null) {
            i10 = R.id.empty;
            GTEmptyViewV3 gTEmptyViewV3 = (GTEmptyViewV3) ViewBindings.findChildViewById(view, i10);
            if (gTEmptyViewV3 != null) {
                i10 = R.id.input;
                EditText editText = (EditText) ViewBindings.findChildViewById(view, i10);
                if (editText != null) {
                    i10 = R.id.pic1;
                    GTUploadV3 gTUploadV3 = (GTUploadV3) ViewBindings.findChildViewById(view, i10);
                    if (gTUploadV3 != null) {
                        i10 = R.id.pic2;
                        GTUploadV3 gTUploadV32 = (GTUploadV3) ViewBindings.findChildViewById(view, i10);
                        if (gTUploadV32 != null) {
                            i10 = R.id.pic3;
                            GTUploadV3 gTUploadV33 = (GTUploadV3) ViewBindings.findChildViewById(view, i10);
                            if (gTUploadV33 != null) {
                                i10 = R.id.pic_layout;
                                HorizontalScrollView horizontalScrollView = (HorizontalScrollView) ViewBindings.findChildViewById(view, i10);
                                if (horizontalScrollView != null) {
                                    i10 = R.id.pic_tip;
                                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView2 != null) {
                                        i10 = R.id.recycler_view;
                                        RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                                        if (recyclerView != null) {
                                            i10 = R.id.submit;
                                            GTButtonV3 gTButtonV3 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
                                            if (gTButtonV3 != null) {
                                                i10 = R.id.title;
                                                GTTitleViewV3 gTTitleViewV3 = (GTTitleViewV3) ViewBindings.findChildViewById(view, i10);
                                                if (gTTitleViewV3 != null) {
                                                    return new FiatloanActivityAppealBinding((RelativeLayout) view, textView, gTEmptyViewV3, editText, gTUploadV3, gTUploadV32, gTUploadV33, horizontalScrollView, textView2, recyclerView, gTButtonV3, gTTitleViewV3);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanActivityAppealBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_activity_appeal, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private FiatloanActivityAppealBinding(@NonNull RelativeLayout relativeLayout, @NonNull TextView textView, @NonNull GTEmptyViewV3 gTEmptyViewV3, @NonNull EditText editText, @NonNull GTUploadV3 gTUploadV3, @NonNull GTUploadV3 gTUploadV32, @NonNull GTUploadV3 gTUploadV33, @NonNull HorizontalScrollView horizontalScrollView, @NonNull TextView textView2, @NonNull RecyclerView recyclerView, @NonNull GTButtonV3 gTButtonV3, @NonNull GTTitleViewV3 gTTitleViewV3) {
        this.rootView = relativeLayout;
        this.appealHistoryLabel = textView;
        this.empty = gTEmptyViewV3;
        this.input = editText;
        this.pic1 = gTUploadV3;
        this.pic2 = gTUploadV32;
        this.pic3 = gTUploadV33;
        this.picLayout = horizontalScrollView;
        this.picTip = textView2;
        this.recyclerView = recyclerView;
        this.submit = gTButtonV3;
        this.title = gTTitleViewV3;
    }
}