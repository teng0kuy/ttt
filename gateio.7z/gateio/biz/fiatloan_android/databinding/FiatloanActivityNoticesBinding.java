package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.state.GTEmptyViewV3;
import com.gateio.lib.uikit.title.GTTitleViewV3;
import com.gateio.lib.uikit.widget.GTCheckBoxV3;

/* loaded from: classes38.dex */
public final class FiatloanActivityNoticesBinding implements ViewBinding {

    @NonNull
    public final GTCheckBoxV3 checkAll;

    @NonNull
    public final TextView delete;

    @NonNull
    public final RelativeLayout editHeadLayout;

    @NonNull
    public final GTEmptyViewV3 empty;

    @NonNull
    public final RecyclerView recyclerView;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final GTTitleViewV3 title;

    @NonNull
    public static FiatloanActivityNoticesBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanActivityNoticesBinding bind(@NonNull View view) {
        int i10 = R.id.check_all;
        GTCheckBoxV3 gTCheckBoxV3 = (GTCheckBoxV3) ViewBindings.findChildViewById(view, i10);
        if (gTCheckBoxV3 != null) {
            i10 = R.id.delete;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                i10 = R.id.edit_head_layout;
                RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                if (relativeLayout != null) {
                    i10 = R.id.empty;
                    GTEmptyViewV3 gTEmptyViewV3 = (GTEmptyViewV3) ViewBindings.findChildViewById(view, i10);
                    if (gTEmptyViewV3 != null) {
                        i10 = R.id.recyclerView;
                        RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                        if (recyclerView != null) {
                            i10 = R.id.title;
                            GTTitleViewV3 gTTitleViewV3 = (GTTitleViewV3) ViewBindings.findChildViewById(view, i10);
                            if (gTTitleViewV3 != null) {
                                return new FiatloanActivityNoticesBinding((LinearLayout) view, gTCheckBoxV3, textView, relativeLayout, gTEmptyViewV3, recyclerView, gTTitleViewV3);
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanActivityNoticesBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_activity_notices, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private FiatloanActivityNoticesBinding(@NonNull LinearLayout linearLayout, @NonNull GTCheckBoxV3 gTCheckBoxV3, @NonNull TextView textView, @NonNull RelativeLayout relativeLayout, @NonNull GTEmptyViewV3 gTEmptyViewV3, @NonNull RecyclerView recyclerView, @NonNull GTTitleViewV3 gTTitleViewV3) {
        this.rootView = linearLayout;
        this.checkAll = gTCheckBoxV3;
        this.delete = textView;
        this.editHeadLayout = relativeLayout;
        this.empty = gTEmptyViewV3;
        this.recyclerView = recyclerView;
        this.title = gTTitleViewV3;
    }
}