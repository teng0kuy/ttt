package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.button.GTButtonV3;
import com.gateio.lib.uikit.title.GTTitleViewV3;

/* loaded from: classes38.dex */
public final class FiatloanActivityHistoryOrderDetailBinding implements ViewBinding {

    @NonNull
    public final GTButtonV3 appeal;

    @NonNull
    public final FiatloanLayoutOrderDetailHeadBinding head;

    @NonNull
    public final FiatloanLayoutOrderDetailPeriodBinding period;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final NestedScrollView scrollView;

    @NonNull
    public final GTTitleViewV3 title;

    @NonNull
    public static FiatloanActivityHistoryOrderDetailBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanActivityHistoryOrderDetailBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.appeal;
        GTButtonV3 gTButtonV3 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
        if (gTButtonV3 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.head))) != null) {
            FiatloanLayoutOrderDetailHeadBinding fiatloanLayoutOrderDetailHeadBindingBind = FiatloanLayoutOrderDetailHeadBinding.bind(viewFindChildViewById);
            i10 = R.id.period;
            View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i10);
            if (viewFindChildViewById2 != null) {
                FiatloanLayoutOrderDetailPeriodBinding fiatloanLayoutOrderDetailPeriodBindingBind = FiatloanLayoutOrderDetailPeriodBinding.bind(viewFindChildViewById2);
                i10 = R.id.scroll_view;
                NestedScrollView nestedScrollView = (NestedScrollView) ViewBindings.findChildViewById(view, i10);
                if (nestedScrollView != null) {
                    i10 = R.id.title;
                    GTTitleViewV3 gTTitleViewV3 = (GTTitleViewV3) ViewBindings.findChildViewById(view, i10);
                    if (gTTitleViewV3 != null) {
                        return new FiatloanActivityHistoryOrderDetailBinding((LinearLayout) view, gTButtonV3, fiatloanLayoutOrderDetailHeadBindingBind, fiatloanLayoutOrderDetailPeriodBindingBind, nestedScrollView, gTTitleViewV3);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanActivityHistoryOrderDetailBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_activity_history_order_detail, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private FiatloanActivityHistoryOrderDetailBinding(@NonNull LinearLayout linearLayout, @NonNull GTButtonV3 gTButtonV3, @NonNull FiatloanLayoutOrderDetailHeadBinding fiatloanLayoutOrderDetailHeadBinding, @NonNull FiatloanLayoutOrderDetailPeriodBinding fiatloanLayoutOrderDetailPeriodBinding, @NonNull NestedScrollView nestedScrollView, @NonNull GTTitleViewV3 gTTitleViewV3) {
        this.rootView = linearLayout;
        this.appeal = gTButtonV3;
        this.head = fiatloanLayoutOrderDetailHeadBinding;
        this.period = fiatloanLayoutOrderDetailPeriodBinding;
        this.scrollView = nestedScrollView;
        this.title = gTTitleViewV3;
    }
}