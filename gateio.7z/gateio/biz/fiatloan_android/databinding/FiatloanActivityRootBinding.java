package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.common.view.CustomViewpager;
import com.gateio.lib.uikit.title.GTTitleViewV3;
import net.lucode.hackware.magicindicator.MagicIndicator;

/* loaded from: classes38.dex */
public final class FiatloanActivityRootBinding implements ViewBinding {

    @NonNull
    public final View divider;

    @NonNull
    public final MagicIndicator magicIndicator;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final GTTitleViewV3 title;

    @NonNull
    public final CustomViewpager viewpager;

    @NonNull
    public static FiatloanActivityRootBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanActivityRootBinding bind(@NonNull View view) {
        int i10 = R.id.divider;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i10);
        if (viewFindChildViewById != null) {
            i10 = R.id.magicIndicator;
            MagicIndicator magicIndicator = (MagicIndicator) ViewBindings.findChildViewById(view, i10);
            if (magicIndicator != null) {
                i10 = R.id.title;
                GTTitleViewV3 gTTitleViewV3 = (GTTitleViewV3) ViewBindings.findChildViewById(view, i10);
                if (gTTitleViewV3 != null) {
                    i10 = R.id.viewpager;
                    CustomViewpager customViewpager = (CustomViewpager) ViewBindings.findChildViewById(view, i10);
                    if (customViewpager != null) {
                        return new FiatloanActivityRootBinding((RelativeLayout) view, viewFindChildViewById, magicIndicator, gTTitleViewV3, customViewpager);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanActivityRootBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_activity_root, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private FiatloanActivityRootBinding(@NonNull RelativeLayout relativeLayout, @NonNull View view, @NonNull MagicIndicator magicIndicator, @NonNull GTTitleViewV3 gTTitleViewV3, @NonNull CustomViewpager customViewpager) {
        this.rootView = relativeLayout;
        this.divider = view;
        this.magicIndicator = magicIndicator;
        this.title = gTTitleViewV3;
        this.viewpager = customViewpager;
    }
}