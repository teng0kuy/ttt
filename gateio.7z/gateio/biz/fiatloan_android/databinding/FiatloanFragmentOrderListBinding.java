package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.state.GTEmptyViewV3;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;

/* loaded from: classes38.dex */
public final class FiatloanFragmentOrderListBinding implements ViewBinding {

    @NonNull
    public final GTEmptyViewV3 empty;

    @NonNull
    public final RecyclerView recyclerView;

    @NonNull
    public final SmartRefreshLayout refresh;

    @NonNull
    private final SmartRefreshLayout rootView;

    @NonNull
    public static FiatloanFragmentOrderListBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanFragmentOrderListBinding bind(@NonNull View view) {
        int i10 = R.id.empty;
        GTEmptyViewV3 gTEmptyViewV3 = (GTEmptyViewV3) ViewBindings.findChildViewById(view, i10);
        if (gTEmptyViewV3 != null) {
            i10 = R.id.recyclerView;
            RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
            if (recyclerView != null) {
                SmartRefreshLayout smartRefreshLayout = (SmartRefreshLayout) view;
                return new FiatloanFragmentOrderListBinding(smartRefreshLayout, gTEmptyViewV3, recyclerView, smartRefreshLayout);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanFragmentOrderListBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_fragment_order_list, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public SmartRefreshLayout getRoot() {
        return this.rootView;
    }

    private FiatloanFragmentOrderListBinding(@NonNull SmartRefreshLayout smartRefreshLayout, @NonNull GTEmptyViewV3 gTEmptyViewV3, @NonNull RecyclerView recyclerView, @NonNull SmartRefreshLayout smartRefreshLayout2) {
        this.rootView = smartRefreshLayout;
        this.empty = gTEmptyViewV3;
        this.recyclerView = recyclerView;
        this.refresh = smartRefreshLayout2;
    }
}