package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.alert.GTAlertV3;
import com.gateio.lib.uikit.button.GTButtonV3;
import com.gateio.lib.uikit.title.GTTitleViewV3;

/* loaded from: classes38.dex */
public final class FiatloanActivityAddCollateralResultBinding implements ViewBinding {

    @NonNull
    public final GTAlertV3 alert;

    @NonNull
    public final GTButtonV3 deposit;

    @NonNull
    public final RecyclerView recyclerView;

    @NonNull
    private final ConstraintLayout rootView;

    @NonNull
    public final GTTitleViewV3 title;

    @NonNull
    public static FiatloanActivityAddCollateralResultBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanActivityAddCollateralResultBinding bind(@NonNull View view) {
        int i10 = R.id.alert;
        GTAlertV3 gTAlertV3 = (GTAlertV3) ViewBindings.findChildViewById(view, i10);
        if (gTAlertV3 != null) {
            i10 = R.id.deposit;
            GTButtonV3 gTButtonV3 = (GTButtonV3) ViewBindings.findChildViewById(view, i10);
            if (gTButtonV3 != null) {
                i10 = R.id.recycler_view;
                RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                if (recyclerView != null) {
                    i10 = R.id.title;
                    GTTitleViewV3 gTTitleViewV3 = (GTTitleViewV3) ViewBindings.findChildViewById(view, i10);
                    if (gTTitleViewV3 != null) {
                        return new FiatloanActivityAddCollateralResultBinding((ConstraintLayout) view, gTAlertV3, gTButtonV3, recyclerView, gTTitleViewV3);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanActivityAddCollateralResultBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_activity_add_collateral_result, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    private FiatloanActivityAddCollateralResultBinding(@NonNull ConstraintLayout constraintLayout, @NonNull GTAlertV3 gTAlertV3, @NonNull GTButtonV3 gTButtonV3, @NonNull RecyclerView recyclerView, @NonNull GTTitleViewV3 gTTitleViewV3) {
        this.rootView = constraintLayout;
        this.alert = gTAlertV3;
        this.deposit = gTButtonV3;
        this.recyclerView = recyclerView;
        this.title = gTTitleViewV3;
    }
}