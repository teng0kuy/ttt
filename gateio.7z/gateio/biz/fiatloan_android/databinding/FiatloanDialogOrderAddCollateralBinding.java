package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.lib.uikit.input.GTEditTextV3;
import com.gateio.lib.uikit.reminder.GTReminderV3;

/* loaded from: classes38.dex */
public final class FiatloanDialogOrderAddCollateralBinding implements ViewBinding {

    @NonNull
    public final GTEditTextV3 addCollateralAmount;

    @NonNull
    public final TextView amount;

    @NonNull
    public final TextView amountLabel;

    @NonNull
    public final RelativeLayout amountLayout;

    @NonNull
    public final GTEditTextV3 fundPass;

    @NonNull
    public final TextView name;

    @NonNull
    public final TextView nameLabel;

    @NonNull
    public final RelativeLayout nameLayout;

    @NonNull
    public final TextView orderId;

    @NonNull
    public final TextView orderIdLabel;

    @NonNull
    public final RelativeLayout orderIdLayout;

    @NonNull
    public final TextView pledgeType;

    @NonNull
    public final TextView pledgeTypeLabel;

    @NonNull
    public final RelativeLayout pledgeTypeLayout;

    @NonNull
    public final GTReminderV3 reminder;

    @NonNull
    private final LinearLayout rootView;

    private FiatloanDialogOrderAddCollateralBinding(@NonNull LinearLayout linearLayout, @NonNull GTEditTextV3 gTEditTextV3, @NonNull TextView textView, @NonNull TextView textView2, @NonNull RelativeLayout relativeLayout, @NonNull GTEditTextV3 gTEditTextV32, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull RelativeLayout relativeLayout2, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull RelativeLayout relativeLayout3, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull RelativeLayout relativeLayout4, @NonNull GTReminderV3 gTReminderV3) {
        this.rootView = linearLayout;
        this.addCollateralAmount = gTEditTextV3;
        this.amount = textView;
        this.amountLabel = textView2;
        this.amountLayout = relativeLayout;
        this.fundPass = gTEditTextV32;
        this.name = textView3;
        this.nameLabel = textView4;
        this.nameLayout = relativeLayout2;
        this.orderId = textView5;
        this.orderIdLabel = textView6;
        this.orderIdLayout = relativeLayout3;
        this.pledgeType = textView7;
        this.pledgeTypeLabel = textView8;
        this.pledgeTypeLayout = relativeLayout4;
        this.reminder = gTReminderV3;
    }

    @NonNull
    public static FiatloanDialogOrderAddCollateralBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanDialogOrderAddCollateralBinding bind(@NonNull View view) {
        int i10 = R.id.add_collateral_amount;
        GTEditTextV3 gTEditTextV3 = (GTEditTextV3) ViewBindings.findChildViewById(view, i10);
        if (gTEditTextV3 != null) {
            i10 = R.id.amount;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                i10 = R.id.amount_label;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView2 != null) {
                    i10 = R.id.amount_layout;
                    RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                    if (relativeLayout != null) {
                        i10 = R.id.fund_pass;
                        GTEditTextV3 gTEditTextV32 = (GTEditTextV3) ViewBindings.findChildViewById(view, i10);
                        if (gTEditTextV32 != null) {
                            i10 = R.id.name;
                            TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView3 != null) {
                                i10 = R.id.name_label;
                                TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView4 != null) {
                                    i10 = R.id.name_layout;
                                    RelativeLayout relativeLayout2 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                    if (relativeLayout2 != null) {
                                        i10 = R.id.order_id;
                                        TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView5 != null) {
                                            i10 = R.id.order_id_label;
                                            TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView6 != null) {
                                                i10 = R.id.order_id_layout;
                                                RelativeLayout relativeLayout3 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                if (relativeLayout3 != null) {
                                                    i10 = R.id.pledge_type;
                                                    TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                    if (textView7 != null) {
                                                        i10 = R.id.pledge_type_label;
                                                        TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                        if (textView8 != null) {
                                                            i10 = R.id.pledge_type_layout;
                                                            RelativeLayout relativeLayout4 = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                                            if (relativeLayout4 != null) {
                                                                i10 = R.id.reminder;
                                                                GTReminderV3 gTReminderV3 = (GTReminderV3) ViewBindings.findChildViewById(view, i10);
                                                                if (gTReminderV3 != null) {
                                                                    return new FiatloanDialogOrderAddCollateralBinding((LinearLayout) view, gTEditTextV3, textView, textView2, relativeLayout, gTEditTextV32, textView3, textView4, relativeLayout2, textView5, textView6, relativeLayout3, textView7, textView8, relativeLayout4, gTReminderV3);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanDialogOrderAddCollateralBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_dialog_order_add_collateral, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }
}