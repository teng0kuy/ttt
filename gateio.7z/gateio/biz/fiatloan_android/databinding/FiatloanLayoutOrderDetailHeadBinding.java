package com.gateio.biz.fiatloan_android.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.fiatloan_android.R;
import com.gateio.common.view.GateioAvatarView;
import com.gateio.lib.uikit.tag.GTTagV3;

/* loaded from: classes38.dex */
public final class FiatloanLayoutOrderDetailHeadBinding implements ViewBinding {

    @NonNull
    public final GateioAvatarView avatar;

    @NonNull
    public final TextView counterpartName;

    @NonNull
    public final TextView dailyRate;

    @NonNull
    public final TextView dailyRateLabel;

    @NonNull
    public final View divider;

    @NonNull
    public final TextView interest;

    @NonNull
    public final TextView interestLabel;

    @NonNull
    public final LinearLayout notice;

    @NonNull
    public final TextView orderId;

    @NonNull
    public final TextView penaltyInterest;

    @NonNull
    public final TextView penaltyInterestLabel;

    @NonNull
    public final TextView pledgeAmount;

    @NonNull
    public final TextView pledgeAmountLabel;

    @NonNull
    public final TextView pledgeRate;

    @NonNull
    public final TextView pledgeRateLabel;

    @NonNull
    public final TextView principalPlusInterest;

    @NonNull
    public final TextView principalPlusInterestLabel;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final GTTagV3 status;

    @NonNull
    public final LinearLayout titleContainer;

    @NonNull
    public final TextView totalAmount;

    @NonNull
    public final TextView totalAmountLabel;

    @NonNull
    public final TextView userName;

    private FiatloanLayoutOrderDetailHeadBinding(@NonNull RelativeLayout relativeLayout, @NonNull GateioAvatarView gateioAvatarView, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull View view, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull LinearLayout linearLayout, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textView9, @NonNull TextView textView10, @NonNull TextView textView11, @NonNull TextView textView12, @NonNull TextView textView13, @NonNull TextView textView14, @NonNull GTTagV3 gTTagV3, @NonNull LinearLayout linearLayout2, @NonNull TextView textView15, @NonNull TextView textView16, @NonNull TextView textView17) {
        this.rootView = relativeLayout;
        this.avatar = gateioAvatarView;
        this.counterpartName = textView;
        this.dailyRate = textView2;
        this.dailyRateLabel = textView3;
        this.divider = view;
        this.interest = textView4;
        this.interestLabel = textView5;
        this.notice = linearLayout;
        this.orderId = textView6;
        this.penaltyInterest = textView7;
        this.penaltyInterestLabel = textView8;
        this.pledgeAmount = textView9;
        this.pledgeAmountLabel = textView10;
        this.pledgeRate = textView11;
        this.pledgeRateLabel = textView12;
        this.principalPlusInterest = textView13;
        this.principalPlusInterestLabel = textView14;
        this.status = gTTagV3;
        this.titleContainer = linearLayout2;
        this.totalAmount = textView15;
        this.totalAmountLabel = textView16;
        this.userName = textView17;
    }

    @NonNull
    public static FiatloanLayoutOrderDetailHeadBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FiatloanLayoutOrderDetailHeadBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.avatar;
        GateioAvatarView gateioAvatarView = (GateioAvatarView) ViewBindings.findChildViewById(view, i10);
        if (gateioAvatarView != null) {
            i10 = R.id.counterpart_name;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                i10 = R.id.daily_rate;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView2 != null) {
                    i10 = R.id.daily_rate_label;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView3 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.divider))) != null) {
                        i10 = R.id.interest;
                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView4 != null) {
                            i10 = R.id.interest_label;
                            TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView5 != null) {
                                i10 = R.id.notice;
                                LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                if (linearLayout != null) {
                                    i10 = R.id.order_id;
                                    TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView6 != null) {
                                        i10 = R.id.penalty_interest;
                                        TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView7 != null) {
                                            i10 = R.id.penalty_interest_label;
                                            TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView8 != null) {
                                                i10 = R.id.pledge_amount;
                                                TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView9 != null) {
                                                    i10 = R.id.pledge_amount_label;
                                                    TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                    if (textView10 != null) {
                                                        i10 = R.id.pledge_rate;
                                                        TextView textView11 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                        if (textView11 != null) {
                                                            i10 = R.id.pledge_rate_label;
                                                            TextView textView12 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                            if (textView12 != null) {
                                                                i10 = R.id.principal_plus_interest;
                                                                TextView textView13 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                if (textView13 != null) {
                                                                    i10 = R.id.principal_plus_interest_label;
                                                                    TextView textView14 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                    if (textView14 != null) {
                                                                        i10 = R.id.status;
                                                                        GTTagV3 gTTagV3 = (GTTagV3) ViewBindings.findChildViewById(view, i10);
                                                                        if (gTTagV3 != null) {
                                                                            i10 = R.id.title_container;
                                                                            LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                                                            if (linearLayout2 != null) {
                                                                                i10 = R.id.total_amount;
                                                                                TextView textView15 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                if (textView15 != null) {
                                                                                    i10 = R.id.total_amount_label;
                                                                                    TextView textView16 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                    if (textView16 != null) {
                                                                                        i10 = R.id.user_name;
                                                                                        TextView textView17 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                        if (textView17 != null) {
                                                                                            return new FiatloanLayoutOrderDetailHeadBinding((RelativeLayout) view, gateioAvatarView, textView, textView2, textView3, viewFindChildViewById, textView4, textView5, linearLayout, textView6, textView7, textView8, textView9, textView10, textView11, textView12, textView13, textView14, gTTagV3, linearLayout2, textView15, textView16, textView17);
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FiatloanLayoutOrderDetailHeadBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fiatloan_layout_order_detail_head, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }
}