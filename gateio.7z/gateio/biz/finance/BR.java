package com.gateio.biz.finance;

/* loaded from: classes38.dex */
public class BR {
    public static final int _all = 0;
}