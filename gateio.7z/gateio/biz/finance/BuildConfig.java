package com.gateio.biz.finance;

/* loaded from: classes38.dex */
public final class BuildConfig {
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "com.gateio.biz.finance";
}