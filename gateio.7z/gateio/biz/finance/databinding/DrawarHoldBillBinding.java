package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;

/* loaded from: classes7.dex */
public final class DrawarHoldBillBinding implements ViewBinding {

    @NonNull
    public final GridView gvType;

    @NonNull
    public final LinearLayout llBottom;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final TextView tvConfirm;

    @NonNull
    public final TextView tvCzlx;

    @NonNull
    public final TextView tvReset;

    @NonNull
    public static DrawarHoldBillBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static DrawarHoldBillBinding bind(@NonNull View view) {
        int i10 = R.id.gv_type;
        GridView gridView = (GridView) ViewBindings.findChildViewById(view, i10);
        if (gridView != null) {
            i10 = R.id.ll_bottom;
            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
            if (linearLayout != null) {
                i10 = R.id.tv_confirm;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView != null) {
                    i10 = R.id.tv_czlx;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView2 != null) {
                        i10 = R.id.tv_reset;
                        TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView3 != null) {
                            return new DrawarHoldBillBinding((RelativeLayout) view, gridView, linearLayout, textView, textView2, textView3);
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static DrawarHoldBillBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.drawar_hold_bill, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private DrawarHoldBillBinding(@NonNull RelativeLayout relativeLayout, @NonNull GridView gridView, @NonNull LinearLayout linearLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3) {
        this.rootView = relativeLayout;
        this.gvType = gridView;
        this.llBottom = linearLayout;
        this.tvConfirm = textView;
        this.tvCzlx = textView2;
        this.tvReset = textView3;
    }
}