package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.contrarywind.view.WheelView;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CornerLinearLayout;

/* loaded from: classes7.dex */
public final class FragmentActionTimePickBinding implements ViewBinding {

    @NonNull
    public final Button btnCancel;

    @NonNull
    public final TextView btnSubmit;

    @NonNull
    public final WheelView day;

    @NonNull
    public final WheelView hour;

    @NonNull
    public final WheelView min;

    @NonNull
    public final WheelView month;

    @NonNull
    private final CornerLinearLayout rootView;

    @NonNull
    public final RelativeLayout rvTopbar;

    @NonNull
    public final WheelView second;

    @NonNull
    public final LinearLayout timepicker;

    @NonNull
    public final TextView tvTitle;

    @NonNull
    public final WheelView year;

    @NonNull
    public static FragmentActionTimePickBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FragmentActionTimePickBinding bind(@NonNull View view) {
        int i10 = R.id.btnCancel;
        Button button = (Button) ViewBindings.findChildViewById(view, i10);
        if (button != null) {
            i10 = R.id.btnSubmit;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                i10 = R.id.day;
                WheelView wheelView = (WheelView) ViewBindings.findChildViewById(view, i10);
                if (wheelView != null) {
                    i10 = R.id.hour;
                    WheelView wheelView2 = (WheelView) ViewBindings.findChildViewById(view, i10);
                    if (wheelView2 != null) {
                        i10 = R.id.min;
                        WheelView wheelView3 = (WheelView) ViewBindings.findChildViewById(view, i10);
                        if (wheelView3 != null) {
                            i10 = R.id.month;
                            WheelView wheelView4 = (WheelView) ViewBindings.findChildViewById(view, i10);
                            if (wheelView4 != null) {
                                i10 = R.id.rv_topbar;
                                RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                                if (relativeLayout != null) {
                                    i10 = R.id.second;
                                    WheelView wheelView5 = (WheelView) ViewBindings.findChildViewById(view, i10);
                                    if (wheelView5 != null) {
                                        i10 = R.id.timepicker;
                                        LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                                        if (linearLayout != null) {
                                            i10 = R.id.tvTitle;
                                            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView2 != null) {
                                                i10 = R.id.year;
                                                WheelView wheelView6 = (WheelView) ViewBindings.findChildViewById(view, i10);
                                                if (wheelView6 != null) {
                                                    return new FragmentActionTimePickBinding((CornerLinearLayout) view, button, textView, wheelView, wheelView2, wheelView3, wheelView4, relativeLayout, wheelView5, linearLayout, textView2, wheelView6);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FragmentActionTimePickBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_action_time_pick, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public CornerLinearLayout getRoot() {
        return this.rootView;
    }

    private FragmentActionTimePickBinding(@NonNull CornerLinearLayout cornerLinearLayout, @NonNull Button button, @NonNull TextView textView, @NonNull WheelView wheelView, @NonNull WheelView wheelView2, @NonNull WheelView wheelView3, @NonNull WheelView wheelView4, @NonNull RelativeLayout relativeLayout, @NonNull WheelView wheelView5, @NonNull LinearLayout linearLayout, @NonNull TextView textView2, @NonNull WheelView wheelView6) {
        this.rootView = cornerLinearLayout;
        this.btnCancel = button;
        this.btnSubmit = textView;
        this.day = wheelView;
        this.hour = wheelView2;
        this.min = wheelView3;
        this.month = wheelView4;
        this.rvTopbar = relativeLayout;
        this.second = wheelView5;
        this.timepicker = linearLayout;
        this.tvTitle = textView2;
        this.year = wheelView6;
    }
}