package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CornerRelativeLayout;

/* loaded from: classes7.dex */
public final class ItemAmmRewardBinding implements ViewBinding {

    @NonNull
    public final ImageView ivQuote;

    @NonNull
    private final CornerRelativeLayout rootView;

    @NonNull
    public final TextView tvQuote;

    @NonNull
    public final TextView tvQuoteExchange;

    @NonNull
    public static ItemAmmRewardBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ItemAmmRewardBinding bind(@NonNull View view) {
        int i10 = R.id.iv_quote;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
        if (imageView != null) {
            i10 = R.id.tv_quote;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                i10 = R.id.tv_quote_exchange;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView2 != null) {
                    return new ItemAmmRewardBinding((CornerRelativeLayout) view, imageView, textView, textView2);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ItemAmmRewardBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.item_amm_reward, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public CornerRelativeLayout getRoot() {
        return this.rootView;
    }

    private ItemAmmRewardBinding(@NonNull CornerRelativeLayout cornerRelativeLayout, @NonNull ImageView imageView, @NonNull TextView textView, @NonNull TextView textView2) {
        this.rootView = cornerRelativeLayout;
        this.ivQuote = imageView;
        this.tvQuote = textView;
        this.tvQuoteExchange = textView2;
    }
}