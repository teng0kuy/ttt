package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import com.gateio.biz.finance.R;

/* loaded from: classes7.dex */
public final class FinanceItemPopTranstypeBinding implements ViewBinding {

    @NonNull
    public final TextView popOrdersType;

    @NonNull
    private final TextView rootView;

    @NonNull
    public static FinanceItemPopTranstypeBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FinanceItemPopTranstypeBinding bind(@NonNull View view) {
        if (view == null) {
            throw new NullPointerException("rootView");
        }
        TextView textView = (TextView) view;
        return new FinanceItemPopTranstypeBinding(textView, textView);
    }

    @NonNull
    public static FinanceItemPopTranstypeBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.finance_item_pop_transtype, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public TextView getRoot() {
        return this.rootView;
    }

    private FinanceItemPopTranstypeBinding(@NonNull TextView textView, @NonNull TextView textView2) {
        this.rootView = textView;
        this.popOrdersType = textView2;
    }
}