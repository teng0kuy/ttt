package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;

/* loaded from: classes7.dex */
public final class LabelLoanRepayBinding implements ViewBinding {

    @NonNull
    public final LinearLayout llLoanRepayLabel;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final TextView tvInterrestTitle;

    @NonNull
    public final TextView tvMarginNumber;

    @NonNull
    public final TextView tvOrderId;

    @NonNull
    public final TextView tvTimeRepay;

    @NonNull
    public static LabelLoanRepayBinding bind(@NonNull View view) {
        LinearLayout linearLayout = (LinearLayout) view;
        int i10 = R.id.tv_interrest_title;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
        if (textView != null) {
            i10 = R.id.tv_margin_number;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView2 != null) {
                i10 = R.id.tv_order_id;
                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView3 != null) {
                    i10 = R.id.tv_time_repay;
                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView4 != null) {
                        return new LabelLoanRepayBinding(linearLayout, linearLayout, textView, textView2, textView3, textView4);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static LabelLoanRepayBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static LabelLoanRepayBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.label_loan_repay, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private LabelLoanRepayBinding(@NonNull LinearLayout linearLayout, @NonNull LinearLayout linearLayout2, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4) {
        this.rootView = linearLayout;
        this.llLoanRepayLabel = linearLayout2;
        this.tvInterrestTitle = textView;
        this.tvMarginNumber = textView2;
        this.tvOrderId = textView3;
        this.tvTimeRepay = textView4;
    }
}