package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.databinding.LayoutHeaderNormalBinding;
import com.gateio.biz.finance.R;

/* loaded from: classes7.dex */
public final class ActivityLoancommitBinding implements ViewBinding {

    @NonNull
    public final CheckBox cbAll;

    @NonNull
    public final EditText edFundingJdsl;

    @NonNull
    public final LayoutHeaderNormalBinding layoutHeader;

    @NonNull
    public final TextView marginCommit;

    @NonNull
    public final RelativeLayout rlType;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final Switch swSwitch;

    @NonNull
    public final TextView tvCoin;

    @NonNull
    public final TextView tvLabel;

    @NonNull
    public final TextView tvMinimun;

    @NonNull
    public final TextView tvPeriod;

    @NonNull
    public final TextView tvRate;

    @NonNull
    public final TextView tvZdkj;

    @NonNull
    public final TextView tvZdkjAccount;

    @NonNull
    public static ActivityLoancommitBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ActivityLoancommitBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.cb_all;
        CheckBox checkBox = (CheckBox) ViewBindings.findChildViewById(view, i10);
        if (checkBox != null) {
            i10 = R.id.ed_funding_jdsl;
            EditText editText = (EditText) ViewBindings.findChildViewById(view, i10);
            if (editText != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.layout_header))) != null) {
                LayoutHeaderNormalBinding layoutHeaderNormalBindingBind = LayoutHeaderNormalBinding.bind(viewFindChildViewById);
                i10 = R.id.margin_commit;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView != null) {
                    i10 = R.id.rl_type;
                    RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                    if (relativeLayout != null) {
                        i10 = R.id.sw_switch;
                        Switch r10 = (Switch) ViewBindings.findChildViewById(view, i10);
                        if (r10 != null) {
                            i10 = R.id.tv_coin;
                            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView2 != null) {
                                i10 = R.id.tv_label;
                                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView3 != null) {
                                    i10 = R.id.tv_minimun;
                                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView4 != null) {
                                        i10 = R.id.tv_period;
                                        TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView5 != null) {
                                            i10 = R.id.tv_rate;
                                            TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView6 != null) {
                                                i10 = R.id.tv_zdkj;
                                                TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView7 != null) {
                                                    i10 = R.id.tv_zdkj_account;
                                                    TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                    if (textView8 != null) {
                                                        return new ActivityLoancommitBinding((RelativeLayout) view, checkBox, editText, layoutHeaderNormalBindingBind, textView, relativeLayout, r10, textView2, textView3, textView4, textView5, textView6, textView7, textView8);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ActivityLoancommitBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_loancommit, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private ActivityLoancommitBinding(@NonNull RelativeLayout relativeLayout, @NonNull CheckBox checkBox, @NonNull EditText editText, @NonNull LayoutHeaderNormalBinding layoutHeaderNormalBinding, @NonNull TextView textView, @NonNull RelativeLayout relativeLayout2, @NonNull Switch r72, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8) {
        this.rootView = relativeLayout;
        this.cbAll = checkBox;
        this.edFundingJdsl = editText;
        this.layoutHeader = layoutHeaderNormalBinding;
        this.marginCommit = textView;
        this.rlType = relativeLayout2;
        this.swSwitch = r72;
        this.tvCoin = textView2;
        this.tvLabel = textView3;
        this.tvMinimun = textView4;
        this.tvPeriod = textView5;
        this.tvRate = textView6;
        this.tvZdkj = textView7;
        this.tvZdkjAccount = textView8;
    }
}