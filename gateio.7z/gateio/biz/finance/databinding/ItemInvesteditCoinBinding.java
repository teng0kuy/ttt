package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;

/* loaded from: classes7.dex */
public final class ItemInvesteditCoinBinding implements ViewBinding {

    @NonNull
    public final ImageView ivLgo;

    @NonNull
    public final LinearLayout llRoot;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final ImageView transPriceAdd;

    @NonNull
    public final ImageView transPriceDel;

    @NonNull
    public final EditText transPriceInput;

    @NonNull
    public final ImageView transPriceSub;

    @NonNull
    public final TextView tvCoinName;

    @NonNull
    public final TextView tvCurrency;

    @NonNull
    public static ItemInvesteditCoinBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ItemInvesteditCoinBinding bind(@NonNull View view) {
        int i10 = R.id.iv_lgo;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
        if (imageView != null) {
            i10 = R.id.ll_root;
            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
            if (linearLayout != null) {
                i10 = R.id.trans_price_add;
                ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i10);
                if (imageView2 != null) {
                    i10 = R.id.trans_price_del;
                    ImageView imageView3 = (ImageView) ViewBindings.findChildViewById(view, i10);
                    if (imageView3 != null) {
                        i10 = R.id.trans_price_input;
                        EditText editText = (EditText) ViewBindings.findChildViewById(view, i10);
                        if (editText != null) {
                            i10 = R.id.trans_price_sub;
                            ImageView imageView4 = (ImageView) ViewBindings.findChildViewById(view, i10);
                            if (imageView4 != null) {
                                i10 = R.id.tv_coin_name;
                                TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView != null) {
                                    i10 = R.id.tv_currency;
                                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView2 != null) {
                                        return new ItemInvesteditCoinBinding((LinearLayout) view, imageView, linearLayout, imageView2, imageView3, editText, imageView4, textView, textView2);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ItemInvesteditCoinBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.item_investedit_coin, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private ItemInvesteditCoinBinding(@NonNull LinearLayout linearLayout, @NonNull ImageView imageView, @NonNull LinearLayout linearLayout2, @NonNull ImageView imageView2, @NonNull ImageView imageView3, @NonNull EditText editText, @NonNull ImageView imageView4, @NonNull TextView textView, @NonNull TextView textView2) {
        this.rootView = linearLayout;
        this.ivLgo = imageView;
        this.llRoot = linearLayout2;
        this.transPriceAdd = imageView2;
        this.transPriceDel = imageView3;
        this.transPriceInput = editText;
        this.transPriceSub = imageView4;
        this.tvCoinName = textView;
        this.tvCurrency = textView2;
    }
}