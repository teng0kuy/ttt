package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CornerLinearLayout;
import com.gateio.common.view.CornerTextView;

/* loaded from: classes7.dex */
public final class FragmentAmmSlippageBinding implements ViewBinding {

    @NonNull
    public final CornerTextView ctvConfirm;

    @NonNull
    public final CornerTextView ctvReset;

    @NonNull
    public final LinearLayout llAction;

    @NonNull
    public final CornerLinearLayout llBottom;

    @NonNull
    private final CornerLinearLayout rootView;

    @NonNull
    public final RadioButton slippage1;

    @NonNull
    public final RadioButton slippage5;

    @NonNull
    public final RadioButton splipage3;

    @NonNull
    public final ImageView tvCancel;

    @NonNull
    public final TextView tvFilter;

    @NonNull
    public static FragmentAmmSlippageBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FragmentAmmSlippageBinding bind(@NonNull View view) {
        int i10 = R.id.ctv_confirm;
        CornerTextView cornerTextView = (CornerTextView) ViewBindings.findChildViewById(view, i10);
        if (cornerTextView != null) {
            i10 = R.id.ctv_reset;
            CornerTextView cornerTextView2 = (CornerTextView) ViewBindings.findChildViewById(view, i10);
            if (cornerTextView2 != null) {
                i10 = R.id.ll_action;
                LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                if (linearLayout != null) {
                    CornerLinearLayout cornerLinearLayout = (CornerLinearLayout) view;
                    i10 = R.id.slippage_1;
                    RadioButton radioButton = (RadioButton) ViewBindings.findChildViewById(view, i10);
                    if (radioButton != null) {
                        i10 = R.id.slippage_5;
                        RadioButton radioButton2 = (RadioButton) ViewBindings.findChildViewById(view, i10);
                        if (radioButton2 != null) {
                            i10 = R.id.splipage_3;
                            RadioButton radioButton3 = (RadioButton) ViewBindings.findChildViewById(view, i10);
                            if (radioButton3 != null) {
                                i10 = R.id.tv_cancel;
                                ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
                                if (imageView != null) {
                                    i10 = R.id.tv_filter;
                                    TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView != null) {
                                        return new FragmentAmmSlippageBinding(cornerLinearLayout, cornerTextView, cornerTextView2, linearLayout, cornerLinearLayout, radioButton, radioButton2, radioButton3, imageView, textView);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FragmentAmmSlippageBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_amm_slippage, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public CornerLinearLayout getRoot() {
        return this.rootView;
    }

    private FragmentAmmSlippageBinding(@NonNull CornerLinearLayout cornerLinearLayout, @NonNull CornerTextView cornerTextView, @NonNull CornerTextView cornerTextView2, @NonNull LinearLayout linearLayout, @NonNull CornerLinearLayout cornerLinearLayout2, @NonNull RadioButton radioButton, @NonNull RadioButton radioButton2, @NonNull RadioButton radioButton3, @NonNull ImageView imageView, @NonNull TextView textView) {
        this.rootView = cornerLinearLayout;
        this.ctvConfirm = cornerTextView;
        this.ctvReset = cornerTextView2;
        this.llAction = linearLayout;
        this.llBottom = cornerLinearLayout2;
        this.slippage1 = radioButton;
        this.slippage5 = radioButton2;
        this.splipage3 = radioButton3;
        this.tvCancel = imageView;
        this.tvFilter = textView;
    }
}