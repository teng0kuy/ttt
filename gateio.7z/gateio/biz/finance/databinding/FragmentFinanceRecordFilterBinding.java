package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CornerTextView;
import com.gateio.common.view.tag.TagLayout;

/* loaded from: classes7.dex */
public final class FragmentFinanceRecordFilterBinding implements ViewBinding {

    @NonNull
    public final ConstraintLayout content;

    @NonNull
    public final ImageView ivClose;

    @NonNull
    private final ConstraintLayout rootView;

    @NonNull
    public final TagLayout tagType;

    @NonNull
    public final LinearLayout timer;

    /* renamed from: tv, reason: collision with root package name */
    @NonNull
    public final TextView f11142tv;

    @NonNull
    public final CornerTextView tvConfirm;

    @NonNull
    public final TextView tvEndTime;

    @NonNull
    public final CornerTextView tvReset;

    @NonNull
    public final TextView tvStartTime;

    @NonNull
    public final TextView tvStatus;

    @NonNull
    public final TextView tvTime;

    @NonNull
    public static FragmentFinanceRecordFilterBinding bind(@NonNull View view) {
        ConstraintLayout constraintLayout = (ConstraintLayout) view;
        int i10 = R.id.iv_close;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
        if (imageView != null) {
            i10 = R.id.tag_type;
            TagLayout tagLayout = (TagLayout) ViewBindings.findChildViewById(view, i10);
            if (tagLayout != null) {
                i10 = R.id.timer;
                LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                if (linearLayout != null) {
                    i10 = R.id.f11137tv;
                    TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView != null) {
                        i10 = R.id.tv_confirm;
                        CornerTextView cornerTextView = (CornerTextView) ViewBindings.findChildViewById(view, i10);
                        if (cornerTextView != null) {
                            i10 = R.id.tv_end_time;
                            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView2 != null) {
                                i10 = R.id.tv_reset;
                                CornerTextView cornerTextView2 = (CornerTextView) ViewBindings.findChildViewById(view, i10);
                                if (cornerTextView2 != null) {
                                    i10 = R.id.tv_start_time;
                                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView3 != null) {
                                        i10 = R.id.tv_status;
                                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView4 != null) {
                                            i10 = R.id.tv_time;
                                            TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView5 != null) {
                                                return new FragmentFinanceRecordFilterBinding(constraintLayout, constraintLayout, imageView, tagLayout, linearLayout, textView, cornerTextView, textView2, cornerTextView2, textView3, textView4, textView5);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FragmentFinanceRecordFilterBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FragmentFinanceRecordFilterBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_finance_record_filter, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    private FragmentFinanceRecordFilterBinding(@NonNull ConstraintLayout constraintLayout, @NonNull ConstraintLayout constraintLayout2, @NonNull ImageView imageView, @NonNull TagLayout tagLayout, @NonNull LinearLayout linearLayout, @NonNull TextView textView, @NonNull CornerTextView cornerTextView, @NonNull TextView textView2, @NonNull CornerTextView cornerTextView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5) {
        this.rootView = constraintLayout;
        this.content = constraintLayout2;
        this.ivClose = imageView;
        this.tagType = tagLayout;
        this.timer = linearLayout;
        this.f11142tv = textView;
        this.tvConfirm = cornerTextView;
        this.tvEndTime = textView2;
        this.tvReset = cornerTextView2;
        this.tvStartTime = textView3;
        this.tvStatus = textView4;
        this.tvTime = textView5;
    }
}