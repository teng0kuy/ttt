package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.gateio.view.CornerConstraintLayout;

/* loaded from: classes7.dex */
public final class ViewStructuredFinanceHomeTopAnnualRateBinding implements ViewBinding {

    @NonNull
    public final ImageView annualRateEmpty;

    @NonNull
    public final RecyclerView annualRateRv;

    @NonNull
    private final CornerConstraintLayout rootView;

    /* renamed from: tv, reason: collision with root package name */
    @NonNull
    public final TextView f11143tv;

    @NonNull
    public final TextView tvAnnualRateMore;

    @NonNull
    public static ViewStructuredFinanceHomeTopAnnualRateBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ViewStructuredFinanceHomeTopAnnualRateBinding bind(@NonNull View view) {
        int i10 = R.id.annual_rate_empty;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
        if (imageView != null) {
            i10 = R.id.annual_rate_rv;
            RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
            if (recyclerView != null) {
                i10 = R.id.f11137tv;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView != null) {
                    i10 = R.id.tv_annual_rate_more;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView2 != null) {
                        return new ViewStructuredFinanceHomeTopAnnualRateBinding((CornerConstraintLayout) view, imageView, recyclerView, textView, textView2);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ViewStructuredFinanceHomeTopAnnualRateBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.view_structured_finance_home_top_annual_rate, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public CornerConstraintLayout getRoot() {
        return this.rootView;
    }

    private ViewStructuredFinanceHomeTopAnnualRateBinding(@NonNull CornerConstraintLayout cornerConstraintLayout, @NonNull ImageView imageView, @NonNull RecyclerView recyclerView, @NonNull TextView textView, @NonNull TextView textView2) {
        this.rootView = cornerConstraintLayout;
        this.annualRateEmpty = imageView;
        this.annualRateRv = recyclerView;
        this.f11143tv = textView;
        this.tvAnnualRateMore = textView2;
    }
}