package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CustomViewpager;
import com.google.android.material.tabs.TabLayout;

/* loaded from: classes7.dex */
public final class FragmentMarginloanBinding implements ViewBinding {

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final TabLayout tabs;

    @NonNull
    public final CustomViewpager vpViewLoan;

    @NonNull
    public static FragmentMarginloanBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FragmentMarginloanBinding bind(@NonNull View view) {
        int i10 = R.id.tabs;
        TabLayout tabLayout = (TabLayout) ViewBindings.findChildViewById(view, i10);
        if (tabLayout != null) {
            i10 = R.id.vp_view_loan;
            CustomViewpager customViewpager = (CustomViewpager) ViewBindings.findChildViewById(view, i10);
            if (customViewpager != null) {
                return new FragmentMarginloanBinding((LinearLayout) view, tabLayout, customViewpager);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FragmentMarginloanBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_marginloan, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private FragmentMarginloanBinding(@NonNull LinearLayout linearLayout, @NonNull TabLayout tabLayout, @NonNull CustomViewpager customViewpager) {
        this.rootView = linearLayout;
        this.tabs = tabLayout;
        this.vpViewLoan = customViewpager;
    }
}