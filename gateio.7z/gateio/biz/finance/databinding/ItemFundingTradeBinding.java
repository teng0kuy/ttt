package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;

/* loaded from: classes7.dex */
public final class ItemFundingTradeBinding implements ViewBinding {

    @NonNull
    public final LinearLayout llRoot;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final Switch swSwitch;

    @NonNull
    public final TextView tvFundingAmount;

    @NonNull
    public final TextView tvFundingDdh;

    @NonNull
    public final TextView tvFundingDhlx;

    @NonNull
    public final TextView tvFundingDqsj;

    @NonNull
    public final TextView tvFundingJkrid;

    @NonNull
    public final TextView tvFundingLjlx;

    @NonNull
    public final TextView tvFundingName;

    @NonNull
    public final TextView tvFundingTime;

    @NonNull
    public final TextView tvFundingYhbj;

    @NonNull
    public final TextView tvType;

    @NonNull
    public static ItemFundingTradeBinding bind(@NonNull View view) {
        LinearLayout linearLayout = (LinearLayout) view;
        int i10 = R.id.sw_switch;
        Switch r32 = (Switch) ViewBindings.findChildViewById(view, i10);
        if (r32 != null) {
            i10 = R.id.tv_funding_amount;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                i10 = R.id.tv_funding_ddh;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView2 != null) {
                    i10 = R.id.tv_funding_dhlx;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView3 != null) {
                        i10 = R.id.tv_funding_dqsj;
                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView4 != null) {
                            i10 = R.id.tv_funding_jkrid;
                            TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView5 != null) {
                                i10 = R.id.tv_funding_ljlx;
                                TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView6 != null) {
                                    i10 = R.id.tv_funding_name;
                                    TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView7 != null) {
                                        i10 = R.id.tv_funding_time;
                                        TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView8 != null) {
                                            i10 = R.id.tv_funding_yhbj;
                                            TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView9 != null) {
                                                i10 = R.id.tv_type;
                                                TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView10 != null) {
                                                    return new ItemFundingTradeBinding(linearLayout, linearLayout, r32, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9, textView10);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ItemFundingTradeBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ItemFundingTradeBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.item_funding_trade, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private ItemFundingTradeBinding(@NonNull LinearLayout linearLayout, @NonNull LinearLayout linearLayout2, @NonNull Switch r32, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textView9, @NonNull TextView textView10) {
        this.rootView = linearLayout;
        this.llRoot = linearLayout2;
        this.swSwitch = r32;
        this.tvFundingAmount = textView;
        this.tvFundingDdh = textView2;
        this.tvFundingDhlx = textView3;
        this.tvFundingDqsj = textView4;
        this.tvFundingJkrid = textView5;
        this.tvFundingLjlx = textView6;
        this.tvFundingName = textView7;
        this.tvFundingTime = textView8;
        this.tvFundingYhbj = textView9;
        this.tvType = textView10;
    }
}