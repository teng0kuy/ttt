package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CornerLinearLayout;
import com.gateio.common.view.GateioAvatarView;

/* loaded from: classes7.dex */
public final class ItemInvestBinding implements ViewBinding {

    @NonNull
    public final GateioAvatarView avatar;

    @NonNull
    public final ImageView ivRank;

    @NonNull
    public final ImageView ivVip;

    @NonNull
    public final CornerLinearLayout llRoot;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final TextView tvLjdt;

    @NonNull
    public final TextView tvLjdtLabel;

    @NonNull
    public final TextView tvLjqs;

    @NonNull
    public final TextView tvLjqsLabel;

    @NonNull
    public final TextView tvName;

    @NonNull
    public final TextView tvRate;

    @NonNull
    public final TextView tvRateLabel;

    @NonNull
    public final TextView tvTime;

    @NonNull
    public final TextView tvTitle;

    @NonNull
    public static ItemInvestBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ItemInvestBinding bind(@NonNull View view) {
        int i10 = R.id.avatar;
        GateioAvatarView gateioAvatarView = (GateioAvatarView) ViewBindings.findChildViewById(view, i10);
        if (gateioAvatarView != null) {
            i10 = R.id.iv_rank;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
            if (imageView != null) {
                i10 = R.id.iv_vip;
                ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i10);
                if (imageView2 != null) {
                    i10 = R.id.ll_root;
                    CornerLinearLayout cornerLinearLayout = (CornerLinearLayout) ViewBindings.findChildViewById(view, i10);
                    if (cornerLinearLayout != null) {
                        i10 = R.id.tv_ljdt;
                        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView != null) {
                            i10 = R.id.tv_ljdt_label;
                            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView2 != null) {
                                i10 = R.id.tv_ljqs;
                                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView3 != null) {
                                    i10 = R.id.tv_ljqs_label;
                                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView4 != null) {
                                        i10 = R.id.tv_name;
                                        TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView5 != null) {
                                            i10 = R.id.tv_rate;
                                            TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView6 != null) {
                                                i10 = R.id.tv_rate_label;
                                                TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView7 != null) {
                                                    i10 = R.id.tv_time;
                                                    TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                    if (textView8 != null) {
                                                        i10 = R.id.tv_title;
                                                        TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                        if (textView9 != null) {
                                                            return new ItemInvestBinding((LinearLayout) view, gateioAvatarView, imageView, imageView2, cornerLinearLayout, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ItemInvestBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.item_invest, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private ItemInvestBinding(@NonNull LinearLayout linearLayout, @NonNull GateioAvatarView gateioAvatarView, @NonNull ImageView imageView, @NonNull ImageView imageView2, @NonNull CornerLinearLayout cornerLinearLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textView9) {
        this.rootView = linearLayout;
        this.avatar = gateioAvatarView;
        this.ivRank = imageView;
        this.ivVip = imageView2;
        this.llRoot = cornerLinearLayout;
        this.tvLjdt = textView;
        this.tvLjdtLabel = textView2;
        this.tvLjqs = textView3;
        this.tvLjqsLabel = textView4;
        this.tvName = textView5;
        this.tvRate = textView6;
        this.tvRateLabel = textView7;
        this.tvTime = textView8;
        this.tvTitle = textView9;
    }
}