package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;

/* loaded from: classes7.dex */
public final class FragmentLoanrepayOnekeyBinding implements ViewBinding {

    @NonNull
    public final CheckBox cbAll;

    @NonNull
    public final EditText edFundingJdsl;

    @NonNull
    public final LinearLayout llBottom;

    @NonNull
    public final LinearLayout llJdsl;

    @NonNull
    public final TextView marginCommit;

    @NonNull
    public final RelativeLayout rlType;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final TextView tvAsset;

    @NonNull
    public final TextView tvCash;

    @NonNull
    public final TextView tvCashLabel;

    @NonNull
    public final TextView tvLjjr;

    @NonNull
    public final TextView tvLjlx;

    @NonNull
    public final TextView tvRepayTotal;

    @NonNull
    public static FragmentLoanrepayOnekeyBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FragmentLoanrepayOnekeyBinding bind(@NonNull View view) {
        int i10 = R.id.cb_all;
        CheckBox checkBox = (CheckBox) ViewBindings.findChildViewById(view, i10);
        if (checkBox != null) {
            i10 = R.id.ed_funding_jdsl;
            EditText editText = (EditText) ViewBindings.findChildViewById(view, i10);
            if (editText != null) {
                i10 = R.id.ll_bottom;
                LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                if (linearLayout != null) {
                    i10 = R.id.ll_jdsl;
                    LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                    if (linearLayout2 != null) {
                        i10 = R.id.margin_commit;
                        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView != null) {
                            i10 = R.id.rl_type;
                            RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                            if (relativeLayout != null) {
                                i10 = R.id.tv_asset;
                                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView2 != null) {
                                    i10 = R.id.tv_cash;
                                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView3 != null) {
                                        i10 = R.id.tv_cash_label;
                                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView4 != null) {
                                            i10 = R.id.tv_ljjr;
                                            TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView5 != null) {
                                                i10 = R.id.tv_ljlx;
                                                TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView6 != null) {
                                                    i10 = R.id.tv_repay_total;
                                                    TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                    if (textView7 != null) {
                                                        return new FragmentLoanrepayOnekeyBinding((RelativeLayout) view, checkBox, editText, linearLayout, linearLayout2, textView, relativeLayout, textView2, textView3, textView4, textView5, textView6, textView7);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FragmentLoanrepayOnekeyBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_loanrepay_onekey, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private FragmentLoanrepayOnekeyBinding(@NonNull RelativeLayout relativeLayout, @NonNull CheckBox checkBox, @NonNull EditText editText, @NonNull LinearLayout linearLayout, @NonNull LinearLayout linearLayout2, @NonNull TextView textView, @NonNull RelativeLayout relativeLayout2, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7) {
        this.rootView = relativeLayout;
        this.cbAll = checkBox;
        this.edFundingJdsl = editText;
        this.llBottom = linearLayout;
        this.llJdsl = linearLayout2;
        this.marginCommit = textView;
        this.rlType = relativeLayout2;
        this.tvAsset = textView2;
        this.tvCash = textView3;
        this.tvCashLabel = textView4;
        this.tvLjjr = textView5;
        this.tvLjlx = textView6;
        this.tvRepayTotal = textView7;
    }
}