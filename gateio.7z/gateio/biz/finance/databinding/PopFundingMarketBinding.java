package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.lib.uikit.state.GateEmptyViewV2;

/* loaded from: classes7.dex */
public final class PopFundingMarketBinding implements ViewBinding {

    @NonNull
    public final RecyclerView futuresMarketList;

    @NonNull
    public final FinanceLayoutAssetSearchBinding rlSearch;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final GateEmptyViewV2 tvEmpty;

    @NonNull
    public static PopFundingMarketBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static PopFundingMarketBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.futures_market_list;
        RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
        if (recyclerView != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.rl_search))) != null) {
            FinanceLayoutAssetSearchBinding financeLayoutAssetSearchBindingBind = FinanceLayoutAssetSearchBinding.bind(viewFindChildViewById);
            int i11 = R.id.tv_empty;
            GateEmptyViewV2 gateEmptyViewV2 = (GateEmptyViewV2) ViewBindings.findChildViewById(view, i11);
            if (gateEmptyViewV2 != null) {
                return new PopFundingMarketBinding((LinearLayout) view, recyclerView, financeLayoutAssetSearchBindingBind, gateEmptyViewV2);
            }
            i10 = i11;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static PopFundingMarketBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.pop_funding_market, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private PopFundingMarketBinding(@NonNull LinearLayout linearLayout, @NonNull RecyclerView recyclerView, @NonNull FinanceLayoutAssetSearchBinding financeLayoutAssetSearchBinding, @NonNull GateEmptyViewV2 gateEmptyViewV2) {
        this.rootView = linearLayout;
        this.futuresMarketList = recyclerView;
        this.rlSearch = financeLayoutAssetSearchBinding;
        this.tvEmpty = gateEmptyViewV2;
    }
}