package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;

/* loaded from: classes7.dex */
public final class ItemCoinSelectBinding implements ViewBinding {

    @NonNull
    public final ImageView ivLogo;

    @NonNull
    public final ImageView ivSelect;

    @NonNull
    public final LinearLayout llRoot;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final TextView tvCoinName;

    @NonNull
    public final TextView tvCurrency;

    @NonNull
    public final View vLine;

    @NonNull
    public static ItemCoinSelectBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ItemCoinSelectBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.iv_logo;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
        if (imageView != null) {
            i10 = R.id.iv_select;
            ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i10);
            if (imageView2 != null) {
                LinearLayout linearLayout = (LinearLayout) view;
                i10 = R.id.tv_coin_name;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView != null) {
                    i10 = R.id.tv_currency;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView2 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.v_line))) != null) {
                        return new ItemCoinSelectBinding(linearLayout, imageView, imageView2, linearLayout, textView, textView2, viewFindChildViewById);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ItemCoinSelectBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.item_coin_select, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private ItemCoinSelectBinding(@NonNull LinearLayout linearLayout, @NonNull ImageView imageView, @NonNull ImageView imageView2, @NonNull LinearLayout linearLayout2, @NonNull TextView textView, @NonNull TextView textView2, @NonNull View view) {
        this.rootView = linearLayout;
        this.ivLogo = imageView;
        this.ivSelect = imageView2;
        this.llRoot = linearLayout2;
        this.tvCoinName = textView;
        this.tvCurrency = textView2;
        this.vLine = view;
    }
}