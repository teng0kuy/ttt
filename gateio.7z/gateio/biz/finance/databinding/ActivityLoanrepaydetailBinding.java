package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.databinding.LayoutHeaderNormalBinding;
import com.gateio.biz.finance.R;
import com.gateio.lib.uikit.state.GateEmptyViewV2;

/* loaded from: classes7.dex */
public final class ActivityLoanrepaydetailBinding implements ViewBinding {

    @NonNull
    public final LayoutHeaderNormalBinding layoutHeader;

    @NonNull
    public final LabelLoanRepayBinding llLoanRepayLabel;

    @NonNull
    public final ProgressBar pbMarginRisk;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final RecyclerView rvLoanRecords;

    @NonNull
    public final Switch swSwitch;

    @NonNull
    public final GateEmptyViewV2 tvEmpty;

    @NonNull
    public final TextView tvId;

    @NonNull
    public final TextView tvInterrest;

    @NonNull
    public final TextView tvInterrestLabel;

    @NonNull
    public final TextView tvInterrestTotalLabel;

    @NonNull
    public final TextView tvJrzje;

    @NonNull
    public final TextView tvLabel;

    @NonNull
    public final TextView tvMarginPeriod;

    @NonNull
    public final TextView tvMarginRepayedLabel;

    @NonNull
    public final TextView tvPbLeft;

    @NonNull
    public final TextView tvPbRight;

    @NonNull
    public final TextView tvPeriod;

    @NonNull
    public final TextView tvPeriodTime;

    @NonNull
    public final TextView tvRate;

    @NonNull
    public final TextView tvRateLabel;

    @NonNull
    public final TextView tvRepayed;

    @NonNull
    public final TextView tvStartTime;

    @NonNull
    public final TextView tvTotalInterrest;

    private ActivityLoanrepaydetailBinding(@NonNull LinearLayout linearLayout, @NonNull LayoutHeaderNormalBinding layoutHeaderNormalBinding, @NonNull LabelLoanRepayBinding labelLoanRepayBinding, @NonNull ProgressBar progressBar, @NonNull RecyclerView recyclerView, @NonNull Switch r82, @NonNull GateEmptyViewV2 gateEmptyViewV2, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textView9, @NonNull TextView textView10, @NonNull TextView textView11, @NonNull TextView textView12, @NonNull TextView textView13, @NonNull TextView textView14, @NonNull TextView textView15, @NonNull TextView textView16, @NonNull TextView textView17) {
        this.rootView = linearLayout;
        this.layoutHeader = layoutHeaderNormalBinding;
        this.llLoanRepayLabel = labelLoanRepayBinding;
        this.pbMarginRisk = progressBar;
        this.rvLoanRecords = recyclerView;
        this.swSwitch = r82;
        this.tvEmpty = gateEmptyViewV2;
        this.tvId = textView;
        this.tvInterrest = textView2;
        this.tvInterrestLabel = textView3;
        this.tvInterrestTotalLabel = textView4;
        this.tvJrzje = textView5;
        this.tvLabel = textView6;
        this.tvMarginPeriod = textView7;
        this.tvMarginRepayedLabel = textView8;
        this.tvPbLeft = textView9;
        this.tvPbRight = textView10;
        this.tvPeriod = textView11;
        this.tvPeriodTime = textView12;
        this.tvRate = textView13;
        this.tvRateLabel = textView14;
        this.tvRepayed = textView15;
        this.tvStartTime = textView16;
        this.tvTotalInterrest = textView17;
    }

    @NonNull
    public static ActivityLoanrepaydetailBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ActivityLoanrepaydetailBinding bind(@NonNull View view) {
        int i10 = R.id.layout_header;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i10);
        if (viewFindChildViewById != null) {
            LayoutHeaderNormalBinding layoutHeaderNormalBindingBind = LayoutHeaderNormalBinding.bind(viewFindChildViewById);
            i10 = R.id.ll_loan_repay_label;
            View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i10);
            if (viewFindChildViewById2 != null) {
                LabelLoanRepayBinding labelLoanRepayBindingBind = LabelLoanRepayBinding.bind(viewFindChildViewById2);
                i10 = R.id.pb_margin_risk;
                ProgressBar progressBar = (ProgressBar) ViewBindings.findChildViewById(view, i10);
                if (progressBar != null) {
                    i10 = R.id.rv_loan_records;
                    RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                    if (recyclerView != null) {
                        i10 = R.id.sw_switch;
                        Switch r92 = (Switch) ViewBindings.findChildViewById(view, i10);
                        if (r92 != null) {
                            i10 = R.id.tv_empty;
                            GateEmptyViewV2 gateEmptyViewV2 = (GateEmptyViewV2) ViewBindings.findChildViewById(view, i10);
                            if (gateEmptyViewV2 != null) {
                                i10 = R.id.tv_id;
                                TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView != null) {
                                    i10 = R.id.tv_interrest;
                                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView2 != null) {
                                        i10 = R.id.tv_interrest_label;
                                        TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView3 != null) {
                                            i10 = R.id.tv_interrest_total_label;
                                            TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView4 != null) {
                                                i10 = R.id.tv_jrzje;
                                                TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView5 != null) {
                                                    i10 = R.id.tv_label;
                                                    TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                    if (textView6 != null) {
                                                        i10 = R.id.tv_margin_period;
                                                        TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                        if (textView7 != null) {
                                                            i10 = R.id.tv_margin_repayed_label;
                                                            TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                            if (textView8 != null) {
                                                                i10 = R.id.tv_pb_left;
                                                                TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                if (textView9 != null) {
                                                                    i10 = R.id.tv_pb_right;
                                                                    TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                    if (textView10 != null) {
                                                                        i10 = R.id.tv_period;
                                                                        TextView textView11 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                        if (textView11 != null) {
                                                                            i10 = R.id.tv_period_time;
                                                                            TextView textView12 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                            if (textView12 != null) {
                                                                                i10 = R.id.tv_rate;
                                                                                TextView textView13 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                if (textView13 != null) {
                                                                                    i10 = R.id.tv_rate_label;
                                                                                    TextView textView14 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                    if (textView14 != null) {
                                                                                        i10 = R.id.tv_repayed;
                                                                                        TextView textView15 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                        if (textView15 != null) {
                                                                                            i10 = R.id.tv_start_time;
                                                                                            TextView textView16 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                            if (textView16 != null) {
                                                                                                i10 = R.id.tv_total_interrest;
                                                                                                TextView textView17 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                                if (textView17 != null) {
                                                                                                    return new ActivityLoanrepaydetailBinding((LinearLayout) view, layoutHeaderNormalBindingBind, labelLoanRepayBindingBind, progressBar, recyclerView, r92, gateEmptyViewV2, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9, textView10, textView11, textView12, textView13, textView14, textView15, textView16, textView17);
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ActivityLoanrepaydetailBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_loanrepaydetail, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }
}