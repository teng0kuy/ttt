package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CornerLinearLayout;
import com.gateio.common.view.CornerTextView;

/* loaded from: classes7.dex */
public final class FragmentAmmActionBinding implements ViewBinding {

    @NonNull
    public final CornerTextView ctvConfirm;

    @NonNull
    public final CornerTextView ctvReset;

    @NonNull
    public final ImageView ivCancel;

    @NonNull
    public final LinearLayout llAction;

    @NonNull
    public final CornerLinearLayout llBottom;

    @NonNull
    public final RelativeLayout rlMarket;

    @NonNull
    private final CornerLinearLayout rootView;

    @NonNull
    public final TextView tvFilter;

    @NonNull
    public final TextView tvMarket;

    @NonNull
    public final TextView tvTimeEnd;

    @NonNull
    public final TextView tvTimeStart;

    @NonNull
    public static FragmentAmmActionBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FragmentAmmActionBinding bind(@NonNull View view) {
        int i10 = R.id.ctv_confirm;
        CornerTextView cornerTextView = (CornerTextView) ViewBindings.findChildViewById(view, i10);
        if (cornerTextView != null) {
            i10 = R.id.ctv_reset;
            CornerTextView cornerTextView2 = (CornerTextView) ViewBindings.findChildViewById(view, i10);
            if (cornerTextView2 != null) {
                i10 = R.id.iv_cancel;
                ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
                if (imageView != null) {
                    i10 = R.id.ll_action;
                    LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                    if (linearLayout != null) {
                        CornerLinearLayout cornerLinearLayout = (CornerLinearLayout) view;
                        i10 = R.id.rl_market;
                        RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                        if (relativeLayout != null) {
                            i10 = R.id.tv_filter;
                            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView != null) {
                                i10 = R.id.tv_market;
                                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView2 != null) {
                                    i10 = R.id.tv_time_end;
                                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView3 != null) {
                                        i10 = R.id.tv_time_start;
                                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView4 != null) {
                                            return new FragmentAmmActionBinding(cornerLinearLayout, cornerTextView, cornerTextView2, imageView, linearLayout, cornerLinearLayout, relativeLayout, textView, textView2, textView3, textView4);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FragmentAmmActionBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_amm_action, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public CornerLinearLayout getRoot() {
        return this.rootView;
    }

    private FragmentAmmActionBinding(@NonNull CornerLinearLayout cornerLinearLayout, @NonNull CornerTextView cornerTextView, @NonNull CornerTextView cornerTextView2, @NonNull ImageView imageView, @NonNull LinearLayout linearLayout, @NonNull CornerLinearLayout cornerLinearLayout2, @NonNull RelativeLayout relativeLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4) {
        this.rootView = cornerLinearLayout;
        this.ctvConfirm = cornerTextView;
        this.ctvReset = cornerTextView2;
        this.ivCancel = imageView;
        this.llAction = linearLayout;
        this.llBottom = cornerLinearLayout2;
        this.rlMarket = relativeLayout;
        this.tvFilter = textView;
        this.tvMarket = textView2;
        this.tvTimeEnd = textView3;
        this.tvTimeStart = textView4;
    }
}