package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.lib.uikit.state.GateEmptyViewV2;

/* loaded from: classes7.dex */
public final class FragmentFundingOrderBinding implements ViewBinding {

    @NonNull
    public final LinearLayout llBottom;

    @NonNull
    public final LinearLayout llCancelall;

    @NonNull
    public final LinearLayout llChangepair;

    @NonNull
    public final CardView llPop;

    @NonNull
    public final RecyclerView recyclerView;

    @NonNull
    public final RelativeLayout rlRoot;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final TextView tvCancel;

    @NonNull
    public final TextView tvCancelall;

    @NonNull
    public final TextView tvChangepair;

    @NonNull
    public final TextView tvConfirm;

    @NonNull
    public final GateEmptyViewV2 tvEmpty;

    @NonNull
    public static FragmentFundingOrderBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FragmentFundingOrderBinding bind(@NonNull View view) {
        int i10 = R.id.ll_bottom;
        LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
        if (linearLayout != null) {
            i10 = R.id.ll_cancelall;
            LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
            if (linearLayout2 != null) {
                i10 = R.id.ll_changepair;
                LinearLayout linearLayout3 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                if (linearLayout3 != null) {
                    i10 = R.id.ll_pop;
                    CardView cardView = (CardView) ViewBindings.findChildViewById(view, i10);
                    if (cardView != null) {
                        i10 = R.id.recycler_view;
                        RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                        if (recyclerView != null) {
                            RelativeLayout relativeLayout = (RelativeLayout) view;
                            i10 = R.id.tv_cancel;
                            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView != null) {
                                i10 = R.id.tv_cancelall;
                                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView2 != null) {
                                    i10 = R.id.tv_changepair;
                                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView3 != null) {
                                        i10 = R.id.tv_confirm;
                                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView4 != null) {
                                            i10 = R.id.tv_empty;
                                            GateEmptyViewV2 gateEmptyViewV2 = (GateEmptyViewV2) ViewBindings.findChildViewById(view, i10);
                                            if (gateEmptyViewV2 != null) {
                                                return new FragmentFundingOrderBinding(relativeLayout, linearLayout, linearLayout2, linearLayout3, cardView, recyclerView, relativeLayout, textView, textView2, textView3, textView4, gateEmptyViewV2);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FragmentFundingOrderBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_funding_order, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private FragmentFundingOrderBinding(@NonNull RelativeLayout relativeLayout, @NonNull LinearLayout linearLayout, @NonNull LinearLayout linearLayout2, @NonNull LinearLayout linearLayout3, @NonNull CardView cardView, @NonNull RecyclerView recyclerView, @NonNull RelativeLayout relativeLayout2, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull GateEmptyViewV2 gateEmptyViewV2) {
        this.rootView = relativeLayout;
        this.llBottom = linearLayout;
        this.llCancelall = linearLayout2;
        this.llChangepair = linearLayout3;
        this.llPop = cardView;
        this.recyclerView = recyclerView;
        this.rlRoot = relativeLayout2;
        this.tvCancel = textView;
        this.tvCancelall = textView2;
        this.tvChangepair = textView3;
        this.tvConfirm = textView4;
        this.tvEmpty = gateEmptyViewV2;
    }
}