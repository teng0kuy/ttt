package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CornerTextView;

/* loaded from: classes7.dex */
public final class FragmentDualRecommendBinding implements ViewBinding {

    @NonNull
    public final AppCompatButton btnLogin;

    @NonNull
    public final Button btnSubmit;

    @NonNull
    public final ConstraintLayout clContent;

    @NonNull
    public final ConstraintLayout clLogin;

    @NonNull
    public final ConstraintLayout clQuestionnairesContent;

    @NonNull
    public final ConstraintLayout clTitle;

    @NonNull
    public final CornerTextView ctvBtc;

    @NonNull
    public final CornerTextView ctvEth;

    @NonNull
    public final ImageView imgNoPermission;

    @NonNull
    public final RecyclerView recycleview;

    @NonNull
    private final ConstraintLayout rootView;

    @NonNull
    public final RecyclerView rvQuestionnaires;

    @NonNull
    public final NestedScrollView scrollView;

    @NonNull
    public final SwipeRefreshLayout swipeRefresh;

    @NonNull
    public final TextView tvEmpty;

    @NonNull
    public final TextView tvLoginTip;

    @NonNull
    public final TextView tvReAssessment;

    @NonNull
    public final CornerTextView tvTip;

    @NonNull
    public final TextView tvTitle;

    @NonNull
    public final TextView tvTitleTip;

    @NonNull
    public final View vLine;

    @NonNull
    public final View vSelect;

    private FragmentDualRecommendBinding(@NonNull ConstraintLayout constraintLayout, @NonNull AppCompatButton appCompatButton, @NonNull Button button, @NonNull ConstraintLayout constraintLayout2, @NonNull ConstraintLayout constraintLayout3, @NonNull ConstraintLayout constraintLayout4, @NonNull ConstraintLayout constraintLayout5, @NonNull CornerTextView cornerTextView, @NonNull CornerTextView cornerTextView2, @NonNull ImageView imageView, @NonNull RecyclerView recyclerView, @NonNull RecyclerView recyclerView2, @NonNull NestedScrollView nestedScrollView, @NonNull SwipeRefreshLayout swipeRefreshLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull CornerTextView cornerTextView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull View view, @NonNull View view2) {
        this.rootView = constraintLayout;
        this.btnLogin = appCompatButton;
        this.btnSubmit = button;
        this.clContent = constraintLayout2;
        this.clLogin = constraintLayout3;
        this.clQuestionnairesContent = constraintLayout4;
        this.clTitle = constraintLayout5;
        this.ctvBtc = cornerTextView;
        this.ctvEth = cornerTextView2;
        this.imgNoPermission = imageView;
        this.recycleview = recyclerView;
        this.rvQuestionnaires = recyclerView2;
        this.scrollView = nestedScrollView;
        this.swipeRefresh = swipeRefreshLayout;
        this.tvEmpty = textView;
        this.tvLoginTip = textView2;
        this.tvReAssessment = textView3;
        this.tvTip = cornerTextView3;
        this.tvTitle = textView4;
        this.tvTitleTip = textView5;
        this.vLine = view;
        this.vSelect = view2;
    }

    @NonNull
    public static FragmentDualRecommendBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FragmentDualRecommendBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        int i10 = R.id.btn_login;
        AppCompatButton appCompatButton = (AppCompatButton) ViewBindings.findChildViewById(view, i10);
        if (appCompatButton != null) {
            i10 = R.id.btn_submit;
            Button button = (Button) ViewBindings.findChildViewById(view, i10);
            if (button != null) {
                i10 = R.id.cl_content;
                ConstraintLayout constraintLayout = (ConstraintLayout) ViewBindings.findChildViewById(view, i10);
                if (constraintLayout != null) {
                    i10 = R.id.cl_login;
                    ConstraintLayout constraintLayout2 = (ConstraintLayout) ViewBindings.findChildViewById(view, i10);
                    if (constraintLayout2 != null) {
                        i10 = R.id.cl_questionnaires_content;
                        ConstraintLayout constraintLayout3 = (ConstraintLayout) ViewBindings.findChildViewById(view, i10);
                        if (constraintLayout3 != null) {
                            i10 = R.id.cl_title;
                            ConstraintLayout constraintLayout4 = (ConstraintLayout) ViewBindings.findChildViewById(view, i10);
                            if (constraintLayout4 != null) {
                                i10 = R.id.ctv_btc;
                                CornerTextView cornerTextView = (CornerTextView) ViewBindings.findChildViewById(view, i10);
                                if (cornerTextView != null) {
                                    i10 = R.id.ctv_eth;
                                    CornerTextView cornerTextView2 = (CornerTextView) ViewBindings.findChildViewById(view, i10);
                                    if (cornerTextView2 != null) {
                                        i10 = R.id.img_no_permission;
                                        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
                                        if (imageView != null) {
                                            i10 = R.id.recycleview;
                                            RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                                            if (recyclerView != null) {
                                                i10 = R.id.rv_questionnaires;
                                                RecyclerView recyclerView2 = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                                                if (recyclerView2 != null) {
                                                    i10 = R.id.scroll_view;
                                                    NestedScrollView nestedScrollView = (NestedScrollView) ViewBindings.findChildViewById(view, i10);
                                                    if (nestedScrollView != null) {
                                                        i10 = R.id.swipe_refresh;
                                                        SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) ViewBindings.findChildViewById(view, i10);
                                                        if (swipeRefreshLayout != null) {
                                                            i10 = R.id.tv_empty;
                                                            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                                                            if (textView != null) {
                                                                i10 = R.id.tv_login_tip;
                                                                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                if (textView2 != null) {
                                                                    i10 = R.id.tv_re_assessment;
                                                                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                    if (textView3 != null) {
                                                                        i10 = R.id.tv_tip;
                                                                        CornerTextView cornerTextView3 = (CornerTextView) ViewBindings.findChildViewById(view, i10);
                                                                        if (cornerTextView3 != null) {
                                                                            i10 = R.id.tv_title;
                                                                            TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                            if (textView4 != null) {
                                                                                i10 = R.id.tv_title_tip;
                                                                                TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                if (textView5 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.v_line))) != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i10 = R.id.v_select))) != null) {
                                                                                    return new FragmentDualRecommendBinding((ConstraintLayout) view, appCompatButton, button, constraintLayout, constraintLayout2, constraintLayout3, constraintLayout4, cornerTextView, cornerTextView2, imageView, recyclerView, recyclerView2, nestedScrollView, swipeRefreshLayout, textView, textView2, textView3, cornerTextView3, textView4, textView5, viewFindChildViewById, viewFindChildViewById2);
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FragmentDualRecommendBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_dual_recommend, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public ConstraintLayout getRoot() {
        return this.rootView;
    }
}