package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CornerTextView;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;

/* loaded from: classes38.dex */
public final class ActivityAmmRewardBinding implements ViewBinding {

    @NonNull
    public final CornerTextView ctvAdd;

    @NonNull
    public final CornerTextView ctvTips;

    @NonNull
    public final RecyclerView listview;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final SmartRefreshLayout swipyrefreshlayout;

    @NonNull
    public final TextView tvEmpty;

    @NonNull
    public final TextView tvRewards;

    @NonNull
    public static ActivityAmmRewardBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ActivityAmmRewardBinding bind(@NonNull View view) {
        int i10 = R.id.ctv_add;
        CornerTextView cornerTextView = (CornerTextView) ViewBindings.findChildViewById(view, i10);
        if (cornerTextView != null) {
            i10 = R.id.ctv_tips;
            CornerTextView cornerTextView2 = (CornerTextView) ViewBindings.findChildViewById(view, i10);
            if (cornerTextView2 != null) {
                i10 = R.id.listview;
                RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                if (recyclerView != null) {
                    i10 = R.id.swipyrefreshlayout;
                    SmartRefreshLayout smartRefreshLayout = (SmartRefreshLayout) ViewBindings.findChildViewById(view, i10);
                    if (smartRefreshLayout != null) {
                        i10 = R.id.tv_empty;
                        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView != null) {
                            i10 = R.id.tv_rewards;
                            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView2 != null) {
                                return new ActivityAmmRewardBinding((RelativeLayout) view, cornerTextView, cornerTextView2, recyclerView, smartRefreshLayout, textView, textView2);
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ActivityAmmRewardBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_amm_reward, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private ActivityAmmRewardBinding(@NonNull RelativeLayout relativeLayout, @NonNull CornerTextView cornerTextView, @NonNull CornerTextView cornerTextView2, @NonNull RecyclerView recyclerView, @NonNull SmartRefreshLayout smartRefreshLayout, @NonNull TextView textView, @NonNull TextView textView2) {
        this.rootView = relativeLayout;
        this.ctvAdd = cornerTextView;
        this.ctvTips = cornerTextView2;
        this.listview = recyclerView;
        this.swipyrefreshlayout = smartRefreshLayout;
        this.tvEmpty = textView;
        this.tvRewards = textView2;
    }
}