package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CornerTextView;
import com.gateio.common.view.CornerView;

/* loaded from: classes7.dex */
public final class ViewStructuredFinanceTopSaleBinding implements ViewBinding {

    @NonNull
    public final CornerView bgView;

    @NonNull
    public final ImageView ivImage;

    @NonNull
    public final ProgressBar progressBar;

    @NonNull
    private final ConstraintLayout rootView;

    @NonNull
    public final View space;

    @NonNull
    public final CornerTextView tvBtn;

    @NonNull
    public final TextView tvEndTime;

    @NonNull
    public final TextView tvName;

    @NonNull
    public final TextView tvRate;

    @NonNull
    public final CornerTextView tvRiskType;

    @NonNull
    public static ViewStructuredFinanceTopSaleBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ViewStructuredFinanceTopSaleBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.bg_view;
        CornerView cornerView = (CornerView) ViewBindings.findChildViewById(view, i10);
        if (cornerView != null) {
            i10 = R.id.iv_image;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
            if (imageView != null) {
                i10 = R.id.progress_bar;
                ProgressBar progressBar = (ProgressBar) ViewBindings.findChildViewById(view, i10);
                if (progressBar != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.space))) != null) {
                    i10 = R.id.tv_btn;
                    CornerTextView cornerTextView = (CornerTextView) ViewBindings.findChildViewById(view, i10);
                    if (cornerTextView != null) {
                        i10 = R.id.tv_end_time;
                        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView != null) {
                            i10 = R.id.tv_name;
                            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView2 != null) {
                                i10 = R.id.tv_rate;
                                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView3 != null) {
                                    i10 = R.id.tv_risk_type;
                                    CornerTextView cornerTextView2 = (CornerTextView) ViewBindings.findChildViewById(view, i10);
                                    if (cornerTextView2 != null) {
                                        return new ViewStructuredFinanceTopSaleBinding((ConstraintLayout) view, cornerView, imageView, progressBar, viewFindChildViewById, cornerTextView, textView, textView2, textView3, cornerTextView2);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ViewStructuredFinanceTopSaleBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.view_structured_finance_top_sale, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    private ViewStructuredFinanceTopSaleBinding(@NonNull ConstraintLayout constraintLayout, @NonNull CornerView cornerView, @NonNull ImageView imageView, @NonNull ProgressBar progressBar, @NonNull View view, @NonNull CornerTextView cornerTextView, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull CornerTextView cornerTextView2) {
        this.rootView = constraintLayout;
        this.bgView = cornerView;
        this.ivImage = imageView;
        this.progressBar = progressBar;
        this.space = view;
        this.tvBtn = cornerTextView;
        this.tvEndTime = textView;
        this.tvName = textView2;
        this.tvRate = textView3;
        this.tvRiskType = cornerTextView2;
    }
}