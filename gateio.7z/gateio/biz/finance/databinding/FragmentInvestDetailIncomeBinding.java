package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.sparkhuu.klinelib.chart.ChainInvestLineChart;

/* loaded from: classes7.dex */
public final class FragmentInvestDetailIncomeBinding implements ViewBinding {

    @NonNull
    public final ImageView ivInvestBdt;

    @NonNull
    public final ChainInvestLineChart marketChart;

    @NonNull
    public final RadioButton rb0;

    @NonNull
    public final RadioButton rb1;

    @NonNull
    public final RadioButton rb2;

    @NonNull
    public final RadioButton rb3;

    @NonNull
    public final RadioButton rb4;

    @NonNull
    public final RadioGroup rg;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final TextView tvInvestBdt;

    @NonNull
    public static FragmentInvestDetailIncomeBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FragmentInvestDetailIncomeBinding bind(@NonNull View view) {
        int i10 = R.id.iv_invest_bdt;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
        if (imageView != null) {
            i10 = R.id.market_chart;
            ChainInvestLineChart chainInvestLineChart = (ChainInvestLineChart) ViewBindings.findChildViewById(view, i10);
            if (chainInvestLineChart != null) {
                i10 = R.id.rb_0;
                RadioButton radioButton = (RadioButton) ViewBindings.findChildViewById(view, i10);
                if (radioButton != null) {
                    i10 = R.id.rb_1;
                    RadioButton radioButton2 = (RadioButton) ViewBindings.findChildViewById(view, i10);
                    if (radioButton2 != null) {
                        i10 = R.id.rb_2;
                        RadioButton radioButton3 = (RadioButton) ViewBindings.findChildViewById(view, i10);
                        if (radioButton3 != null) {
                            i10 = R.id.rb_3;
                            RadioButton radioButton4 = (RadioButton) ViewBindings.findChildViewById(view, i10);
                            if (radioButton4 != null) {
                                i10 = R.id.rb_4;
                                RadioButton radioButton5 = (RadioButton) ViewBindings.findChildViewById(view, i10);
                                if (radioButton5 != null) {
                                    i10 = R.id.rg;
                                    RadioGroup radioGroup = (RadioGroup) ViewBindings.findChildViewById(view, i10);
                                    if (radioGroup != null) {
                                        i10 = R.id.tv_invest_bdt;
                                        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView != null) {
                                            return new FragmentInvestDetailIncomeBinding((LinearLayout) view, imageView, chainInvestLineChart, radioButton, radioButton2, radioButton3, radioButton4, radioButton5, radioGroup, textView);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FragmentInvestDetailIncomeBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_invest_detail_income, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private FragmentInvestDetailIncomeBinding(@NonNull LinearLayout linearLayout, @NonNull ImageView imageView, @NonNull ChainInvestLineChart chainInvestLineChart, @NonNull RadioButton radioButton, @NonNull RadioButton radioButton2, @NonNull RadioButton radioButton3, @NonNull RadioButton radioButton4, @NonNull RadioButton radioButton5, @NonNull RadioGroup radioGroup, @NonNull TextView textView) {
        this.rootView = linearLayout;
        this.ivInvestBdt = imageView;
        this.marketChart = chainInvestLineChart;
        this.rb0 = radioButton;
        this.rb1 = radioButton2;
        this.rb2 = radioButton3;
        this.rb3 = radioButton4;
        this.rb4 = radioButton5;
        this.rg = radioGroup;
        this.tvInvestBdt = textView;
    }
}