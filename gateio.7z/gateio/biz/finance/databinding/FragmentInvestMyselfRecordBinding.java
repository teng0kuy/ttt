package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.lib.uikit.state.GateEmptyViewV2;

/* loaded from: classes7.dex */
public final class FragmentInvestMyselfRecordBinding implements ViewBinding {

    @NonNull
    public final RecyclerView recyclerView;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final GateEmptyViewV2 tvEmpty;

    @NonNull
    public static FragmentInvestMyselfRecordBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FragmentInvestMyselfRecordBinding bind(@NonNull View view) {
        int i10 = R.id.recycler_view;
        RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
        if (recyclerView != null) {
            i10 = R.id.tv_empty;
            GateEmptyViewV2 gateEmptyViewV2 = (GateEmptyViewV2) ViewBindings.findChildViewById(view, i10);
            if (gateEmptyViewV2 != null) {
                return new FragmentInvestMyselfRecordBinding((LinearLayout) view, recyclerView, gateEmptyViewV2);
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FragmentInvestMyselfRecordBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_invest_myself_record, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private FragmentInvestMyselfRecordBinding(@NonNull LinearLayout linearLayout, @NonNull RecyclerView recyclerView, @NonNull GateEmptyViewV2 gateEmptyViewV2) {
        this.rootView = linearLayout;
        this.recyclerView = recyclerView;
        this.tvEmpty = gateEmptyViewV2;
    }
}