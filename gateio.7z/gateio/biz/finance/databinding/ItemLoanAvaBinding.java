package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;

/* loaded from: classes7.dex */
public final class ItemLoanAvaBinding implements ViewBinding {

    @NonNull
    public final LinearLayout itemLoanAva;

    @NonNull
    public final ImageView ivArrow;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final TextView tvAmount;

    @NonNull
    public final TextView tvPeroid;

    @NonNull
    public final TextView tvRate;

    @NonNull
    public final TextView tvRate2;

    @NonNull
    public static ItemLoanAvaBinding bind(@NonNull View view) {
        LinearLayout linearLayout = (LinearLayout) view;
        int i10 = R.id.iv_arrow;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
        if (imageView != null) {
            i10 = R.id.tv_amount;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                i10 = R.id.tv_peroid;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView2 != null) {
                    i10 = R.id.tv_rate;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView3 != null) {
                        i10 = R.id.tv_rate2;
                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView4 != null) {
                            return new ItemLoanAvaBinding(linearLayout, linearLayout, imageView, textView, textView2, textView3, textView4);
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ItemLoanAvaBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ItemLoanAvaBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.item_loan_ava, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private ItemLoanAvaBinding(@NonNull LinearLayout linearLayout, @NonNull LinearLayout linearLayout2, @NonNull ImageView imageView, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4) {
        this.rootView = linearLayout;
        this.itemLoanAva = linearLayout2;
        this.ivArrow = imageView;
        this.tvAmount = textView;
        this.tvPeroid = textView2;
        this.tvRate = textView3;
        this.tvRate2 = textView4;
    }
}