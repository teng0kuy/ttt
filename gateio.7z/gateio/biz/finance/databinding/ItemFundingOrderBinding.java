package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CornerTextView;

/* loaded from: classes7.dex */
public final class ItemFundingOrderBinding implements ViewBinding {

    @NonNull
    public final CheckBox cbOrder;

    @NonNull
    public final ImageView imgDel;

    @NonNull
    public final LinearLayout llRoot;

    @NonNull
    public final LinearLayout llRootDetail;

    @NonNull
    public final ProgressBar pbOrder;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final Switch swSwitch;

    @NonNull
    public final TextView tvFundingAmount;

    @NonNull
    public final TextView tvFundingDdh;

    @NonNull
    public final TextView tvFundingLl;

    @NonNull
    public final TextView tvFundingQx;

    @NonNull
    public final CornerTextView tvFundingShare;

    @NonNull
    public final TextView tvFundingTime;

    @NonNull
    public final TextView tvType;

    @NonNull
    public static ItemFundingOrderBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ItemFundingOrderBinding bind(@NonNull View view) {
        int i10 = R.id.cb_order;
        CheckBox checkBox = (CheckBox) ViewBindings.findChildViewById(view, i10);
        if (checkBox != null) {
            i10 = R.id.img_del;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
            if (imageView != null) {
                LinearLayout linearLayout = (LinearLayout) view;
                i10 = R.id.ll_root_detail;
                LinearLayout linearLayout2 = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                if (linearLayout2 != null) {
                    i10 = R.id.pb_order;
                    ProgressBar progressBar = (ProgressBar) ViewBindings.findChildViewById(view, i10);
                    if (progressBar != null) {
                        i10 = R.id.sw_switch;
                        Switch r10 = (Switch) ViewBindings.findChildViewById(view, i10);
                        if (r10 != null) {
                            i10 = R.id.tv_funding_amount;
                            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView != null) {
                                i10 = R.id.tv_funding_ddh;
                                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView2 != null) {
                                    i10 = R.id.tv_funding_ll;
                                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView3 != null) {
                                        i10 = R.id.tv_funding_qx;
                                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView4 != null) {
                                            i10 = R.id.tv_funding_share;
                                            CornerTextView cornerTextView = (CornerTextView) ViewBindings.findChildViewById(view, i10);
                                            if (cornerTextView != null) {
                                                i10 = R.id.tv_funding_time;
                                                TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView5 != null) {
                                                    i10 = R.id.tv_type;
                                                    TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                    if (textView6 != null) {
                                                        return new ItemFundingOrderBinding(linearLayout, checkBox, imageView, linearLayout, linearLayout2, progressBar, r10, textView, textView2, textView3, textView4, cornerTextView, textView5, textView6);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ItemFundingOrderBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.item_funding_order, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private ItemFundingOrderBinding(@NonNull LinearLayout linearLayout, @NonNull CheckBox checkBox, @NonNull ImageView imageView, @NonNull LinearLayout linearLayout2, @NonNull LinearLayout linearLayout3, @NonNull ProgressBar progressBar, @NonNull Switch r72, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull CornerTextView cornerTextView, @NonNull TextView textView5, @NonNull TextView textView6) {
        this.rootView = linearLayout;
        this.cbOrder = checkBox;
        this.imgDel = imageView;
        this.llRoot = linearLayout2;
        this.llRootDetail = linearLayout3;
        this.pbOrder = progressBar;
        this.swSwitch = r72;
        this.tvFundingAmount = textView;
        this.tvFundingDdh = textView2;
        this.tvFundingLl = textView3;
        this.tvFundingQx = textView4;
        this.tvFundingShare = cornerTextView;
        this.tvFundingTime = textView5;
        this.tvType = textView6;
    }
}