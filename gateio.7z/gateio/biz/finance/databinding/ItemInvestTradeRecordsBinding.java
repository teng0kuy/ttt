package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;

/* loaded from: classes7.dex */
public final class ItemInvestTradeRecordsBinding implements ViewBinding {

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final TextView tvInvestId;

    @NonNull
    public final TextView tvInvestIdLabel;

    @NonNull
    public final TextView tvInvestMarket;

    @NonNull
    public final TextView tvInvestNum;

    @NonNull
    public final TextView tvInvestNumLocal;

    @NonNull
    public final TextView tvInvestPrice;

    @NonNull
    public final TextView tvInvestPriceLocal;

    @NonNull
    public final TextView tvInvestTime;

    @NonNull
    public final TextView tvInvestTimeLocal;

    @NonNull
    public static ItemInvestTradeRecordsBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ItemInvestTradeRecordsBinding bind(@NonNull View view) {
        int i10 = R.id.tv_invest_id;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
        if (textView != null) {
            i10 = R.id.tv_invest_id_label;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView2 != null) {
                i10 = R.id.tv_invest_market;
                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView3 != null) {
                    i10 = R.id.tv_invest_num;
                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView4 != null) {
                        i10 = R.id.tv_invest_num_local;
                        TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView5 != null) {
                            i10 = R.id.tv_invest_price;
                            TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView6 != null) {
                                i10 = R.id.tv_invest_price_local;
                                TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView7 != null) {
                                    i10 = R.id.tv_invest_time;
                                    TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView8 != null) {
                                        i10 = R.id.tv_invest_time_local;
                                        TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView9 != null) {
                                            return new ItemInvestTradeRecordsBinding((LinearLayout) view, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ItemInvestTradeRecordsBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.item_invest_trade_records, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private ItemInvestTradeRecordsBinding(@NonNull LinearLayout linearLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textView9) {
        this.rootView = linearLayout;
        this.tvInvestId = textView;
        this.tvInvestIdLabel = textView2;
        this.tvInvestMarket = textView3;
        this.tvInvestNum = textView4;
        this.tvInvestNumLocal = textView5;
        this.tvInvestPrice = textView6;
        this.tvInvestPriceLocal = textView7;
        this.tvInvestTime = textView8;
        this.tvInvestTimeLocal = textView9;
    }
}