package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.Barrier;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CornerTextView;
import com.gateio.gateio.view.CornerConstraintLayout;

/* loaded from: classes7.dex */
public final class ItemStructuredMarketBinding implements ViewBinding {

    @NonNull
    public final Barrier barrier;

    @NonNull
    public final Barrier bottomBarrier;

    @NonNull
    public final ImageView ivImage;

    @NonNull
    public final ProgressBar progressBar;

    @NonNull
    private final CornerConstraintLayout rootView;

    @NonNull
    public final View space;

    @NonNull
    public final TextView tv1;

    @NonNull
    public final CornerTextView tvBtn;

    @NonNull
    public final TextView tvDay;

    @NonNull
    public final TextView tvLimitAmount;

    @NonNull
    public final TextView tvName;

    @NonNull
    public final TextView tvRate;

    @NonNull
    public final CornerTextView tvRiskType;

    @NonNull
    public static ItemStructuredMarketBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ItemStructuredMarketBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.barrier;
        Barrier barrier = (Barrier) ViewBindings.findChildViewById(view, i10);
        if (barrier != null) {
            i10 = R.id.bottom_barrier;
            Barrier barrier2 = (Barrier) ViewBindings.findChildViewById(view, i10);
            if (barrier2 != null) {
                i10 = R.id.iv_image;
                ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
                if (imageView != null) {
                    i10 = R.id.progress_bar;
                    ProgressBar progressBar = (ProgressBar) ViewBindings.findChildViewById(view, i10);
                    if (progressBar != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.space))) != null) {
                        i10 = R.id.tv1;
                        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView != null) {
                            i10 = R.id.tv_btn;
                            CornerTextView cornerTextView = (CornerTextView) ViewBindings.findChildViewById(view, i10);
                            if (cornerTextView != null) {
                                i10 = R.id.tv_day;
                                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView2 != null) {
                                    i10 = R.id.tv_limit_amount;
                                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView3 != null) {
                                        i10 = R.id.tv_name;
                                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView4 != null) {
                                            i10 = R.id.tv_rate;
                                            TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView5 != null) {
                                                i10 = R.id.tv_risk_type;
                                                CornerTextView cornerTextView2 = (CornerTextView) ViewBindings.findChildViewById(view, i10);
                                                if (cornerTextView2 != null) {
                                                    return new ItemStructuredMarketBinding((CornerConstraintLayout) view, barrier, barrier2, imageView, progressBar, viewFindChildViewById, textView, cornerTextView, textView2, textView3, textView4, textView5, cornerTextView2);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ItemStructuredMarketBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.item_structured_market, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public CornerConstraintLayout getRoot() {
        return this.rootView;
    }

    private ItemStructuredMarketBinding(@NonNull CornerConstraintLayout cornerConstraintLayout, @NonNull Barrier barrier, @NonNull Barrier barrier2, @NonNull ImageView imageView, @NonNull ProgressBar progressBar, @NonNull View view, @NonNull TextView textView, @NonNull CornerTextView cornerTextView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull CornerTextView cornerTextView2) {
        this.rootView = cornerConstraintLayout;
        this.barrier = barrier;
        this.bottomBarrier = barrier2;
        this.ivImage = imageView;
        this.progressBar = progressBar;
        this.space = view;
        this.tv1 = textView;
        this.tvBtn = cornerTextView;
        this.tvDay = textView2;
        this.tvLimitAmount = textView3;
        this.tvName = textView4;
        this.tvRate = textView5;
        this.tvRiskType = cornerTextView2;
    }
}