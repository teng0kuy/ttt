package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.lib.uikit.state.GateEmptyViewV2;

/* loaded from: classes7.dex */
public final class FragmentDualOrderListBinding implements ViewBinding {

    @NonNull
    public final RecyclerView recycleview;

    @NonNull
    private final SwipeRefreshLayout rootView;

    @NonNull
    public final SwipeRefreshLayout swipeRefresh;

    @NonNull
    public final GateEmptyViewV2 tvEmpty;

    @NonNull
    public static FragmentDualOrderListBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FragmentDualOrderListBinding bind(@NonNull View view) {
        int i10 = R.id.recycleview;
        RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
        if (recyclerView != null) {
            SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) view;
            int i11 = R.id.tv_empty;
            GateEmptyViewV2 gateEmptyViewV2 = (GateEmptyViewV2) ViewBindings.findChildViewById(view, i11);
            if (gateEmptyViewV2 != null) {
                return new FragmentDualOrderListBinding(swipeRefreshLayout, recyclerView, swipeRefreshLayout, gateEmptyViewV2);
            }
            i10 = i11;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FragmentDualOrderListBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_dual_order_list, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public SwipeRefreshLayout getRoot() {
        return this.rootView;
    }

    private FragmentDualOrderListBinding(@NonNull SwipeRefreshLayout swipeRefreshLayout, @NonNull RecyclerView recyclerView, @NonNull SwipeRefreshLayout swipeRefreshLayout2, @NonNull GateEmptyViewV2 gateEmptyViewV2) {
        this.rootView = swipeRefreshLayout;
        this.recycleview = recyclerView;
        this.swipeRefresh = swipeRefreshLayout2;
        this.tvEmpty = gateEmptyViewV2;
    }
}