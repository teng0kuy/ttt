package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.Barrier;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CornerTextView;

/* loaded from: classes7.dex */
public final class ViewFinanceDoneDetailBinding implements ViewBinding {

    @NonNull
    public final Barrier barrier;

    @NonNull
    public final ImageView ivArrow;

    @NonNull
    private final ConstraintLayout rootView;

    @NonNull
    public final TextView tv1;

    @NonNull
    public final TextView tv2;

    @NonNull
    public final TextView tv3;

    @NonNull
    public final TextView tv4;

    @NonNull
    public final TextView tv5;

    @NonNull
    public final TextView tv7;

    @NonNull
    public final TextView tvCapital;

    @NonNull
    public final TextView tvEndProfit;

    @NonNull
    public final TextView tvEndTime;

    @NonNull
    public final TextView tvName;

    @NonNull
    public final TextView tvProfit;

    @NonNull
    public final TextView tvSettledMethod;

    @NonNull
    public final TextView tvSettledPrice;

    @NonNull
    public final TextView tvSettledPriceDesc;

    @NonNull
    public final TextView tvStartTime;

    @NonNull
    public final CornerTextView tvType;

    private ViewFinanceDoneDetailBinding(@NonNull ConstraintLayout constraintLayout, @NonNull Barrier barrier, @NonNull ImageView imageView, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textView9, @NonNull TextView textView10, @NonNull TextView textView11, @NonNull TextView textView12, @NonNull TextView textView13, @NonNull TextView textView14, @NonNull TextView textView15, @NonNull CornerTextView cornerTextView) {
        this.rootView = constraintLayout;
        this.barrier = barrier;
        this.ivArrow = imageView;
        this.tv1 = textView;
        this.tv2 = textView2;
        this.tv3 = textView3;
        this.tv4 = textView4;
        this.tv5 = textView5;
        this.tv7 = textView6;
        this.tvCapital = textView7;
        this.tvEndProfit = textView8;
        this.tvEndTime = textView9;
        this.tvName = textView10;
        this.tvProfit = textView11;
        this.tvSettledMethod = textView12;
        this.tvSettledPrice = textView13;
        this.tvSettledPriceDesc = textView14;
        this.tvStartTime = textView15;
        this.tvType = cornerTextView;
    }

    @NonNull
    public static ViewFinanceDoneDetailBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ViewFinanceDoneDetailBinding bind(@NonNull View view) {
        int i10 = R.id.barrier;
        Barrier barrier = (Barrier) ViewBindings.findChildViewById(view, i10);
        if (barrier != null) {
            i10 = R.id.iv_arrow;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
            if (imageView != null) {
                i10 = R.id.tv1;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView != null) {
                    i10 = R.id.tv2;
                    TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView2 != null) {
                        i10 = R.id.tv3;
                        TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView3 != null) {
                            i10 = R.id.tv4;
                            TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView4 != null) {
                                i10 = R.id.tv5;
                                TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView5 != null) {
                                    i10 = R.id.tv7;
                                    TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView6 != null) {
                                        i10 = R.id.tv_capital;
                                        TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView7 != null) {
                                            i10 = R.id.tv_end_profit;
                                            TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView8 != null) {
                                                i10 = R.id.tv_end_time;
                                                TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView9 != null) {
                                                    i10 = R.id.tv_name;
                                                    TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                    if (textView10 != null) {
                                                        i10 = R.id.tv_profit;
                                                        TextView textView11 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                        if (textView11 != null) {
                                                            i10 = R.id.tv_settled_method;
                                                            TextView textView12 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                            if (textView12 != null) {
                                                                i10 = R.id.tv_settled_price;
                                                                TextView textView13 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                if (textView13 != null) {
                                                                    i10 = R.id.tv_settled_price_desc;
                                                                    TextView textView14 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                    if (textView14 != null) {
                                                                        i10 = R.id.tv_start_time;
                                                                        TextView textView15 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                        if (textView15 != null) {
                                                                            i10 = R.id.tv_type;
                                                                            CornerTextView cornerTextView = (CornerTextView) ViewBindings.findChildViewById(view, i10);
                                                                            if (cornerTextView != null) {
                                                                                return new ViewFinanceDoneDetailBinding((ConstraintLayout) view, barrier, imageView, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9, textView10, textView11, textView12, textView13, textView14, textView15, cornerTextView);
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ViewFinanceDoneDetailBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.view_finance_done_detail, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public ConstraintLayout getRoot() {
        return this.rootView;
    }
}