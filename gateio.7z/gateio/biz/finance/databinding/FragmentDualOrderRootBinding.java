package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CustomViewpager;
import net.lucode.hackware.magicindicator.MagicIndicator;

/* loaded from: classes7.dex */
public final class FragmentDualOrderRootBinding implements ViewBinding {

    @NonNull
    public final ImageView ivSelect;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final MagicIndicator tabs;

    @NonNull
    public final TextView tvSelect;

    @NonNull
    public final CustomViewpager viewPager;

    @NonNull
    public static FragmentDualOrderRootBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FragmentDualOrderRootBinding bind(@NonNull View view) {
        int i10 = R.id.iv_select;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
        if (imageView != null) {
            i10 = R.id.tabs;
            MagicIndicator magicIndicator = (MagicIndicator) ViewBindings.findChildViewById(view, i10);
            if (magicIndicator != null) {
                i10 = R.id.tv_select;
                TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView != null) {
                    i10 = R.id.view_pager;
                    CustomViewpager customViewpager = (CustomViewpager) ViewBindings.findChildViewById(view, i10);
                    if (customViewpager != null) {
                        return new FragmentDualOrderRootBinding((LinearLayout) view, imageView, magicIndicator, textView, customViewpager);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FragmentDualOrderRootBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_dual_order_root, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private FragmentDualOrderRootBinding(@NonNull LinearLayout linearLayout, @NonNull ImageView imageView, @NonNull MagicIndicator magicIndicator, @NonNull TextView textView, @NonNull CustomViewpager customViewpager) {
        this.rootView = linearLayout;
        this.ivSelect = imageView;
        this.tabs = magicIndicator;
        this.tvSelect = textView;
        this.viewPager = customViewpager;
    }
}