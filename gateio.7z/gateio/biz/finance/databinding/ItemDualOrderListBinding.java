package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;

/* loaded from: classes7.dex */
public final class ItemDualOrderListBinding implements ViewBinding {

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final TextView tvDualAmount;

    @NonNull
    public final TextView tvDualCcqx;

    @NonNull
    public final TextView tvDualCcqxLabel;

    @NonNull
    public final TextView tvDualDqr;

    @NonNull
    public final TextView tvDualGgckj;

    @NonNull
    public final TextView tvDualGgckjLabel;

    @NonNull
    public final TextView tvDualHkje;

    @NonNull
    public final TextView tvDualId;

    @NonNull
    public final TextView tvDualJsj;

    @NonNull
    public final TextView tvDualJsjLabel;

    @NonNull
    public final TextView tvDualName;

    @NonNull
    public final TextView tvDualRate;

    @NonNull
    public final TextView tvDualStatus;

    @NonNull
    public final TextView tvDualTime;

    @NonNull
    public static ItemDualOrderListBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ItemDualOrderListBinding bind(@NonNull View view) {
        int i10 = R.id.tv_dual_amount;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
        if (textView != null) {
            i10 = R.id.tv_dual_ccqx;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView2 != null) {
                i10 = R.id.tv_dual_ccqx_label;
                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView3 != null) {
                    i10 = R.id.tv_dual_dqr;
                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView4 != null) {
                        i10 = R.id.tv_dual_ggckj;
                        TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView5 != null) {
                            i10 = R.id.tv_dual_ggckj_label;
                            TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView6 != null) {
                                i10 = R.id.tv_dual_hkje;
                                TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView7 != null) {
                                    i10 = R.id.tv_dual_id;
                                    TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView8 != null) {
                                        i10 = R.id.tv_dual_jsj;
                                        TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView9 != null) {
                                            i10 = R.id.tv_dual_jsj_label;
                                            TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView10 != null) {
                                                i10 = R.id.tv_dual_name;
                                                TextView textView11 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView11 != null) {
                                                    i10 = R.id.tv_dual_rate;
                                                    TextView textView12 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                    if (textView12 != null) {
                                                        i10 = R.id.tv_dual_status;
                                                        TextView textView13 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                        if (textView13 != null) {
                                                            i10 = R.id.tv_dual_time;
                                                            TextView textView14 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                            if (textView14 != null) {
                                                                return new ItemDualOrderListBinding((LinearLayout) view, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9, textView10, textView11, textView12, textView13, textView14);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ItemDualOrderListBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.item_dual_order_list, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private ItemDualOrderListBinding(@NonNull LinearLayout linearLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textView9, @NonNull TextView textView10, @NonNull TextView textView11, @NonNull TextView textView12, @NonNull TextView textView13, @NonNull TextView textView14) {
        this.rootView = linearLayout;
        this.tvDualAmount = textView;
        this.tvDualCcqx = textView2;
        this.tvDualCcqxLabel = textView3;
        this.tvDualDqr = textView4;
        this.tvDualGgckj = textView5;
        this.tvDualGgckjLabel = textView6;
        this.tvDualHkje = textView7;
        this.tvDualId = textView8;
        this.tvDualJsj = textView9;
        this.tvDualJsjLabel = textView10;
        this.tvDualName = textView11;
        this.tvDualRate = textView12;
        this.tvDualStatus = textView13;
        this.tvDualTime = textView14;
    }
}