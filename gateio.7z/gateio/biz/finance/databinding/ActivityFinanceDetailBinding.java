package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Group;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.databinding.LayoutHeaderNormalBinding;
import com.gateio.biz.finance.R;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.sparkhuu.klinelib.chart.ChainInvestLineChart;

/* loaded from: classes7.dex */
public final class ActivityFinanceDetailBinding implements ViewBinding {

    @NonNull
    public final CardView card;

    @NonNull
    public final ViewFinanceDoneDetailBinding financeDone;

    @NonNull
    public final ViewFinanceInProcessDetailBinding financeInProcess;

    @NonNull
    public final ChainInvestLineChart lineChart;

    @NonNull
    public final Group priceGroup;

    @NonNull
    public final ViewFinancePriceShowBinding priceLabel;

    @NonNull
    public final SmartRefreshLayout refresh;

    @NonNull
    private final ConstraintLayout rootView;

    @NonNull
    public final LayoutHeaderNormalBinding titleView;

    @NonNull
    public final TextView tvEmpty;

    @NonNull
    public final TextView tvPriceDesc;

    @NonNull
    public final TextView tvSubTitle;

    @NonNull
    public static ActivityFinanceDetailBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ActivityFinanceDetailBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        View viewFindChildViewById3;
        int i10 = R.id.card;
        CardView cardView = (CardView) ViewBindings.findChildViewById(view, i10);
        if (cardView != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.finance_done))) != null) {
            ViewFinanceDoneDetailBinding viewFinanceDoneDetailBindingBind = ViewFinanceDoneDetailBinding.bind(viewFindChildViewById);
            i10 = R.id.finance_in_process;
            View viewFindChildViewById4 = ViewBindings.findChildViewById(view, i10);
            if (viewFindChildViewById4 != null) {
                ViewFinanceInProcessDetailBinding viewFinanceInProcessDetailBindingBind = ViewFinanceInProcessDetailBinding.bind(viewFindChildViewById4);
                i10 = R.id.line_chart;
                ChainInvestLineChart chainInvestLineChart = (ChainInvestLineChart) ViewBindings.findChildViewById(view, i10);
                if (chainInvestLineChart != null) {
                    i10 = R.id.priceGroup;
                    Group group = (Group) ViewBindings.findChildViewById(view, i10);
                    if (group != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i10 = R.id.price_label))) != null) {
                        ViewFinancePriceShowBinding viewFinancePriceShowBindingBind = ViewFinancePriceShowBinding.bind(viewFindChildViewById2);
                        i10 = R.id.refresh;
                        SmartRefreshLayout smartRefreshLayout = (SmartRefreshLayout) ViewBindings.findChildViewById(view, i10);
                        if (smartRefreshLayout != null && (viewFindChildViewById3 = ViewBindings.findChildViewById(view, (i10 = R.id.titleView))) != null) {
                            LayoutHeaderNormalBinding layoutHeaderNormalBindingBind = LayoutHeaderNormalBinding.bind(viewFindChildViewById3);
                            i10 = R.id.tv_empty;
                            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView != null) {
                                i10 = R.id.tv_price_desc;
                                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView2 != null) {
                                    i10 = R.id.tv_sub_title;
                                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView3 != null) {
                                        return new ActivityFinanceDetailBinding((ConstraintLayout) view, cardView, viewFinanceDoneDetailBindingBind, viewFinanceInProcessDetailBindingBind, chainInvestLineChart, group, viewFinancePriceShowBindingBind, smartRefreshLayout, layoutHeaderNormalBindingBind, textView, textView2, textView3);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ActivityFinanceDetailBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_finance_detail, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    private ActivityFinanceDetailBinding(@NonNull ConstraintLayout constraintLayout, @NonNull CardView cardView, @NonNull ViewFinanceDoneDetailBinding viewFinanceDoneDetailBinding, @NonNull ViewFinanceInProcessDetailBinding viewFinanceInProcessDetailBinding, @NonNull ChainInvestLineChart chainInvestLineChart, @NonNull Group group, @NonNull ViewFinancePriceShowBinding viewFinancePriceShowBinding, @NonNull SmartRefreshLayout smartRefreshLayout, @NonNull LayoutHeaderNormalBinding layoutHeaderNormalBinding, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3) {
        this.rootView = constraintLayout;
        this.card = cardView;
        this.financeDone = viewFinanceDoneDetailBinding;
        this.financeInProcess = viewFinanceInProcessDetailBinding;
        this.lineChart = chainInvestLineChart;
        this.priceGroup = group;
        this.priceLabel = viewFinancePriceShowBinding;
        this.refresh = smartRefreshLayout;
        this.titleView = layoutHeaderNormalBinding;
        this.tvEmpty = textView;
        this.tvPriceDesc = textView2;
        this.tvSubTitle = textView3;
    }
}