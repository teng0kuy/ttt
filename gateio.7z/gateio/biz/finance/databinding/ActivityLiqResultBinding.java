package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CornerTextView;

/* loaded from: classes7.dex */
public final class ActivityLiqResultBinding implements ViewBinding {

    @NonNull
    public final CornerTextView ctvBack;

    @NonNull
    public final CornerTextView ctvMarket;

    @NonNull
    public final ImageView ivBase;

    @NonNull
    public final ImageView ivQuato;

    @NonNull
    public final LinearLayout llAction;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final TextView tvActionDesc;

    @NonNull
    public final TextView tvActionResult;

    @NonNull
    public final TextView tvBase;

    @NonNull
    public final TextView tvLiqAcitonLabel;

    @NonNull
    public final TextView tvLiqShares;

    @NonNull
    public final TextView tvLiqSharesLabel;

    @NonNull
    public final TextView tvLiqTotal;

    @NonNull
    public final TextView tvMarket;

    @NonNull
    public final TextView tvMarketLabel;

    @NonNull
    public final TextView tvQuato;

    @NonNull
    public final TextView tvShareExchange;

    @NonNull
    public final TextView tvShareExchangeLabel;

    @NonNull
    public final TextView tvShareLabel;

    @NonNull
    public final TextView tvShares;

    private ActivityLiqResultBinding(@NonNull RelativeLayout relativeLayout, @NonNull CornerTextView cornerTextView, @NonNull CornerTextView cornerTextView2, @NonNull ImageView imageView, @NonNull ImageView imageView2, @NonNull LinearLayout linearLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textView9, @NonNull TextView textView10, @NonNull TextView textView11, @NonNull TextView textView12, @NonNull TextView textView13, @NonNull TextView textView14) {
        this.rootView = relativeLayout;
        this.ctvBack = cornerTextView;
        this.ctvMarket = cornerTextView2;
        this.ivBase = imageView;
        this.ivQuato = imageView2;
        this.llAction = linearLayout;
        this.tvActionDesc = textView;
        this.tvActionResult = textView2;
        this.tvBase = textView3;
        this.tvLiqAcitonLabel = textView4;
        this.tvLiqShares = textView5;
        this.tvLiqSharesLabel = textView6;
        this.tvLiqTotal = textView7;
        this.tvMarket = textView8;
        this.tvMarketLabel = textView9;
        this.tvQuato = textView10;
        this.tvShareExchange = textView11;
        this.tvShareExchangeLabel = textView12;
        this.tvShareLabel = textView13;
        this.tvShares = textView14;
    }

    @NonNull
    public static ActivityLiqResultBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ActivityLiqResultBinding bind(@NonNull View view) {
        int i10 = R.id.ctv_back;
        CornerTextView cornerTextView = (CornerTextView) ViewBindings.findChildViewById(view, i10);
        if (cornerTextView != null) {
            i10 = R.id.ctv_market;
            CornerTextView cornerTextView2 = (CornerTextView) ViewBindings.findChildViewById(view, i10);
            if (cornerTextView2 != null) {
                i10 = R.id.iv_base;
                ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
                if (imageView != null) {
                    i10 = R.id.iv_quato;
                    ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i10);
                    if (imageView2 != null) {
                        i10 = R.id.ll_action;
                        LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                        if (linearLayout != null) {
                            i10 = R.id.tv_action_desc;
                            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView != null) {
                                i10 = R.id.tv_action_result;
                                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView2 != null) {
                                    i10 = R.id.tv_base;
                                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView3 != null) {
                                        i10 = R.id.tv_liq_aciton_label;
                                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView4 != null) {
                                            i10 = R.id.tv_liq_shares;
                                            TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView5 != null) {
                                                i10 = R.id.tv_liq_shares_label;
                                                TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView6 != null) {
                                                    i10 = R.id.tv_liq_total;
                                                    TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                    if (textView7 != null) {
                                                        i10 = R.id.tv_market;
                                                        TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                        if (textView8 != null) {
                                                            i10 = R.id.tv_market_label;
                                                            TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                            if (textView9 != null) {
                                                                i10 = R.id.tv_quato;
                                                                TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                if (textView10 != null) {
                                                                    i10 = R.id.tv_share_exchange;
                                                                    TextView textView11 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                    if (textView11 != null) {
                                                                        i10 = R.id.tv_share_exchange_label;
                                                                        TextView textView12 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                        if (textView12 != null) {
                                                                            i10 = R.id.tv_share_label;
                                                                            TextView textView13 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                            if (textView13 != null) {
                                                                                i10 = R.id.tv_shares;
                                                                                TextView textView14 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                if (textView14 != null) {
                                                                                    return new ActivityLiqResultBinding((RelativeLayout) view, cornerTextView, cornerTextView2, imageView, imageView2, linearLayout, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9, textView10, textView11, textView12, textView13, textView14);
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ActivityLiqResultBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_liq_result, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }
}