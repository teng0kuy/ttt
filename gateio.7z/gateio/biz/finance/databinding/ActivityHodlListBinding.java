package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.databinding.LayoutMainHeaderBinding;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CustomViewpager;
import com.gateio.common.view.ViewPagerSwipeRefreshLayout;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.tabs.TabLayout;

/* loaded from: classes7.dex */
public final class ActivityHodlListBinding implements ViewBinding {

    @NonNull
    public final AppBarLayout appBar;

    @NonNull
    public final CoordinatorLayout coordinatorRoot;

    @NonNull
    public final LayoutMainHeaderBinding layoutHeader;

    @NonNull
    public final ViewPagerSwipeRefreshLayout refreshLayout;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final TextView subtitle;

    @NonNull
    public final TabLayout tabLayout;

    @NonNull
    public final TextView title;

    @NonNull
    public final CustomViewpager viewPager;

    @NonNull
    public static ActivityHodlListBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ActivityHodlListBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.app_bar;
        AppBarLayout appBarLayout = (AppBarLayout) ViewBindings.findChildViewById(view, i10);
        if (appBarLayout != null) {
            i10 = R.id.coordinator_root;
            CoordinatorLayout coordinatorLayout = (CoordinatorLayout) ViewBindings.findChildViewById(view, i10);
            if (coordinatorLayout != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.layout_header))) != null) {
                LayoutMainHeaderBinding layoutMainHeaderBindingBind = LayoutMainHeaderBinding.bind(viewFindChildViewById);
                i10 = R.id.refreshLayout;
                ViewPagerSwipeRefreshLayout viewPagerSwipeRefreshLayout = (ViewPagerSwipeRefreshLayout) ViewBindings.findChildViewById(view, i10);
                if (viewPagerSwipeRefreshLayout != null) {
                    i10 = R.id.subtitle;
                    TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView != null) {
                        i10 = R.id.tab_layout;
                        TabLayout tabLayout = (TabLayout) ViewBindings.findChildViewById(view, i10);
                        if (tabLayout != null) {
                            i10 = R.id.title;
                            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView2 != null) {
                                i10 = R.id.view_pager;
                                CustomViewpager customViewpager = (CustomViewpager) ViewBindings.findChildViewById(view, i10);
                                if (customViewpager != null) {
                                    return new ActivityHodlListBinding((LinearLayout) view, appBarLayout, coordinatorLayout, layoutMainHeaderBindingBind, viewPagerSwipeRefreshLayout, textView, tabLayout, textView2, customViewpager);
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ActivityHodlListBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_hodl_list, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private ActivityHodlListBinding(@NonNull LinearLayout linearLayout, @NonNull AppBarLayout appBarLayout, @NonNull CoordinatorLayout coordinatorLayout, @NonNull LayoutMainHeaderBinding layoutMainHeaderBinding, @NonNull ViewPagerSwipeRefreshLayout viewPagerSwipeRefreshLayout, @NonNull TextView textView, @NonNull TabLayout tabLayout, @NonNull TextView textView2, @NonNull CustomViewpager customViewpager) {
        this.rootView = linearLayout;
        this.appBar = appBarLayout;
        this.coordinatorRoot = coordinatorLayout;
        this.layoutHeader = layoutMainHeaderBinding;
        this.refreshLayout = viewPagerSwipeRefreshLayout;
        this.subtitle = textView;
        this.tabLayout = tabLayout;
        this.title = textView2;
        this.viewPager = customViewpager;
    }
}