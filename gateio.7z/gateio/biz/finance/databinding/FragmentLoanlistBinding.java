package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.lib.uikit.state.GateEmptyViewV2;

/* loaded from: classes7.dex */
public final class FragmentLoanlistBinding implements ViewBinding {

    @NonNull
    public final ItemLoanTitleBinding layoutLoanTitle;

    @NonNull
    public final RelativeLayout llTop;

    @NonNull
    public final SwipeRefreshLayout refresh;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final RecyclerView rvMarginLoans;

    @NonNull
    public final GateEmptyViewV2 tvEmpty;

    @NonNull
    public final TextView tvRest;

    @NonNull
    public final TextView tvRestLabel;

    @NonNull
    public final TextView tvTotal;

    @NonNull
    public final TextView tvTotalLabel;

    @NonNull
    public final View vDivide;

    @NonNull
    public static FragmentLoanlistBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static FragmentLoanlistBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.layout_loan_title;
        View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i10);
        if (viewFindChildViewById2 != null) {
            ItemLoanTitleBinding itemLoanTitleBindingBind = ItemLoanTitleBinding.bind(viewFindChildViewById2);
            i10 = R.id.ll_top;
            RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
            if (relativeLayout != null) {
                i10 = R.id.refresh;
                SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) ViewBindings.findChildViewById(view, i10);
                if (swipeRefreshLayout != null) {
                    i10 = R.id.rv_margin_loans;
                    RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                    if (recyclerView != null) {
                        i10 = R.id.tv_empty;
                        GateEmptyViewV2 gateEmptyViewV2 = (GateEmptyViewV2) ViewBindings.findChildViewById(view, i10);
                        if (gateEmptyViewV2 != null) {
                            i10 = R.id.tv_rest;
                            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView != null) {
                                i10 = R.id.tv_rest_label;
                                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView2 != null) {
                                    i10 = R.id.tv_total;
                                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView3 != null) {
                                        i10 = R.id.tv_total_label;
                                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView4 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.v_divide))) != null) {
                                            return new FragmentLoanlistBinding((RelativeLayout) view, itemLoanTitleBindingBind, relativeLayout, swipeRefreshLayout, recyclerView, gateEmptyViewV2, textView, textView2, textView3, textView4, viewFindChildViewById);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static FragmentLoanlistBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.fragment_loanlist, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private FragmentLoanlistBinding(@NonNull RelativeLayout relativeLayout, @NonNull ItemLoanTitleBinding itemLoanTitleBinding, @NonNull RelativeLayout relativeLayout2, @NonNull SwipeRefreshLayout swipeRefreshLayout, @NonNull RecyclerView recyclerView, @NonNull GateEmptyViewV2 gateEmptyViewV2, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull View view) {
        this.rootView = relativeLayout;
        this.layoutLoanTitle = itemLoanTitleBinding;
        this.llTop = relativeLayout2;
        this.refresh = swipeRefreshLayout;
        this.rvMarginLoans = recyclerView;
        this.tvEmpty = gateEmptyViewV2;
        this.tvRest = textView;
        this.tvRestLabel = textView2;
        this.tvTotal = textView3;
        this.tvTotalLabel = textView4;
        this.vDivide = view;
    }
}