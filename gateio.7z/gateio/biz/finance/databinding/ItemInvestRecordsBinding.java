package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CornerLinearLayout;

/* loaded from: classes7.dex */
public final class ItemInvestRecordsBinding implements ViewBinding {

    @NonNull
    public final CornerLinearLayout llRoot;

    @NonNull
    public final TextView orderId;

    @NonNull
    public final TextView orderTime;

    @NonNull
    public final TextView orderTimeLabel;

    @NonNull
    public final TextView ordersName;

    @NonNull
    public final TextView ordersSide;

    @NonNull
    private final CornerLinearLayout rootView;

    @NonNull
    public final TextView tvAmount;

    @NonNull
    public final TextView tvInvestCysy;

    @NonNull
    public final TextView tvInvestLjsy;

    @NonNull
    public final TextView tvInvestZrsy;

    @NonNull
    public final ViewInvestMyselfBinding vInvestMyself;

    @NonNull
    public static ItemInvestRecordsBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        CornerLinearLayout cornerLinearLayout = (CornerLinearLayout) view;
        int i10 = R.id.order_id;
        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
        if (textView != null) {
            i10 = R.id.order_time;
            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView2 != null) {
                i10 = R.id.order_time_label;
                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView3 != null) {
                    i10 = R.id.orders_name;
                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView4 != null) {
                        i10 = R.id.orders_side;
                        TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView5 != null) {
                            i10 = R.id.tv_amount;
                            TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView6 != null) {
                                i10 = R.id.tv_invest_cysy;
                                TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView7 != null) {
                                    i10 = R.id.tv_invest_ljsy;
                                    TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView8 != null) {
                                        i10 = R.id.tv_invest_zrsy;
                                        TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView9 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.v_invest_myself))) != null) {
                                            return new ItemInvestRecordsBinding(cornerLinearLayout, cornerLinearLayout, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9, ViewInvestMyselfBinding.bind(viewFindChildViewById));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ItemInvestRecordsBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ItemInvestRecordsBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.item_invest_records, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public CornerLinearLayout getRoot() {
        return this.rootView;
    }

    private ItemInvestRecordsBinding(@NonNull CornerLinearLayout cornerLinearLayout, @NonNull CornerLinearLayout cornerLinearLayout2, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textView9, @NonNull ViewInvestMyselfBinding viewInvestMyselfBinding) {
        this.rootView = cornerLinearLayout;
        this.llRoot = cornerLinearLayout2;
        this.orderId = textView;
        this.orderTime = textView2;
        this.orderTimeLabel = textView3;
        this.ordersName = textView4;
        this.ordersSide = textView5;
        this.tvAmount = textView6;
        this.tvInvestCysy = textView7;
        this.tvInvestLjsy = textView8;
        this.tvInvestZrsy = textView9;
        this.vInvestMyself = viewInvestMyselfBinding;
    }
}