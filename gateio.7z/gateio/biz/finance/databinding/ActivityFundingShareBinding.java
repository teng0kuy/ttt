package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;

/* loaded from: classes7.dex */
public final class ActivityFundingShareBinding implements ViewBinding {

    @NonNull
    public final ImageView ivRate;

    @NonNull
    public final ImageView qrcodeImage;

    @NonNull
    public final RelativeLayout rlRoot;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final LinearLayout shareContent;

    @NonNull
    public final TextView tvCurrency;

    @NonNull
    public final TextView tvDesc;

    @NonNull
    public final TextView tvPointShare;

    @NonNull
    public final TextView tvRate;

    @NonNull
    public static ActivityFundingShareBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ActivityFundingShareBinding bind(@NonNull View view) {
        int i10 = R.id.iv_rate;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
        if (imageView != null) {
            i10 = R.id.qrcode_image;
            ImageView imageView2 = (ImageView) ViewBindings.findChildViewById(view, i10);
            if (imageView2 != null) {
                RelativeLayout relativeLayout = (RelativeLayout) view;
                i10 = R.id.share_content;
                LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                if (linearLayout != null) {
                    i10 = R.id.tv_currency;
                    TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView != null) {
                        i10 = R.id.tv_desc;
                        TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView2 != null) {
                            i10 = R.id.tv_point_share;
                            TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView3 != null) {
                                i10 = R.id.tv_rate;
                                TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView4 != null) {
                                    return new ActivityFundingShareBinding(relativeLayout, imageView, imageView2, relativeLayout, linearLayout, textView, textView2, textView3, textView4);
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ActivityFundingShareBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_funding_share, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private ActivityFundingShareBinding(@NonNull RelativeLayout relativeLayout, @NonNull ImageView imageView, @NonNull ImageView imageView2, @NonNull RelativeLayout relativeLayout2, @NonNull LinearLayout linearLayout, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4) {
        this.rootView = relativeLayout;
        this.ivRate = imageView;
        this.qrcodeImage = imageView2;
        this.rlRoot = relativeLayout2;
        this.shareContent = linearLayout;
        this.tvCurrency = textView;
        this.tvDesc = textView2;
        this.tvPointShare = textView3;
        this.tvRate = textView4;
    }
}