package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CustomViewpager;
import net.lucode.hackware.magicindicator.MagicIndicator;

/* loaded from: classes7.dex */
public final class ActivityMarginmanageBinding implements ViewBinding {

    @NonNull
    public final ImageView btnHeadBack;

    @NonNull
    public final MagicIndicator magicIndicatorTrans;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final CustomViewpager vpMarginManage;

    @NonNull
    public static ActivityMarginmanageBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ActivityMarginmanageBinding bind(@NonNull View view) {
        int i10 = R.id.btn_head_back;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
        if (imageView != null) {
            i10 = R.id.magic_indicator_trans;
            MagicIndicator magicIndicator = (MagicIndicator) ViewBindings.findChildViewById(view, i10);
            if (magicIndicator != null) {
                i10 = R.id.vp_margin_manage;
                CustomViewpager customViewpager = (CustomViewpager) ViewBindings.findChildViewById(view, i10);
                if (customViewpager != null) {
                    return new ActivityMarginmanageBinding((LinearLayout) view, imageView, magicIndicator, customViewpager);
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ActivityMarginmanageBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_marginmanage, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private ActivityMarginmanageBinding(@NonNull LinearLayout linearLayout, @NonNull ImageView imageView, @NonNull MagicIndicator magicIndicator, @NonNull CustomViewpager customViewpager) {
        this.rootView = linearLayout;
        this.btnHeadBack = imageView;
        this.magicIndicatorTrans = magicIndicator;
        this.vpMarginManage = customViewpager;
    }
}