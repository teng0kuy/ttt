package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.databinding.LayoutMainHeaderBinding;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CustomViewpager;
import net.lucode.hackware.magicindicator.MagicIndicator;

/* loaded from: classes7.dex */
public final class ActivityHoldFinancesBinding implements ViewBinding {

    @NonNull
    public final DrawerLayout drawerLayout;

    @NonNull
    public final ImageView ivFilter;

    @NonNull
    public final LayoutMainHeaderBinding layoutHeader;

    @NonNull
    public final MagicIndicator magicIndicator;

    @NonNull
    public final DrawarHoldBillBinding rlDrawer;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final CustomViewpager viewPager;

    @NonNull
    public static ActivityHoldFinancesBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ActivityHoldFinancesBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        View viewFindChildViewById2;
        int i10 = R.id.drawer_layout;
        DrawerLayout drawerLayout = (DrawerLayout) ViewBindings.findChildViewById(view, i10);
        if (drawerLayout != null) {
            i10 = R.id.iv_filter;
            ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
            if (imageView != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.layout_header))) != null) {
                LayoutMainHeaderBinding layoutMainHeaderBindingBind = LayoutMainHeaderBinding.bind(viewFindChildViewById);
                i10 = R.id.magic_indicator;
                MagicIndicator magicIndicator = (MagicIndicator) ViewBindings.findChildViewById(view, i10);
                if (magicIndicator != null && (viewFindChildViewById2 = ViewBindings.findChildViewById(view, (i10 = R.id.rl_drawer))) != null) {
                    DrawarHoldBillBinding drawarHoldBillBindingBind = DrawarHoldBillBinding.bind(viewFindChildViewById2);
                    i10 = R.id.view_pager;
                    CustomViewpager customViewpager = (CustomViewpager) ViewBindings.findChildViewById(view, i10);
                    if (customViewpager != null) {
                        return new ActivityHoldFinancesBinding((LinearLayout) view, drawerLayout, imageView, layoutMainHeaderBindingBind, magicIndicator, drawarHoldBillBindingBind, customViewpager);
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ActivityHoldFinancesBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_hold_finances, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private ActivityHoldFinancesBinding(@NonNull LinearLayout linearLayout, @NonNull DrawerLayout drawerLayout, @NonNull ImageView imageView, @NonNull LayoutMainHeaderBinding layoutMainHeaderBinding, @NonNull MagicIndicator magicIndicator, @NonNull DrawarHoldBillBinding drawarHoldBillBinding, @NonNull CustomViewpager customViewpager) {
        this.rootView = linearLayout;
        this.drawerLayout = drawerLayout;
        this.ivFilter = imageView;
        this.layoutHeader = layoutMainHeaderBinding;
        this.magicIndicator = magicIndicator;
        this.rlDrawer = drawarHoldBillBinding;
        this.viewPager = customViewpager;
    }
}