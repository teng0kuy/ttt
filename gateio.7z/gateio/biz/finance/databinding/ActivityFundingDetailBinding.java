package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.databinding.LayoutMainHeaderBinding;
import com.gateio.biz.finance.R;
import com.gateio.lib.uikit.state.GateEmptyViewV2;

/* loaded from: classes7.dex */
public final class ActivityFundingDetailBinding implements ViewBinding {

    @NonNull
    public final LayoutMainHeaderBinding layoutHeader;

    @NonNull
    public final LinearLayout llContent;

    @NonNull
    public final NestedScrollView nestScroll;

    @NonNull
    public final ProgressBar pbOrder;

    @NonNull
    public final RecyclerView recyclerView;

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final Switch swSwitch;

    @NonNull
    public final SwipeRefreshLayout swipeRefresh;

    @NonNull
    public final GateEmptyViewV2 tvEmpty;

    @NonNull
    public final TextView tvFundingAmount;

    @NonNull
    public final TextView tvFundingCancel;

    @NonNull
    public final TextView tvFundingDay;

    @NonNull
    public final TextView tvFundingName;

    @NonNull
    public final TextView tvFundingRate;

    @NonNull
    public final TextView tvFundingSl;

    @NonNull
    public final TextView tvFundingWcjd;

    @NonNull
    public final TextView tvId;

    @NonNull
    public final TextView tvProgressNum;

    @NonNull
    public final TextView tvProgressPercent;

    @NonNull
    public final TextView tvStartTime;

    @NonNull
    public final TextView tvState;

    @NonNull
    public final TextView tvType;

    @NonNull
    public final View vLineBottom;

    private ActivityFundingDetailBinding(@NonNull LinearLayout linearLayout, @NonNull LayoutMainHeaderBinding layoutMainHeaderBinding, @NonNull LinearLayout linearLayout2, @NonNull NestedScrollView nestedScrollView, @NonNull ProgressBar progressBar, @NonNull RecyclerView recyclerView, @NonNull Switch r92, @NonNull SwipeRefreshLayout swipeRefreshLayout, @NonNull GateEmptyViewV2 gateEmptyViewV2, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textView9, @NonNull TextView textView10, @NonNull TextView textView11, @NonNull TextView textView12, @NonNull TextView textView13, @NonNull View view) {
        this.rootView = linearLayout;
        this.layoutHeader = layoutMainHeaderBinding;
        this.llContent = linearLayout2;
        this.nestScroll = nestedScrollView;
        this.pbOrder = progressBar;
        this.recyclerView = recyclerView;
        this.swSwitch = r92;
        this.swipeRefresh = swipeRefreshLayout;
        this.tvEmpty = gateEmptyViewV2;
        this.tvFundingAmount = textView;
        this.tvFundingCancel = textView2;
        this.tvFundingDay = textView3;
        this.tvFundingName = textView4;
        this.tvFundingRate = textView5;
        this.tvFundingSl = textView6;
        this.tvFundingWcjd = textView7;
        this.tvId = textView8;
        this.tvProgressNum = textView9;
        this.tvProgressPercent = textView10;
        this.tvStartTime = textView11;
        this.tvState = textView12;
        this.tvType = textView13;
        this.vLineBottom = view;
    }

    @NonNull
    public static ActivityFundingDetailBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ActivityFundingDetailBinding bind(@NonNull View view) {
        View viewFindChildViewById;
        int i10 = R.id.layout_header;
        View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i10);
        if (viewFindChildViewById2 != null) {
            LayoutMainHeaderBinding layoutMainHeaderBindingBind = LayoutMainHeaderBinding.bind(viewFindChildViewById2);
            i10 = R.id.ll_content;
            LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
            if (linearLayout != null) {
                i10 = R.id.nest_scroll;
                NestedScrollView nestedScrollView = (NestedScrollView) ViewBindings.findChildViewById(view, i10);
                if (nestedScrollView != null) {
                    i10 = R.id.pb_order;
                    ProgressBar progressBar = (ProgressBar) ViewBindings.findChildViewById(view, i10);
                    if (progressBar != null) {
                        i10 = R.id.recycler_view;
                        RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                        if (recyclerView != null) {
                            i10 = R.id.sw_switch;
                            Switch r10 = (Switch) ViewBindings.findChildViewById(view, i10);
                            if (r10 != null) {
                                i10 = R.id.swipe_refresh;
                                SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) ViewBindings.findChildViewById(view, i10);
                                if (swipeRefreshLayout != null) {
                                    i10 = R.id.tv_empty;
                                    GateEmptyViewV2 gateEmptyViewV2 = (GateEmptyViewV2) ViewBindings.findChildViewById(view, i10);
                                    if (gateEmptyViewV2 != null) {
                                        i10 = R.id.tv_funding_amount;
                                        TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView != null) {
                                            i10 = R.id.tv_funding_cancel;
                                            TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                            if (textView2 != null) {
                                                i10 = R.id.tv_funding_day;
                                                TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView3 != null) {
                                                    i10 = R.id.tv_funding_name;
                                                    TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                    if (textView4 != null) {
                                                        i10 = R.id.tv_funding_rate;
                                                        TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                        if (textView5 != null) {
                                                            i10 = R.id.tv_funding_sl;
                                                            TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                            if (textView6 != null) {
                                                                i10 = R.id.tv_funding_wcjd;
                                                                TextView textView7 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                if (textView7 != null) {
                                                                    i10 = R.id.tv_id;
                                                                    TextView textView8 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                    if (textView8 != null) {
                                                                        i10 = R.id.tv_progress_num;
                                                                        TextView textView9 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                        if (textView9 != null) {
                                                                            i10 = R.id.tv_progress_percent;
                                                                            TextView textView10 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                            if (textView10 != null) {
                                                                                i10 = R.id.tv_start_time;
                                                                                TextView textView11 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                if (textView11 != null) {
                                                                                    i10 = R.id.tv_state;
                                                                                    TextView textView12 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                    if (textView12 != null) {
                                                                                        i10 = R.id.tv_type;
                                                                                        TextView textView13 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                                                        if (textView13 != null && (viewFindChildViewById = ViewBindings.findChildViewById(view, (i10 = R.id.v_line_bottom))) != null) {
                                                                                            return new ActivityFundingDetailBinding((LinearLayout) view, layoutMainHeaderBindingBind, linearLayout, nestedScrollView, progressBar, recyclerView, r10, swipeRefreshLayout, gateEmptyViewV2, textView, textView2, textView3, textView4, textView5, textView6, textView7, textView8, textView9, textView10, textView11, textView12, textView13, viewFindChildViewById);
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ActivityFundingDetailBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_funding_detail, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }
}