package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CornerLinearLayout;
import com.gateio.common.view.CornerTextView;

/* loaded from: classes7.dex */
public final class LayoutInvestShBinding implements ViewBinding {

    @NonNull
    public final EditText edShContent;

    @NonNull
    public final TextView edShTitle;

    @NonNull
    private final CornerLinearLayout rootView;

    @NonNull
    public final TextView tvCancel;

    @NonNull
    public final CornerTextView tvCommit;

    @NonNull
    public final TextView tvPercent100;

    @NonNull
    public final TextView tvPercent25;

    @NonNull
    public final TextView tvPercent50;

    @NonNull
    public final TextView tvPercent75;

    @NonNull
    public static LayoutInvestShBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static LayoutInvestShBinding bind(@NonNull View view) {
        int i10 = R.id.ed_sh_content;
        EditText editText = (EditText) ViewBindings.findChildViewById(view, i10);
        if (editText != null) {
            i10 = R.id.ed_sh_title;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                i10 = R.id.tv_cancel;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView2 != null) {
                    i10 = R.id.tv_commit;
                    CornerTextView cornerTextView = (CornerTextView) ViewBindings.findChildViewById(view, i10);
                    if (cornerTextView != null) {
                        i10 = R.id.tv_percent_100;
                        TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView3 != null) {
                            i10 = R.id.tv_percent_25;
                            TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView4 != null) {
                                i10 = R.id.tv_percent_50;
                                TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView5 != null) {
                                    i10 = R.id.tv_percent_75;
                                    TextView textView6 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView6 != null) {
                                        return new LayoutInvestShBinding((CornerLinearLayout) view, editText, textView, textView2, cornerTextView, textView3, textView4, textView5, textView6);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static LayoutInvestShBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.layout_invest_sh, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public CornerLinearLayout getRoot() {
        return this.rootView;
    }

    private LayoutInvestShBinding(@NonNull CornerLinearLayout cornerLinearLayout, @NonNull EditText editText, @NonNull TextView textView, @NonNull TextView textView2, @NonNull CornerTextView cornerTextView, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5, @NonNull TextView textView6) {
        this.rootView = cornerLinearLayout;
        this.edShContent = editText;
        this.edShTitle = textView;
        this.tvCancel = textView2;
        this.tvCommit = cornerTextView;
        this.tvPercent100 = textView3;
        this.tvPercent25 = textView4;
        this.tvPercent50 = textView5;
        this.tvPercent75 = textView6;
    }
}