package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.CornerLinearLayout;
import com.gateio.common.view.CornerRelativeLayout;
import com.gateio.common.view.CornerTextView;
import com.gateio.lib.uikit.text.GTDashTextView;

/* loaded from: classes7.dex */
public final class LayoutAccountInvestBinding implements ViewBinding {

    @NonNull
    public final ImageView ivArrow;

    @NonNull
    public final CornerLinearLayout llInvestName;

    @NonNull
    public final LinearLayout llLabel;

    @NonNull
    public final CornerRelativeLayout rlAccountInvest;

    @NonNull
    public final RelativeLayout rlTitle;

    @NonNull
    private final CornerRelativeLayout rootView;

    @NonNull
    public final GTDashTextView tvAvailableText;

    @NonNull
    public final TextView tvInvestCysy;

    @NonNull
    public final TextView tvInvestDqsz;

    @NonNull
    public final TextView tvInvestKyye;

    @NonNull
    public final TextView tvInvestLjsy;

    @NonNull
    public final CornerTextView tvInvestName;

    @NonNull
    public final TextView tvInvestZrsy;

    @NonNull
    public static LayoutAccountInvestBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static LayoutAccountInvestBinding bind(@NonNull View view) {
        int i10 = R.id.iv_arrow;
        ImageView imageView = (ImageView) ViewBindings.findChildViewById(view, i10);
        if (imageView != null) {
            i10 = R.id.ll_invest_name;
            CornerLinearLayout cornerLinearLayout = (CornerLinearLayout) ViewBindings.findChildViewById(view, i10);
            if (cornerLinearLayout != null) {
                i10 = R.id.ll_label;
                LinearLayout linearLayout = (LinearLayout) ViewBindings.findChildViewById(view, i10);
                if (linearLayout != null) {
                    CornerRelativeLayout cornerRelativeLayout = (CornerRelativeLayout) view;
                    i10 = R.id.rl_title;
                    RelativeLayout relativeLayout = (RelativeLayout) ViewBindings.findChildViewById(view, i10);
                    if (relativeLayout != null) {
                        i10 = R.id.tv_available_text;
                        GTDashTextView gTDashTextView = (GTDashTextView) ViewBindings.findChildViewById(view, i10);
                        if (gTDashTextView != null) {
                            i10 = R.id.tv_invest_cysy;
                            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView != null) {
                                i10 = R.id.tv_invest_dqsz;
                                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView2 != null) {
                                    i10 = R.id.tv_invest_kyye;
                                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView3 != null) {
                                        i10 = R.id.tv_invest_ljsy;
                                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                                        if (textView4 != null) {
                                            i10 = R.id.tv_invest_name;
                                            CornerTextView cornerTextView = (CornerTextView) ViewBindings.findChildViewById(view, i10);
                                            if (cornerTextView != null) {
                                                i10 = R.id.tv_invest_zrsy;
                                                TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                                                if (textView5 != null) {
                                                    return new LayoutAccountInvestBinding(cornerRelativeLayout, imageView, cornerLinearLayout, linearLayout, cornerRelativeLayout, relativeLayout, gTDashTextView, textView, textView2, textView3, textView4, cornerTextView, textView5);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static LayoutAccountInvestBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.layout_account_invest, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public CornerRelativeLayout getRoot() {
        return this.rootView;
    }

    private LayoutAccountInvestBinding(@NonNull CornerRelativeLayout cornerRelativeLayout, @NonNull ImageView imageView, @NonNull CornerLinearLayout cornerLinearLayout, @NonNull LinearLayout linearLayout, @NonNull CornerRelativeLayout cornerRelativeLayout2, @NonNull RelativeLayout relativeLayout, @NonNull GTDashTextView gTDashTextView, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull CornerTextView cornerTextView, @NonNull TextView textView5) {
        this.rootView = cornerRelativeLayout;
        this.ivArrow = imageView;
        this.llInvestName = cornerLinearLayout;
        this.llLabel = linearLayout;
        this.rlAccountInvest = cornerRelativeLayout2;
        this.rlTitle = relativeLayout;
        this.tvAvailableText = gTDashTextView;
        this.tvInvestCysy = textView;
        this.tvInvestDqsz = textView2;
        this.tvInvestKyye = textView3;
        this.tvInvestLjsy = textView4;
        this.tvInvestName = cornerTextView;
        this.tvInvestZrsy = textView5;
    }
}