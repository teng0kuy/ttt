package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.gateio.view.CornerConstraintLayout;

/* loaded from: classes7.dex */
public final class ViewStructuredFinanceHomeMenuBinding implements ViewBinding {

    @NonNull
    public final View bg;

    @NonNull
    public final CornerConstraintLayout bgView;

    @NonNull
    public final AppCompatImageView ivStructuredMarket;

    @NonNull
    public final AppCompatImageView ivStructuredMyFinance;

    @NonNull
    public final AppCompatImageView ivStructuredRecord;

    @NonNull
    private final ConstraintLayout rootView;

    @NonNull
    public final TextView structuredMarket;

    @NonNull
    public final TextView structuredMyFinance;

    @NonNull
    public final TextView structuredRecord;

    @NonNull
    public static ViewStructuredFinanceHomeMenuBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ViewStructuredFinanceHomeMenuBinding bind(@NonNull View view) {
        int i10 = R.id.bg;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i10);
        if (viewFindChildViewById != null) {
            i10 = R.id.bg_view;
            CornerConstraintLayout cornerConstraintLayout = (CornerConstraintLayout) ViewBindings.findChildViewById(view, i10);
            if (cornerConstraintLayout != null) {
                i10 = R.id.iv_structured_market;
                AppCompatImageView appCompatImageView = (AppCompatImageView) ViewBindings.findChildViewById(view, i10);
                if (appCompatImageView != null) {
                    i10 = R.id.iv_structured_my_finance;
                    AppCompatImageView appCompatImageView2 = (AppCompatImageView) ViewBindings.findChildViewById(view, i10);
                    if (appCompatImageView2 != null) {
                        i10 = R.id.iv_structured_record;
                        AppCompatImageView appCompatImageView3 = (AppCompatImageView) ViewBindings.findChildViewById(view, i10);
                        if (appCompatImageView3 != null) {
                            i10 = R.id.structured_market;
                            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView != null) {
                                i10 = R.id.structured_my_finance;
                                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                                if (textView2 != null) {
                                    i10 = R.id.structured_record;
                                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                                    if (textView3 != null) {
                                        return new ViewStructuredFinanceHomeMenuBinding((ConstraintLayout) view, viewFindChildViewById, cornerConstraintLayout, appCompatImageView, appCompatImageView2, appCompatImageView3, textView, textView2, textView3);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ViewStructuredFinanceHomeMenuBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.view_structured_finance_home_menu, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public ConstraintLayout getRoot() {
        return this.rootView;
    }

    private ViewStructuredFinanceHomeMenuBinding(@NonNull ConstraintLayout constraintLayout, @NonNull View view, @NonNull CornerConstraintLayout cornerConstraintLayout, @NonNull AppCompatImageView appCompatImageView, @NonNull AppCompatImageView appCompatImageView2, @NonNull AppCompatImageView appCompatImageView3, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3) {
        this.rootView = constraintLayout;
        this.bg = view;
        this.bgView = cornerConstraintLayout;
        this.ivStructuredMarket = appCompatImageView;
        this.ivStructuredMyFinance = appCompatImageView2;
        this.ivStructuredRecord = appCompatImageView3;
        this.structuredMarket = textView;
        this.structuredMyFinance = textView2;
        this.structuredRecord = textView3;
    }
}