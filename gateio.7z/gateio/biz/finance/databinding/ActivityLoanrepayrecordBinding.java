package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.base.databinding.LayoutHeaderNormalBinding;
import com.gateio.biz.finance.R;
import com.gateio.lib.uikit.state.GateEmptyViewV2;

/* loaded from: classes7.dex */
public final class ActivityLoanrepayrecordBinding implements ViewBinding {

    @NonNull
    public final LayoutHeaderNormalBinding layoutHeader;

    @NonNull
    public final LabelLoanRepayBinding llLoanRepayLabel;

    @NonNull
    public final SwipeRefreshLayout refresh;

    @NonNull
    private final RelativeLayout rootView;

    @NonNull
    public final RecyclerView rvLoanRecords;

    @NonNull
    public final GateEmptyViewV2 tvEmpty;

    @NonNull
    public static ActivityLoanrepayrecordBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ActivityLoanrepayrecordBinding bind(@NonNull View view) {
        int i10 = R.id.layout_header;
        View viewFindChildViewById = ViewBindings.findChildViewById(view, i10);
        if (viewFindChildViewById != null) {
            LayoutHeaderNormalBinding layoutHeaderNormalBindingBind = LayoutHeaderNormalBinding.bind(viewFindChildViewById);
            i10 = R.id.ll_loan_repay_label;
            View viewFindChildViewById2 = ViewBindings.findChildViewById(view, i10);
            if (viewFindChildViewById2 != null) {
                LabelLoanRepayBinding labelLoanRepayBindingBind = LabelLoanRepayBinding.bind(viewFindChildViewById2);
                i10 = R.id.refresh;
                SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) ViewBindings.findChildViewById(view, i10);
                if (swipeRefreshLayout != null) {
                    i10 = R.id.rv_loan_records;
                    RecyclerView recyclerView = (RecyclerView) ViewBindings.findChildViewById(view, i10);
                    if (recyclerView != null) {
                        i10 = R.id.tv_empty;
                        GateEmptyViewV2 gateEmptyViewV2 = (GateEmptyViewV2) ViewBindings.findChildViewById(view, i10);
                        if (gateEmptyViewV2 != null) {
                            return new ActivityLoanrepayrecordBinding((RelativeLayout) view, layoutHeaderNormalBindingBind, labelLoanRepayBindingBind, swipeRefreshLayout, recyclerView, gateEmptyViewV2);
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ActivityLoanrepayrecordBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_loanrepayrecord, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public RelativeLayout getRoot() {
        return this.rootView;
    }

    private ActivityLoanrepayrecordBinding(@NonNull RelativeLayout relativeLayout, @NonNull LayoutHeaderNormalBinding layoutHeaderNormalBinding, @NonNull LabelLoanRepayBinding labelLoanRepayBinding, @NonNull SwipeRefreshLayout swipeRefreshLayout, @NonNull RecyclerView recyclerView, @NonNull GateEmptyViewV2 gateEmptyViewV2) {
        this.rootView = relativeLayout;
        this.layoutHeader = layoutHeaderNormalBinding;
        this.llLoanRepayLabel = labelLoanRepayBinding;
        this.refresh = swipeRefreshLayout;
        this.rvLoanRecords = recyclerView;
        this.tvEmpty = gateEmptyViewV2;
    }
}