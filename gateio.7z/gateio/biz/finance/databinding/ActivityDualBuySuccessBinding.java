package com.gateio.biz.finance.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.gateio.biz.finance.R;
import com.gateio.common.view.GateioTitleView;

/* loaded from: classes7.dex */
public final class ActivityDualBuySuccessBinding implements ViewBinding {

    @NonNull
    private final LinearLayout rootView;

    @NonNull
    public final GateioTitleView titleView;

    @NonNull
    public final TextView tvAmount;

    @NonNull
    public final TextView tvDetail;

    @NonNull
    public final TextView tvId;

    @NonNull
    public final TextView tvList;

    @NonNull
    public final TextView tvTime;

    @NonNull
    public static ActivityDualBuySuccessBinding inflate(@NonNull LayoutInflater layoutInflater) {
        return inflate(layoutInflater, null, false);
    }

    @NonNull
    public static ActivityDualBuySuccessBinding bind(@NonNull View view) {
        int i10 = R.id.title_view;
        GateioTitleView gateioTitleView = (GateioTitleView) ViewBindings.findChildViewById(view, i10);
        if (gateioTitleView != null) {
            i10 = R.id.tv_amount;
            TextView textView = (TextView) ViewBindings.findChildViewById(view, i10);
            if (textView != null) {
                i10 = R.id.tv_detail;
                TextView textView2 = (TextView) ViewBindings.findChildViewById(view, i10);
                if (textView2 != null) {
                    i10 = R.id.tv_id;
                    TextView textView3 = (TextView) ViewBindings.findChildViewById(view, i10);
                    if (textView3 != null) {
                        i10 = R.id.tv_list;
                        TextView textView4 = (TextView) ViewBindings.findChildViewById(view, i10);
                        if (textView4 != null) {
                            i10 = R.id.tv_time;
                            TextView textView5 = (TextView) ViewBindings.findChildViewById(view, i10);
                            if (textView5 != null) {
                                return new ActivityDualBuySuccessBinding((LinearLayout) view, gateioTitleView, textView, textView2, textView3, textView4, textView5);
                            }
                        }
                    }
                }
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(i10)));
    }

    @NonNull
    public static ActivityDualBuySuccessBinding inflate(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, boolean z10) {
        View viewInflate = layoutInflater.inflate(R.layout.activity_dual_buy_success, viewGroup, false);
        if (z10) {
            viewGroup.addView(viewInflate);
        }
        return bind(viewInflate);
    }

    @Override // androidx.viewbinding.ViewBinding
    @NonNull
    public LinearLayout getRoot() {
        return this.rootView;
    }

    private ActivityDualBuySuccessBinding(@NonNull LinearLayout linearLayout, @NonNull GateioTitleView gateioTitleView, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView5) {
        this.rootView = linearLayout;
        this.titleView = gateioTitleView;
        this.tvAmount = textView;
        this.tvDetail = textView2;
        this.tvId = textView3;
        this.tvList = textView4;
        this.tvTime = textView5;
    }
}